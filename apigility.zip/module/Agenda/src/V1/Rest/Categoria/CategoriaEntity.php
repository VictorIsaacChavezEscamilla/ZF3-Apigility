<?php
namespace Agenda\V1\Rest\Categoria;

use ArrayObject;

class CategoriaEntity extends ArrayObject
{
}
