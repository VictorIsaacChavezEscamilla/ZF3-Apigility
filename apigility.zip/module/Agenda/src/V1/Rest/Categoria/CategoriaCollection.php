<?php
namespace Agenda\V1\Rest\Categoria;

use Zend\Paginator\Paginator;

class CategoriaCollection extends Paginator
{
}
