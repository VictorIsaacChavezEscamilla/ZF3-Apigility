<?php
namespace Agenda\V1\Rest\Contacto;

use ArrayObject;

class ContactoEntity extends ArrayObject
{
}
