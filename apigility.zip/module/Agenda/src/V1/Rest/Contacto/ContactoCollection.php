<?php
namespace Agenda\V1\Rest\Contacto;

use Zend\Paginator\Paginator;

class ContactoCollection extends Paginator
{
}
