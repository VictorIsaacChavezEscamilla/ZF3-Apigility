<?php
return [
    'router' => [
        'routes' => [
            'agenda.rest.categoria' => [
                'type' => 'Segment',
                'options' => [
                    'route' => '/categoria[/:categoria_id]',
                    'defaults' => [
                        'controller' => 'Agenda\\V1\\Rest\\Categoria\\Controller',
                    ],
                ],
            ],
            'agenda.rest.contacto' => [
                'type' => 'Segment',
                'options' => [
                    'route' => '/contacto[/:contacto_id]',
                    'defaults' => [
                        'controller' => 'Agenda\\V1\\Rest\\Contacto\\Controller',
                    ],
                ],
            ],
        ],
    ],
    'zf-versioning' => [
        'uri' => [
            0 => 'agenda.rest.categoria',
            1 => 'agenda.rest.contacto',
        ],
    ],
    'zf-rest' => [
        'Agenda\\V1\\Rest\\Categoria\\Controller' => [
            'listener' => 'Agenda\\V1\\Rest\\Categoria\\CategoriaResource',
            'route_name' => 'agenda.rest.categoria',
            'route_identifier_name' => 'categoria_id',
            'collection_name' => 'categoria',
            'entity_http_methods' => [
                0 => 'GET',
                1 => 'PATCH',
                2 => 'PUT',
                3 => 'DELETE',
                4 => 'POST',
            ],
            'collection_http_methods' => [
                0 => 'GET',
                1 => 'POST',
            ],
            'collection_query_whitelist' => [],
            'page_size' => 25,
            'page_size_param' => null,
            'entity_class' => \Agenda\V1\Rest\Categoria\CategoriaEntity::class,
            'collection_class' => \Agenda\V1\Rest\Categoria\CategoriaCollection::class,
            'service_name' => 'categoria',
        ],
        'Agenda\\V1\\Rest\\Contacto\\Controller' => [
            'listener' => 'Agenda\\V1\\Rest\\Contacto\\ContactoResource',
            'route_name' => 'agenda.rest.contacto',
            'route_identifier_name' => 'contacto_id',
            'collection_name' => 'contacto',
            'entity_http_methods' => [
                0 => 'GET',
                1 => 'PATCH',
                2 => 'PUT',
                3 => 'DELETE',
                4 => 'POST',
            ],
            'collection_http_methods' => [
                0 => 'GET',
                1 => 'POST',
            ],
            'collection_query_whitelist' => [],
            'page_size' => 25,
            'page_size_param' => null,
            'entity_class' => \Agenda\V1\Rest\Contacto\ContactoEntity::class,
            'collection_class' => \Agenda\V1\Rest\Contacto\ContactoCollection::class,
            'service_name' => 'contacto',
        ],
    ],
    'zf-content-negotiation' => [
        'controllers' => [
            'Agenda\\V1\\Rest\\Categoria\\Controller' => 'Json',
            'Agenda\\V1\\Rest\\Contacto\\Controller' => 'Json',
        ],
        'accept_whitelist' => [
            'Agenda\\V1\\Rest\\Categoria\\Controller' => [
                0 => 'application/vnd.agenda.v1+json',
                1 => 'application/hal+json',
                2 => 'application/json',
            ],
            'Agenda\\V1\\Rest\\Contacto\\Controller' => [
                0 => 'application/vnd.agenda.v1+json',
                1 => 'application/hal+json',
                2 => 'application/json',
            ],
        ],
        'content_type_whitelist' => [
            'Agenda\\V1\\Rest\\Categoria\\Controller' => [
                0 => 'application/vnd.agenda.v1+json',
                1 => 'application/json',
                2 => 'application/x-www-form-urlencoded',
                3 => 'multipart/form-data',
            ],
            'Agenda\\V1\\Rest\\Contacto\\Controller' => [
                0 => 'application/vnd.agenda.v1+json',
                1 => 'application/json',
                2 => 'application/x-www-form-urlencoded',
                3 => 'multipart/form-data',
            ],
        ],
    ],
    'zf-hal' => [
        'metadata_map' => [
            \Agenda\V1\Rest\Categoria\CategoriaEntity::class => [
                'entity_identifier_name' => 'idCategoria',
                'route_name' => 'agenda.rest.categoria',
                'route_identifier_name' => 'categoria_id',
                'hydrator' => \Zend\Hydrator\ArraySerializable::class,
            ],
            \Agenda\V1\Rest\Categoria\CategoriaCollection::class => [
                'entity_identifier_name' => 'idCategoria',
                'route_name' => 'agenda.rest.categoria',
                'route_identifier_name' => 'categoria_id',
                'is_collection' => true,
            ],
            \Agenda\V1\Rest\Contacto\ContactoEntity::class => [
                'entity_identifier_name' => 'idContacto',
                'route_name' => 'agenda.rest.contacto',
                'route_identifier_name' => 'contacto_id',
                'hydrator' => \Zend\Hydrator\ArraySerializable::class,
            ],
            \Agenda\V1\Rest\Contacto\ContactoCollection::class => [
                'entity_identifier_name' => 'idContacto',
                'route_name' => 'agenda.rest.contacto',
                'route_identifier_name' => 'contacto_id',
                'is_collection' => true,
            ],
        ],
    ],
    'zf-apigility' => [
        'db-connected' => [
            'Agenda\\V1\\Rest\\Categoria\\CategoriaResource' => [
                'adapter_name' => 'DB_Agenda',
                'table_name' => 'categoria',
                'hydrator_name' => \Zend\Hydrator\ArraySerializable::class,
                'controller_service_name' => 'Agenda\\V1\\Rest\\Categoria\\Controller',
                'entity_identifier_name' => 'idCategoria',
                'table_service' => 'Agenda\\V1\\Rest\\Categoria\\CategoriaResource\\Table',
            ],
            'Agenda\\V1\\Rest\\Contacto\\ContactoResource' => [
                'adapter_name' => 'DB_Agenda',
                'table_name' => 'contacto',
                'hydrator_name' => \Zend\Hydrator\ArraySerializable::class,
                'controller_service_name' => 'Agenda\\V1\\Rest\\Contacto\\Controller',
                'entity_identifier_name' => 'idContacto',
                'table_service' => 'Agenda\\V1\\Rest\\Contacto\\ContactoResource\\Table',
            ],
        ],
    ],
    'zf-content-validation' => [
        'Agenda\\V1\\Rest\\Categoria\\Controller' => [
            'input_filter' => 'Agenda\\V1\\Rest\\Categoria\\Validator',
        ],
        'Agenda\\V1\\Rest\\Contacto\\Controller' => [
            'input_filter' => 'Agenda\\V1\\Rest\\Contacto\\Validator',
        ],
    ],
    'input_filter_specs' => [
        'Agenda\\V1\\Rest\\Categoria\\Validator' => [
            0 => [
                'name' => 'idCategoria',
                'required' => true,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\Digits::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => 'ZF\\ContentValidation\\Validator\\DbNoRecordExists',
                        'options' => [
                            'adapter' => 'DB_Agenda',
                            'table' => 'categoria',
                            'field' => 'idCategoria',
                        ],
                    ],
                ],
            ],
            1 => [
                'name' => 'nombre',
                'required' => true,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => '10',
                            'max' => '60',
                        ],
                    ],
                ],
            ],
            2 => [
                'name' => 'descripcion',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'max' => '200',
                        ],
                    ],
                ],
            ],
        ],
        'Agenda\\V1\\Rest\\Contacto\\Validator' => [
            0 => [
                'name' => 'idContacto',
                'required' => true,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\Digits::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => 'ZF\\ContentValidation\\Validator\\DbNoRecordExists',
                        'options' => [
                            'adapter' => 'DB_Agenda',
                            'table' => 'contacto',
                            'field' => 'idContacto',
                        ],
                    ],
                ],
            ],
            1 => [
                'name' => 'nombre',
                'required' => true,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => 1,
                            'max' => '400',
                        ],
                    ],
                ],
            ],
            2 => [
                'name' => 'telefono',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => 1,
                            'max' => '32',
                        ],
                    ],
                ],
            ],
            3 => [
                'name' => 'correo',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => 1,
                            'max' => '255',
                        ],
                    ],
                    1 => [
                        'name' => \Zend\Validator\EmailAddress::class,
                        'options' => [],
                    ],
                ],
            ],
            4 => [
                'name' => 'idCategoria',
                'required' => true,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\Digits::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => 'ZF\\ContentValidation\\Validator\\DbRecordExists',
                        'options' => [
                            'adapter' => 'DB_Agenda',
                            'table' => 'categoria',
                            'field' => 'idCategoria',
                        ],
                    ],
                ],
            ],
        ],
    ],
];
