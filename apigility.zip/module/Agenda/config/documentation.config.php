<?php
return [
    'Agenda\\V1\\Rest\\Contacto\\Controller' => [
        'collection' => [
            'GET' => [
                'response' => '{
   "_links": {
       "self": {
           "href": "/contacto"
       },
       "first": {
           "href": "/contacto?page={page}"
       },
       "prev": {
           "href": "/contacto?page={page}"
       },
       "next": {
           "href": "/contacto?page={page}"
       },
       "last": {
           "href": "/contacto?page={page}"
       }
   }
   "_embedded": {
       "contacto": [
           {
               "_links": {
                   "self": {
                       "href": "/contacto[/:contacto_id]"
                   }
               }
              "idContacto": "",
              "nombre": "",
              "telefono": "",
              "correo": "",
              "idCategoria": ""
           }
       ]
   }
}',
            ],
            'POST' => [
                'request' => '{
   "idContacto": "",
   "nombre": "",
   "telefono": "",
   "correo": "",
   "idCategoria": ""
}',
                'response' => '{
   "_links": {
       "self": {
           "href": "/contacto[/:contacto_id]"
       }
   }
   "idContacto": "",
   "nombre": "",
   "telefono": "",
   "correo": "",
   "idCategoria": ""
}',
            ],
        ],
        'entity' => [
            'GET' => [
                'response' => '{
   "_links": {
       "self": {
           "href": "/contacto[/:contacto_id]"
       }
   }
   "idContacto": "",
   "nombre": "",
   "telefono": "",
   "correo": "",
   "idCategoria": ""
}',
            ],
            'PATCH' => [
                'request' => '{
   "idContacto": "",
   "nombre": "",
   "telefono": "",
   "correo": "",
   "idCategoria": ""
}',
                'response' => '{
   "_links": {
       "self": {
           "href": "/contacto[/:contacto_id]"
       }
   }
   "idContacto": "",
   "nombre": "",
   "telefono": "",
   "correo": "",
   "idCategoria": ""
}',
            ],
            'PUT' => [
                'request' => '{
   "idContacto": "",
   "nombre": "",
   "telefono": "",
   "correo": "",
   "idCategoria": ""
}',
                'response' => '{
   "_links": {
       "self": {
           "href": "/contacto[/:contacto_id]"
       }
   }
   "idContacto": "",
   "nombre": "",
   "telefono": "",
   "correo": "",
   "idCategoria": ""
}',
            ],
            'DELETE' => [
                'request' => '{
   "idContacto": "",
   "nombre": "",
   "telefono": "",
   "correo": "",
   "idCategoria": ""
}',
                'response' => '{
   "_links": {
       "self": {
           "href": "/contacto[/:contacto_id]"
       }
   }
   "idContacto": "",
   "nombre": "",
   "telefono": "",
   "correo": "",
   "idCategoria": ""
}',
            ],
            'POST' => [
                'request' => '{
   "idContacto": "",
   "nombre": "",
   "telefono": "",
   "correo": "",
   "idCategoria": ""
}',
                'response' => '{
   "_links": {
       "self": {
           "href": "/contacto[/:contacto_id]"
       }
   }
   "idContacto": "",
   "nombre": "",
   "telefono": "",
   "correo": "",
   "idCategoria": ""
}',
            ],
        ],
    ],
];
