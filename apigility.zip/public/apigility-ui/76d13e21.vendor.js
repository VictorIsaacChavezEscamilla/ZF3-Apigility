! function(a, b) {
    "object" == typeof module && "object" == typeof module.exports ? module.exports = a.document ? b(a, !0) : function(a) {
        if (!a.document) throw new Error("jQuery requires a window with a document");
        return b(a)
    } : b(a)
}("undefined" != typeof window ? window : this, function(a, b) {
    function c(a) {
        var b = "length" in a && a.length,
            c = _.type(a);
        return "function" === c || _.isWindow(a) ? !1 : 1 === a.nodeType && b ? !0 : "array" === c || 0 === b || "number" == typeof b && b > 0 && b - 1 in a
    }

    function d(a, b, c) {
        if (_.isFunction(b)) return _.grep(a, function(a, d) {
            return !!b.call(a, d, a) !== c
        });
        if (b.nodeType) return _.grep(a, function(a) {
            return a === b !== c
        });
        if ("string" == typeof b) {
            if (ha.test(b)) return _.filter(b, a, c);
            b = _.filter(b, a)
        }
        return _.grep(a, function(a) {
            return U.call(b, a) >= 0 !== c
        })
    }

    function e(a, b) {
        for (;
            (a = a[b]) && 1 !== a.nodeType;);
        return a
    }

    function f(a) {
        var b = oa[a] = {};
        return _.each(a.match(na) || [], function(a, c) {
            b[c] = !0
        }), b
    }

    function g() {
        Z.removeEventListener("DOMContentLoaded", g, !1), a.removeEventListener("load", g, !1), _.ready()
    }

    function h() {
        Object.defineProperty(this.cache = {}, 0, {
            get: function() {
                return {}
            }
        }), this.expando = _.expando + h.uid++
    }

    function i(a, b, c) {
        var d;
        if (void 0 === c && 1 === a.nodeType)
            if (d = "data-" + b.replace(ua, "-$1").toLowerCase(), c = a.getAttribute(d), "string" == typeof c) {
                try {
                    c = "true" === c ? !0 : "false" === c ? !1 : "null" === c ? null : +c + "" === c ? +c : ta.test(c) ? _.parseJSON(c) : c
                } catch (e) {}
                sa.set(a, b, c)
            } else c = void 0;
        return c
    }

    function j() {
        return !0
    }

    function k() {
        return !1
    }

    function l() {
        try {
            return Z.activeElement
        } catch (a) {}
    }

    function m(a, b) {
        return _.nodeName(a, "table") && _.nodeName(11 !== b.nodeType ? b : b.firstChild, "tr") ? a.getElementsByTagName("tbody")[0] || a.appendChild(a.ownerDocument.createElement("tbody")) : a
    }

    function n(a) {
        return a.type = (null !== a.getAttribute("type")) + "/" + a.type, a
    }

    function o(a) {
        var b = Ka.exec(a.type);
        return b ? a.type = b[1] : a.removeAttribute("type"), a
    }

    function p(a, b) {
        for (var c = 0, d = a.length; d > c; c++) ra.set(a[c], "globalEval", !b || ra.get(b[c], "globalEval"))
    }

    function q(a, b) {
        var c, d, e, f, g, h, i, j;
        if (1 === b.nodeType) {
            if (ra.hasData(a) && (f = ra.access(a), g = ra.set(b, f), j = f.events)) {
                delete g.handle, g.events = {};
                for (e in j)
                    for (c = 0, d = j[e].length; d > c; c++) _.event.add(b, e, j[e][c])
            }
            sa.hasData(a) && (h = sa.access(a), i = _.extend({}, h), sa.set(b, i))
        }
    }

    function r(a, b) {
        var c = a.getElementsByTagName ? a.getElementsByTagName(b || "*") : a.querySelectorAll ? a.querySelectorAll(b || "*") : [];
        return void 0 === b || b && _.nodeName(a, b) ? _.merge([a], c) : c
    }

    function s(a, b) {
        var c = b.nodeName.toLowerCase();
        "input" === c && ya.test(a.type) ? b.checked = a.checked : ("input" === c || "textarea" === c) && (b.defaultValue = a.defaultValue)
    }

    function t(b, c) {
        var d, e = _(c.createElement(b)).appendTo(c.body),
            f = a.getDefaultComputedStyle && (d = a.getDefaultComputedStyle(e[0])) ? d.display : _.css(e[0], "display");
        return e.detach(), f
    }

    function u(a) {
        var b = Z,
            c = Oa[a];
        return c || (c = t(a, b), "none" !== c && c || (Na = (Na || _("<iframe frameborder='0' width='0' height='0'/>")).appendTo(b.documentElement), b = Na[0].contentDocument, b.write(), b.close(), c = t(a, b), Na.detach()), Oa[a] = c), c
    }

    function v(a, b, c) {
        var d, e, f, g, h = a.style;
        return c = c || Ra(a), c && (g = c.getPropertyValue(b) || c[b]), c && ("" !== g || _.contains(a.ownerDocument, a) || (g = _.style(a, b)), Qa.test(g) && Pa.test(b) && (d = h.width, e = h.minWidth, f = h.maxWidth, h.minWidth = h.maxWidth = h.width = g, g = c.width, h.width = d, h.minWidth = e, h.maxWidth = f)), void 0 !== g ? g + "" : g
    }

    function w(a, b) {
        return {
            get: function() {
                return a() ? void delete this.get : (this.get = b).apply(this, arguments)
            }
        }
    }

    function x(a, b) {
        if (b in a) return b;
        for (var c = b[0].toUpperCase() + b.slice(1), d = b, e = Xa.length; e--;)
            if (b = Xa[e] + c, b in a) return b;
        return d
    }

    function y(a, b, c) {
        var d = Ta.exec(b);
        return d ? Math.max(0, d[1] - (c || 0)) + (d[2] || "px") : b
    }

    function z(a, b, c, d, e) {
        for (var f = c === (d ? "border" : "content") ? 4 : "width" === b ? 1 : 0, g = 0; 4 > f; f += 2) "margin" === c && (g += _.css(a, c + wa[f], !0, e)), d ? ("content" === c && (g -= _.css(a, "padding" + wa[f], !0, e)), "margin" !== c && (g -= _.css(a, "border" + wa[f] + "Width", !0, e))) : (g += _.css(a, "padding" + wa[f], !0, e), "padding" !== c && (g += _.css(a, "border" + wa[f] + "Width", !0, e)));
        return g
    }

    function A(a, b, c) {
        var d = !0,
            e = "width" === b ? a.offsetWidth : a.offsetHeight,
            f = Ra(a),
            g = "border-box" === _.css(a, "boxSizing", !1, f);
        if (0 >= e || null == e) {
            if (e = v(a, b, f), (0 > e || null == e) && (e = a.style[b]), Qa.test(e)) return e;
            d = g && (Y.boxSizingReliable() || e === a.style[b]), e = parseFloat(e) || 0
        }
        return e + z(a, b, c || (g ? "border" : "content"), d, f) + "px"
    }

    function B(a, b) {
        for (var c, d, e, f = [], g = 0, h = a.length; h > g; g++) d = a[g], d.style && (f[g] = ra.get(d, "olddisplay"), c = d.style.display, b ? (f[g] || "none" !== c || (d.style.display = ""), "" === d.style.display && xa(d) && (f[g] = ra.access(d, "olddisplay", u(d.nodeName)))) : (e = xa(d), "none" === c && e || ra.set(d, "olddisplay", e ? c : _.css(d, "display"))));
        for (g = 0; h > g; g++) d = a[g], d.style && (b && "none" !== d.style.display && "" !== d.style.display || (d.style.display = b ? f[g] || "" : "none"));
        return a
    }

    function C(a, b, c, d, e) {
        return new C.prototype.init(a, b, c, d, e)
    }

    function D() {
        return setTimeout(function() {
            Ya = void 0
        }), Ya = _.now()
    }

    function E(a, b) {
        var c, d = 0,
            e = {
                height: a
            };
        for (b = b ? 1 : 0; 4 > d; d += 2 - b) c = wa[d], e["margin" + c] = e["padding" + c] = a;
        return b && (e.opacity = e.width = a), e
    }

    function F(a, b, c) {
        for (var d, e = (cb[b] || []).concat(cb["*"]), f = 0, g = e.length; g > f; f++)
            if (d = e[f].call(c, b, a)) return d
    }

    function G(a, b, c) {
        var d, e, f, g, h, i, j, k, l = this,
            m = {},
            n = a.style,
            o = a.nodeType && xa(a),
            p = ra.get(a, "fxshow");
        c.queue || (h = _._queueHooks(a, "fx"), null == h.unqueued && (h.unqueued = 0, i = h.empty.fire, h.empty.fire = function() {
            h.unqueued || i()
        }), h.unqueued++, l.always(function() {
            l.always(function() {
                h.unqueued--, _.queue(a, "fx").length || h.empty.fire()
            })
        })), 1 === a.nodeType && ("height" in b || "width" in b) && (c.overflow = [n.overflow, n.overflowX, n.overflowY], j = _.css(a, "display"), k = "none" === j ? ra.get(a, "olddisplay") || u(a.nodeName) : j, "inline" === k && "none" === _.css(a, "float") && (n.display = "inline-block")), c.overflow && (n.overflow = "hidden", l.always(function() {
            n.overflow = c.overflow[0], n.overflowX = c.overflow[1], n.overflowY = c.overflow[2]
        }));
        for (d in b)
            if (e = b[d], $a.exec(e)) {
                if (delete b[d], f = f || "toggle" === e, e === (o ? "hide" : "show")) {
                    if ("show" !== e || !p || void 0 === p[d]) continue;
                    o = !0
                }
                m[d] = p && p[d] || _.style(a, d)
            } else j = void 0;
        if (_.isEmptyObject(m)) "inline" === ("none" === j ? u(a.nodeName) : j) && (n.display = j);
        else {
            p ? "hidden" in p && (o = p.hidden) : p = ra.access(a, "fxshow", {}), f && (p.hidden = !o), o ? _(a).show() : l.done(function() {
                _(a).hide()
            }), l.done(function() {
                var b;
                ra.remove(a, "fxshow");
                for (b in m) _.style(a, b, m[b])
            });
            for (d in m) g = F(o ? p[d] : 0, d, l), d in p || (p[d] = g.start, o && (g.end = g.start, g.start = "width" === d || "height" === d ? 1 : 0))
        }
    }

    function H(a, b) {
        var c, d, e, f, g;
        for (c in a)
            if (d = _.camelCase(c), e = b[d], f = a[c], _.isArray(f) && (e = f[1], f = a[c] = f[0]), c !== d && (a[d] = f, delete a[c]), g = _.cssHooks[d], g && "expand" in g) {
                f = g.expand(f), delete a[d];
                for (c in f) c in a || (a[c] = f[c], b[c] = e)
            } else b[d] = e
    }

    function I(a, b, c) {
        var d, e, f = 0,
            g = bb.length,
            h = _.Deferred().always(function() {
                delete i.elem
            }),
            i = function() {
                if (e) return !1;
                for (var b = Ya || D(), c = Math.max(0, j.startTime + j.duration - b), d = c / j.duration || 0, f = 1 - d, g = 0, i = j.tweens.length; i > g; g++) j.tweens[g].run(f);
                return h.notifyWith(a, [j, f, c]), 1 > f && i ? c : (h.resolveWith(a, [j]), !1)
            },
            j = h.promise({
                elem: a,
                props: _.extend({}, b),
                opts: _.extend(!0, {
                    specialEasing: {}
                }, c),
                originalProperties: b,
                originalOptions: c,
                startTime: Ya || D(),
                duration: c.duration,
                tweens: [],
                createTween: function(b, c) {
                    var d = _.Tween(a, j.opts, b, c, j.opts.specialEasing[b] || j.opts.easing);
                    return j.tweens.push(d), d
                },
                stop: function(b) {
                    var c = 0,
                        d = b ? j.tweens.length : 0;
                    if (e) return this;
                    for (e = !0; d > c; c++) j.tweens[c].run(1);
                    return b ? h.resolveWith(a, [j, b]) : h.rejectWith(a, [j, b]), this
                }
            }),
            k = j.props;
        for (H(k, j.opts.specialEasing); g > f; f++)
            if (d = bb[f].call(j, a, k, j.opts)) return d;
        return _.map(k, F, j), _.isFunction(j.opts.start) && j.opts.start.call(a, j), _.fx.timer(_.extend(i, {
            elem: a,
            anim: j,
            queue: j.opts.queue
        })), j.progress(j.opts.progress).done(j.opts.done, j.opts.complete).fail(j.opts.fail).always(j.opts.always)
    }

    function J(a) {
        return function(b, c) {
            "string" != typeof b && (c = b, b = "*");
            var d, e = 0,
                f = b.toLowerCase().match(na) || [];
            if (_.isFunction(c))
                for (; d = f[e++];) "+" === d[0] ? (d = d.slice(1) || "*", (a[d] = a[d] || []).unshift(c)) : (a[d] = a[d] || []).push(c)
        }
    }

    function K(a, b, c, d) {
        function e(h) {
            var i;
            return f[h] = !0, _.each(a[h] || [], function(a, h) {
                var j = h(b, c, d);
                return "string" != typeof j || g || f[j] ? g ? !(i = j) : void 0 : (b.dataTypes.unshift(j), e(j), !1)
            }), i
        }
        var f = {},
            g = a === tb;
        return e(b.dataTypes[0]) || !f["*"] && e("*")
    }

    function L(a, b) {
        var c, d, e = _.ajaxSettings.flatOptions || {};
        for (c in b) void 0 !== b[c] && ((e[c] ? a : d || (d = {}))[c] = b[c]);
        return d && _.extend(!0, a, d), a
    }

    function M(a, b, c) {
        for (var d, e, f, g, h = a.contents, i = a.dataTypes;
            "*" === i[0];) i.shift(), void 0 === d && (d = a.mimeType || b.getResponseHeader("Content-Type"));
        if (d)
            for (e in h)
                if (h[e] && h[e].test(d)) {
                    i.unshift(e);
                    break
                }
        if (i[0] in c) f = i[0];
        else {
            for (e in c) {
                if (!i[0] || a.converters[e + " " + i[0]]) {
                    f = e;
                    break
                }
                g || (g = e)
            }
            f = f || g
        }
        return f ? (f !== i[0] && i.unshift(f), c[f]) : void 0
    }

    function N(a, b, c, d) {
        var e, f, g, h, i, j = {},
            k = a.dataTypes.slice();
        if (k[1])
            for (g in a.converters) j[g.toLowerCase()] = a.converters[g];
        for (f = k.shift(); f;)
            if (a.responseFields[f] && (c[a.responseFields[f]] = b), !i && d && a.dataFilter && (b = a.dataFilter(b, a.dataType)), i = f, f = k.shift())
                if ("*" === f) f = i;
                else if ("*" !== i && i !== f) {
            if (g = j[i + " " + f] || j["* " + f], !g)
                for (e in j)
                    if (h = e.split(" "), h[1] === f && (g = j[i + " " + h[0]] || j["* " + h[0]])) {
                        g === !0 ? g = j[e] : j[e] !== !0 && (f = h[0], k.unshift(h[1]));
                        break
                    }
            if (g !== !0)
                if (g && a["throws"]) b = g(b);
                else try {
                    b = g(b)
                } catch (l) {
                    return {
                        state: "parsererror",
                        error: g ? l : "No conversion from " + i + " to " + f
                    }
                }
        }
        return {
            state: "success",
            data: b
        }
    }

    function O(a, b, c, d) {
        var e;
        if (_.isArray(b)) _.each(b, function(b, e) {
            c || yb.test(a) ? d(a, e) : O(a + "[" + ("object" == typeof e ? b : "") + "]", e, c, d)
        });
        else if (c || "object" !== _.type(b)) d(a, b);
        else
            for (e in b) O(a + "[" + e + "]", b[e], c, d)
    }

    function P(a) {
        return _.isWindow(a) ? a : 9 === a.nodeType && a.defaultView
    }
    var Q = [],
        R = Q.slice,
        S = Q.concat,
        T = Q.push,
        U = Q.indexOf,
        V = {},
        W = V.toString,
        X = V.hasOwnProperty,
        Y = {},
        Z = a.document,
        $ = "2.1.4",
        _ = function(a, b) {
            return new _.fn.init(a, b)
        },
        aa = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g,
        ba = /^-ms-/,
        ca = /-([\da-z])/gi,
        da = function(a, b) {
            return b.toUpperCase()
        };
    _.fn = _.prototype = {
        jquery: $,
        constructor: _,
        selector: "",
        length: 0,
        toArray: function() {
            return R.call(this)
        },
        get: function(a) {
            return null != a ? 0 > a ? this[a + this.length] : this[a] : R.call(this)
        },
        pushStack: function(a) {
            var b = _.merge(this.constructor(), a);
            return b.prevObject = this, b.context = this.context, b
        },
        each: function(a, b) {
            return _.each(this, a, b)
        },
        map: function(a) {
            return this.pushStack(_.map(this, function(b, c) {
                return a.call(b, c, b)
            }))
        },
        slice: function() {
            return this.pushStack(R.apply(this, arguments))
        },
        first: function() {
            return this.eq(0)
        },
        last: function() {
            return this.eq(-1)
        },
        eq: function(a) {
            var b = this.length,
                c = +a + (0 > a ? b : 0);
            return this.pushStack(c >= 0 && b > c ? [this[c]] : [])
        },
        end: function() {
            return this.prevObject || this.constructor(null)
        },
        push: T,
        sort: Q.sort,
        splice: Q.splice
    }, _.extend = _.fn.extend = function() {
        var a, b, c, d, e, f, g = arguments[0] || {},
            h = 1,
            i = arguments.length,
            j = !1;
        for ("boolean" == typeof g && (j = g, g = arguments[h] || {}, h++), "object" == typeof g || _.isFunction(g) || (g = {}), h === i && (g = this, h--); i > h; h++)
            if (null != (a = arguments[h]))
                for (b in a) c = g[b], d = a[b], g !== d && (j && d && (_.isPlainObject(d) || (e = _.isArray(d))) ? (e ? (e = !1, f = c && _.isArray(c) ? c : []) : f = c && _.isPlainObject(c) ? c : {}, g[b] = _.extend(j, f, d)) : void 0 !== d && (g[b] = d));
        return g
    }, _.extend({
        expando: "jQuery" + ($ + Math.random()).replace(/\D/g, ""),
        isReady: !0,
        error: function(a) {
            throw new Error(a)
        },
        noop: function() {},
        isFunction: function(a) {
            return "function" === _.type(a)
        },
        isArray: Array.isArray,
        isWindow: function(a) {
            return null != a && a === a.window
        },
        isNumeric: function(a) {
            return !_.isArray(a) && a - parseFloat(a) + 1 >= 0
        },
        isPlainObject: function(a) {
            return "object" !== _.type(a) || a.nodeType || _.isWindow(a) ? !1 : a.constructor && !X.call(a.constructor.prototype, "isPrototypeOf") ? !1 : !0
        },
        isEmptyObject: function(a) {
            var b;
            for (b in a) return !1;
            return !0
        },
        type: function(a) {
            return null == a ? a + "" : "object" == typeof a || "function" == typeof a ? V[W.call(a)] || "object" : typeof a
        },
        globalEval: function(a) {
            var b, c = eval;
            a = _.trim(a), a && (1 === a.indexOf("use strict") ? (b = Z.createElement("script"), b.text = a, Z.head.appendChild(b).parentNode.removeChild(b)) : c(a))
        },
        camelCase: function(a) {
            return a.replace(ba, "ms-").replace(ca, da)
        },
        nodeName: function(a, b) {
            return a.nodeName && a.nodeName.toLowerCase() === b.toLowerCase()
        },
        each: function(a, b, d) {
            var e, f = 0,
                g = a.length,
                h = c(a);
            if (d) {
                if (h)
                    for (; g > f && (e = b.apply(a[f], d), e !== !1); f++);
                else
                    for (f in a)
                        if (e = b.apply(a[f], d), e === !1) break
            } else if (h)
                for (; g > f && (e = b.call(a[f], f, a[f]), e !== !1); f++);
            else
                for (f in a)
                    if (e = b.call(a[f], f, a[f]), e === !1) break;
            return a
        },
        trim: function(a) {
            return null == a ? "" : (a + "").replace(aa, "")
        },
        makeArray: function(a, b) {
            var d = b || [];
            return null != a && (c(Object(a)) ? _.merge(d, "string" == typeof a ? [a] : a) : T.call(d, a)), d
        },
        inArray: function(a, b, c) {
            return null == b ? -1 : U.call(b, a, c)
        },
        merge: function(a, b) {
            for (var c = +b.length, d = 0, e = a.length; c > d; d++) a[e++] = b[d];
            return a.length = e, a
        },
        grep: function(a, b, c) {
            for (var d, e = [], f = 0, g = a.length, h = !c; g > f; f++) d = !b(a[f], f), d !== h && e.push(a[f]);
            return e
        },
        map: function(a, b, d) {
            var e, f = 0,
                g = a.length,
                h = c(a),
                i = [];
            if (h)
                for (; g > f; f++) e = b(a[f], f, d), null != e && i.push(e);
            else
                for (f in a) e = b(a[f], f, d), null != e && i.push(e);
            return S.apply([], i)
        },
        guid: 1,
        proxy: function(a, b) {
            var c, d, e;
            return "string" == typeof b && (c = a[b], b = a, a = c), _.isFunction(a) ? (d = R.call(arguments, 2), e = function() {
                return a.apply(b || this, d.concat(R.call(arguments)))
            }, e.guid = a.guid = a.guid || _.guid++, e) : void 0
        },
        now: Date.now,
        support: Y
    }), _.each("Boolean Number String Function Array Date RegExp Object Error".split(" "), function(a, b) {
        V["[object " + b + "]"] = b.toLowerCase()
    });
    var ea = function(a) {
        function b(a, b, c, d) {
            var e, f, g, h, i, j, l, n, o, p;
            if ((b ? b.ownerDocument || b : O) !== G && F(b), b = b || G, c = c || [], h = b.nodeType, "string" != typeof a || !a || 1 !== h && 9 !== h && 11 !== h) return c;
            if (!d && I) {
                if (11 !== h && (e = sa.exec(a)))
                    if (g = e[1]) {
                        if (9 === h) {
                            if (f = b.getElementById(g), !f || !f.parentNode) return c;
                            if (f.id === g) return c.push(f), c
                        } else if (b.ownerDocument && (f = b.ownerDocument.getElementById(g)) && M(b, f) && f.id === g) return c.push(f), c
                    } else {
                        if (e[2]) return $.apply(c, b.getElementsByTagName(a)), c;
                        if ((g = e[3]) && v.getElementsByClassName) return $.apply(c, b.getElementsByClassName(g)), c
                    }
                if (v.qsa && (!J || !J.test(a))) {
                    if (n = l = N, o = b, p = 1 !== h && a, 1 === h && "object" !== b.nodeName.toLowerCase()) {
                        for (j = z(a), (l = b.getAttribute("id")) ? n = l.replace(ua, "\\$&") : b.setAttribute("id", n), n = "[id='" + n + "'] ", i = j.length; i--;) j[i] = n + m(j[i]);
                        o = ta.test(a) && k(b.parentNode) || b, p = j.join(",")
                    }
                    if (p) try {
                        return $.apply(c, o.querySelectorAll(p)), c
                    } catch (q) {} finally {
                        l || b.removeAttribute("id")
                    }
                }
            }
            return B(a.replace(ia, "$1"), b, c, d)
        }

        function c() {
            function a(c, d) {
                return b.push(c + " ") > w.cacheLength && delete a[b.shift()], a[c + " "] = d
            }
            var b = [];
            return a
        }

        function d(a) {
            return a[N] = !0, a
        }

        function e(a) {
            var b = G.createElement("div");
            try {
                return !!a(b)
            } catch (c) {
                return !1
            } finally {
                b.parentNode && b.parentNode.removeChild(b), b = null
            }
        }

        function f(a, b) {
            for (var c = a.split("|"), d = a.length; d--;) w.attrHandle[c[d]] = b
        }

        function g(a, b) {
            var c = b && a,
                d = c && 1 === a.nodeType && 1 === b.nodeType && (~b.sourceIndex || V) - (~a.sourceIndex || V);
            if (d) return d;
            if (c)
                for (; c = c.nextSibling;)
                    if (c === b) return -1;
            return a ? 1 : -1
        }

        function h(a) {
            return function(b) {
                var c = b.nodeName.toLowerCase();
                return "input" === c && b.type === a
            }
        }

        function i(a) {
            return function(b) {
                var c = b.nodeName.toLowerCase();
                return ("input" === c || "button" === c) && b.type === a
            }
        }

        function j(a) {
            return d(function(b) {
                return b = +b, d(function(c, d) {
                    for (var e, f = a([], c.length, b), g = f.length; g--;) c[e = f[g]] && (c[e] = !(d[e] = c[e]))
                })
            })
        }

        function k(a) {
            return a && "undefined" != typeof a.getElementsByTagName && a
        }

        function l() {}

        function m(a) {
            for (var b = 0, c = a.length, d = ""; c > b; b++) d += a[b].value;
            return d
        }

        function n(a, b, c) {
            var d = b.dir,
                e = c && "parentNode" === d,
                f = Q++;
            return b.first ? function(b, c, f) {
                for (; b = b[d];)
                    if (1 === b.nodeType || e) return a(b, c, f)
            } : function(b, c, g) {
                var h, i, j = [P, f];
                if (g) {
                    for (; b = b[d];)
                        if ((1 === b.nodeType || e) && a(b, c, g)) return !0
                } else
                    for (; b = b[d];)
                        if (1 === b.nodeType || e) {
                            if (i = b[N] || (b[N] = {}), (h = i[d]) && h[0] === P && h[1] === f) return j[2] = h[2];
                            if (i[d] = j, j[2] = a(b, c, g)) return !0
                        }
            }
        }

        function o(a) {
            return a.length > 1 ? function(b, c, d) {
                for (var e = a.length; e--;)
                    if (!a[e](b, c, d)) return !1;
                return !0
            } : a[0]
        }

        function p(a, c, d) {
            for (var e = 0, f = c.length; f > e; e++) b(a, c[e], d);
            return d
        }

        function q(a, b, c, d, e) {
            for (var f, g = [], h = 0, i = a.length, j = null != b; i > h; h++)(f = a[h]) && (!c || c(f, d, e)) && (g.push(f), j && b.push(h));
            return g
        }

        function r(a, b, c, e, f, g) {
            return e && !e[N] && (e = r(e)), f && !f[N] && (f = r(f, g)), d(function(d, g, h, i) {
                var j, k, l, m = [],
                    n = [],
                    o = g.length,
                    r = d || p(b || "*", h.nodeType ? [h] : h, []),
                    s = !a || !d && b ? r : q(r, m, a, h, i),
                    t = c ? f || (d ? a : o || e) ? [] : g : s;
                if (c && c(s, t, h, i), e)
                    for (j = q(t, n), e(j, [], h, i), k = j.length; k--;)(l = j[k]) && (t[n[k]] = !(s[n[k]] = l));
                if (d) {
                    if (f || a) {
                        if (f) {
                            for (j = [], k = t.length; k--;)(l = t[k]) && j.push(s[k] = l);
                            f(null, t = [], j, i)
                        }
                        for (k = t.length; k--;)(l = t[k]) && (j = f ? aa(d, l) : m[k]) > -1 && (d[j] = !(g[j] = l))
                    }
                } else t = q(t === g ? t.splice(o, t.length) : t), f ? f(null, g, t, i) : $.apply(g, t)
            })
        }

        function s(a) {
            for (var b, c, d, e = a.length, f = w.relative[a[0].type], g = f || w.relative[" "], h = f ? 1 : 0, i = n(function(a) {
                    return a === b
                }, g, !0), j = n(function(a) {
                    return aa(b, a) > -1
                }, g, !0), k = [function(a, c, d) {
                    var e = !f && (d || c !== C) || ((b = c).nodeType ? i(a, c, d) : j(a, c, d));
                    return b = null, e
                }]; e > h; h++)
                if (c = w.relative[a[h].type]) k = [n(o(k), c)];
                else {
                    if (c = w.filter[a[h].type].apply(null, a[h].matches), c[N]) {
                        for (d = ++h; e > d && !w.relative[a[d].type]; d++);
                        return r(h > 1 && o(k), h > 1 && m(a.slice(0, h - 1).concat({
                            value: " " === a[h - 2].type ? "*" : ""
                        })).replace(ia, "$1"), c, d > h && s(a.slice(h, d)), e > d && s(a = a.slice(d)), e > d && m(a))
                    }
                    k.push(c)
                }
            return o(k)
        }

        function t(a, c) {
            var e = c.length > 0,
                f = a.length > 0,
                g = function(d, g, h, i, j) {
                    var k, l, m, n = 0,
                        o = "0",
                        p = d && [],
                        r = [],
                        s = C,
                        t = d || f && w.find.TAG("*", j),
                        u = P += null == s ? 1 : Math.random() || .1,
                        v = t.length;
                    for (j && (C = g !== G && g); o !== v && null != (k = t[o]); o++) {
                        if (f && k) {
                            for (l = 0; m = a[l++];)
                                if (m(k, g, h)) {
                                    i.push(k);
                                    break
                                }
                            j && (P = u)
                        }
                        e && ((k = !m && k) && n--, d && p.push(k))
                    }
                    if (n += o, e && o !== n) {
                        for (l = 0; m = c[l++];) m(p, r, g, h);
                        if (d) {
                            if (n > 0)
                                for (; o--;) p[o] || r[o] || (r[o] = Y.call(i));
                            r = q(r)
                        }
                        $.apply(i, r), j && !d && r.length > 0 && n + c.length > 1 && b.uniqueSort(i)
                    }
                    return j && (P = u, C = s), p
                };
            return e ? d(g) : g
        }
        var u, v, w, x, y, z, A, B, C, D, E, F, G, H, I, J, K, L, M, N = "sizzle" + 1 * new Date,
            O = a.document,
            P = 0,
            Q = 0,
            R = c(),
            S = c(),
            T = c(),
            U = function(a, b) {
                return a === b && (E = !0), 0
            },
            V = 1 << 31,
            W = {}.hasOwnProperty,
            X = [],
            Y = X.pop,
            Z = X.push,
            $ = X.push,
            _ = X.slice,
            aa = function(a, b) {
                for (var c = 0, d = a.length; d > c; c++)
                    if (a[c] === b) return c;
                return -1
            },
            ba = "checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped",
            ca = "[\\x20\\t\\r\\n\\f]",
            da = "(?:\\\\.|[\\w-]|[^\\x00-\\xa0])+",
            ea = da.replace("w", "w#"),
            fa = "\\[" + ca + "*(" + da + ")(?:" + ca + "*([*^$|!~]?=)" + ca + "*(?:'((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\"|(" + ea + "))|)" + ca + "*\\]",
            ga = ":(" + da + ")(?:\\((('((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\")|((?:\\\\.|[^\\\\()[\\]]|" + fa + ")*)|.*)\\)|)",
            ha = new RegExp(ca + "+", "g"),
            ia = new RegExp("^" + ca + "+|((?:^|[^\\\\])(?:\\\\.)*)" + ca + "+$", "g"),
            ja = new RegExp("^" + ca + "*," + ca + "*"),
            ka = new RegExp("^" + ca + "*([>+~]|" + ca + ")" + ca + "*"),
            la = new RegExp("=" + ca + "*([^\\]'\"]*?)" + ca + "*\\]", "g"),
            ma = new RegExp(ga),
            na = new RegExp("^" + ea + "$"),
            oa = {
                ID: new RegExp("^#(" + da + ")"),
                CLASS: new RegExp("^\\.(" + da + ")"),
                TAG: new RegExp("^(" + da.replace("w", "w*") + ")"),
                ATTR: new RegExp("^" + fa),
                PSEUDO: new RegExp("^" + ga),
                CHILD: new RegExp("^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\(" + ca + "*(even|odd|(([+-]|)(\\d*)n|)" + ca + "*(?:([+-]|)" + ca + "*(\\d+)|))" + ca + "*\\)|)", "i"),
                bool: new RegExp("^(?:" + ba + ")$", "i"),
                needsContext: new RegExp("^" + ca + "*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\(" + ca + "*((?:-\\d)?\\d*)" + ca + "*\\)|)(?=[^-]|$)", "i")
            },
            pa = /^(?:input|select|textarea|button)$/i,
            qa = /^h\d$/i,
            ra = /^[^{]+\{\s*\[native \w/,
            sa = /^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/,
            ta = /[+~]/,
            ua = /'|\\/g,
            va = new RegExp("\\\\([\\da-f]{1,6}" + ca + "?|(" + ca + ")|.)", "ig"),
            wa = function(a, b, c) {
                var d = "0x" + b - 65536;
                return d !== d || c ? b : 0 > d ? String.fromCharCode(d + 65536) : String.fromCharCode(d >> 10 | 55296, 1023 & d | 56320)
            },
            xa = function() {
                F()
            };
        try {
            $.apply(X = _.call(O.childNodes), O.childNodes), X[O.childNodes.length].nodeType
        } catch (ya) {
            $ = {
                apply: X.length ? function(a, b) {
                    Z.apply(a, _.call(b))
                } : function(a, b) {
                    for (var c = a.length, d = 0; a[c++] = b[d++];);
                    a.length = c - 1
                }
            }
        }
        v = b.support = {}, y = b.isXML = function(a) {
            var b = a && (a.ownerDocument || a).documentElement;
            return b ? "HTML" !== b.nodeName : !1
        }, F = b.setDocument = function(a) {
            var b, c, d = a ? a.ownerDocument || a : O;
            return d !== G && 9 === d.nodeType && d.documentElement ? (G = d, H = d.documentElement, c = d.defaultView, c && c !== c.top && (c.addEventListener ? c.addEventListener("unload", xa, !1) : c.attachEvent && c.attachEvent("onunload", xa)), I = !y(d), v.attributes = e(function(a) {
                return a.className = "i", !a.getAttribute("className")
            }), v.getElementsByTagName = e(function(a) {
                return a.appendChild(d.createComment("")), !a.getElementsByTagName("*").length
            }), v.getElementsByClassName = ra.test(d.getElementsByClassName), v.getById = e(function(a) {
                return H.appendChild(a).id = N, !d.getElementsByName || !d.getElementsByName(N).length
            }), v.getById ? (w.find.ID = function(a, b) {
                if ("undefined" != typeof b.getElementById && I) {
                    var c = b.getElementById(a);
                    return c && c.parentNode ? [c] : []
                }
            }, w.filter.ID = function(a) {
                var b = a.replace(va, wa);
                return function(a) {
                    return a.getAttribute("id") === b
                }
            }) : (delete w.find.ID, w.filter.ID = function(a) {
                var b = a.replace(va, wa);
                return function(a) {
                    var c = "undefined" != typeof a.getAttributeNode && a.getAttributeNode("id");
                    return c && c.value === b
                }
            }), w.find.TAG = v.getElementsByTagName ? function(a, b) {
                return "undefined" != typeof b.getElementsByTagName ? b.getElementsByTagName(a) : v.qsa ? b.querySelectorAll(a) : void 0
            } : function(a, b) {
                var c, d = [],
                    e = 0,
                    f = b.getElementsByTagName(a);
                if ("*" === a) {
                    for (; c = f[e++];) 1 === c.nodeType && d.push(c);
                    return d
                }
                return f
            }, w.find.CLASS = v.getElementsByClassName && function(a, b) {
                return I ? b.getElementsByClassName(a) : void 0
            }, K = [], J = [], (v.qsa = ra.test(d.querySelectorAll)) && (e(function(a) {
                H.appendChild(a).innerHTML = "<a id='" + N + "'></a><select id='" + N + "-\f]' msallowcapture=''><option selected=''></option></select>", a.querySelectorAll("[msallowcapture^='']").length && J.push("[*^$]=" + ca + "*(?:''|\"\")"), a.querySelectorAll("[selected]").length || J.push("\\[" + ca + "*(?:value|" + ba + ")"), a.querySelectorAll("[id~=" + N + "-]").length || J.push("~="), a.querySelectorAll(":checked").length || J.push(":checked"), a.querySelectorAll("a#" + N + "+*").length || J.push(".#.+[+~]")
            }), e(function(a) {
                var b = d.createElement("input");
                b.setAttribute("type", "hidden"), a.appendChild(b).setAttribute("name", "D"), a.querySelectorAll("[name=d]").length && J.push("name" + ca + "*[*^$|!~]?="), a.querySelectorAll(":enabled").length || J.push(":enabled", ":disabled"), a.querySelectorAll("*,:x"), J.push(",.*:")
            })), (v.matchesSelector = ra.test(L = H.matches || H.webkitMatchesSelector || H.mozMatchesSelector || H.oMatchesSelector || H.msMatchesSelector)) && e(function(a) {
                v.disconnectedMatch = L.call(a, "div"), L.call(a, "[s!='']:x"), K.push("!=", ga)
            }), J = J.length && new RegExp(J.join("|")), K = K.length && new RegExp(K.join("|")), b = ra.test(H.compareDocumentPosition), M = b || ra.test(H.contains) ? function(a, b) {
                var c = 9 === a.nodeType ? a.documentElement : a,
                    d = b && b.parentNode;
                return a === d || !(!d || 1 !== d.nodeType || !(c.contains ? c.contains(d) : a.compareDocumentPosition && 16 & a.compareDocumentPosition(d)))
            } : function(a, b) {
                if (b)
                    for (; b = b.parentNode;)
                        if (b === a) return !0;
                return !1
            }, U = b ? function(a, b) {
                if (a === b) return E = !0, 0;
                var c = !a.compareDocumentPosition - !b.compareDocumentPosition;
                return c ? c : (c = (a.ownerDocument || a) === (b.ownerDocument || b) ? a.compareDocumentPosition(b) : 1, 1 & c || !v.sortDetached && b.compareDocumentPosition(a) === c ? a === d || a.ownerDocument === O && M(O, a) ? -1 : b === d || b.ownerDocument === O && M(O, b) ? 1 : D ? aa(D, a) - aa(D, b) : 0 : 4 & c ? -1 : 1)
            } : function(a, b) {
                if (a === b) return E = !0, 0;
                var c, e = 0,
                    f = a.parentNode,
                    h = b.parentNode,
                    i = [a],
                    j = [b];
                if (!f || !h) return a === d ? -1 : b === d ? 1 : f ? -1 : h ? 1 : D ? aa(D, a) - aa(D, b) : 0;
                if (f === h) return g(a, b);
                for (c = a; c = c.parentNode;) i.unshift(c);
                for (c = b; c = c.parentNode;) j.unshift(c);
                for (; i[e] === j[e];) e++;
                return e ? g(i[e], j[e]) : i[e] === O ? -1 : j[e] === O ? 1 : 0
            }, d) : G
        }, b.matches = function(a, c) {
            return b(a, null, null, c)
        }, b.matchesSelector = function(a, c) {
            if ((a.ownerDocument || a) !== G && F(a), c = c.replace(la, "='$1']"), !(!v.matchesSelector || !I || K && K.test(c) || J && J.test(c))) try {
                var d = L.call(a, c);
                if (d || v.disconnectedMatch || a.document && 11 !== a.document.nodeType) return d
            } catch (e) {}
            return b(c, G, null, [a]).length > 0
        }, b.contains = function(a, b) {
            return (a.ownerDocument || a) !== G && F(a), M(a, b)
        }, b.attr = function(a, b) {
            (a.ownerDocument || a) !== G && F(a);
            var c = w.attrHandle[b.toLowerCase()],
                d = c && W.call(w.attrHandle, b.toLowerCase()) ? c(a, b, !I) : void 0;
            return void 0 !== d ? d : v.attributes || !I ? a.getAttribute(b) : (d = a.getAttributeNode(b)) && d.specified ? d.value : null
        }, b.error = function(a) {
            throw new Error("Syntax error, unrecognized expression: " + a)
        }, b.uniqueSort = function(a) {
            var b, c = [],
                d = 0,
                e = 0;
            if (E = !v.detectDuplicates, D = !v.sortStable && a.slice(0), a.sort(U), E) {
                for (; b = a[e++];) b === a[e] && (d = c.push(e));
                for (; d--;) a.splice(c[d], 1)
            }
            return D = null, a
        }, x = b.getText = function(a) {
            var b, c = "",
                d = 0,
                e = a.nodeType;
            if (e) {
                if (1 === e || 9 === e || 11 === e) {
                    if ("string" == typeof a.textContent) return a.textContent;
                    for (a = a.firstChild; a; a = a.nextSibling) c += x(a)
                } else if (3 === e || 4 === e) return a.nodeValue
            } else
                for (; b = a[d++];) c += x(b);
            return c
        }, w = b.selectors = {
            cacheLength: 50,
            createPseudo: d,
            match: oa,
            attrHandle: {},
            find: {},
            relative: {
                ">": {
                    dir: "parentNode",
                    first: !0
                },
                " ": {
                    dir: "parentNode"
                },
                "+": {
                    dir: "previousSibling",
                    first: !0
                },
                "~": {
                    dir: "previousSibling"
                }
            },
            preFilter: {
                ATTR: function(a) {
                    return a[1] = a[1].replace(va, wa), a[3] = (a[3] || a[4] || a[5] || "").replace(va, wa), "~=" === a[2] && (a[3] = " " + a[3] + " "), a.slice(0, 4)
                },
                CHILD: function(a) {
                    return a[1] = a[1].toLowerCase(), "nth" === a[1].slice(0, 3) ? (a[3] || b.error(a[0]), a[4] = +(a[4] ? a[5] + (a[6] || 1) : 2 * ("even" === a[3] || "odd" === a[3])), a[5] = +(a[7] + a[8] || "odd" === a[3])) : a[3] && b.error(a[0]), a
                },
                PSEUDO: function(a) {
                    var b, c = !a[6] && a[2];
                    return oa.CHILD.test(a[0]) ? null : (a[3] ? a[2] = a[4] || a[5] || "" : c && ma.test(c) && (b = z(c, !0)) && (b = c.indexOf(")", c.length - b) - c.length) && (a[0] = a[0].slice(0, b), a[2] = c.slice(0, b)), a.slice(0, 3))
                }
            },
            filter: {
                TAG: function(a) {
                    var b = a.replace(va, wa).toLowerCase();
                    return "*" === a ? function() {
                        return !0
                    } : function(a) {
                        return a.nodeName && a.nodeName.toLowerCase() === b
                    }
                },
                CLASS: function(a) {
                    var b = R[a + " "];
                    return b || (b = new RegExp("(^|" + ca + ")" + a + "(" + ca + "|$)")) && R(a, function(a) {
                        return b.test("string" == typeof a.className && a.className || "undefined" != typeof a.getAttribute && a.getAttribute("class") || "")
                    })
                },
                ATTR: function(a, c, d) {
                    return function(e) {
                        var f = b.attr(e, a);
                        return null == f ? "!=" === c : c ? (f += "", "=" === c ? f === d : "!=" === c ? f !== d : "^=" === c ? d && 0 === f.indexOf(d) : "*=" === c ? d && f.indexOf(d) > -1 : "$=" === c ? d && f.slice(-d.length) === d : "~=" === c ? (" " + f.replace(ha, " ") + " ").indexOf(d) > -1 : "|=" === c ? f === d || f.slice(0, d.length + 1) === d + "-" : !1) : !0
                    }
                },
                CHILD: function(a, b, c, d, e) {
                    var f = "nth" !== a.slice(0, 3),
                        g = "last" !== a.slice(-4),
                        h = "of-type" === b;
                    return 1 === d && 0 === e ? function(a) {
                        return !!a.parentNode
                    } : function(b, c, i) {
                        var j, k, l, m, n, o, p = f !== g ? "nextSibling" : "previousSibling",
                            q = b.parentNode,
                            r = h && b.nodeName.toLowerCase(),
                            s = !i && !h;
                        if (q) {
                            if (f) {
                                for (; p;) {
                                    for (l = b; l = l[p];)
                                        if (h ? l.nodeName.toLowerCase() === r : 1 === l.nodeType) return !1;
                                    o = p = "only" === a && !o && "nextSibling"
                                }
                                return !0
                            }
                            if (o = [g ? q.firstChild : q.lastChild], g && s) {
                                for (k = q[N] || (q[N] = {}), j = k[a] || [], n = j[0] === P && j[1], m = j[0] === P && j[2], l = n && q.childNodes[n]; l = ++n && l && l[p] || (m = n = 0) || o.pop();)
                                    if (1 === l.nodeType && ++m && l === b) {
                                        k[a] = [P, n, m];
                                        break
                                    }
                            } else if (s && (j = (b[N] || (b[N] = {}))[a]) && j[0] === P) m = j[1];
                            else
                                for (;
                                    (l = ++n && l && l[p] || (m = n = 0) || o.pop()) && ((h ? l.nodeName.toLowerCase() !== r : 1 !== l.nodeType) || !++m || (s && ((l[N] || (l[N] = {}))[a] = [P, m]), l !== b)););
                            return m -= e, m === d || m % d === 0 && m / d >= 0
                        }
                    }
                },
                PSEUDO: function(a, c) {
                    var e, f = w.pseudos[a] || w.setFilters[a.toLowerCase()] || b.error("unsupported pseudo: " + a);
                    return f[N] ? f(c) : f.length > 1 ? (e = [a, a, "", c], w.setFilters.hasOwnProperty(a.toLowerCase()) ? d(function(a, b) {
                        for (var d, e = f(a, c), g = e.length; g--;) d = aa(a, e[g]), a[d] = !(b[d] = e[g])
                    }) : function(a) {
                        return f(a, 0, e)
                    }) : f
                }
            },
            pseudos: {
                not: d(function(a) {
                    var b = [],
                        c = [],
                        e = A(a.replace(ia, "$1"));
                    return e[N] ? d(function(a, b, c, d) {
                        for (var f, g = e(a, null, d, []), h = a.length; h--;)(f = g[h]) && (a[h] = !(b[h] = f))
                    }) : function(a, d, f) {
                        return b[0] = a, e(b, null, f, c), b[0] = null, !c.pop()
                    }
                }),
                has: d(function(a) {
                    return function(c) {
                        return b(a, c).length > 0
                    }
                }),
                contains: d(function(a) {
                    return a = a.replace(va, wa),
                        function(b) {
                            return (b.textContent || b.innerText || x(b)).indexOf(a) > -1
                        }
                }),
                lang: d(function(a) {
                    return na.test(a || "") || b.error("unsupported lang: " + a), a = a.replace(va, wa).toLowerCase(),
                        function(b) {
                            var c;
                            do
                                if (c = I ? b.lang : b.getAttribute("xml:lang") || b.getAttribute("lang")) return c = c.toLowerCase(), c === a || 0 === c.indexOf(a + "-"); while ((b = b.parentNode) && 1 === b.nodeType);
                            return !1
                        }
                }),
                target: function(b) {
                    var c = a.location && a.location.hash;
                    return c && c.slice(1) === b.id
                },
                root: function(a) {
                    return a === H
                },
                focus: function(a) {
                    return a === G.activeElement && (!G.hasFocus || G.hasFocus()) && !!(a.type || a.href || ~a.tabIndex)
                },
                enabled: function(a) {
                    return a.disabled === !1
                },
                disabled: function(a) {
                    return a.disabled === !0
                },
                checked: function(a) {
                    var b = a.nodeName.toLowerCase();
                    return "input" === b && !!a.checked || "option" === b && !!a.selected
                },
                selected: function(a) {
                    return a.parentNode && a.parentNode.selectedIndex, a.selected === !0
                },
                empty: function(a) {
                    for (a = a.firstChild; a; a = a.nextSibling)
                        if (a.nodeType < 6) return !1;
                    return !0
                },
                parent: function(a) {
                    return !w.pseudos.empty(a)
                },
                header: function(a) {
                    return qa.test(a.nodeName)
                },
                input: function(a) {
                    return pa.test(a.nodeName)
                },
                button: function(a) {
                    var b = a.nodeName.toLowerCase();
                    return "input" === b && "button" === a.type || "button" === b
                },
                text: function(a) {
                    var b;
                    return "input" === a.nodeName.toLowerCase() && "text" === a.type && (null == (b = a.getAttribute("type")) || "text" === b.toLowerCase())
                },
                first: j(function() {
                    return [0]
                }),
                last: j(function(a, b) {
                    return [b - 1]
                }),
                eq: j(function(a, b, c) {
                    return [0 > c ? c + b : c]
                }),
                even: j(function(a, b) {
                    for (var c = 0; b > c; c += 2) a.push(c);
                    return a
                }),
                odd: j(function(a, b) {
                    for (var c = 1; b > c; c += 2) a.push(c);
                    return a
                }),
                lt: j(function(a, b, c) {
                    for (var d = 0 > c ? c + b : c; --d >= 0;) a.push(d);
                    return a
                }),
                gt: j(function(a, b, c) {
                    for (var d = 0 > c ? c + b : c; ++d < b;) a.push(d);
                    return a
                })
            }
        }, w.pseudos.nth = w.pseudos.eq;
        for (u in {
                radio: !0,
                checkbox: !0,
                file: !0,
                password: !0,
                image: !0
            }) w.pseudos[u] = h(u);
        for (u in {
                submit: !0,
                reset: !0
            }) w.pseudos[u] = i(u);
        return l.prototype = w.filters = w.pseudos, w.setFilters = new l, z = b.tokenize = function(a, c) {
            var d, e, f, g, h, i, j, k = S[a + " "];
            if (k) return c ? 0 : k.slice(0);
            for (h = a, i = [], j = w.preFilter; h;) {
                (!d || (e = ja.exec(h))) && (e && (h = h.slice(e[0].length) || h), i.push(f = [])), d = !1, (e = ka.exec(h)) && (d = e.shift(), f.push({
                    value: d,
                    type: e[0].replace(ia, " ")
                }), h = h.slice(d.length));
                for (g in w.filter) !(e = oa[g].exec(h)) || j[g] && !(e = j[g](e)) || (d = e.shift(), f.push({
                    value: d,
                    type: g,
                    matches: e
                }), h = h.slice(d.length));
                if (!d) break
            }
            return c ? h.length : h ? b.error(a) : S(a, i).slice(0)
        }, A = b.compile = function(a, b) {
            var c, d = [],
                e = [],
                f = T[a + " "];
            if (!f) {
                for (b || (b = z(a)), c = b.length; c--;) f = s(b[c]), f[N] ? d.push(f) : e.push(f);
                f = T(a, t(e, d)), f.selector = a
            }
            return f
        }, B = b.select = function(a, b, c, d) {
            var e, f, g, h, i, j = "function" == typeof a && a,
                l = !d && z(a = j.selector || a);
            if (c = c || [], 1 === l.length) {
                if (f = l[0] = l[0].slice(0), f.length > 2 && "ID" === (g = f[0]).type && v.getById && 9 === b.nodeType && I && w.relative[f[1].type]) {
                    if (b = (w.find.ID(g.matches[0].replace(va, wa), b) || [])[0], !b) return c;
                    j && (b = b.parentNode), a = a.slice(f.shift().value.length)
                }
                for (e = oa.needsContext.test(a) ? 0 : f.length; e-- && (g = f[e], !w.relative[h = g.type]);)
                    if ((i = w.find[h]) && (d = i(g.matches[0].replace(va, wa), ta.test(f[0].type) && k(b.parentNode) || b))) {
                        if (f.splice(e, 1), a = d.length && m(f), !a) return $.apply(c, d), c;
                        break
                    }
            }
            return (j || A(a, l))(d, b, !I, c, ta.test(a) && k(b.parentNode) || b), c
        }, v.sortStable = N.split("").sort(U).join("") === N, v.detectDuplicates = !!E, F(), v.sortDetached = e(function(a) {
            return 1 & a.compareDocumentPosition(G.createElement("div"))
        }), e(function(a) {
            return a.innerHTML = "<a href='#'></a>", "#" === a.firstChild.getAttribute("href")
        }) || f("type|href|height|width", function(a, b, c) {
            return c ? void 0 : a.getAttribute(b, "type" === b.toLowerCase() ? 1 : 2)
        }), v.attributes && e(function(a) {
            return a.innerHTML = "<input/>", a.firstChild.setAttribute("value", ""), "" === a.firstChild.getAttribute("value")
        }) || f("value", function(a, b, c) {
            return c || "input" !== a.nodeName.toLowerCase() ? void 0 : a.defaultValue
        }), e(function(a) {
            return null == a.getAttribute("disabled")
        }) || f(ba, function(a, b, c) {
            var d;
            return c ? void 0 : a[b] === !0 ? b.toLowerCase() : (d = a.getAttributeNode(b)) && d.specified ? d.value : null
        }), b
    }(a);
    _.find = ea, _.expr = ea.selectors, _.expr[":"] = _.expr.pseudos, _.unique = ea.uniqueSort, _.text = ea.getText, _.isXMLDoc = ea.isXML, _.contains = ea.contains;
    var fa = _.expr.match.needsContext,
        ga = /^<(\w+)\s*\/?>(?:<\/\1>|)$/,
        ha = /^.[^:#\[\.,]*$/;
    _.filter = function(a, b, c) {
        var d = b[0];
        return c && (a = ":not(" + a + ")"), 1 === b.length && 1 === d.nodeType ? _.find.matchesSelector(d, a) ? [d] : [] : _.find.matches(a, _.grep(b, function(a) {
            return 1 === a.nodeType
        }))
    }, _.fn.extend({
        find: function(a) {
            var b, c = this.length,
                d = [],
                e = this;
            if ("string" != typeof a) return this.pushStack(_(a).filter(function() {
                for (b = 0; c > b; b++)
                    if (_.contains(e[b], this)) return !0
            }));
            for (b = 0; c > b; b++) _.find(a, e[b], d);
            return d = this.pushStack(c > 1 ? _.unique(d) : d), d.selector = this.selector ? this.selector + " " + a : a, d
        },
        filter: function(a) {
            return this.pushStack(d(this, a || [], !1))
        },
        not: function(a) {
            return this.pushStack(d(this, a || [], !0))
        },
        is: function(a) {
            return !!d(this, "string" == typeof a && fa.test(a) ? _(a) : a || [], !1).length
        }
    });
    var ia, ja = /^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]*))$/,
        ka = _.fn.init = function(a, b) {
            var c, d;
            if (!a) return this;
            if ("string" == typeof a) {
                if (c = "<" === a[0] && ">" === a[a.length - 1] && a.length >= 3 ? [null, a, null] : ja.exec(a), !c || !c[1] && b) return !b || b.jquery ? (b || ia).find(a) : this.constructor(b).find(a);
                if (c[1]) {
                    if (b = b instanceof _ ? b[0] : b, _.merge(this, _.parseHTML(c[1], b && b.nodeType ? b.ownerDocument || b : Z, !0)), ga.test(c[1]) && _.isPlainObject(b))
                        for (c in b) _.isFunction(this[c]) ? this[c](b[c]) : this.attr(c, b[c]);
                    return this
                }
                return d = Z.getElementById(c[2]), d && d.parentNode && (this.length = 1, this[0] = d), this.context = Z, this.selector = a, this
            }
            return a.nodeType ? (this.context = this[0] = a, this.length = 1, this) : _.isFunction(a) ? "undefined" != typeof ia.ready ? ia.ready(a) : a(_) : (void 0 !== a.selector && (this.selector = a.selector, this.context = a.context), _.makeArray(a, this))
        };
    ka.prototype = _.fn, ia = _(Z);
    var la = /^(?:parents|prev(?:Until|All))/,
        ma = {
            children: !0,
            contents: !0,
            next: !0,
            prev: !0
        };
    _.extend({
        dir: function(a, b, c) {
            for (var d = [], e = void 0 !== c;
                (a = a[b]) && 9 !== a.nodeType;)
                if (1 === a.nodeType) {
                    if (e && _(a).is(c)) break;
                    d.push(a)
                }
            return d
        },
        sibling: function(a, b) {
            for (var c = []; a; a = a.nextSibling) 1 === a.nodeType && a !== b && c.push(a);
            return c
        }
    }), _.fn.extend({
        has: function(a) {
            var b = _(a, this),
                c = b.length;
            return this.filter(function() {
                for (var a = 0; c > a; a++)
                    if (_.contains(this, b[a])) return !0
            })
        },
        closest: function(a, b) {
            for (var c, d = 0, e = this.length, f = [], g = fa.test(a) || "string" != typeof a ? _(a, b || this.context) : 0; e > d; d++)
                for (c = this[d]; c && c !== b; c = c.parentNode)
                    if (c.nodeType < 11 && (g ? g.index(c) > -1 : 1 === c.nodeType && _.find.matchesSelector(c, a))) {
                        f.push(c);
                        break
                    }
            return this.pushStack(f.length > 1 ? _.unique(f) : f)
        },
        index: function(a) {
            return a ? "string" == typeof a ? U.call(_(a), this[0]) : U.call(this, a.jquery ? a[0] : a) : this[0] && this[0].parentNode ? this.first().prevAll().length : -1
        },
        add: function(a, b) {
            return this.pushStack(_.unique(_.merge(this.get(), _(a, b))))
        },
        addBack: function(a) {
            return this.add(null == a ? this.prevObject : this.prevObject.filter(a))
        }
    }), _.each({
        parent: function(a) {
            var b = a.parentNode;
            return b && 11 !== b.nodeType ? b : null
        },
        parents: function(a) {
            return _.dir(a, "parentNode")
        },
        parentsUntil: function(a, b, c) {
            return _.dir(a, "parentNode", c)
        },
        next: function(a) {
            return e(a, "nextSibling")
        },
        prev: function(a) {
            return e(a, "previousSibling")
        },
        nextAll: function(a) {
            return _.dir(a, "nextSibling")
        },
        prevAll: function(a) {
            return _.dir(a, "previousSibling")
        },
        nextUntil: function(a, b, c) {
            return _.dir(a, "nextSibling", c)
        },
        prevUntil: function(a, b, c) {
            return _.dir(a, "previousSibling", c)
        },
        siblings: function(a) {
            return _.sibling((a.parentNode || {}).firstChild, a)
        },
        children: function(a) {
            return _.sibling(a.firstChild)
        },
        contents: function(a) {
            return a.contentDocument || _.merge([], a.childNodes)
        }
    }, function(a, b) {
        _.fn[a] = function(c, d) {
            var e = _.map(this, b, c);
            return "Until" !== a.slice(-5) && (d = c), d && "string" == typeof d && (e = _.filter(d, e)), this.length > 1 && (ma[a] || _.unique(e), la.test(a) && e.reverse()), this.pushStack(e)
        }
    });
    var na = /\S+/g,
        oa = {};
    _.Callbacks = function(a) {
        a = "string" == typeof a ? oa[a] || f(a) : _.extend({}, a);
        var b, c, d, e, g, h, i = [],
            j = !a.once && [],
            k = function(f) {
                for (b = a.memory && f, c = !0, h = e || 0, e = 0, g = i.length, d = !0; i && g > h; h++)
                    if (i[h].apply(f[0], f[1]) === !1 && a.stopOnFalse) {
                        b = !1;
                        break
                    }
                d = !1, i && (j ? j.length && k(j.shift()) : b ? i = [] : l.disable())
            },
            l = {
                add: function() {
                    if (i) {
                        var c = i.length;
                        ! function f(b) {
                            _.each(b, function(b, c) {
                                var d = _.type(c);
                                "function" === d ? a.unique && l.has(c) || i.push(c) : c && c.length && "string" !== d && f(c)
                            })
                        }(arguments), d ? g = i.length : b && (e = c, k(b))
                    }
                    return this
                },
                remove: function() {
                    return i && _.each(arguments, function(a, b) {
                        for (var c;
                            (c = _.inArray(b, i, c)) > -1;) i.splice(c, 1), d && (g >= c && g--, h >= c && h--)
                    }), this
                },
                has: function(a) {
                    return a ? _.inArray(a, i) > -1 : !(!i || !i.length)
                },
                empty: function() {
                    return i = [], g = 0, this
                },
                disable: function() {
                    return i = j = b = void 0, this
                },
                disabled: function() {
                    return !i
                },
                lock: function() {
                    return j = void 0, b || l.disable(), this
                },
                locked: function() {
                    return !j
                },
                fireWith: function(a, b) {
                    return !i || c && !j || (b = b || [], b = [a, b.slice ? b.slice() : b], d ? j.push(b) : k(b)), this
                },
                fire: function() {
                    return l.fireWith(this, arguments), this
                },
                fired: function() {
                    return !!c
                }
            };
        return l
    }, _.extend({
        Deferred: function(a) {
            var b = [
                    ["resolve", "done", _.Callbacks("once memory"), "resolved"],
                    ["reject", "fail", _.Callbacks("once memory"), "rejected"],
                    ["notify", "progress", _.Callbacks("memory")]
                ],
                c = "pending",
                d = {
                    state: function() {
                        return c
                    },
                    always: function() {
                        return e.done(arguments).fail(arguments), this
                    },
                    then: function() {
                        var a = arguments;
                        return _.Deferred(function(c) {
                            _.each(b, function(b, f) {
                                var g = _.isFunction(a[b]) && a[b];
                                e[f[1]](function() {
                                    var a = g && g.apply(this, arguments);
                                    a && _.isFunction(a.promise) ? a.promise().done(c.resolve).fail(c.reject).progress(c.notify) : c[f[0] + "With"](this === d ? c.promise() : this, g ? [a] : arguments)
                                })
                            }), a = null
                        }).promise()
                    },
                    promise: function(a) {
                        return null != a ? _.extend(a, d) : d
                    }
                },
                e = {};
            return d.pipe = d.then, _.each(b, function(a, f) {
                var g = f[2],
                    h = f[3];
                d[f[1]] = g.add, h && g.add(function() {
                    c = h
                }, b[1 ^ a][2].disable, b[2][2].lock), e[f[0]] = function() {
                    return e[f[0] + "With"](this === e ? d : this, arguments), this
                }, e[f[0] + "With"] = g.fireWith
            }), d.promise(e), a && a.call(e, e), e
        },
        when: function(a) {
            var b, c, d, e = 0,
                f = R.call(arguments),
                g = f.length,
                h = 1 !== g || a && _.isFunction(a.promise) ? g : 0,
                i = 1 === h ? a : _.Deferred(),
                j = function(a, c, d) {
                    return function(e) {
                        c[a] = this, d[a] = arguments.length > 1 ? R.call(arguments) : e, d === b ? i.notifyWith(c, d) : --h || i.resolveWith(c, d)
                    }
                };
            if (g > 1)
                for (b = new Array(g), c = new Array(g), d = new Array(g); g > e; e++) f[e] && _.isFunction(f[e].promise) ? f[e].promise().done(j(e, d, f)).fail(i.reject).progress(j(e, c, b)) : --h;
            return h || i.resolveWith(d, f), i.promise()
        }
    });
    var pa;
    _.fn.ready = function(a) {
        return _.ready.promise().done(a), this
    }, _.extend({
        isReady: !1,
        readyWait: 1,
        holdReady: function(a) {
            a ? _.readyWait++ : _.ready(!0)
        },
        ready: function(a) {
            (a === !0 ? --_.readyWait : _.isReady) || (_.isReady = !0, a !== !0 && --_.readyWait > 0 || (pa.resolveWith(Z, [_]), _.fn.triggerHandler && (_(Z).triggerHandler("ready"), _(Z).off("ready"))))
        }
    }), _.ready.promise = function(b) {
        return pa || (pa = _.Deferred(), "complete" === Z.readyState ? setTimeout(_.ready) : (Z.addEventListener("DOMContentLoaded", g, !1), a.addEventListener("load", g, !1))), pa.promise(b)
    }, _.ready.promise();
    var qa = _.access = function(a, b, c, d, e, f, g) {
        var h = 0,
            i = a.length,
            j = null == c;
        if ("object" === _.type(c)) {
            e = !0;
            for (h in c) _.access(a, b, h, c[h], !0, f, g)
        } else if (void 0 !== d && (e = !0, _.isFunction(d) || (g = !0), j && (g ? (b.call(a, d), b = null) : (j = b, b = function(a, b, c) {
                return j.call(_(a), c)
            })), b))
            for (; i > h; h++) b(a[h], c, g ? d : d.call(a[h], h, b(a[h], c)));
        return e ? a : j ? b.call(a) : i ? b(a[0], c) : f
    };
    _.acceptData = function(a) {
        return 1 === a.nodeType || 9 === a.nodeType || !+a.nodeType
    }, h.uid = 1, h.accepts = _.acceptData, h.prototype = {
        key: function(a) {
            if (!h.accepts(a)) return 0;
            var b = {},
                c = a[this.expando];
            if (!c) {
                c = h.uid++;
                try {
                    b[this.expando] = {
                        value: c
                    }, Object.defineProperties(a, b)
                } catch (d) {
                    b[this.expando] = c, _.extend(a, b)
                }
            }
            return this.cache[c] || (this.cache[c] = {}), c
        },
        set: function(a, b, c) {
            var d, e = this.key(a),
                f = this.cache[e];
            if ("string" == typeof b) f[b] = c;
            else if (_.isEmptyObject(f)) _.extend(this.cache[e], b);
            else
                for (d in b) f[d] = b[d];
            return f
        },
        get: function(a, b) {
            var c = this.cache[this.key(a)];
            return void 0 === b ? c : c[b]
        },
        access: function(a, b, c) {
            var d;
            return void 0 === b || b && "string" == typeof b && void 0 === c ? (d = this.get(a, b), void 0 !== d ? d : this.get(a, _.camelCase(b))) : (this.set(a, b, c), void 0 !== c ? c : b)
        },
        remove: function(a, b) {
            var c, d, e, f = this.key(a),
                g = this.cache[f];
            if (void 0 === b) this.cache[f] = {};
            else {
                _.isArray(b) ? d = b.concat(b.map(_.camelCase)) : (e = _.camelCase(b), b in g ? d = [b, e] : (d = e, d = d in g ? [d] : d.match(na) || [])), c = d.length;
                for (; c--;) delete g[d[c]]
            }
        },
        hasData: function(a) {
            return !_.isEmptyObject(this.cache[a[this.expando]] || {})
        },
        discard: function(a) {
            a[this.expando] && delete this.cache[a[this.expando]]
        }
    };
    var ra = new h,
        sa = new h,
        ta = /^(?:\{[\w\W]*\}|\[[\w\W]*\])$/,
        ua = /([A-Z])/g;
    _.extend({
        hasData: function(a) {
            return sa.hasData(a) || ra.hasData(a)
        },
        data: function(a, b, c) {
            return sa.access(a, b, c)
        },
        removeData: function(a, b) {
            sa.remove(a, b)
        },
        _data: function(a, b, c) {
            return ra.access(a, b, c)
        },
        _removeData: function(a, b) {
            ra.remove(a, b)
        }
    }), _.fn.extend({
        data: function(a, b) {
            var c, d, e, f = this[0],
                g = f && f.attributes;
            if (void 0 === a) {
                if (this.length && (e = sa.get(f), 1 === f.nodeType && !ra.get(f, "hasDataAttrs"))) {
                    for (c = g.length; c--;) g[c] && (d = g[c].name, 0 === d.indexOf("data-") && (d = _.camelCase(d.slice(5)), i(f, d, e[d])));
                    ra.set(f, "hasDataAttrs", !0)
                }
                return e
            }
            return "object" == typeof a ? this.each(function() {
                sa.set(this, a)
            }) : qa(this, function(b) {
                var c, d = _.camelCase(a);
                if (f && void 0 === b) {
                    if (c = sa.get(f, a), void 0 !== c) return c;
                    if (c = sa.get(f, d), void 0 !== c) return c;
                    if (c = i(f, d, void 0), void 0 !== c) return c
                } else this.each(function() {
                    var c = sa.get(this, d);
                    sa.set(this, d, b), -1 !== a.indexOf("-") && void 0 !== c && sa.set(this, a, b)
                })
            }, null, b, arguments.length > 1, null, !0)
        },
        removeData: function(a) {
            return this.each(function() {
                sa.remove(this, a)
            })
        }
    }), _.extend({
        queue: function(a, b, c) {
            var d;
            return a ? (b = (b || "fx") + "queue", d = ra.get(a, b), c && (!d || _.isArray(c) ? d = ra.access(a, b, _.makeArray(c)) : d.push(c)), d || []) : void 0
        },
        dequeue: function(a, b) {
            b = b || "fx";
            var c = _.queue(a, b),
                d = c.length,
                e = c.shift(),
                f = _._queueHooks(a, b),
                g = function() {
                    _.dequeue(a, b)
                };
            "inprogress" === e && (e = c.shift(), d--), e && ("fx" === b && c.unshift("inprogress"), delete f.stop, e.call(a, g, f)), !d && f && f.empty.fire()
        },
        _queueHooks: function(a, b) {
            var c = b + "queueHooks";
            return ra.get(a, c) || ra.access(a, c, {
                empty: _.Callbacks("once memory").add(function() {
                    ra.remove(a, [b + "queue", c])
                })
            })
        }
    }), _.fn.extend({
        queue: function(a, b) {
            var c = 2;
            return "string" != typeof a && (b = a, a = "fx", c--), arguments.length < c ? _.queue(this[0], a) : void 0 === b ? this : this.each(function() {
                var c = _.queue(this, a, b);
                _._queueHooks(this, a), "fx" === a && "inprogress" !== c[0] && _.dequeue(this, a)
            })
        },
        dequeue: function(a) {
            return this.each(function() {
                _.dequeue(this, a)
            })
        },
        clearQueue: function(a) {
            return this.queue(a || "fx", [])
        },
        promise: function(a, b) {
            var c, d = 1,
                e = _.Deferred(),
                f = this,
                g = this.length,
                h = function() {
                    --d || e.resolveWith(f, [f])
                };
            for ("string" != typeof a && (b = a, a = void 0), a = a || "fx"; g--;) c = ra.get(f[g], a + "queueHooks"), c && c.empty && (d++, c.empty.add(h));
            return h(), e.promise(b)
        }
    });
    var va = /[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source,
        wa = ["Top", "Right", "Bottom", "Left"],
        xa = function(a, b) {
            return a = b || a, "none" === _.css(a, "display") || !_.contains(a.ownerDocument, a)
        },
        ya = /^(?:checkbox|radio)$/i;
    ! function() {
        var a = Z.createDocumentFragment(),
            b = a.appendChild(Z.createElement("div")),
            c = Z.createElement("input");
        c.setAttribute("type", "radio"), c.setAttribute("checked", "checked"), c.setAttribute("name", "t"), b.appendChild(c), Y.checkClone = b.cloneNode(!0).cloneNode(!0).lastChild.checked, b.innerHTML = "<textarea>x</textarea>", Y.noCloneChecked = !!b.cloneNode(!0).lastChild.defaultValue
    }();
    var za = "undefined";
    Y.focusinBubbles = "onfocusin" in a;
    var Aa = /^key/,
        Ba = /^(?:mouse|pointer|contextmenu)|click/,
        Ca = /^(?:focusinfocus|focusoutblur)$/,
        Da = /^([^.]*)(?:\.(.+)|)$/;
    _.event = {
        global: {},
        add: function(a, b, c, d, e) {
            var f, g, h, i, j, k, l, m, n, o, p, q = ra.get(a);
            if (q)
                for (c.handler && (f = c, c = f.handler, e = f.selector), c.guid || (c.guid = _.guid++), (i = q.events) || (i = q.events = {}), (g = q.handle) || (g = q.handle = function(b) {
                        return typeof _ !== za && _.event.triggered !== b.type ? _.event.dispatch.apply(a, arguments) : void 0
                    }), b = (b || "").match(na) || [""], j = b.length; j--;) h = Da.exec(b[j]) || [], n = p = h[1], o = (h[2] || "").split(".").sort(), n && (l = _.event.special[n] || {}, n = (e ? l.delegateType : l.bindType) || n, l = _.event.special[n] || {}, k = _.extend({
                    type: n,
                    origType: p,
                    data: d,
                    handler: c,
                    guid: c.guid,
                    selector: e,
                    needsContext: e && _.expr.match.needsContext.test(e),
                    namespace: o.join(".")
                }, f), (m = i[n]) || (m = i[n] = [], m.delegateCount = 0, l.setup && l.setup.call(a, d, o, g) !== !1 || a.addEventListener && a.addEventListener(n, g, !1)), l.add && (l.add.call(a, k), k.handler.guid || (k.handler.guid = c.guid)), e ? m.splice(m.delegateCount++, 0, k) : m.push(k), _.event.global[n] = !0)
        },
        remove: function(a, b, c, d, e) {
            var f, g, h, i, j, k, l, m, n, o, p, q = ra.hasData(a) && ra.get(a);
            if (q && (i = q.events)) {
                for (b = (b || "").match(na) || [""], j = b.length; j--;)
                    if (h = Da.exec(b[j]) || [], n = p = h[1], o = (h[2] || "").split(".").sort(), n) {
                        for (l = _.event.special[n] || {}, n = (d ? l.delegateType : l.bindType) || n, m = i[n] || [], h = h[2] && new RegExp("(^|\\.)" + o.join("\\.(?:.*\\.|)") + "(\\.|$)"), g = f = m.length; f--;) k = m[f], !e && p !== k.origType || c && c.guid !== k.guid || h && !h.test(k.namespace) || d && d !== k.selector && ("**" !== d || !k.selector) || (m.splice(f, 1), k.selector && m.delegateCount--, l.remove && l.remove.call(a, k));
                        g && !m.length && (l.teardown && l.teardown.call(a, o, q.handle) !== !1 || _.removeEvent(a, n, q.handle), delete i[n])
                    } else
                        for (n in i) _.event.remove(a, n + b[j], c, d, !0);
                _.isEmptyObject(i) && (delete q.handle, ra.remove(a, "events"))
            }
        },
        trigger: function(b, c, d, e) {
            var f, g, h, i, j, k, l, m = [d || Z],
                n = X.call(b, "type") ? b.type : b,
                o = X.call(b, "namespace") ? b.namespace.split(".") : [];
            if (g = h = d = d || Z, 3 !== d.nodeType && 8 !== d.nodeType && !Ca.test(n + _.event.triggered) && (n.indexOf(".") >= 0 && (o = n.split("."), n = o.shift(), o.sort()), j = n.indexOf(":") < 0 && "on" + n, b = b[_.expando] ? b : new _.Event(n, "object" == typeof b && b), b.isTrigger = e ? 2 : 3, b.namespace = o.join("."), b.namespace_re = b.namespace ? new RegExp("(^|\\.)" + o.join("\\.(?:.*\\.|)") + "(\\.|$)") : null, b.result = void 0, b.target || (b.target = d), c = null == c ? [b] : _.makeArray(c, [b]), l = _.event.special[n] || {}, e || !l.trigger || l.trigger.apply(d, c) !== !1)) {
                if (!e && !l.noBubble && !_.isWindow(d)) {
                    for (i = l.delegateType || n, Ca.test(i + n) || (g = g.parentNode); g; g = g.parentNode) m.push(g), h = g;
                    h === (d.ownerDocument || Z) && m.push(h.defaultView || h.parentWindow || a)
                }
                for (f = 0;
                    (g = m[f++]) && !b.isPropagationStopped();) b.type = f > 1 ? i : l.bindType || n, k = (ra.get(g, "events") || {})[b.type] && ra.get(g, "handle"), k && k.apply(g, c), k = j && g[j], k && k.apply && _.acceptData(g) && (b.result = k.apply(g, c), b.result === !1 && b.preventDefault());
                return b.type = n, e || b.isDefaultPrevented() || l._default && l._default.apply(m.pop(), c) !== !1 || !_.acceptData(d) || j && _.isFunction(d[n]) && !_.isWindow(d) && (h = d[j], h && (d[j] = null), _.event.triggered = n, d[n](), _.event.triggered = void 0, h && (d[j] = h)), b.result
            }
        },
        dispatch: function(a) {
            a = _.event.fix(a);
            var b, c, d, e, f, g = [],
                h = R.call(arguments),
                i = (ra.get(this, "events") || {})[a.type] || [],
                j = _.event.special[a.type] || {};
            if (h[0] = a, a.delegateTarget = this, !j.preDispatch || j.preDispatch.call(this, a) !== !1) {
                for (g = _.event.handlers.call(this, a, i), b = 0;
                    (e = g[b++]) && !a.isPropagationStopped();)
                    for (a.currentTarget = e.elem, c = 0;
                        (f = e.handlers[c++]) && !a.isImmediatePropagationStopped();)(!a.namespace_re || a.namespace_re.test(f.namespace)) && (a.handleObj = f, a.data = f.data, d = ((_.event.special[f.origType] || {}).handle || f.handler).apply(e.elem, h), void 0 !== d && (a.result = d) === !1 && (a.preventDefault(), a.stopPropagation()));
                return j.postDispatch && j.postDispatch.call(this, a), a.result
            }
        },
        handlers: function(a, b) {
            var c, d, e, f, g = [],
                h = b.delegateCount,
                i = a.target;
            if (h && i.nodeType && (!a.button || "click" !== a.type))
                for (; i !== this; i = i.parentNode || this)
                    if (i.disabled !== !0 || "click" !== a.type) {
                        for (d = [], c = 0; h > c; c++) f = b[c], e = f.selector + " ", void 0 === d[e] && (d[e] = f.needsContext ? _(e, this).index(i) >= 0 : _.find(e, this, null, [i]).length), d[e] && d.push(f);
                        d.length && g.push({
                            elem: i,
                            handlers: d
                        })
                    }
            return h < b.length && g.push({
                elem: this,
                handlers: b.slice(h)
            }), g
        },
        props: "altKey bubbles cancelable ctrlKey currentTarget eventPhase metaKey relatedTarget shiftKey target timeStamp view which".split(" "),
        fixHooks: {},
        keyHooks: {
            props: "char charCode key keyCode".split(" "),
            filter: function(a, b) {
                return null == a.which && (a.which = null != b.charCode ? b.charCode : b.keyCode), a
            }
        },
        mouseHooks: {
            props: "button buttons clientX clientY offsetX offsetY pageX pageY screenX screenY toElement".split(" "),
            filter: function(a, b) {
                var c, d, e, f = b.button;
                return null == a.pageX && null != b.clientX && (c = a.target.ownerDocument || Z, d = c.documentElement, e = c.body, a.pageX = b.clientX + (d && d.scrollLeft || e && e.scrollLeft || 0) - (d && d.clientLeft || e && e.clientLeft || 0), a.pageY = b.clientY + (d && d.scrollTop || e && e.scrollTop || 0) - (d && d.clientTop || e && e.clientTop || 0)), a.which || void 0 === f || (a.which = 1 & f ? 1 : 2 & f ? 3 : 4 & f ? 2 : 0), a
            }
        },
        fix: function(a) {
            if (a[_.expando]) return a;
            var b, c, d, e = a.type,
                f = a,
                g = this.fixHooks[e];
            for (g || (this.fixHooks[e] = g = Ba.test(e) ? this.mouseHooks : Aa.test(e) ? this.keyHooks : {}), d = g.props ? this.props.concat(g.props) : this.props, a = new _.Event(f), b = d.length; b--;) c = d[b], a[c] = f[c];
            return a.target || (a.target = Z), 3 === a.target.nodeType && (a.target = a.target.parentNode), g.filter ? g.filter(a, f) : a
        },
        special: {
            load: {
                noBubble: !0
            },
            focus: {
                trigger: function() {
                    return this !== l() && this.focus ? (this.focus(), !1) : void 0
                },
                delegateType: "focusin"
            },
            blur: {
                trigger: function() {
                    return this === l() && this.blur ? (this.blur(), !1) : void 0
                },
                delegateType: "focusout"
            },
            click: {
                trigger: function() {
                    return "checkbox" === this.type && this.click && _.nodeName(this, "input") ? (this.click(), !1) : void 0
                },
                _default: function(a) {
                    return _.nodeName(a.target, "a")
                }
            },
            beforeunload: {
                postDispatch: function(a) {
                    void 0 !== a.result && a.originalEvent && (a.originalEvent.returnValue = a.result)
                }
            }
        },
        simulate: function(a, b, c, d) {
            var e = _.extend(new _.Event, c, {
                type: a,
                isSimulated: !0,
                originalEvent: {}
            });
            d ? _.event.trigger(e, null, b) : _.event.dispatch.call(b, e), e.isDefaultPrevented() && c.preventDefault()
        }
    }, _.removeEvent = function(a, b, c) {
        a.removeEventListener && a.removeEventListener(b, c, !1)
    }, _.Event = function(a, b) {
        return this instanceof _.Event ? (a && a.type ? (this.originalEvent = a, this.type = a.type, this.isDefaultPrevented = a.defaultPrevented || void 0 === a.defaultPrevented && a.returnValue === !1 ? j : k) : this.type = a, b && _.extend(this, b), this.timeStamp = a && a.timeStamp || _.now(), void(this[_.expando] = !0)) : new _.Event(a, b)
    }, _.Event.prototype = {
        isDefaultPrevented: k,
        isPropagationStopped: k,
        isImmediatePropagationStopped: k,
        preventDefault: function() {
            var a = this.originalEvent;
            this.isDefaultPrevented = j, a && a.preventDefault && a.preventDefault()
        },
        stopPropagation: function() {
            var a = this.originalEvent;
            this.isPropagationStopped = j, a && a.stopPropagation && a.stopPropagation()
        },
        stopImmediatePropagation: function() {
            var a = this.originalEvent;
            this.isImmediatePropagationStopped = j, a && a.stopImmediatePropagation && a.stopImmediatePropagation(), this.stopPropagation()
        }
    }, _.each({
        mouseenter: "mouseover",
        mouseleave: "mouseout",
        pointerenter: "pointerover",
        pointerleave: "pointerout"
    }, function(a, b) {
        _.event.special[a] = {
            delegateType: b,
            bindType: b,
            handle: function(a) {
                var c, d = this,
                    e = a.relatedTarget,
                    f = a.handleObj;
                return (!e || e !== d && !_.contains(d, e)) && (a.type = f.origType, c = f.handler.apply(this, arguments), a.type = b), c
            }
        }
    }), Y.focusinBubbles || _.each({
        focus: "focusin",
        blur: "focusout"
    }, function(a, b) {
        var c = function(a) {
            _.event.simulate(b, a.target, _.event.fix(a), !0)
        };
        _.event.special[b] = {
            setup: function() {
                var d = this.ownerDocument || this,
                    e = ra.access(d, b);
                e || d.addEventListener(a, c, !0), ra.access(d, b, (e || 0) + 1)
            },
            teardown: function() {
                var d = this.ownerDocument || this,
                    e = ra.access(d, b) - 1;
                e ? ra.access(d, b, e) : (d.removeEventListener(a, c, !0), ra.remove(d, b))
            }
        }
    }), _.fn.extend({
        on: function(a, b, c, d, e) {
            var f, g;
            if ("object" == typeof a) {
                "string" != typeof b && (c = c || b, b = void 0);
                for (g in a) this.on(g, b, c, a[g], e);
                return this
            }
            if (null == c && null == d ? (d = b, c = b = void 0) : null == d && ("string" == typeof b ? (d = c, c = void 0) : (d = c, c = b, b = void 0)), d === !1) d = k;
            else if (!d) return this;
            return 1 === e && (f = d, d = function(a) {
                return _().off(a), f.apply(this, arguments)
            }, d.guid = f.guid || (f.guid = _.guid++)), this.each(function() {
                _.event.add(this, a, d, c, b)
            })
        },
        one: function(a, b, c, d) {
            return this.on(a, b, c, d, 1)
        },
        off: function(a, b, c) {
            var d, e;
            if (a && a.preventDefault && a.handleObj) return d = a.handleObj, _(a.delegateTarget).off(d.namespace ? d.origType + "." + d.namespace : d.origType, d.selector, d.handler), this;
            if ("object" == typeof a) {
                for (e in a) this.off(e, b, a[e]);
                return this
            }
            return (b === !1 || "function" == typeof b) && (c = b, b = void 0), c === !1 && (c = k), this.each(function() {
                _.event.remove(this, a, c, b)
            })
        },
        trigger: function(a, b) {
            return this.each(function() {
                _.event.trigger(a, b, this)
            })
        },
        triggerHandler: function(a, b) {
            var c = this[0];
            return c ? _.event.trigger(a, b, c, !0) : void 0
        }
    });
    var Ea = /<(?!area|br|col|embed|hr|img|input|link|meta|param)(([\w:]+)[^>]*)\/>/gi,
        Fa = /<([\w:]+)/,
        Ga = /<|&#?\w+;/,
        Ha = /<(?:script|style|link)/i,
        Ia = /checked\s*(?:[^=]|=\s*.checked.)/i,
        Ja = /^$|\/(?:java|ecma)script/i,
        Ka = /^true\/(.*)/,
        La = /^\s*<!(?:\[CDATA\[|--)|(?:\]\]|--)>\s*$/g,
        Ma = {
            option: [1, "<select multiple='multiple'>", "</select>"],
            thead: [1, "<table>", "</table>"],
            col: [2, "<table><colgroup>", "</colgroup></table>"],
            tr: [2, "<table><tbody>", "</tbody></table>"],
            td: [3, "<table><tbody><tr>", "</tr></tbody></table>"],
            _default: [0, "", ""]
        };
    Ma.optgroup = Ma.option, Ma.tbody = Ma.tfoot = Ma.colgroup = Ma.caption = Ma.thead, Ma.th = Ma.td, _.extend({
        clone: function(a, b, c) {
            var d, e, f, g, h = a.cloneNode(!0),
                i = _.contains(a.ownerDocument, a);
            if (!(Y.noCloneChecked || 1 !== a.nodeType && 11 !== a.nodeType || _.isXMLDoc(a)))
                for (g = r(h), f = r(a), d = 0, e = f.length; e > d; d++) s(f[d], g[d]);
            if (b)
                if (c)
                    for (f = f || r(a), g = g || r(h), d = 0, e = f.length; e > d; d++) q(f[d], g[d]);
                else q(a, h);
            return g = r(h, "script"), g.length > 0 && p(g, !i && r(a, "script")), h
        },
        buildFragment: function(a, b, c, d) {
            for (var e, f, g, h, i, j, k = b.createDocumentFragment(), l = [], m = 0, n = a.length; n > m; m++)
                if (e = a[m], e || 0 === e)
                    if ("object" === _.type(e)) _.merge(l, e.nodeType ? [e] : e);
                    else if (Ga.test(e)) {
                for (f = f || k.appendChild(b.createElement("div")), g = (Fa.exec(e) || ["", ""])[1].toLowerCase(), h = Ma[g] || Ma._default, f.innerHTML = h[1] + e.replace(Ea, "<$1></$2>") + h[2], j = h[0]; j--;) f = f.lastChild;
                _.merge(l, f.childNodes), f = k.firstChild, f.textContent = ""
            } else l.push(b.createTextNode(e));
            for (k.textContent = "", m = 0; e = l[m++];)
                if ((!d || -1 === _.inArray(e, d)) && (i = _.contains(e.ownerDocument, e), f = r(k.appendChild(e), "script"), i && p(f), c))
                    for (j = 0; e = f[j++];) Ja.test(e.type || "") && c.push(e);
            return k
        },
        cleanData: function(a) {
            for (var b, c, d, e, f = _.event.special, g = 0; void 0 !== (c = a[g]); g++) {
                if (_.acceptData(c) && (e = c[ra.expando], e && (b = ra.cache[e]))) {
                    if (b.events)
                        for (d in b.events) f[d] ? _.event.remove(c, d) : _.removeEvent(c, d, b.handle);
                    ra.cache[e] && delete ra.cache[e]
                }
                delete sa.cache[c[sa.expando]]
            }
        }
    }), _.fn.extend({
        text: function(a) {
            return qa(this, function(a) {
                return void 0 === a ? _.text(this) : this.empty().each(function() {
                    (1 === this.nodeType || 11 === this.nodeType || 9 === this.nodeType) && (this.textContent = a)
                })
            }, null, a, arguments.length)
        },
        append: function() {
            return this.domManip(arguments, function(a) {
                if (1 === this.nodeType || 11 === this.nodeType || 9 === this.nodeType) {
                    var b = m(this, a);
                    b.appendChild(a)
                }
            })
        },
        prepend: function() {
            return this.domManip(arguments, function(a) {
                if (1 === this.nodeType || 11 === this.nodeType || 9 === this.nodeType) {
                    var b = m(this, a);
                    b.insertBefore(a, b.firstChild)
                }
            })
        },
        before: function() {
            return this.domManip(arguments, function(a) {
                this.parentNode && this.parentNode.insertBefore(a, this)
            })
        },
        after: function() {
            return this.domManip(arguments, function(a) {
                this.parentNode && this.parentNode.insertBefore(a, this.nextSibling)
            })
        },
        remove: function(a, b) {
            for (var c, d = a ? _.filter(a, this) : this, e = 0; null != (c = d[e]); e++) b || 1 !== c.nodeType || _.cleanData(r(c)), c.parentNode && (b && _.contains(c.ownerDocument, c) && p(r(c, "script")), c.parentNode.removeChild(c));
            return this
        },
        empty: function() {
            for (var a, b = 0; null != (a = this[b]); b++) 1 === a.nodeType && (_.cleanData(r(a, !1)), a.textContent = "");
            return this
        },
        clone: function(a, b) {
            return a = null == a ? !1 : a, b = null == b ? a : b, this.map(function() {
                return _.clone(this, a, b)
            })
        },
        html: function(a) {
            return qa(this, function(a) {
                var b = this[0] || {},
                    c = 0,
                    d = this.length;
                if (void 0 === a && 1 === b.nodeType) return b.innerHTML;
                if ("string" == typeof a && !Ha.test(a) && !Ma[(Fa.exec(a) || ["", ""])[1].toLowerCase()]) {
                    a = a.replace(Ea, "<$1></$2>");
                    try {
                        for (; d > c; c++) b = this[c] || {}, 1 === b.nodeType && (_.cleanData(r(b, !1)), b.innerHTML = a);
                        b = 0
                    } catch (e) {}
                }
                b && this.empty().append(a)
            }, null, a, arguments.length)
        },
        replaceWith: function() {
            var a = arguments[0];
            return this.domManip(arguments, function(b) {
                a = this.parentNode, _.cleanData(r(this)), a && a.replaceChild(b, this)
            }), a && (a.length || a.nodeType) ? this : this.remove()
        },
        detach: function(a) {
            return this.remove(a, !0)
        },
        domManip: function(a, b) {
            a = S.apply([], a);
            var c, d, e, f, g, h, i = 0,
                j = this.length,
                k = this,
                l = j - 1,
                m = a[0],
                p = _.isFunction(m);
            if (p || j > 1 && "string" == typeof m && !Y.checkClone && Ia.test(m)) return this.each(function(c) {
                var d = k.eq(c);
                p && (a[0] = m.call(this, c, d.html())), d.domManip(a, b)
            });
            if (j && (c = _.buildFragment(a, this[0].ownerDocument, !1, this), d = c.firstChild, 1 === c.childNodes.length && (c = d), d)) {
                for (e = _.map(r(c, "script"), n), f = e.length; j > i; i++) g = c, i !== l && (g = _.clone(g, !0, !0), f && _.merge(e, r(g, "script"))), b.call(this[i], g, i);
                if (f)
                    for (h = e[e.length - 1].ownerDocument, _.map(e, o), i = 0; f > i; i++) g = e[i], Ja.test(g.type || "") && !ra.access(g, "globalEval") && _.contains(h, g) && (g.src ? _._evalUrl && _._evalUrl(g.src) : _.globalEval(g.textContent.replace(La, "")))
            }
            return this
        }
    }), _.each({
        appendTo: "append",
        prependTo: "prepend",
        insertBefore: "before",
        insertAfter: "after",
        replaceAll: "replaceWith"
    }, function(a, b) {
        _.fn[a] = function(a) {
            for (var c, d = [], e = _(a), f = e.length - 1, g = 0; f >= g; g++) c = g === f ? this : this.clone(!0), _(e[g])[b](c), T.apply(d, c.get());
            return this.pushStack(d)
        }
    });
    var Na, Oa = {},
        Pa = /^margin/,
        Qa = new RegExp("^(" + va + ")(?!px)[a-z%]+$", "i"),
        Ra = function(b) {
            return b.ownerDocument.defaultView.opener ? b.ownerDocument.defaultView.getComputedStyle(b, null) : a.getComputedStyle(b, null)
        };
    ! function() {
        function b() {
            g.style.cssText = "-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;display:block;margin-top:1%;top:1%;border:1px;padding:1px;width:4px;position:absolute", g.innerHTML = "", e.appendChild(f);
            var b = a.getComputedStyle(g, null);
            c = "1%" !== b.top, d = "4px" === b.width, e.removeChild(f)
        }
        var c, d, e = Z.documentElement,
            f = Z.createElement("div"),
            g = Z.createElement("div");
        g.style && (g.style.backgroundClip = "content-box", g.cloneNode(!0).style.backgroundClip = "", Y.clearCloneStyle = "content-box" === g.style.backgroundClip, f.style.cssText = "border:0;width:0;height:0;top:0;left:-9999px;margin-top:1px;position:absolute", f.appendChild(g), a.getComputedStyle && _.extend(Y, {
            pixelPosition: function() {
                return b(), c
            },
            boxSizingReliable: function() {
                return null == d && b(), d
            },
            reliableMarginRight: function() {
                var b, c = g.appendChild(Z.createElement("div"));
                return c.style.cssText = g.style.cssText = "-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box;display:block;margin:0;border:0;padding:0", c.style.marginRight = c.style.width = "0", g.style.width = "1px", e.appendChild(f), b = !parseFloat(a.getComputedStyle(c, null).marginRight), e.removeChild(f), g.removeChild(c), b
            }
        }))
    }(), _.swap = function(a, b, c, d) {
        var e, f, g = {};
        for (f in b) g[f] = a.style[f], a.style[f] = b[f];
        e = c.apply(a, d || []);
        for (f in b) a.style[f] = g[f];
        return e
    };
    var Sa = /^(none|table(?!-c[ea]).+)/,
        Ta = new RegExp("^(" + va + ")(.*)$", "i"),
        Ua = new RegExp("^([+-])=(" + va + ")", "i"),
        Va = {
            position: "absolute",
            visibility: "hidden",
            display: "block"
        },
        Wa = {
            letterSpacing: "0",
            fontWeight: "400"
        },
        Xa = ["Webkit", "O", "Moz", "ms"];
    _.extend({
        cssHooks: {
            opacity: {
                get: function(a, b) {
                    if (b) {
                        var c = v(a, "opacity");
                        return "" === c ? "1" : c
                    }
                }
            }
        },
        cssNumber: {
            columnCount: !0,
            fillOpacity: !0,
            flexGrow: !0,
            flexShrink: !0,
            fontWeight: !0,
            lineHeight: !0,
            opacity: !0,
            order: !0,
            orphans: !0,
            widows: !0,
            zIndex: !0,
            zoom: !0
        },
        cssProps: {
            "float": "cssFloat"
        },
        style: function(a, b, c, d) {
            if (a && 3 !== a.nodeType && 8 !== a.nodeType && a.style) {
                var e, f, g, h = _.camelCase(b),
                    i = a.style;
                return b = _.cssProps[h] || (_.cssProps[h] = x(i, h)), g = _.cssHooks[b] || _.cssHooks[h], void 0 === c ? g && "get" in g && void 0 !== (e = g.get(a, !1, d)) ? e : i[b] : (f = typeof c, "string" === f && (e = Ua.exec(c)) && (c = (e[1] + 1) * e[2] + parseFloat(_.css(a, b)), f = "number"), void(null != c && c === c && ("number" !== f || _.cssNumber[h] || (c += "px"), Y.clearCloneStyle || "" !== c || 0 !== b.indexOf("background") || (i[b] = "inherit"), g && "set" in g && void 0 === (c = g.set(a, c, d)) || (i[b] = c))))
            }
        },
        css: function(a, b, c, d) {
            var e, f, g, h = _.camelCase(b);
            return b = _.cssProps[h] || (_.cssProps[h] = x(a.style, h)), g = _.cssHooks[b] || _.cssHooks[h], g && "get" in g && (e = g.get(a, !0, c)), void 0 === e && (e = v(a, b, d)), "normal" === e && b in Wa && (e = Wa[b]), "" === c || c ? (f = parseFloat(e), c === !0 || _.isNumeric(f) ? f || 0 : e) : e
        }
    }), _.each(["height", "width"], function(a, b) {
        _.cssHooks[b] = {
            get: function(a, c, d) {
                return c ? Sa.test(_.css(a, "display")) && 0 === a.offsetWidth ? _.swap(a, Va, function() {
                    return A(a, b, d)
                }) : A(a, b, d) : void 0
            },
            set: function(a, c, d) {
                var e = d && Ra(a);
                return y(a, c, d ? z(a, b, d, "border-box" === _.css(a, "boxSizing", !1, e), e) : 0)
            }
        }
    }), _.cssHooks.marginRight = w(Y.reliableMarginRight, function(a, b) {
        return b ? _.swap(a, {
            display: "inline-block"
        }, v, [a, "marginRight"]) : void 0
    }), _.each({
        margin: "",
        padding: "",
        border: "Width"
    }, function(a, b) {
        _.cssHooks[a + b] = {
            expand: function(c) {
                for (var d = 0, e = {}, f = "string" == typeof c ? c.split(" ") : [c]; 4 > d; d++) e[a + wa[d] + b] = f[d] || f[d - 2] || f[0];
                return e
            }
        }, Pa.test(a) || (_.cssHooks[a + b].set = y)
    }), _.fn.extend({
        css: function(a, b) {
            return qa(this, function(a, b, c) {
                var d, e, f = {},
                    g = 0;
                if (_.isArray(b)) {
                    for (d = Ra(a), e = b.length; e > g; g++) f[b[g]] = _.css(a, b[g], !1, d);
                    return f
                }
                return void 0 !== c ? _.style(a, b, c) : _.css(a, b)
            }, a, b, arguments.length > 1)
        },
        show: function() {
            return B(this, !0)
        },
        hide: function() {
            return B(this)
        },
        toggle: function(a) {
            return "boolean" == typeof a ? a ? this.show() : this.hide() : this.each(function() {
                xa(this) ? _(this).show() : _(this).hide()
            })
        }
    }), _.Tween = C, C.prototype = {
        constructor: C,
        init: function(a, b, c, d, e, f) {
            this.elem = a, this.prop = c, this.easing = e || "swing", this.options = b, this.start = this.now = this.cur(), this.end = d, this.unit = f || (_.cssNumber[c] ? "" : "px")
        },
        cur: function() {
            var a = C.propHooks[this.prop];
            return a && a.get ? a.get(this) : C.propHooks._default.get(this)
        },
        run: function(a) {
            var b, c = C.propHooks[this.prop];
            return this.options.duration ? this.pos = b = _.easing[this.easing](a, this.options.duration * a, 0, 1, this.options.duration) : this.pos = b = a, this.now = (this.end - this.start) * b + this.start, this.options.step && this.options.step.call(this.elem, this.now, this), c && c.set ? c.set(this) : C.propHooks._default.set(this), this
        }
    }, C.prototype.init.prototype = C.prototype, C.propHooks = {
        _default: {
            get: function(a) {
                var b;
                return null == a.elem[a.prop] || a.elem.style && null != a.elem.style[a.prop] ? (b = _.css(a.elem, a.prop, ""), b && "auto" !== b ? b : 0) : a.elem[a.prop]
            },
            set: function(a) {
                _.fx.step[a.prop] ? _.fx.step[a.prop](a) : a.elem.style && (null != a.elem.style[_.cssProps[a.prop]] || _.cssHooks[a.prop]) ? _.style(a.elem, a.prop, a.now + a.unit) : a.elem[a.prop] = a.now
            }
        }
    }, C.propHooks.scrollTop = C.propHooks.scrollLeft = {
        set: function(a) {
            a.elem.nodeType && a.elem.parentNode && (a.elem[a.prop] = a.now)
        }
    }, _.easing = {
        linear: function(a) {
            return a
        },
        swing: function(a) {
            return .5 - Math.cos(a * Math.PI) / 2
        }
    }, _.fx = C.prototype.init, _.fx.step = {};
    var Ya, Za, $a = /^(?:toggle|show|hide)$/,
        _a = new RegExp("^(?:([+-])=|)(" + va + ")([a-z%]*)$", "i"),
        ab = /queueHooks$/,
        bb = [G],
        cb = {
            "*": [function(a, b) {
                var c = this.createTween(a, b),
                    d = c.cur(),
                    e = _a.exec(b),
                    f = e && e[3] || (_.cssNumber[a] ? "" : "px"),
                    g = (_.cssNumber[a] || "px" !== f && +d) && _a.exec(_.css(c.elem, a)),
                    h = 1,
                    i = 20;
                if (g && g[3] !== f) {
                    f = f || g[3], e = e || [], g = +d || 1;
                    do h = h || ".5", g /= h, _.style(c.elem, a, g + f); while (h !== (h = c.cur() / d) && 1 !== h && --i)
                }
                return e && (g = c.start = +g || +d || 0, c.unit = f, c.end = e[1] ? g + (e[1] + 1) * e[2] : +e[2]), c
            }]
        };
    _.Animation = _.extend(I, {
            tweener: function(a, b) {
                _.isFunction(a) ? (b = a, a = ["*"]) : a = a.split(" ");
                for (var c, d = 0, e = a.length; e > d; d++) c = a[d], cb[c] = cb[c] || [], cb[c].unshift(b)
            },
            prefilter: function(a, b) {
                b ? bb.unshift(a) : bb.push(a)
            }
        }), _.speed = function(a, b, c) {
            var d = a && "object" == typeof a ? _.extend({}, a) : {
                complete: c || !c && b || _.isFunction(a) && a,
                duration: a,
                easing: c && b || b && !_.isFunction(b) && b
            };
            return d.duration = _.fx.off ? 0 : "number" == typeof d.duration ? d.duration : d.duration in _.fx.speeds ? _.fx.speeds[d.duration] : _.fx.speeds._default, (null == d.queue || d.queue === !0) && (d.queue = "fx"), d.old = d.complete, d.complete = function() {
                _.isFunction(d.old) && d.old.call(this), d.queue && _.dequeue(this, d.queue)
            }, d
        }, _.fn.extend({
            fadeTo: function(a, b, c, d) {
                return this.filter(xa).css("opacity", 0).show().end().animate({
                    opacity: b
                }, a, c, d)
            },
            animate: function(a, b, c, d) {
                var e = _.isEmptyObject(a),
                    f = _.speed(b, c, d),
                    g = function() {
                        var b = I(this, _.extend({}, a), f);
                        (e || ra.get(this, "finish")) && b.stop(!0)
                    };
                return g.finish = g, e || f.queue === !1 ? this.each(g) : this.queue(f.queue, g)
            },
            stop: function(a, b, c) {
                var d = function(a) {
                    var b = a.stop;
                    delete a.stop, b(c)
                };
                return "string" != typeof a && (c = b, b = a, a = void 0), b && a !== !1 && this.queue(a || "fx", []), this.each(function() {
                    var b = !0,
                        e = null != a && a + "queueHooks",
                        f = _.timers,
                        g = ra.get(this);
                    if (e) g[e] && g[e].stop && d(g[e]);
                    else
                        for (e in g) g[e] && g[e].stop && ab.test(e) && d(g[e]);
                    for (e = f.length; e--;) f[e].elem !== this || null != a && f[e].queue !== a || (f[e].anim.stop(c), b = !1, f.splice(e, 1));
                    (b || !c) && _.dequeue(this, a)
                })
            },
            finish: function(a) {
                return a !== !1 && (a = a || "fx"), this.each(function() {
                    var b, c = ra.get(this),
                        d = c[a + "queue"],
                        e = c[a + "queueHooks"],
                        f = _.timers,
                        g = d ? d.length : 0;
                    for (c.finish = !0, _.queue(this, a, []), e && e.stop && e.stop.call(this, !0), b = f.length; b--;) f[b].elem === this && f[b].queue === a && (f[b].anim.stop(!0), f.splice(b, 1));
                    for (b = 0; g > b; b++) d[b] && d[b].finish && d[b].finish.call(this);
                    delete c.finish
                })
            }
        }), _.each(["toggle", "show", "hide"], function(a, b) {
            var c = _.fn[b];
            _.fn[b] = function(a, d, e) {
                return null == a || "boolean" == typeof a ? c.apply(this, arguments) : this.animate(E(b, !0), a, d, e)
            }
        }), _.each({
            slideDown: E("show"),
            slideUp: E("hide"),
            slideToggle: E("toggle"),
            fadeIn: {
                opacity: "show"
            },
            fadeOut: {
                opacity: "hide"
            },
            fadeToggle: {
                opacity: "toggle"
            }
        }, function(a, b) {
            _.fn[a] = function(a, c, d) {
                return this.animate(b, a, c, d)
            }
        }), _.timers = [], _.fx.tick = function() {
            var a, b = 0,
                c = _.timers;
            for (Ya = _.now(); b < c.length; b++) a = c[b], a() || c[b] !== a || c.splice(b--, 1);
            c.length || _.fx.stop(), Ya = void 0
        }, _.fx.timer = function(a) {
            _.timers.push(a), a() ? _.fx.start() : _.timers.pop()
        }, _.fx.interval = 13, _.fx.start = function() {
            Za || (Za = setInterval(_.fx.tick, _.fx.interval))
        }, _.fx.stop = function() {
            clearInterval(Za), Za = null
        }, _.fx.speeds = {
            slow: 600,
            fast: 200,
            _default: 400
        }, _.fn.delay = function(a, b) {
            return a = _.fx ? _.fx.speeds[a] || a : a, b = b || "fx", this.queue(b, function(b, c) {
                var d = setTimeout(b, a);
                c.stop = function() {
                    clearTimeout(d)
                }
            })
        },
        function() {
            var a = Z.createElement("input"),
                b = Z.createElement("select"),
                c = b.appendChild(Z.createElement("option"));
            a.type = "checkbox", Y.checkOn = "" !== a.value, Y.optSelected = c.selected, b.disabled = !0, Y.optDisabled = !c.disabled, a = Z.createElement("input"), a.value = "t", a.type = "radio", Y.radioValue = "t" === a.value
        }();
    var db, eb, fb = _.expr.attrHandle;
    _.fn.extend({
        attr: function(a, b) {
            return qa(this, _.attr, a, b, arguments.length > 1)
        },
        removeAttr: function(a) {
            return this.each(function() {
                _.removeAttr(this, a)
            })
        }
    }), _.extend({
        attr: function(a, b, c) {
            var d, e, f = a.nodeType;
            return a && 3 !== f && 8 !== f && 2 !== f ? typeof a.getAttribute === za ? _.prop(a, b, c) : (1 === f && _.isXMLDoc(a) || (b = b.toLowerCase(), d = _.attrHooks[b] || (_.expr.match.bool.test(b) ? eb : db)), void 0 === c ? d && "get" in d && null !== (e = d.get(a, b)) ? e : (e = _.find.attr(a, b), null == e ? void 0 : e) : null !== c ? d && "set" in d && void 0 !== (e = d.set(a, c, b)) ? e : (a.setAttribute(b, c + ""), c) : void _.removeAttr(a, b)) : void 0
        },
        removeAttr: function(a, b) {
            var c, d, e = 0,
                f = b && b.match(na);
            if (f && 1 === a.nodeType)
                for (; c = f[e++];) d = _.propFix[c] || c, _.expr.match.bool.test(c) && (a[d] = !1), a.removeAttribute(c)
        },
        attrHooks: {
            type: {
                set: function(a, b) {
                    if (!Y.radioValue && "radio" === b && _.nodeName(a, "input")) {
                        var c = a.value;
                        return a.setAttribute("type", b), c && (a.value = c), b
                    }
                }
            }
        }
    }), eb = {
        set: function(a, b, c) {
            return b === !1 ? _.removeAttr(a, c) : a.setAttribute(c, c), c
        }
    }, _.each(_.expr.match.bool.source.match(/\w+/g), function(a, b) {
        var c = fb[b] || _.find.attr;
        fb[b] = function(a, b, d) {
            var e, f;
            return d || (f = fb[b], fb[b] = e, e = null != c(a, b, d) ? b.toLowerCase() : null, fb[b] = f), e
        }
    });
    var gb = /^(?:input|select|textarea|button)$/i;
    _.fn.extend({
        prop: function(a, b) {
            return qa(this, _.prop, a, b, arguments.length > 1)
        },
        removeProp: function(a) {
            return this.each(function() {
                delete this[_.propFix[a] || a]
            })
        }
    }), _.extend({
        propFix: {
            "for": "htmlFor",
            "class": "className"
        },
        prop: function(a, b, c) {
            var d, e, f, g = a.nodeType;
            return a && 3 !== g && 8 !== g && 2 !== g ? (f = 1 !== g || !_.isXMLDoc(a), f && (b = _.propFix[b] || b, e = _.propHooks[b]), void 0 !== c ? e && "set" in e && void 0 !== (d = e.set(a, c, b)) ? d : a[b] = c : e && "get" in e && null !== (d = e.get(a, b)) ? d : a[b]) : void 0
        },
        propHooks: {
            tabIndex: {
                get: function(a) {
                    return a.hasAttribute("tabindex") || gb.test(a.nodeName) || a.href ? a.tabIndex : -1
                }
            }
        }
    }), Y.optSelected || (_.propHooks.selected = {
        get: function(a) {
            var b = a.parentNode;
            return b && b.parentNode && b.parentNode.selectedIndex, null
        }
    }), _.each(["tabIndex", "readOnly", "maxLength", "cellSpacing", "cellPadding", "rowSpan", "colSpan", "useMap", "frameBorder", "contentEditable"], function() {
        _.propFix[this.toLowerCase()] = this
    });
    var hb = /[\t\r\n\f]/g;
    _.fn.extend({
        addClass: function(a) {
            var b, c, d, e, f, g, h = "string" == typeof a && a,
                i = 0,
                j = this.length;
            if (_.isFunction(a)) return this.each(function(b) {
                _(this).addClass(a.call(this, b, this.className))
            });
            if (h)
                for (b = (a || "").match(na) || []; j > i; i++)
                    if (c = this[i], d = 1 === c.nodeType && (c.className ? (" " + c.className + " ").replace(hb, " ") : " ")) {
                        for (f = 0; e = b[f++];) d.indexOf(" " + e + " ") < 0 && (d += e + " ");
                        g = _.trim(d), c.className !== g && (c.className = g)
                    }
            return this
        },
        removeClass: function(a) {
            var b, c, d, e, f, g, h = 0 === arguments.length || "string" == typeof a && a,
                i = 0,
                j = this.length;
            if (_.isFunction(a)) return this.each(function(b) {
                _(this).removeClass(a.call(this, b, this.className))
            });
            if (h)
                for (b = (a || "").match(na) || []; j > i; i++)
                    if (c = this[i], d = 1 === c.nodeType && (c.className ? (" " + c.className + " ").replace(hb, " ") : "")) {
                        for (f = 0; e = b[f++];)
                            for (; d.indexOf(" " + e + " ") >= 0;) d = d.replace(" " + e + " ", " ");
                        g = a ? _.trim(d) : "", c.className !== g && (c.className = g)
                    }
            return this
        },
        toggleClass: function(a, b) {
            var c = typeof a;
            return "boolean" == typeof b && "string" === c ? b ? this.addClass(a) : this.removeClass(a) : this.each(_.isFunction(a) ? function(c) {
                _(this).toggleClass(a.call(this, c, this.className, b), b)
            } : function() {
                if ("string" === c)
                    for (var b, d = 0, e = _(this), f = a.match(na) || []; b = f[d++];) e.hasClass(b) ? e.removeClass(b) : e.addClass(b);
                else(c === za || "boolean" === c) && (this.className && ra.set(this, "__className__", this.className), this.className = this.className || a === !1 ? "" : ra.get(this, "__className__") || "")
            })
        },
        hasClass: function(a) {
            for (var b = " " + a + " ", c = 0, d = this.length; d > c; c++)
                if (1 === this[c].nodeType && (" " + this[c].className + " ").replace(hb, " ").indexOf(b) >= 0) return !0;
            return !1
        }
    });
    var ib = /\r/g;
    _.fn.extend({
        val: function(a) {
            var b, c, d, e = this[0];
            return arguments.length ? (d = _.isFunction(a), this.each(function(c) {
                var e;
                1 === this.nodeType && (e = d ? a.call(this, c, _(this).val()) : a, null == e ? e = "" : "number" == typeof e ? e += "" : _.isArray(e) && (e = _.map(e, function(a) {
                    return null == a ? "" : a + ""
                })), b = _.valHooks[this.type] || _.valHooks[this.nodeName.toLowerCase()], b && "set" in b && void 0 !== b.set(this, e, "value") || (this.value = e))
            })) : e ? (b = _.valHooks[e.type] || _.valHooks[e.nodeName.toLowerCase()], b && "get" in b && void 0 !== (c = b.get(e, "value")) ? c : (c = e.value, "string" == typeof c ? c.replace(ib, "") : null == c ? "" : c)) : void 0
        }
    }), _.extend({
        valHooks: {
            option: {
                get: function(a) {
                    var b = _.find.attr(a, "value");
                    return null != b ? b : _.trim(_.text(a))
                }
            },
            select: {
                get: function(a) {
                    for (var b, c, d = a.options, e = a.selectedIndex, f = "select-one" === a.type || 0 > e, g = f ? null : [], h = f ? e + 1 : d.length, i = 0 > e ? h : f ? e : 0; h > i; i++)
                        if (c = d[i], !(!c.selected && i !== e || (Y.optDisabled ? c.disabled : null !== c.getAttribute("disabled")) || c.parentNode.disabled && _.nodeName(c.parentNode, "optgroup"))) {
                            if (b = _(c).val(), f) return b;
                            g.push(b)
                        }
                    return g
                },
                set: function(a, b) {
                    for (var c, d, e = a.options, f = _.makeArray(b), g = e.length; g--;) d = e[g], (d.selected = _.inArray(d.value, f) >= 0) && (c = !0);
                    return c || (a.selectedIndex = -1), f
                }
            }
        }
    }), _.each(["radio", "checkbox"], function() {
        _.valHooks[this] = {
            set: function(a, b) {
                return _.isArray(b) ? a.checked = _.inArray(_(a).val(), b) >= 0 : void 0
            }
        }, Y.checkOn || (_.valHooks[this].get = function(a) {
            return null === a.getAttribute("value") ? "on" : a.value
        })
    }), _.each("blur focus focusin focusout load resize scroll unload click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup error contextmenu".split(" "), function(a, b) {
        _.fn[b] = function(a, c) {
            return arguments.length > 0 ? this.on(b, null, a, c) : this.trigger(b)
        }
    }), _.fn.extend({
        hover: function(a, b) {
            return this.mouseenter(a).mouseleave(b || a)
        },
        bind: function(a, b, c) {
            return this.on(a, null, b, c)
        },
        unbind: function(a, b) {
            return this.off(a, null, b)
        },
        delegate: function(a, b, c, d) {
            return this.on(b, a, c, d)
        },
        undelegate: function(a, b, c) {
            return 1 === arguments.length ? this.off(a, "**") : this.off(b, a || "**", c)
        }
    });
    var jb = _.now(),
        kb = /\?/;
    _.parseJSON = function(a) {
        return JSON.parse(a + "")
    }, _.parseXML = function(a) {
        var b, c;
        if (!a || "string" != typeof a) return null;
        try {
            c = new DOMParser, b = c.parseFromString(a, "text/xml")
        } catch (d) {
            b = void 0
        }
        return (!b || b.getElementsByTagName("parsererror").length) && _.error("Invalid XML: " + a), b
    };
    var lb = /#.*$/,
        mb = /([?&])_=[^&]*/,
        nb = /^(.*?):[ \t]*([^\r\n]*)$/gm,
        ob = /^(?:about|app|app-storage|.+-extension|file|res|widget):$/,
        pb = /^(?:GET|HEAD)$/,
        qb = /^\/\//,
        rb = /^([\w.+-]+:)(?:\/\/(?:[^\/?#]*@|)([^\/?#:]*)(?::(\d+)|)|)/,
        sb = {},
        tb = {},
        ub = "*/".concat("*"),
        vb = a.location.href,
        wb = rb.exec(vb.toLowerCase()) || [];
    _.extend({
        active: 0,
        lastModified: {},
        etag: {},
        ajaxSettings: {
            url: vb,
            type: "GET",
            isLocal: ob.test(wb[1]),
            global: !0,
            processData: !0,
            async: !0,
            contentType: "application/x-www-form-urlencoded; charset=UTF-8",
            accepts: {
                "*": ub,
                text: "text/plain",
                html: "text/html",
                xml: "application/xml, text/xml",
                json: "application/json, text/javascript"
            },
            contents: {
                xml: /xml/,
                html: /html/,
                json: /json/
            },
            responseFields: {
                xml: "responseXML",
                text: "responseText",
                json: "responseJSON"
            },
            converters: {
                "* text": String,
                "text html": !0,
                "text json": _.parseJSON,
                "text xml": _.parseXML
            },
            flatOptions: {
                url: !0,
                context: !0
            }
        },
        ajaxSetup: function(a, b) {
            return b ? L(L(a, _.ajaxSettings), b) : L(_.ajaxSettings, a)
        },
        ajaxPrefilter: J(sb),
        ajaxTransport: J(tb),
        ajax: function(a, b) {
            function c(a, b, c, g) {
                var i, k, r, s, u, w = b;
                2 !== t && (t = 2, h && clearTimeout(h), d = void 0, f = g || "", v.readyState = a > 0 ? 4 : 0, i = a >= 200 && 300 > a || 304 === a, c && (s = M(l, v, c)), s = N(l, s, v, i), i ? (l.ifModified && (u = v.getResponseHeader("Last-Modified"), u && (_.lastModified[e] = u), u = v.getResponseHeader("etag"), u && (_.etag[e] = u)), 204 === a || "HEAD" === l.type ? w = "nocontent" : 304 === a ? w = "notmodified" : (w = s.state, k = s.data, r = s.error, i = !r)) : (r = w, (a || !w) && (w = "error", 0 > a && (a = 0))), v.status = a, v.statusText = (b || w) + "", i ? o.resolveWith(m, [k, w, v]) : o.rejectWith(m, [v, w, r]), v.statusCode(q), q = void 0, j && n.trigger(i ? "ajaxSuccess" : "ajaxError", [v, l, i ? k : r]), p.fireWith(m, [v, w]), j && (n.trigger("ajaxComplete", [v, l]), --_.active || _.event.trigger("ajaxStop")))
            }
            "object" == typeof a && (b = a, a = void 0), b = b || {};
            var d, e, f, g, h, i, j, k, l = _.ajaxSetup({}, b),
                m = l.context || l,
                n = l.context && (m.nodeType || m.jquery) ? _(m) : _.event,
                o = _.Deferred(),
                p = _.Callbacks("once memory"),
                q = l.statusCode || {},
                r = {},
                s = {},
                t = 0,
                u = "canceled",
                v = {
                    readyState: 0,
                    getResponseHeader: function(a) {
                        var b;
                        if (2 === t) {
                            if (!g)
                                for (g = {}; b = nb.exec(f);) g[b[1].toLowerCase()] = b[2];
                            b = g[a.toLowerCase()]
                        }
                        return null == b ? null : b
                    },
                    getAllResponseHeaders: function() {
                        return 2 === t ? f : null
                    },
                    setRequestHeader: function(a, b) {
                        var c = a.toLowerCase();
                        return t || (a = s[c] = s[c] || a, r[a] = b), this
                    },
                    overrideMimeType: function(a) {
                        return t || (l.mimeType = a), this
                    },
                    statusCode: function(a) {
                        var b;
                        if (a)
                            if (2 > t)
                                for (b in a) q[b] = [q[b], a[b]];
                            else v.always(a[v.status]);
                        return this
                    },
                    abort: function(a) {
                        var b = a || u;
                        return d && d.abort(b), c(0, b), this
                    }
                };
            if (o.promise(v).complete = p.add, v.success = v.done, v.error = v.fail, l.url = ((a || l.url || vb) + "").replace(lb, "").replace(qb, wb[1] + "//"), l.type = b.method || b.type || l.method || l.type, l.dataTypes = _.trim(l.dataType || "*").toLowerCase().match(na) || [""], null == l.crossDomain && (i = rb.exec(l.url.toLowerCase()), l.crossDomain = !(!i || i[1] === wb[1] && i[2] === wb[2] && (i[3] || ("http:" === i[1] ? "80" : "443")) === (wb[3] || ("http:" === wb[1] ? "80" : "443")))), l.data && l.processData && "string" != typeof l.data && (l.data = _.param(l.data, l.traditional)), K(sb, l, b, v), 2 === t) return v;
            j = _.event && l.global, j && 0 === _.active++ && _.event.trigger("ajaxStart"), l.type = l.type.toUpperCase(), l.hasContent = !pb.test(l.type), e = l.url, l.hasContent || (l.data && (e = l.url += (kb.test(e) ? "&" : "?") + l.data, delete l.data), l.cache === !1 && (l.url = mb.test(e) ? e.replace(mb, "$1_=" + jb++) : e + (kb.test(e) ? "&" : "?") + "_=" + jb++)), l.ifModified && (_.lastModified[e] && v.setRequestHeader("If-Modified-Since", _.lastModified[e]), _.etag[e] && v.setRequestHeader("If-None-Match", _.etag[e])), (l.data && l.hasContent && l.contentType !== !1 || b.contentType) && v.setRequestHeader("Content-Type", l.contentType), v.setRequestHeader("Accept", l.dataTypes[0] && l.accepts[l.dataTypes[0]] ? l.accepts[l.dataTypes[0]] + ("*" !== l.dataTypes[0] ? ", " + ub + "; q=0.01" : "") : l.accepts["*"]);
            for (k in l.headers) v.setRequestHeader(k, l.headers[k]);
            if (l.beforeSend && (l.beforeSend.call(m, v, l) === !1 || 2 === t)) return v.abort();
            u = "abort";
            for (k in {
                    success: 1,
                    error: 1,
                    complete: 1
                }) v[k](l[k]);
            if (d = K(tb, l, b, v)) {
                v.readyState = 1, j && n.trigger("ajaxSend", [v, l]), l.async && l.timeout > 0 && (h = setTimeout(function() {
                    v.abort("timeout")
                }, l.timeout));
                try {
                    t = 1, d.send(r, c)
                } catch (w) {
                    if (!(2 > t)) throw w;
                    c(-1, w)
                }
            } else c(-1, "No Transport");
            return v
        },
        getJSON: function(a, b, c) {
            return _.get(a, b, c, "json")
        },
        getScript: function(a, b) {
            return _.get(a, void 0, b, "script")
        }
    }), _.each(["get", "post"], function(a, b) {
        _[b] = function(a, c, d, e) {
            return _.isFunction(c) && (e = e || d, d = c, c = void 0), _.ajax({
                url: a,
                type: b,
                dataType: e,
                data: c,
                success: d
            })
        }
    }), _._evalUrl = function(a) {
        return _.ajax({
            url: a,
            type: "GET",
            dataType: "script",
            async: !1,
            global: !1,
            "throws": !0
        })
    }, _.fn.extend({
        wrapAll: function(a) {
            var b;
            return _.isFunction(a) ? this.each(function(b) {
                _(this).wrapAll(a.call(this, b))
            }) : (this[0] && (b = _(a, this[0].ownerDocument).eq(0).clone(!0), this[0].parentNode && b.insertBefore(this[0]), b.map(function() {
                for (var a = this; a.firstElementChild;) a = a.firstElementChild;
                return a
            }).append(this)), this)
        },
        wrapInner: function(a) {
            return this.each(_.isFunction(a) ? function(b) {
                _(this).wrapInner(a.call(this, b))
            } : function() {
                var b = _(this),
                    c = b.contents();
                c.length ? c.wrapAll(a) : b.append(a)
            })
        },
        wrap: function(a) {
            var b = _.isFunction(a);
            return this.each(function(c) {
                _(this).wrapAll(b ? a.call(this, c) : a)
            })
        },
        unwrap: function() {
            return this.parent().each(function() {
                _.nodeName(this, "body") || _(this).replaceWith(this.childNodes)
            }).end()
        }
    }), _.expr.filters.hidden = function(a) {
        return a.offsetWidth <= 0 && a.offsetHeight <= 0
    }, _.expr.filters.visible = function(a) {
        return !_.expr.filters.hidden(a)
    };
    var xb = /%20/g,
        yb = /\[\]$/,
        zb = /\r?\n/g,
        Ab = /^(?:submit|button|image|reset|file)$/i,
        Bb = /^(?:input|select|textarea|keygen)/i;
    _.param = function(a, b) {
        var c, d = [],
            e = function(a, b) {
                b = _.isFunction(b) ? b() : null == b ? "" : b, d[d.length] = encodeURIComponent(a) + "=" + encodeURIComponent(b)
            };
        if (void 0 === b && (b = _.ajaxSettings && _.ajaxSettings.traditional), _.isArray(a) || a.jquery && !_.isPlainObject(a)) _.each(a, function() {
            e(this.name, this.value)
        });
        else
            for (c in a) O(c, a[c], b, e);
        return d.join("&").replace(xb, "+")
    }, _.fn.extend({
        serialize: function() {
            return _.param(this.serializeArray())
        },
        serializeArray: function() {
            return this.map(function() {
                var a = _.prop(this, "elements");
                return a ? _.makeArray(a) : this
            }).filter(function() {
                var a = this.type;
                return this.name && !_(this).is(":disabled") && Bb.test(this.nodeName) && !Ab.test(a) && (this.checked || !ya.test(a))
            }).map(function(a, b) {
                var c = _(this).val();
                return null == c ? null : _.isArray(c) ? _.map(c, function(a) {
                    return {
                        name: b.name,
                        value: a.replace(zb, "\r\n")
                    }
                }) : {
                    name: b.name,
                    value: c.replace(zb, "\r\n")
                }
            }).get()
        }
    }), _.ajaxSettings.xhr = function() {
        try {
            return new XMLHttpRequest
        } catch (a) {}
    };
    var Cb = 0,
        Db = {},
        Eb = {
            0: 200,
            1223: 204
        },
        Fb = _.ajaxSettings.xhr();
    a.attachEvent && a.attachEvent("onunload", function() {
        for (var a in Db) Db[a]()
    }), Y.cors = !!Fb && "withCredentials" in Fb, Y.ajax = Fb = !!Fb, _.ajaxTransport(function(a) {
        var b;
        return Y.cors || Fb && !a.crossDomain ? {
            send: function(c, d) {
                var e, f = a.xhr(),
                    g = ++Cb;
                if (f.open(a.type, a.url, a.async, a.username, a.password), a.xhrFields)
                    for (e in a.xhrFields) f[e] = a.xhrFields[e];
                a.mimeType && f.overrideMimeType && f.overrideMimeType(a.mimeType), a.crossDomain || c["X-Requested-With"] || (c["X-Requested-With"] = "XMLHttpRequest");
                for (e in c) f.setRequestHeader(e, c[e]);
                b = function(a) {
                    return function() {
                        b && (delete Db[g], b = f.onload = f.onerror = null, "abort" === a ? f.abort() : "error" === a ? d(f.status, f.statusText) : d(Eb[f.status] || f.status, f.statusText, "string" == typeof f.responseText ? {
                            text: f.responseText
                        } : void 0, f.getAllResponseHeaders()))
                    }
                }, f.onload = b(), f.onerror = b("error"), b = Db[g] = b("abort");
                try {
                    f.send(a.hasContent && a.data || null)
                } catch (h) {
                    if (b) throw h
                }
            },
            abort: function() {
                b && b()
            }
        } : void 0
    }), _.ajaxSetup({
        accepts: {
            script: "text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"
        },
        contents: {
            script: /(?:java|ecma)script/
        },
        converters: {
            "text script": function(a) {
                return _.globalEval(a), a
            }
        }
    }), _.ajaxPrefilter("script", function(a) {
        void 0 === a.cache && (a.cache = !1), a.crossDomain && (a.type = "GET")
    }), _.ajaxTransport("script", function(a) {
        if (a.crossDomain) {
            var b, c;
            return {
                send: function(d, e) {
                    b = _("<script>").prop({
                        async: !0,
                        charset: a.scriptCharset,
                        src: a.url
                    }).on("load error", c = function(a) {
                        b.remove(), c = null, a && e("error" === a.type ? 404 : 200, a.type)
                    }), Z.head.appendChild(b[0])
                },
                abort: function() {
                    c && c()
                }
            }
        }
    });
    var Gb = [],
        Hb = /(=)\?(?=&|$)|\?\?/;
    _.ajaxSetup({
        jsonp: "callback",
        jsonpCallback: function() {
            var a = Gb.pop() || _.expando + "_" + jb++;
            return this[a] = !0, a
        }
    }), _.ajaxPrefilter("json jsonp", function(b, c, d) {
        var e, f, g, h = b.jsonp !== !1 && (Hb.test(b.url) ? "url" : "string" == typeof b.data && !(b.contentType || "").indexOf("application/x-www-form-urlencoded") && Hb.test(b.data) && "data");
        return h || "jsonp" === b.dataTypes[0] ? (e = b.jsonpCallback = _.isFunction(b.jsonpCallback) ? b.jsonpCallback() : b.jsonpCallback, h ? b[h] = b[h].replace(Hb, "$1" + e) : b.jsonp !== !1 && (b.url += (kb.test(b.url) ? "&" : "?") + b.jsonp + "=" + e), b.converters["script json"] = function() {
            return g || _.error(e + " was not called"), g[0]
        }, b.dataTypes[0] = "json", f = a[e], a[e] = function() {
            g = arguments
        }, d.always(function() {
            a[e] = f, b[e] && (b.jsonpCallback = c.jsonpCallback, Gb.push(e)), g && _.isFunction(f) && f(g[0]), g = f = void 0
        }), "script") : void 0
    }), _.parseHTML = function(a, b, c) {
        if (!a || "string" != typeof a) return null;
        "boolean" == typeof b && (c = b, b = !1), b = b || Z;
        var d = ga.exec(a),
            e = !c && [];
        return d ? [b.createElement(d[1])] : (d = _.buildFragment([a], b, e), e && e.length && _(e).remove(), _.merge([], d.childNodes))
    };
    var Ib = _.fn.load;
    _.fn.load = function(a, b, c) {
        if ("string" != typeof a && Ib) return Ib.apply(this, arguments);
        var d, e, f, g = this,
            h = a.indexOf(" ");
        return h >= 0 && (d = _.trim(a.slice(h)), a = a.slice(0, h)), _.isFunction(b) ? (c = b, b = void 0) : b && "object" == typeof b && (e = "POST"), g.length > 0 && _.ajax({
            url: a,
            type: e,
            dataType: "html",
            data: b
        }).done(function(a) {
            f = arguments, g.html(d ? _("<div>").append(_.parseHTML(a)).find(d) : a)
        }).complete(c && function(a, b) {
            g.each(c, f || [a.responseText, b, a])
        }), this
    }, _.each(["ajaxStart", "ajaxStop", "ajaxComplete", "ajaxError", "ajaxSuccess", "ajaxSend"], function(a, b) {
        _.fn[b] = function(a) {
            return this.on(b, a)
        }
    }), _.expr.filters.animated = function(a) {
        return _.grep(_.timers, function(b) {
            return a === b.elem
        }).length
    };
    var Jb = a.document.documentElement;
    _.offset = {
        setOffset: function(a, b, c) {
            var d, e, f, g, h, i, j, k = _.css(a, "position"),
                l = _(a),
                m = {};
            "static" === k && (a.style.position = "relative"), h = l.offset(), f = _.css(a, "top"), i = _.css(a, "left"), j = ("absolute" === k || "fixed" === k) && (f + i).indexOf("auto") > -1, j ? (d = l.position(), g = d.top, e = d.left) : (g = parseFloat(f) || 0, e = parseFloat(i) || 0), _.isFunction(b) && (b = b.call(a, c, h)), null != b.top && (m.top = b.top - h.top + g), null != b.left && (m.left = b.left - h.left + e), "using" in b ? b.using.call(a, m) : l.css(m)
        }
    }, _.fn.extend({
        offset: function(a) {
            if (arguments.length) return void 0 === a ? this : this.each(function(b) {
                _.offset.setOffset(this, a, b)
            });
            var b, c, d = this[0],
                e = {
                    top: 0,
                    left: 0
                },
                f = d && d.ownerDocument;
            return f ? (b = f.documentElement, _.contains(b, d) ? (typeof d.getBoundingClientRect !== za && (e = d.getBoundingClientRect()), c = P(f), {
                top: e.top + c.pageYOffset - b.clientTop,
                left: e.left + c.pageXOffset - b.clientLeft
            }) : e) : void 0
        },
        position: function() {
            if (this[0]) {
                var a, b, c = this[0],
                    d = {
                        top: 0,
                        left: 0
                    };
                return "fixed" === _.css(c, "position") ? b = c.getBoundingClientRect() : (a = this.offsetParent(), b = this.offset(), _.nodeName(a[0], "html") || (d = a.offset()), d.top += _.css(a[0], "borderTopWidth", !0), d.left += _.css(a[0], "borderLeftWidth", !0)), {
                    top: b.top - d.top - _.css(c, "marginTop", !0),
                    left: b.left - d.left - _.css(c, "marginLeft", !0)
                }
            }
        },
        offsetParent: function() {
            return this.map(function() {
                for (var a = this.offsetParent || Jb; a && !_.nodeName(a, "html") && "static" === _.css(a, "position");) a = a.offsetParent;
                return a || Jb
            })
        }
    }), _.each({
        scrollLeft: "pageXOffset",
        scrollTop: "pageYOffset"
    }, function(b, c) {
        var d = "pageYOffset" === c;
        _.fn[b] = function(e) {
            return qa(this, function(b, e, f) {
                var g = P(b);
                return void 0 === f ? g ? g[c] : b[e] : void(g ? g.scrollTo(d ? a.pageXOffset : f, d ? f : a.pageYOffset) : b[e] = f)
            }, b, e, arguments.length, null)
        }
    }), _.each(["top", "left"], function(a, b) {
        _.cssHooks[b] = w(Y.pixelPosition, function(a, c) {
            return c ? (c = v(a, b), Qa.test(c) ? _(a).position()[b] + "px" : c) : void 0
        })
    }), _.each({
        Height: "height",
        Width: "width"
    }, function(a, b) {
        _.each({
            padding: "inner" + a,
            content: b,
            "": "outer" + a
        }, function(c, d) {
            _.fn[d] = function(d, e) {
                var f = arguments.length && (c || "boolean" != typeof d),
                    g = c || (d === !0 || e === !0 ? "margin" : "border");
                return qa(this, function(b, c, d) {
                    var e;
                    return _.isWindow(b) ? b.document.documentElement["client" + a] : 9 === b.nodeType ? (e = b.documentElement, Math.max(b.body["scroll" + a], e["scroll" + a], b.body["offset" + a], e["offset" + a], e["client" + a])) : void 0 === d ? _.css(b, c, g) : _.style(b, c, d, g)
                }, b, f ? d : void 0, f, null)
            }
        })
    }), _.fn.size = function() {
        return this.length
    }, _.fn.andSelf = _.fn.addBack, "function" == typeof define && define.amd && define("jquery", [], function() {
        return _
    });
    var Kb = a.jQuery,
        Lb = a.$;
    return _.noConflict = function(b) {
        return a.$ === _ && (a.$ = Lb), b && a.jQuery === _ && (a.jQuery = Kb), _
    }, typeof b === za && (a.jQuery = a.$ = _), _
}),
function(a, b, c) {
    "use strict";

    function d(a) {
        return function() {
            var b, c, d = arguments[0],
                e = "[" + (a ? a + ":" : "") + d + "] ",
                f = arguments[1],
                g = arguments,
                h = function(a) {
                    return "function" == typeof a ? a.toString().replace(/ \{[\s\S]*$/, "") : "undefined" == typeof a ? "undefined" : "string" != typeof a ? JSON.stringify(a) : a
                };
            for (b = e + f.replace(/\{\d+\}/g, function(a) {
                    var b, c = +a.slice(1, -1);
                    return c + 2 < g.length ? (b = g[c + 2], "function" == typeof b ? b.toString().replace(/ ?\{[\s\S]*$/, "") : "undefined" == typeof b ? "undefined" : "string" != typeof b ? Q(b) : b) : a
                }), b = b + "\nhttp://errors.angularjs.org/1.2.30/" + (a ? a + "/" : "") + d, c = 2; c < arguments.length; c++) b = b + (2 == c ? "?" : "&") + "p" + (c - 2) + "=" + encodeURIComponent(h(arguments[c]));
            return new Error(b)
        }
    }

    function e(a) {
        if (null == a || z(a)) return !1;
        var b = a.length;
        return 1 === a.nodeType && b ? !0 : u(a) || Gc(a) || 0 === b || "number" == typeof b && b > 0 && b - 1 in a
    }

    function f(a, b, c) {
        var d;
        if (a)
            if (x(a))
                for (d in a) "prototype" == d || "length" == d || "name" == d || a.hasOwnProperty && !a.hasOwnProperty(d) || b.call(c, a[d], d);
            else if (Gc(a) || e(a))
            for (d = 0; d < a.length; d++) b.call(c, a[d], d);
        else if (a.forEach && a.forEach !== f) a.forEach(b, c);
        else
            for (d in a) a.hasOwnProperty(d) && b.call(c, a[d], d);
        return a
    }

    function g(a) {
        var b = [];
        for (var c in a) a.hasOwnProperty(c) && b.push(c);
        return b.sort()
    }

    function h(a, b, c) {
        for (var d = g(a), e = 0; e < d.length; e++) b.call(c, a[d[e]], d[e]);
        return d
    }

    function i(a) {
        return function(b, c) {
            a(c, b)
        }
    }

    function j() {
        for (var a, b = Fc.length; b;) {
            if (b--, a = Fc[b].charCodeAt(0), 57 == a) return Fc[b] = "A", Fc.join("");
            if (90 != a) return Fc[b] = String.fromCharCode(a + 1), Fc.join("");
            Fc[b] = "0"
        }
        return Fc.unshift("0"), Fc.join("")
    }

    function k(a, b) {
        b ? a.$$hashKey = b : delete a.$$hashKey
    }

    function l(a) {
        var b = a.$$hashKey;
        return f(arguments, function(b) {
            b !== a && f(b, function(b, c) {
                a[c] = b
            })
        }), k(a, b), a
    }

    function m(a) {
        return parseInt(a, 10)
    }

    function n(a, b) {
        return l(new(l(function() {}, {
            prototype: a
        })), b)
    }

    function o() {}

    function p(a) {
        return a
    }

    function q(a) {
        return function() {
            return a
        }
    }

    function r(a) {
        return "undefined" == typeof a
    }

    function s(a) {
        return "undefined" != typeof a
    }

    function t(a) {
        return null != a && "object" == typeof a
    }

    function u(a) {
        return "string" == typeof a
    }

    function v(a) {
        return "number" == typeof a
    }

    function w(a) {
        return "[object Date]" === Cc.call(a)
    }

    function x(a) {
        return "function" == typeof a
    }

    function y(a) {
        return "[object RegExp]" === Cc.call(a)
    }

    function z(a) {
        return a && a.document && a.location && a.alert && a.setInterval
    }

    function A(a) {
        return a && a.$evalAsync && a.$watch
    }

    function B(a) {
        return "[object File]" === Cc.call(a)
    }

    function C(a) {
        return "[object Blob]" === Cc.call(a)
    }

    function D(a) {
        return a && x(a.then)
    }

    function E(a) {
        return !(!a || !(a.nodeName || a.prop && a.attr && a.find))
    }

    function F(a, b, c) {
        var d = [];
        return f(a, function(a, e, f) {
            d.push(b.call(c, a, e, f))
        }), d
    }

    function G(a, b) {
        return -1 != H(a, b)
    }

    function H(a, b) {
        if (a.indexOf) return a.indexOf(b);
        for (var c = 0; c < a.length; c++)
            if (b === a[c]) return c;
        return -1
    }

    function I(a, b) {
        var c = H(a, b);
        return c >= 0 && a.splice(c, 1), b
    }

    function J(a, b, c, d) {
        if (z(a) || A(a)) throw Dc("cpws", "Can't copy! Making copies of Window or Scope instances is not supported.");
        if (b) {
            if (a === b) throw Dc("cpi", "Can't copy! Source and destination are identical.");
            if (c = c || [], d = d || [], t(a)) {
                var e = H(c, a);
                if (-1 !== e) return d[e];
                c.push(a), d.push(b)
            }
            var g;
            if (Gc(a)) {
                b.length = 0;
                for (var h = 0; h < a.length; h++) g = J(a[h], null, c, d), t(a[h]) && (c.push(a[h]), d.push(g)), b.push(g)
            } else {
                var i = b.$$hashKey;
                Gc(b) ? b.length = 0 : f(b, function(a, c) {
                    delete b[c]
                });
                for (var j in a) g = J(a[j], null, c, d), t(a[j]) && (c.push(a[j]), d.push(g)), b[j] = g;
                k(b, i)
            }
        } else b = a, a && (Gc(a) ? b = J(a, [], c, d) : w(a) ? b = new Date(a.getTime()) : y(a) ? (b = new RegExp(a.source, a.toString().match(/[^\/]*$/)[0]), b.lastIndex = a.lastIndex) : t(a) && (b = J(a, {}, c, d)));
        return b
    }

    function K(a, b) {
        if (Gc(a)) {
            b = b || [];
            for (var c = 0; c < a.length; c++) b[c] = a[c]
        } else if (t(a)) {
            b = b || {};
            for (var d in a) !rc.call(a, d) || "$" === d.charAt(0) && "$" === d.charAt(1) || (b[d] = a[d])
        }
        return b || a
    }

    function L(a, b) {
        if (a === b) return !0;
        if (null === a || null === b) return !1;
        if (a !== a && b !== b) return !0;
        var d, e, f, g = typeof a,
            h = typeof b;
        if (g == h && "object" == g) {
            if (!Gc(a)) {
                if (w(a)) return w(b) ? isNaN(a.getTime()) && isNaN(b.getTime()) || a.getTime() === b.getTime() : !1;
                if (y(a) && y(b)) return a.toString() == b.toString();
                if (A(a) || A(b) || z(a) || z(b) || Gc(b)) return !1;
                f = {};
                for (e in a)
                    if ("$" !== e.charAt(0) && !x(a[e])) {
                        if (!L(a[e], b[e])) return !1;
                        f[e] = !0
                    }
                for (e in b)
                    if (!f.hasOwnProperty(e) && "$" !== e.charAt(0) && b[e] !== c && !x(b[e])) return !1;
                return !0
            }
            if (!Gc(b)) return !1;
            if ((d = a.length) == b.length) {
                for (e = 0; d > e; e++)
                    if (!L(a[e], b[e])) return !1;
                return !0
            }
        }
        return !1
    }

    function M(a, b, c) {
        return a.concat(Ac.call(b, c))
    }

    function N(a, b) {
        return Ac.call(a, b || 0)
    }

    function O(a, b) {
        var c = arguments.length > 2 ? N(arguments, 2) : [];
        return !x(b) || b instanceof RegExp ? b : c.length ? function() {
            return arguments.length ? b.apply(a, c.concat(Ac.call(arguments, 0))) : b.apply(a, c)
        } : function() {
            return arguments.length ? b.apply(a, arguments) : b.call(a)
        }
    }

    function P(a, d) {
        var e = d;
        return "string" == typeof a && "$" === a.charAt(0) ? e = c : z(d) ? e = "$WINDOW" : d && b === d ? e = "$DOCUMENT" : A(d) && (e = "$SCOPE"), e
    }

    function Q(a, b) {
        return "undefined" == typeof a ? c : JSON.stringify(a, P, b ? "  " : null)
    }

    function R(a) {
        return u(a) ? JSON.parse(a) : a
    }

    function S(a) {
        if ("function" == typeof a) a = !0;
        else if (a && 0 !== a.length) {
            var b = qc("" + a);
            a = !("f" == b || "0" == b || "false" == b || "no" == b || "n" == b || "[]" == b)
        } else a = !1;
        return a
    }

    function T(a) {
        a = wc(a).clone();
        try {
            a.empty()
        } catch (b) {}
        var c = 3,
            d = wc("<div>").append(a).html();
        try {
            return a[0].nodeType === c ? qc(d) : d.match(/^(<[^>]+>)/)[1].replace(/^<([\w\-]+)/, function(a, b) {
                return "<" + qc(b)
            })
        } catch (b) {
            return qc(d)
        }
    }

    function U(a) {
        try {
            return decodeURIComponent(a)
        } catch (b) {}
    }

    function V(a) {
        var b, c, d = {};
        return f((a || "").split("&"), function(a) {
            if (a && (b = a.replace(/\+/g, "%20").split("="), c = U(b[0]), s(c))) {
                var e = s(b[1]) ? U(b[1]) : !0;
                rc.call(d, c) ? Gc(d[c]) ? d[c].push(e) : d[c] = [d[c], e] : d[c] = e
            }
        }), d
    }

    function W(a) {
        var b = [];
        return f(a, function(a, c) {
            Gc(a) ? f(a, function(a) {
                b.push(Y(c, !0) + (a === !0 ? "" : "=" + Y(a, !0)))
            }) : b.push(Y(c, !0) + (a === !0 ? "" : "=" + Y(a, !0)))
        }), b.length ? b.join("&") : ""
    }

    function X(a) {
        return Y(a, !0).replace(/%26/gi, "&").replace(/%3D/gi, "=").replace(/%2B/gi, "+")
    }

    function Y(a, b) {
        return encodeURIComponent(a).replace(/%40/gi, "@").replace(/%3A/gi, ":").replace(/%24/g, "$").replace(/%2C/gi, ",").replace(/%20/g, b ? "%20" : "+")
    }

    function Z(a, c) {
        function d(a) {
            a && h.push(a)
        }
        var e, g, h = [a],
            i = ["ng:app", "ng-app", "x-ng-app", "data-ng-app"],
            j = /\sng[:\-]app(:\s*([\w\d_]+);?)?\s/;
        f(i, function(c) {
            i[c] = !0, d(b.getElementById(c)), c = c.replace(":", "\\:"), a.querySelectorAll && (f(a.querySelectorAll("." + c), d), f(a.querySelectorAll("." + c + "\\:"), d), f(a.querySelectorAll("[" + c + "]"), d))
        }), f(h, function(a) {
            if (!e) {
                var b = " " + a.className + " ",
                    c = j.exec(b);
                c ? (e = a, g = (c[2] || "").replace(/\s+/g, ",")) : f(a.attributes, function(b) {
                    !e && i[b.name] && (e = a, g = b.value)
                })
            }
        }), e && c(e, g ? [g] : [])
    }

    function $(c, d) {
        var e = function() {
                if (c = wc(c), c.injector()) {
                    var a = c[0] === b ? "document" : T(c);
                    throw Dc("btstrpd", "App Already Bootstrapped with this Element '{0}'", a.replace(/</, "&lt;").replace(/>/, "&gt;"))
                }
                d = d || [], d.unshift(["$provide", function(a) {
                    a.value("$rootElement", c)
                }]), d.unshift("ng");
                var e = Ha(d);
                return e.invoke(["$rootScope", "$rootElement", "$compile", "$injector", "$animate", function(a, b, c, d, e) {
                    a.$apply(function() {
                        b.data("$injector", d), c(b)(a)
                    })
                }]), e
            },
            g = /^NG_DEFER_BOOTSTRAP!/;
        return a && !g.test(a.name) ? e() : (a.name = a.name.replace(g, ""), void(Ec.resumeBootstrap = function(a) {
            f(a, function(a) {
                d.push(a)
            }), e()
        }))
    }

    function _(a, b) {
        return b = b || "_", a.replace(Jc, function(a, c) {
            return (c ? b : "") + a.toLowerCase()
        })
    }

    function aa() {
        xc = a.jQuery, xc && xc.fn.on ? (wc = xc, l(xc.fn, {
            scope: Xc.scope,
            isolateScope: Xc.isolateScope,
            controller: Xc.controller,
            injector: Xc.injector,
            inheritedData: Xc.inheritedData
        }), ka("remove", !0, !0, !1), ka("empty", !1, !1, !1), ka("html", !1, !1, !0)) : wc = oa, Ec.element = wc
    }

    function ba(a, b, c) {
        if (!a) throw Dc("areq", "Argument '{0}' is {1}", b || "?", c || "required");
        return a
    }

    function ca(a, b, c) {
        return c && Gc(a) && (a = a[a.length - 1]), ba(x(a), b, "not a function, got " + (a && "object" == typeof a ? a.constructor.name || "Object" : typeof a)), a
    }

    function da(a, b) {
        if ("hasOwnProperty" === a) throw Dc("badname", "hasOwnProperty is not a valid {0} name", b)
    }

    function ea(a, b, c) {
        if (!b) return a;
        for (var d, e = b.split("."), f = a, g = e.length, h = 0; g > h; h++) d = e[h], a && (a = (f = a)[d]);
        return !c && x(a) ? O(f, a) : a
    }

    function fa(a) {
        var b = a[0],
            c = a[a.length - 1];
        if (b === c) return wc(b);
        var d = b,
            e = [d];
        do {
            if (d = d.nextSibling, !d) break;
            e.push(d)
        } while (d !== c);
        return wc(e)
    }

    function ga(a) {
        function b(a, b, c) {
            return a[b] || (a[b] = c())
        }
        var c = d("$injector"),
            e = d("ng"),
            f = b(a, "angular", Object);
        return f.$$minErr = f.$$minErr || d, b(f, "module", function() {
            var a = {};
            return function(d, f, g) {
                var h = function(a, b) {
                    if ("hasOwnProperty" === a) throw e("badname", "hasOwnProperty is not a valid {0} name", b)
                };
                return h(d, "module"), f && a.hasOwnProperty(d) && (a[d] = null), b(a, d, function() {
                    function a(a, c, d) {
                        return function() {
                            return b[d || "push"]([a, c, arguments]), i
                        }
                    }
                    if (!f) throw c("nomod", "Module '{0}' is not available! You either misspelled the module name or forgot to load it. If registering a module ensure that you specify the dependencies as the second argument.", d);
                    var b = [],
                        e = [],
                        h = a("$injector", "invoke"),
                        i = {
                            _invokeQueue: b,
                            _runBlocks: e,
                            requires: f,
                            name: d,
                            provider: a("$provide", "provider"),
                            factory: a("$provide", "factory"),
                            service: a("$provide", "service"),
                            value: a("$provide", "value"),
                            constant: a("$provide", "constant", "unshift"),
                            animation: a("$animateProvider", "register"),
                            filter: a("$filterProvider", "register"),
                            controller: a("$controllerProvider", "register"),
                            directive: a("$compileProvider", "directive"),
                            config: h,
                            run: function(a) {
                                return e.push(a), this
                            }
                        };
                    return g && h(g), i
                })
            }
        })
    }

    function ha(b) {
        l(b, {
            bootstrap: $,
            copy: J,
            extend: l,
            equals: L,
            element: wc,
            forEach: f,
            injector: Ha,
            noop: o,
            bind: O,
            toJson: Q,
            fromJson: R,
            identity: p,
            isUndefined: r,
            isDefined: s,
            isString: u,
            isFunction: x,
            isObject: t,
            isNumber: v,
            isElement: E,
            isArray: Gc,
            version: Kc,
            isDate: w,
            lowercase: qc,
            uppercase: sc,
            callbacks: {
                counter: 0
            },
            $$minErr: d,
            $$csp: Ic
        }), yc = ga(a);
        try {
            yc("ngLocale")
        } catch (c) {
            yc("ngLocale", []).provider("$locale", cb)
        }
        yc("ng", ["ngLocale"], ["$provide", function(a) {
            a.provider({
                $$sanitizeUri: Gb
            }), a.provider("$compile", Oa).directive({
                a: Hd,
                input: Sd,
                textarea: Sd,
                form: Ld,
                script: Ae,
                select: De,
                style: Fe,
                option: Ee,
                ngBind: ce,
                ngBindHtml: ee,
                ngBindTemplate: de,
                ngClass: fe,
                ngClassEven: he,
                ngClassOdd: ge,
                ngCloak: ie,
                ngController: je,
                ngForm: Md,
                ngHide: ue,
                ngIf: me,
                ngInclude: ne,
                ngInit: pe,
                ngNonBindable: qe,
                ngPluralize: re,
                ngRepeat: se,
                ngShow: te,
                ngStyle: ve,
                ngSwitch: we,
                ngSwitchWhen: xe,
                ngSwitchDefault: ye,
                ngOptions: Ce,
                ngTransclude: ze,
                ngModel: Yd,
                ngList: _d,
                ngChange: Zd,
                required: $d,
                ngRequired: $d,
                ngValue: be
            }).directive({
                ngInclude: oe
            }).directive(Id).directive(ke), a.provider({
                $anchorScroll: Ia,
                $animate: ed,
                $browser: La,
                $cacheFactory: Ma,
                $controller: Ra,
                $document: Sa,
                $exceptionHandler: Ta,
                $filter: Rb,
                $interpolate: ab,
                $interval: bb,
                $http: Ya,
                $httpBackend: $a,
                $location: qb,
                $log: rb,
                $parse: Bb,
                $rootScope: Fb,
                $q: Cb,
                $sce: Lb,
                $sceDelegate: Kb,
                $sniffer: Mb,
                $templateCache: Na,
                $timeout: Nb,
                $window: Qb,
                $$rAF: Eb,
                $$asyncCallback: Ja
            })
        }])
    }

    function ia() {
        return ++Mc
    }

    function ja(a) {
        return a.replace(Pc, function(a, b, c, d) {
            return d ? c.toUpperCase() : c
        }).replace(Qc, "Moz$1")
    }

    function ka(a, b, c, d) {
        function e(a) {
            var e, g, h, i, j, k, l, m = c && a ? [this.filter(a)] : [this],
                n = b;
            if (!d || null != a)
                for (; m.length;)
                    for (e = m.shift(), g = 0, h = e.length; h > g; g++)
                        for (i = wc(e[g]), n ? i.triggerHandler("$destroy") : n = !n, j = 0, k = (l = i.children()).length; k > j; j++) m.push(xc(l[j]));
            return f.apply(this, arguments)
        }
        var f = xc.fn[a];
        f = f.$original || f, e.$original = f, xc.fn[a] = e
    }

    function la(a) {
        return !Tc.test(a)
    }

    function ma(a, b) {
        var c, d, e, f, g, h, i = b.createDocumentFragment(),
            j = [];
        if (la(a)) j.push(b.createTextNode(a));
        else {
            for (c = i.appendChild(b.createElement("div")), d = (Uc.exec(a) || ["", ""])[1].toLowerCase(), e = Wc[d] || Wc._default, c.innerHTML = "<div>&#160;</div>" + e[1] + a.replace(Vc, "<$1></$2>") + e[2], c.removeChild(c.firstChild), f = e[0]; f--;) c = c.lastChild;
            for (g = 0, h = c.childNodes.length; h > g; ++g) j.push(c.childNodes[g]);
            c = i.firstChild, c.textContent = ""
        }
        return i.textContent = "", i.innerHTML = "", j
    }

    function na(a, c) {
        c = c || b;
        var d;
        return (d = Sc.exec(a)) ? [c.createElement(d[1])] : ma(a, c)
    }

    function oa(a) {
        if (a instanceof oa) return a;
        if (u(a) && (a = Hc(a)), !(this instanceof oa)) {
            if (u(a) && "<" != a.charAt(0)) throw Rc("nosel", "Looking up elements via selectors is not supported by jqLite! See: http://docs.angularjs.org/api/angular.element");
            return new oa(a)
        }
        if (u(a)) {
            ya(this, na(a));
            var c = wc(b.createDocumentFragment());
            c.append(this)
        } else ya(this, a)
    }

    function pa(a) {
        return a.cloneNode(!0)
    }

    function qa(a) {
        sa(a);
        for (var b = 0, c = a.childNodes || []; b < c.length; b++) qa(c[b])
    }

    function ra(a, b, c, d) {
        if (s(d)) throw Rc("offargs", "jqLite#off() does not support the `selector` argument");
        var e = ta(a, "events"),
            g = ta(a, "handle");
        g && (r(b) ? f(e, function(b, c) {
            Oc(a, c, b), delete e[c]
        }) : f(b.split(" "), function(b) {
            r(c) ? (Oc(a, b, e[b]), delete e[b]) : I(e[b] || [], c)
        }))
    }

    function sa(a, b) {
        var d = a.ng339,
            e = Lc[d];
        if (e) {
            if (b) return void delete Lc[d].data[b];
            e.handle && (e.events.$destroy && e.handle({}, "$destroy"), ra(a)), delete Lc[d], a.ng339 = c
        }
    }

    function ta(a, b, c) {
        var d = a.ng339,
            e = Lc[d || -1];
        return s(c) ? (e || (a.ng339 = d = ia(), e = Lc[d] = {}), void(e[b] = c)) : e && e[b]
    }

    function ua(a, b, c) {
        var d = ta(a, "data"),
            e = s(c),
            f = !e && s(b),
            g = f && !t(b);
        if (d || g || ta(a, "data", d = {}), e) d[b] = c;
        else {
            if (!f) return d;
            if (g) return d && d[b];
            l(d, b)
        }
    }

    function va(a, b) {
        return a.getAttribute ? (" " + (a.getAttribute("class") || "") + " ").replace(/[\n\t]/g, " ").indexOf(" " + b + " ") > -1 : !1
    }

    function wa(a, b) {
        b && a.setAttribute && f(b.split(" "), function(b) {
            a.setAttribute("class", Hc((" " + (a.getAttribute("class") || "") + " ").replace(/[\n\t]/g, " ").replace(" " + Hc(b) + " ", " ")))
        })
    }

    function xa(a, b) {
        if (b && a.setAttribute) {
            var c = (" " + (a.getAttribute("class") || "") + " ").replace(/[\n\t]/g, " ");
            f(b.split(" "), function(a) {
                a = Hc(a), -1 === c.indexOf(" " + a + " ") && (c += a + " ")
            }), a.setAttribute("class", Hc(c))
        }
    }

    function ya(a, b) {
        if (b) {
            b = b.nodeName || !s(b.length) || z(b) ? [b] : b;
            for (var c = 0; c < b.length; c++) a.push(b[c])
        }
    }

    function za(a, b) {
        return Aa(a, "$" + (b || "ngController") + "Controller")
    }

    function Aa(a, b, d) {
        9 == a.nodeType && (a = a.documentElement);
        for (var e = Gc(b) ? b : [b]; a;) {
            for (var f = 0, g = e.length; g > f; f++)
                if ((d = wc.data(a, e[f])) !== c) return d;
            a = a.parentNode || 11 === a.nodeType && a.host
        }
    }

    function Ba(a) {
        for (var b = 0, c = a.childNodes; b < c.length; b++) qa(c[b]);
        for (; a.firstChild;) a.removeChild(a.firstChild)
    }

    function Ca(a, b) {
        var c = Yc[b.toLowerCase()];
        return c && Zc[a.nodeName] && c
    }

    function Da(a, c) {
        var d = function(d, e) {
            if (d.preventDefault || (d.preventDefault = function() {
                    d.returnValue = !1
                }), d.stopPropagation || (d.stopPropagation = function() {
                    d.cancelBubble = !0
                }), d.target || (d.target = d.srcElement || b), r(d.defaultPrevented)) {
                var g = d.preventDefault;
                d.preventDefault = function() {
                    d.defaultPrevented = !0, g.call(d)
                }, d.defaultPrevented = !1
            }
            d.isDefaultPrevented = function() {
                return d.defaultPrevented || d.returnValue === !1
            };
            var h = K(c[e || d.type] || []);
            f(h, function(b) {
                b.call(a, d)
            }), 8 >= vc ? (d.preventDefault = null, d.stopPropagation = null, d.isDefaultPrevented = null) : (delete d.preventDefault, delete d.stopPropagation, delete d.isDefaultPrevented)
        };
        return d.elem = a, d
    }

    function Ea(a, b) {
        var d, e = typeof a;
        return "function" == e || "object" == e && null !== a ? "function" == typeof(d = a.$$hashKey) ? d = a.$$hashKey() : d === c && (d = a.$$hashKey = (b || j)()) : d = a, e + ":" + d
    }

    function Fa(a, b) {
        if (b) {
            var c = 0;
            this.nextUid = function() {
                return ++c
            }
        }
        f(a, this.put, this)
    }

    function Ga(a) {
        var b, c, d, e;
        return "function" == typeof a ? (b = a.$inject) || (b = [], a.length && (c = a.toString().replace(bd, ""), d = c.match($c), f(d[1].split(_c), function(a) {
            a.replace(ad, function(a, c, d) {
                b.push(d)
            })
        })), a.$inject = b) : Gc(a) ? (e = a.length - 1, ca(a[e], "fn"), b = a.slice(0, e)) : ca(a, "fn", !0), b
    }

    function Ha(a) {
        function b(a) {
            return function(b, c) {
                return t(b) ? void f(b, i(a)) : a(b, c)
            }
        }

        function c(a, b) {
            if (da(a, "service"), (x(b) || Gc(b)) && (b = v.instantiate(b)), !b.$get) throw cd("pget", "Provider '{0}' must define $get factory method.", a);
            return s[a + n] = b
        }

        function d(a, b) {
            return c(a, {
                $get: b
            })
        }

        function e(a, b) {
            return d(a, ["$injector", function(a) {
                return a.instantiate(b)
            }])
        }

        function g(a, b) {
            return d(a, q(b))
        }

        function h(a, b) {
            da(a, "constant"), s[a] = b, w[a] = b
        }

        function j(a, b) {
            var c = v.get(a + n),
                d = c.$get;
            c.$get = function() {
                var a = y.invoke(d, c);
                return y.invoke(b, null, {
                    $delegate: a
                })
            }
        }

        function k(a) {
            var b, c, d, e, g = [];
            return f(a, function(a) {
                if (!r.get(a)) {
                    r.put(a, !0);
                    try {
                        if (u(a))
                            for (b = yc(a), g = g.concat(k(b.requires)).concat(b._runBlocks), c = b._invokeQueue, d = 0, e = c.length; e > d; d++) {
                                var f = c[d],
                                    h = v.get(f[0]);
                                h[f[1]].apply(h, f[2])
                            } else x(a) ? g.push(v.invoke(a)) : Gc(a) ? g.push(v.invoke(a)) : ca(a, "module")
                    } catch (i) {
                        throw Gc(a) && (a = a[a.length - 1]), i.message && i.stack && -1 == i.stack.indexOf(i.message) && (i = i.message + "\n" + i.stack), cd("modulerr", "Failed to instantiate module {0} due to:\n{1}", a, i.stack || i.message || i)
                    }
                }
            }), g
        }

        function l(a, b) {
            function c(c) {
                if (a.hasOwnProperty(c)) {
                    if (a[c] === m) throw cd("cdep", "Circular dependency found: {0}", c + " <- " + p.join(" <- "));
                    return a[c]
                }
                try {
                    return p.unshift(c), a[c] = m, a[c] = b(c)
                } catch (d) {
                    throw a[c] === m && delete a[c], d
                } finally {
                    p.shift()
                }
            }

            function d(a, b, d) {
                var e, f, g, h = [],
                    i = Ga(a);
                for (f = 0, e = i.length; e > f; f++) {
                    if (g = i[f], "string" != typeof g) throw cd("itkn", "Incorrect injection token! Expected service name as string, got {0}", g);
                    h.push(d && d.hasOwnProperty(g) ? d[g] : c(g))
                }
                return Gc(a) && (a = a[e]), a.apply(b, h)
            }

            function e(a, b) {
                var c, e, f = function() {};
                return f.prototype = (Gc(a) ? a[a.length - 1] : a).prototype, c = new f, e = d(a, c, b), t(e) || x(e) ? e : c
            }
            return {
                invoke: d,
                instantiate: e,
                get: c,
                annotate: Ga,
                has: function(b) {
                    return s.hasOwnProperty(b + n) || a.hasOwnProperty(b)
                }
            }
        }
        var m = {},
            n = "Provider",
            p = [],
            r = new Fa([], !0),
            s = {
                $provide: {
                    provider: b(c),
                    factory: b(d),
                    service: b(e),
                    value: b(g),
                    constant: b(h),
                    decorator: j
                }
            },
            v = s.$injector = l(s, function() {
                throw cd("unpr", "Unknown provider: {0}", p.join(" <- "))
            }),
            w = {},
            y = w.$injector = l(w, function(a) {
                var b = v.get(a + n);
                return y.invoke(b.$get, b)
            });
        return f(k(a), function(a) {
            y.invoke(a || o)
        }), y
    }

    function Ia() {
        var a = !0;
        this.disableAutoScrolling = function() {
            a = !1
        }, this.$get = ["$window", "$location", "$rootScope", function(b, c, d) {
            function e(a) {
                var b = null;
                return f(a, function(a) {
                    b || "a" !== qc(a.nodeName) || (b = a)
                }), b
            }

            function g() {
                var a, d = c.hash();
                d ? (a = h.getElementById(d)) ? a.scrollIntoView() : (a = e(h.getElementsByName(d))) ? a.scrollIntoView() : "top" === d && b.scrollTo(0, 0) : b.scrollTo(0, 0)
            }
            var h = b.document;
            return a && d.$watch(function() {
                return c.hash()
            }, function() {
                d.$evalAsync(g)
            }), g
        }]
    }

    function Ja() {
        this.$get = ["$$rAF", "$timeout", function(a, b) {
            return a.supported ? function(b) {
                return a(b)
            } : function(a) {
                return b(a, 0, !1)
            }
        }]
    }

    function Ka(a, b, d, e) {
        function g(a) {
            try {
                a.apply(null, N(arguments, 1))
            } finally {
                if (t--, 0 === t)
                    for (; v.length;) try {
                        v.pop()()
                    } catch (b) {
                        d.error(b)
                    }
            }
        }

        function h(a) {
            var b = a.indexOf("#");
            return -1 === b ? "" : a.substr(b + 1)
        }

        function i(a, b) {
            ! function c() {
                f(x, function(a) {
                    a()
                }), w = b(c, a)
            }()
        }

        function j() {
            y != k.url() && (y = k.url(), f(B, function(a) {
                a(k.url())
            }))
        }
        var k = this,
            l = b[0],
            m = a.location,
            n = a.history,
            p = a.setTimeout,
            q = a.clearTimeout,
            s = {};
        k.isMock = !1;
        var t = 0,
            v = [];
        k.$$completeOutstandingRequest = g, k.$$incOutstandingRequestCount = function() {
            t++
        }, k.notifyWhenNoOutstandingRequests = function(a) {
            f(x, function(a) {
                a()
            }), 0 === t ? a() : v.push(a)
        };
        var w, x = [];
        k.addPollFn = function(a) {
            return r(w) && i(100, p), x.push(a), a
        };
        var y = m.href,
            z = b.find("base"),
            A = null;
        k.url = function(b, c) {
            if (m !== a.location && (m = a.location), n !== a.history && (n = a.history), b) {
                if (y == b) return;
                var d = y && hb(y) === hb(b);
                return y = b, !d && e.history ? c ? n.replaceState(null, "", b) : (n.pushState(null, "", b), z.attr("href", z.attr("href"))) : (d || (A = b), c ? m.replace(b) : d ? m.hash = h(b) : m.href = b), k
            }
            return A || m.href.replace(/%27/g, "'")
        };
        var B = [],
            C = !1;
        k.onUrlChange = function(b) {
            return C || (e.history && wc(a).on("popstate", j), e.hashchange ? wc(a).on("hashchange", j) : k.addPollFn(j), C = !0), B.push(b), b
        }, k.$$checkUrlChange = j, k.baseHref = function() {
            var a = z.attr("href");
            return a ? a.replace(/^(https?\:)?\/\/[^\/]*/, "") : ""
        };
        var D = {},
            E = "",
            F = k.baseHref();
        k.cookies = function(a, b) {
            var e, f, g, h, i;
            if (!a) {
                if (l.cookie !== E)
                    for (E = l.cookie, f = E.split("; "), D = {}, h = 0; h < f.length; h++) g = f[h], i = g.indexOf("="), i > 0 && (a = unescape(g.substring(0, i)), D[a] === c && (D[a] = unescape(g.substring(i + 1))));
                return D
            }
            b === c ? l.cookie = escape(a) + "=;path=" + F + ";expires=Thu, 01 Jan 1970 00:00:00 GMT" : u(b) && (e = (l.cookie = escape(a) + "=" + escape(b) + ";path=" + F).length + 1, e > 4096 && d.warn("Cookie '" + a + "' possibly not set or overflowed because it was too large (" + e + " > 4096 bytes)!"))
        }, k.defer = function(a, b) {
            var c;
            return t++, c = p(function() {
                delete s[c], g(a)
            }, b || 0), s[c] = !0, c
        }, k.defer.cancel = function(a) {
            return s[a] ? (delete s[a], q(a), g(o), !0) : !1
        }
    }

    function La() {
        this.$get = ["$window", "$log", "$sniffer", "$document", function(a, b, c, d) {
            return new Ka(a, d, b, c)
        }]
    }

    function Ma() {
        this.$get = function() {
            function a(a, c) {
                function e(a) {
                    a != m && (n ? n == a && (n = a.n) : n = a, f(a.n, a.p), f(a, m), m = a, m.n = null)
                }

                function f(a, b) {
                    a != b && (a && (a.p = b), b && (b.n = a))
                }
                if (a in b) throw d("$cacheFactory")("iid", "CacheId '{0}' is already taken!", a);
                var g = 0,
                    h = l({}, c, {
                        id: a
                    }),
                    i = {},
                    j = c && c.capacity || Number.MAX_VALUE,
                    k = {},
                    m = null,
                    n = null;
                return b[a] = {
                    put: function(a, b) {
                        if (j < Number.MAX_VALUE) {
                            var c = k[a] || (k[a] = {
                                key: a
                            });
                            e(c)
                        }
                        if (!r(b)) return a in i || g++, i[a] = b, g > j && this.remove(n.key), b
                    },
                    get: function(a) {
                        if (j < Number.MAX_VALUE) {
                            var b = k[a];
                            if (!b) return;
                            e(b)
                        }
                        return i[a]
                    },
                    remove: function(a) {
                        if (j < Number.MAX_VALUE) {
                            var b = k[a];
                            if (!b) return;
                            b == m && (m = b.p), b == n && (n = b.n), f(b.n, b.p), delete k[a]
                        }
                        delete i[a], g--
                    },
                    removeAll: function() {
                        i = {}, g = 0, k = {}, m = n = null
                    },
                    destroy: function() {
                        i = null, h = null, k = null, delete b[a]
                    },
                    info: function() {
                        return l({}, h, {
                            size: g
                        })
                    }
                }
            }
            var b = {};
            return a.info = function() {
                var a = {};
                return f(b, function(b, c) {
                    a[c] = b.info()
                }), a
            }, a.get = function(a) {
                return b[a]
            }, a
        }
    }

    function Na() {
        this.$get = ["$cacheFactory", function(a) {
            return a("templates")
        }]
    }

    function Oa(a, d) {
        var e = {},
            g = "Directive",
            h = /^\s*directive\:\s*([\d\w_\-]+)\s+(.*)$/,
            j = /(([\d\w_\-]+)(?:\:([^;]+))?;?)/,
            k = /^(on[a-z]+|formaction)$/;
        this.directive = function m(b, c) {
            return da(b, "directive"), u(b) ? (ba(c, "directiveFactory"), e.hasOwnProperty(b) || (e[b] = [], a.factory(b + g, ["$injector", "$exceptionHandler", function(a, c) {
                var d = [];
                return f(e[b], function(e, f) {
                    try {
                        var g = a.invoke(e);
                        x(g) ? g = {
                            compile: q(g)
                        } : !g.compile && g.link && (g.compile = q(g.link)), g.priority = g.priority || 0, g.index = f, g.name = g.name || b, g.require = g.require || g.controller && g.name, g.restrict = g.restrict || "A", d.push(g)
                    } catch (h) {
                        c(h)
                    }
                }), d
            }])), e[b].push(c)) : f(b, i(m)), this
        }, this.aHrefSanitizationWhitelist = function(a) {
            return s(a) ? (d.aHrefSanitizationWhitelist(a), this) : d.aHrefSanitizationWhitelist()
        }, this.imgSrcSanitizationWhitelist = function(a) {
            return s(a) ? (d.imgSrcSanitizationWhitelist(a), this) : d.imgSrcSanitizationWhitelist()
        }, this.$get = ["$injector", "$interpolate", "$exceptionHandler", "$http", "$templateCache", "$parse", "$controller", "$rootScope", "$document", "$sce", "$animate", "$$sanitizeUri", function(a, d, i, m, o, q, r, s, v, w, y, z) {
            function A(a, b, c, d, e) {
                a instanceof wc || (a = wc(a)), f(a, function(b, c) {
                    3 == b.nodeType && b.nodeValue.match(/\S+/) && (a[c] = b = wc(b).wrap("<span></span>").parent()[0])
                });
                var g = C(a, b, a, c, d, e);
                return B(a, "ng-scope"),
                    function(b, c, d, e) {
                        ba(b, "scope");
                        var h = c ? Xc.clone.call(a) : a;
                        f(d, function(a, b) {
                            h.data("$" + b + "Controller", a)
                        });
                        for (var i = 0, j = h.length; j > i; i++) {
                            var k = h[i],
                                l = k.nodeType;
                            (1 === l || 9 === l) && h.eq(i).data("$scope", b)
                        }
                        return c && c(h, b), g && g(b, h, h, e), h
                    }
            }

            function B(a, b) {
                try {
                    a.addClass(b)
                } catch (c) {}
            }

            function C(a, b, d, e, f, g) {
                function h(a, d, e, f) {
                    var g, h, i, j, k, l, m, n, p = d.length,
                        q = new Array(p);
                    for (k = 0; p > k; k++) q[k] = d[k];
                    for (k = 0, m = 0, l = o.length; l > k; m++) i = q[m], g = o[k++], h = o[k++], g ? (g.scope ? (j = a.$new(), wc.data(i, "$scope", j)) : j = a, n = g.transcludeOnThisElement ? D(a, g.transclude, f) : !g.templateOnThisElement && f ? f : !f && b ? D(a, b) : null, g(h, j, i, e, n)) : h && h(a, i.childNodes, c, f)
                }
                for (var i, j, k, l, m, n, o = [], p = 0; p < a.length; p++) i = new X, j = E(a[p], [], i, 0 === p ? e : c, f), k = j.length ? H(j, a[p], i, b, d, null, [], [], g) : null, k && k.scope && B(i.$$element, "ng-scope"), m = k && k.terminal || !(l = a[p].childNodes) || !l.length ? null : C(l, k ? (k.transcludeOnThisElement || !k.templateOnThisElement) && k.transclude : b), o.push(k, m), n = n || k || m, g = null;
                return n ? h : null
            }

            function D(a, b, c) {
                var d = function(d, e, f) {
                    var g = !1;
                    d || (d = a.$new(), d.$$transcluded = !0, g = !0);
                    var h = b(d, e, f, c);
                    return g && h.on("$destroy", function() {
                        d.$destroy()
                    }), h
                };
                return d
            }

            function E(a, b, c, d, e) {
                var f, g, i = a.nodeType,
                    k = c.$attr;
                switch (i) {
                    case 1:
                        J(b, Pa(zc(a).toLowerCase()), "E", d, e);
                        for (var l, m, n, o, p, q, r = a.attributes, s = 0, t = r && r.length; t > s; s++) {
                            var v = !1,
                                w = !1;
                            if (l = r[s], !vc || vc >= 8 || l.specified) {
                                m = l.name, p = Hc(l.value), o = Pa(m), (q = aa.test(o)) && (m = _(o.substr(6), "-"));
                                var x = o.replace(/(Start|End)$/, "");
                                o === x + "Start" && (v = m, w = m.substr(0, m.length - 5) + "end", m = m.substr(0, m.length - 6)), n = Pa(m.toLowerCase()), k[n] = m, (q || !c.hasOwnProperty(n)) && (c[n] = p, Ca(a, n) && (c[n] = !0)), U(a, b, p, n), J(b, n, "A", d, e, v, w)
                            }
                        }
                        if (g = a.className, u(g) && "" !== g)
                            for (; f = j.exec(g);) n = Pa(f[2]), J(b, n, "C", d, e) && (c[n] = Hc(f[3])), g = g.substr(f.index + f[0].length);
                        break;
                    case 3:
                        if (11 === vc)
                            for (; a.parentNode && a.nextSibling && 3 === a.nextSibling.nodeType;) a.nodeValue = a.nodeValue + a.nextSibling.nodeValue, a.parentNode.removeChild(a.nextSibling);
                        R(b, a.nodeValue);
                        break;
                    case 8:
                        try {
                            f = h.exec(a.nodeValue), f && (n = Pa(f[1]), J(b, n, "M", d, e) && (c[n] = Hc(f[2])))
                        } catch (y) {}
                }
                return b.sort(P), b
            }

            function F(a, b, c) {
                var d = [],
                    e = 0;
                if (b && a.hasAttribute && a.hasAttribute(b)) {
                    do {
                        if (!a) throw fd("uterdir", "Unterminated attribute, found '{0}' but no matching '{1}' found.", b, c);
                        1 == a.nodeType && (a.hasAttribute(b) && e++, a.hasAttribute(c) && e--), d.push(a), a = a.nextSibling
                    } while (e > 0)
                } else d.push(a);
                return wc(d)
            }

            function G(a, b, c) {
                return function(d, e, f, g, h) {
                    return e = F(e[0], b, c), a(d, e, f, g, h)
                }
            }

            function H(a, e, g, h, j, k, l, m, n) {
                function o(a, b, c, d) {
                    a && (c && (a = G(a, c, d)), a.require = w.require, a.directiveName = y, (P === w || w.$$isolateScope) && (a = W(a, {
                        isolateScope: !0
                    })), l.push(a)), b && (c && (b = G(b, c, d)), b.require = w.require, b.directiveName = y, (P === w || w.$$isolateScope) && (b = W(b, {
                        isolateScope: !0
                    })), m.push(b))
                }

                function p(a, b, c, d) {
                    var e, g = "data",
                        h = !1;
                    if (u(b)) {
                        for (;
                            "^" == (e = b.charAt(0)) || "?" == e;) b = b.substr(1), "^" == e && (g = "inheritedData"), h = h || "?" == e;
                        if (e = null, d && "data" === g && (e = d[b]), e = e || c[g]("$" + b + "Controller"), !e && !h) throw fd("ctreq", "Controller '{0}', required by directive '{1}', can't be found!", b, a);
                        return e
                    }
                    return Gc(b) && (e = [], f(b, function(b) {
                        e.push(p(a, b, c, d))
                    })), e
                }

                function s(a, b, h, j, k) {
                    function n(a, b) {
                        var d;
                        return arguments.length < 2 && (b = a, a = c), Z && (d = z), k(a, b, d)
                    }
                    var o, s, t, u, v, w, x, y, z = {};
                    if (o = e === h ? g : K(g, new X(wc(h), g.$attr)), s = o.$$element, P) {
                        var A = /^\s*([@=&])(\??)\s*(\w*)\s*$/;
                        x = b.$new(!0), !R || R !== P && R !== P.$$originalDirective ? s.data("$isolateScopeNoTemplate", x) : s.data("$isolateScope", x), B(s, "ng-isolate-scope"), f(P.scope, function(a, c) {
                            var e, f, g, h, i = a.match(A) || [],
                                j = i[3] || c,
                                k = "?" == i[2],
                                l = i[1];
                            switch (x.$$isolateBindings[c] = l + j, l) {
                                case "@":
                                    o.$observe(j, function(a) {
                                        x[c] = a
                                    }), o.$$observers[j].$$scope = b, o[j] && (x[c] = d(o[j])(b));
                                    break;
                                case "=":
                                    if (k && !o[j]) return;
                                    f = q(o[j]), h = f.literal ? L : function(a, b) {
                                        return a === b || a !== a && b !== b
                                    }, g = f.assign || function() {
                                        throw e = x[c] = f(b), fd("nonassign", "Expression '{0}' used with directive '{1}' is non-assignable!", o[j], P.name)
                                    }, e = x[c] = f(b), x.$watch(function() {
                                        var a = f(b);
                                        return h(a, x[c]) || (h(a, e) ? g(b, a = x[c]) : x[c] = a), e = a
                                    }, null, f.literal);
                                    break;
                                case "&":
                                    f = q(o[j]), x[c] = function(a) {
                                        return f(b, a)
                                    };
                                    break;
                                default:
                                    throw fd("iscp", "Invalid isolate scope definition for directive '{0}'. Definition: {... {1}: '{2}' ...}", P.name, c, a)
                            }
                        })
                    }
                    for (y = k && n, J && f(J, function(a) {
                            var c, d = {
                                $scope: a === P || a.$$isolateScope ? x : b,
                                $element: s,
                                $attrs: o,
                                $transclude: y
                            };
                            w = a.controller, "@" == w && (w = o[a.name]), c = r(w, d), z[a.name] = c, Z || s.data("$" + a.name + "Controller", c), a.controllerAs && (d.$scope[a.controllerAs] = c)
                        }), t = 0, u = l.length; u > t; t++) try {
                        v = l[t], v(v.isolateScope ? x : b, s, o, v.require && p(v.directiveName, v.require, s, z), y)
                    } catch (C) {
                        i(C, T(s))
                    }
                    var D = b;
                    for (P && (P.template || null === P.templateUrl) && (D = x), a && a(D, h.childNodes, c, k), t = m.length - 1; t >= 0; t--) try {
                        v = m[t], v(v.isolateScope ? x : b, s, o, v.require && p(v.directiveName, v.require, s, z), y)
                    } catch (C) {
                        i(C, T(s))
                    }
                }
                n = n || {};
                for (var v, w, y, z, C, D, H = -Number.MAX_VALUE, J = n.controllerDirectives, P = n.newIsolateScopeDirective, R = n.templateDirective, S = n.nonTlbTranscludeDirective, U = !1, Y = !1, Z = n.hasElementTranscludeDirective, _ = g.$$element = wc(e), aa = k, ba = h, ca = 0, da = a.length; da > ca; ca++) {
                    w = a[ca];
                    var ea = w.$$start,
                        fa = w.$$end;
                    if (ea && (_ = F(e, ea, fa)), z = c, H > w.priority) break;
                    if ((D = w.scope) && (v = v || w, w.templateUrl || (Q("new/isolated scope", P, w, _), t(D) && (P = w))), y = w.name, !w.templateUrl && w.controller && (D = w.controller, J = J || {}, Q("'" + y + "' controller", J[y], w, _), J[y] = w), (D = w.transclude) && (U = !0, w.$$tlb || (Q("transclusion", S, w, _), S = w), "element" == D ? (Z = !0, H = w.priority, z = _, _ = g.$$element = wc(b.createComment(" " + y + ": " + g[y] + " ")), e = _[0], V(j, N(z), e), ba = A(z, h, H, aa && aa.name, {
                            nonTlbTranscludeDirective: S
                        })) : (z = wc(pa(e)).contents(), _.empty(), ba = A(z, h))), w.template)
                        if (Y = !0, Q("template", R, w, _), R = w, D = x(w.template) ? w.template(_, g) : w.template, D = $(D), w.replace) {
                            if (aa = w, z = la(D) ? [] : wc(Hc(D)), e = z[0], 1 != z.length || 1 !== e.nodeType) throw fd("tplrt", "Template for directive '{0}' must have exactly one root element. {1}", y, "");
                            V(j, _, e);
                            var ga = {
                                    $attr: {}
                                },
                                ha = E(e, [], ga),
                                ia = a.splice(ca + 1, a.length - (ca + 1));
                            P && I(ha), a = a.concat(ha).concat(ia), M(g, ga), da = a.length
                        } else _.html(D);
                    if (w.templateUrl) Y = !0, Q("template", R, w, _), R = w, w.replace && (aa = w), s = O(a.splice(ca, a.length - ca), _, g, j, U && ba, l, m, {
                        controllerDirectives: J,
                        newIsolateScopeDirective: P,
                        templateDirective: R,
                        nonTlbTranscludeDirective: S
                    }), da = a.length;
                    else if (w.compile) try {
                        C = w.compile(_, g, ba), x(C) ? o(null, C, ea, fa) : C && o(C.pre, C.post, ea, fa)
                    } catch (ja) {
                        i(ja, T(_))
                    }
                    w.terminal && (s.terminal = !0, H = Math.max(H, w.priority))
                }
                return s.scope = v && v.scope === !0, s.transcludeOnThisElement = U, s.templateOnThisElement = Y, s.transclude = ba, n.hasElementTranscludeDirective = Z, s
            }

            function I(a) {
                for (var b = 0, c = a.length; c > b; b++) a[b] = n(a[b], {
                    $$isolateScope: !0
                })
            }

            function J(b, d, f, h, j, k, l) {
                if (d === j) return null;
                var m = null;
                if (e.hasOwnProperty(d))
                    for (var o, p = a.get(d + g), q = 0, r = p.length; r > q; q++) try {
                        o = p[q], (h === c || h > o.priority) && -1 != o.restrict.indexOf(f) && (k && (o = n(o, {
                            $$start: k,
                            $$end: l
                        })), b.push(o), m = o)
                    } catch (s) {
                        i(s)
                    }
                return m
            }

            function M(a, b) {
                var c = b.$attr,
                    d = a.$attr,
                    e = a.$$element;
                f(a, function(d, e) {
                    "$" != e.charAt(0) && (b[e] && b[e] !== d && (d += ("style" === e ? ";" : " ") + b[e]), a.$set(e, d, !0, c[e]))
                }), f(b, function(b, f) {
                    "class" == f ? (B(e, b), a["class"] = (a["class"] ? a["class"] + " " : "") + b) : "style" == f ? (e.attr("style", e.attr("style") + ";" + b), a.style = (a.style ? a.style + ";" : "") + b) : "$" == f.charAt(0) || a.hasOwnProperty(f) || (a[f] = b, d[f] = c[f])
                })
            }

            function O(a, b, c, d, e, g, h, i) {
                var j, k, n = [],
                    p = b[0],
                    q = a.shift(),
                    r = l({}, q, {
                        templateUrl: null,
                        transclude: null,
                        replace: null,
                        $$originalDirective: q
                    }),
                    s = x(q.templateUrl) ? q.templateUrl(b, c) : q.templateUrl;
                return b.empty(), m.get(w.getTrustedResourceUrl(s), {
                        cache: o
                    }).success(function(l) {
                        var m, o, u, v;
                        if (l = $(l), q.replace) {
                            if (u = la(l) ? [] : wc(Hc(l)), m = u[0], 1 != u.length || 1 !== m.nodeType) throw fd("tplrt", "Template for directive '{0}' must have exactly one root element. {1}", q.name, s);
                            o = {
                                $attr: {}
                            }, V(d, b, m);
                            var w = E(m, [], o);
                            t(q.scope) && I(w), a = w.concat(a), M(c, o)
                        } else m = p, b.html(l);
                        for (a.unshift(r), j = H(a, m, c, e, b, q, g, h, i), f(d, function(a, c) {
                                a == m && (d[c] = b[0])
                            }), k = C(b[0].childNodes, e); n.length;) {
                            var x = n.shift(),
                                y = n.shift(),
                                z = n.shift(),
                                A = n.shift(),
                                F = b[0];
                            if (y !== p) {
                                var G = y.className;
                                i.hasElementTranscludeDirective && q.replace || (F = pa(m)), V(z, wc(y), F), B(wc(F), G)
                            }
                            v = j.transcludeOnThisElement ? D(x, j.transclude, A) : A, j(k, x, F, d, v)
                        }
                        n = null
                    }).error(function(a, b, c, d) {
                        throw fd("tpload", "Failed to load template: {0}", d.url)
                    }),
                    function(a, b, c, d, e) {
                        var f = e;
                        n ? (n.push(b), n.push(c), n.push(d), n.push(f)) : (j.transcludeOnThisElement && (f = D(b, j.transclude, e)), j(k, b, c, d, f))
                    }
            }

            function P(a, b) {
                var c = b.priority - a.priority;
                return 0 !== c ? c : a.name !== b.name ? a.name < b.name ? -1 : 1 : a.index - b.index
            }

            function Q(a, b, c, d) {
                if (b) throw fd("multidir", "Multiple directives [{0}, {1}] asking for {2} on: {3}", b.name, c.name, a, T(d))
            }

            function R(a, b) {
                var c = d(b, !0);
                c && a.push({
                    priority: 0,
                    compile: function(a) {
                        var b = a.parent(),
                            d = b.length;
                        return d && B(a.parent(), "ng-binding"),
                            function(a, b) {
                                var e = b.parent(),
                                    f = e.data("$binding") || [];
                                f.push(c), e.data("$binding", f), d || B(e, "ng-binding"), a.$watch(c, function(a) {
                                    b[0].nodeValue = a
                                })
                            }
                    }
                })
            }

            function S(a, b) {
                if ("srcdoc" == b) return w.HTML;
                var c = zc(a);
                return "xlinkHref" == b || "FORM" == c && "action" == b || "LINK" == c && "href" == b || "IMG" != c && ("src" == b || "ngSrc" == b) ? w.RESOURCE_URL : void 0
            }

            function U(a, b, c, e) {
                var f = d(c, !0);
                if (f) {
                    if ("multiple" === e && "SELECT" === zc(a)) throw fd("selmulti", "Binding to the 'multiple' attribute is not supported. Element: {0}", T(a));
                    b.push({
                        priority: 100,
                        compile: function() {
                            return {
                                pre: function(b, c, g) {
                                    var h = g.$$observers || (g.$$observers = {});
                                    if (k.test(e)) throw fd("nodomevents", "Interpolations for HTML DOM event attributes are disallowed.  Please use the ng- versions (such as ng-click instead of onclick) instead.");
                                    f = d(g[e], !0, S(a, e)), f && (g[e] = f(b), (h[e] || (h[e] = [])).$$inter = !0, (g.$$observers && g.$$observers[e].$$scope || b).$watch(f, function(a, b) {
                                        "class" === e && a != b ? g.$updateClass(a, b) : g.$set(e, a)
                                    }))
                                }
                            }
                        }
                    })
                }
            }

            function V(a, c, d) {
                var e, f, g = c[0],
                    h = c.length,
                    i = g.parentNode;
                if (a)
                    for (e = 0, f = a.length; f > e; e++)
                        if (a[e] == g) {
                            a[e++] = d;
                            for (var j = e, k = j + h - 1, l = a.length; l > j; j++, k++) l > k ? a[j] = a[k] : delete a[j];
                            a.length -= h - 1;
                            break
                        }
                i && i.replaceChild(d, g);
                var m = b.createDocumentFragment();
                m.appendChild(g), d[wc.expando] = g[wc.expando];
                for (var n = 1, o = c.length; o > n; n++) {
                    var p = c[n];
                    wc(p).remove(), m.appendChild(p), delete c[n]
                }
                c[0] = d, c.length = 1
            }

            function W(a, b) {
                return l(function() {
                    return a.apply(null, arguments)
                }, a, b)
            }
            var X = function(a, b) {
                this.$$element = a, this.$attr = b || {}
            };
            X.prototype = {
                $normalize: Pa,
                $addClass: function(a) {
                    a && a.length > 0 && y.addClass(this.$$element, a)
                },
                $removeClass: function(a) {
                    a && a.length > 0 && y.removeClass(this.$$element, a)
                },
                $updateClass: function(a, b) {
                    var c = Qa(a, b),
                        d = Qa(b, a);
                    0 === c.length ? y.removeClass(this.$$element, d) : 0 === d.length ? y.addClass(this.$$element, c) : y.setClass(this.$$element, c, d)
                },
                $set: function(a, b, d, e) {
                    var g, h = Ca(this.$$element[0], a);
                    h && (this.$$element.prop(a, b), e = h), this[a] = b, e ? this.$attr[a] = e : (e = this.$attr[a], e || (this.$attr[a] = e = _(a, "-"))), g = zc(this.$$element).toUpperCase(), ("A" === g && ("href" === a || "xlinkHref" === a) || "IMG" === g && "src" === a) && (this[a] = b = z(b, "src" === a)), d !== !1 && (null === b || b === c ? this.$$element.removeAttr(e) : this.$$element.attr(e, b));
                    var j = this.$$observers;
                    j && f(j[a], function(a) {
                        try {
                            a(b)
                        } catch (c) {
                            i(c)
                        }
                    })
                },
                $observe: function(a, b) {
                    var c = this,
                        d = c.$$observers || (c.$$observers = {}),
                        e = d[a] || (d[a] = []);
                    return e.push(b), s.$evalAsync(function() {
                        e.$$inter || b(c[a])
                    }), b
                }
            };
            var Y = d.startSymbol(),
                Z = d.endSymbol(),
                $ = "{{" == Y || "}}" == Z ? p : function(a) {
                    return a.replace(/\{\{/g, Y).replace(/}}/g, Z)
                },
                aa = /^ngAttr[A-Z]/;
            return A
        }]
    }

    function Pa(a) {
        return ja(a.replace(gd, ""))
    }

    function Qa(a, b) {
        var c = "",
            d = a.split(/\s+/),
            e = b.split(/\s+/);
        a: for (var f = 0; f < d.length; f++) {
            for (var g = d[f], h = 0; h < e.length; h++)
                if (g == e[h]) continue a;
            c += (c.length > 0 ? " " : "") + g
        }
        return c
    }

    function Ra() {
        var a = {},
            b = /^(\S+)(\s+as\s+(\w+))?$/;
        this.register = function(b, c) {
            da(b, "controller"), t(b) ? l(a, b) : a[b] = c
        }, this.$get = ["$injector", "$window", function(c, e) {
            return function(f, g) {
                var h, i, j, k;
                if (u(f) && (i = f.match(b), j = i[1], k = i[3], f = a.hasOwnProperty(j) ? a[j] : ea(g.$scope, j, !0) || ea(e, j, !0), ca(f, j, !0)), h = c.instantiate(f, g), k) {
                    if (!g || "object" != typeof g.$scope) throw d("$controller")("noscp", "Cannot export controller '{0}' as '{1}'! No $scope object provided via `locals`.", j || f.name, k);
                    g.$scope[k] = h
                }
                return h
            }
        }]
    }

    function Sa() {
        this.$get = ["$window", function(a) {
            return wc(a.document)
        }]
    }

    function Ta() {
        this.$get = ["$log", function(a) {
            return function(b, c) {
                a.error.apply(a, arguments)
            }
        }]
    }

    function Ua(a) {
        var b, c, d, e = {};
        return a ? (f(a.split("\n"), function(a) {
            d = a.indexOf(":"), b = qc(Hc(a.substr(0, d))), c = Hc(a.substr(d + 1)), b && (e[b] = e[b] ? e[b] + ", " + c : c)
        }), e) : e
    }

    function Va(a) {
        var b = t(a) ? a : c;
        return function(c) {
            return b || (b = Ua(a)), c ? b[qc(c)] || null : b
        }
    }

    function Wa(a, b, c) {
        return x(c) ? c(a, b) : (f(c, function(c) {
            a = c(a, b)
        }), a)
    }

    function Xa(a) {
        return a >= 200 && 300 > a
    }

    function Ya() {
        var a = /^\s*(\[|\{[^\{])/,
            b = /[\}\]]\s*$/,
            d = /^\)\]\}',?\n/,
            e = {
                "Content-Type": "application/json;charset=utf-8"
            },
            g = this.defaults = {
                transformResponse: [function(c) {
                    return u(c) && (c = c.replace(d, ""), a.test(c) && b.test(c) && (c = R(c))), c
                }],
                transformRequest: [function(a) {
                    return !t(a) || B(a) || C(a) ? a : Q(a)
                }],
                headers: {
                    common: {
                        Accept: "application/json, text/plain, */*"
                    },
                    post: K(e),
                    put: K(e),
                    patch: K(e)
                },
                xsrfCookieName: "XSRF-TOKEN",
                xsrfHeaderName: "X-XSRF-TOKEN"
            },
            i = this.interceptors = [],
            j = this.responseInterceptors = [];
        this.$get = ["$httpBackend", "$browser", "$cacheFactory", "$rootScope", "$q", "$injector", function(a, b, d, e, k, m) {
            function n(a) {
                function b(a) {
                    var b = l({}, a, {
                        data: Wa(a.data, a.headers, e.transformResponse)
                    });
                    return Xa(a.status) ? b : k.reject(b)
                }

                function d(a) {
                    function b(a) {
                        var b;
                        f(a, function(c, d) {
                            x(c) && (b = c(), null != b ? a[d] = b : delete a[d])
                        })
                    }
                    var c, d, e, h = g.headers,
                        i = l({}, a.headers);
                    h = l({}, h.common, h[qc(a.method)]);
                    a: for (c in h) {
                        d = qc(c);
                        for (e in i)
                            if (qc(e) === d) continue a;
                        i[c] = h[c]
                    }
                    return b(i), i
                }
                var e = {
                        method: "get",
                        transformRequest: g.transformRequest,
                        transformResponse: g.transformResponse
                    },
                    h = d(a);
                l(e, a), e.headers = h, e.method = sc(e.method);
                var i = function(a) {
                        h = a.headers;
                        var c = Wa(a.data, Va(h), a.transformRequest);
                        return r(c) && f(h, function(a, b) {
                            "content-type" === qc(b) && delete h[b]
                        }), r(a.withCredentials) && !r(g.withCredentials) && (a.withCredentials = g.withCredentials), q(a, c, h).then(b, b)
                    },
                    j = [i, c],
                    m = k.when(e);
                for (f(z, function(a) {
                        (a.request || a.requestError) && j.unshift(a.request, a.requestError), (a.response || a.responseError) && j.push(a.response, a.responseError)
                    }); j.length;) {
                    var n = j.shift(),
                        o = j.shift();
                    m = m.then(n, o)
                }
                return m.success = function(a) {
                    return m.then(function(b) {
                        a(b.data, b.status, b.headers, e)
                    }), m
                }, m.error = function(a) {
                    return m.then(null, function(b) {
                        a(b.data, b.status, b.headers, e)
                    }), m
                }, m
            }

            function o(a) {
                f(arguments, function(a) {
                    n[a] = function(b, c) {
                        return n(l(c || {}, {
                            method: a,
                            url: b
                        }))
                    }
                })
            }

            function p(a) {
                f(arguments, function(a) {
                    n[a] = function(b, c, d) {
                        return n(l(d || {}, {
                            method: a,
                            url: b,
                            data: c
                        }))
                    }
                })
            }

            function q(d, f, h) {
                function i(a, b, c, d) {
                    m && (Xa(a) ? m.put(u, [a, b, Ua(c), d]) : m.remove(u)), j(b, a, c, d), e.$$phase || e.$apply()
                }

                function j(a, b, c, e) {
                    b = Math.max(b, 0), (Xa(b) ? p.resolve : p.reject)({
                        data: a,
                        status: b,
                        headers: Va(c),
                        config: d,
                        statusText: e
                    })
                }

                function l() {
                    var a = H(n.pendingRequests, d); - 1 !== a && n.pendingRequests.splice(a, 1)
                }
                var m, o, p = k.defer(),
                    q = p.promise,
                    u = v(d.url, d.params);
                if (n.pendingRequests.push(d), q.then(l, l), !d.cache && !g.cache || d.cache === !1 || "GET" !== d.method && "JSONP" !== d.method || (m = t(d.cache) ? d.cache : t(g.cache) ? g.cache : y), m)
                    if (o = m.get(u), s(o)) {
                        if (D(o)) return o.then(l, l), o;
                        Gc(o) ? j(o[1], o[0], K(o[2]), o[3]) : j(o, 200, {}, "OK")
                    } else m.put(u, q);
                if (r(o)) {
                    var w = Pb(d.url) ? b.cookies()[d.xsrfCookieName || g.xsrfCookieName] : c;
                    w && (h[d.xsrfHeaderName || g.xsrfHeaderName] = w), a(d.method, u, f, i, h, d.timeout, d.withCredentials, d.responseType)
                }
                return q
            }

            function v(a, b) {
                if (!b) return a;
                var c = [];
                return h(b, function(a, b) {
                    null === a || r(a) || (Gc(a) || (a = [a]), f(a, function(a) {
                        t(a) && (a = w(a) ? a.toISOString() : Q(a)), c.push(Y(b) + "=" + Y(a))
                    }))
                }), c.length > 0 && (a += (-1 == a.indexOf("?") ? "?" : "&") + c.join("&")), a
            }
            var y = d("$http"),
                z = [];
            return f(i, function(a) {
                z.unshift(u(a) ? m.get(a) : m.invoke(a))
            }), f(j, function(a, b) {
                var c = u(a) ? m.get(a) : m.invoke(a);
                z.splice(b, 0, {
                    response: function(a) {
                        return c(k.when(a))
                    },
                    responseError: function(a) {
                        return c(k.reject(a))
                    }
                })
            }), n.pendingRequests = [], o("get", "delete", "head", "jsonp"), p("post", "put", "patch"), n.defaults = g, n
        }]
    }

    function Za(b) {
        if (8 >= vc && (!b.match(/^(get|post|head|put|delete|options)$/i) || !a.XMLHttpRequest)) return new a.ActiveXObject("Microsoft.XMLHTTP");
        if (a.XMLHttpRequest) return new a.XMLHttpRequest;
        throw d("$httpBackend")("noxhr", "This browser does not support XMLHttpRequest.")
    }

    function $a() {
        this.$get = ["$browser", "$window", "$document", function(a, b, c) {
            return _a(a, Za, a.defer, b.angular.callbacks, c[0])
        }]
    }

    function _a(a, b, c, d, e) {
        function g(a, b, c) {
            var f = e.createElement("script"),
                g = null;
            return f.type = "text/javascript", f.src = a, f.async = !0, g = function(a) {
                Oc(f, "load", g), Oc(f, "error", g), e.body.removeChild(f), f = null;
                var h = -1,
                    i = "unknown";
                a && ("load" !== a.type || d[b].called || (a = {
                    type: "error"
                }), i = a.type, h = "error" === a.type ? 404 : 200), c && c(h, i)
            }, Nc(f, "load", g), Nc(f, "error", g), 8 >= vc && (f.onreadystatechange = function() {
                u(f.readyState) && /loaded|complete/.test(f.readyState) && (f.onreadystatechange = null, g({
                    type: "load"
                }))
            }), e.body.appendChild(f), g
        }
        var h = -1;
        return function(e, i, j, k, l, m, n, p) {
            function q() {
                t = h, v && v(), w && w.abort()
            }

            function r(b, d, e, f, g) {
                y && c.cancel(y), v = w = null, 0 === d && (d = e ? 200 : "file" == Ob(i).protocol ? 404 : 0), d = 1223 === d ? 204 : d, g = g || "", b(d, e, f, g), a.$$completeOutstandingRequest(o)
            }
            var t;
            if (a.$$incOutstandingRequestCount(), i = i || a.url(), "jsonp" == qc(e)) {
                var u = "_" + (d.counter++).toString(36);
                d[u] = function(a) {
                    d[u].data = a, d[u].called = !0
                };
                var v = g(i.replace("JSON_CALLBACK", "angular.callbacks." + u), u, function(a, b) {
                    r(k, a, d[u].data, "", b), d[u] = o
                })
            } else {
                var w = b(e);
                if (w.open(e, i, !0), f(l, function(a, b) {
                        s(a) && w.setRequestHeader(b, a)
                    }), w.onreadystatechange = function() {
                        if (w && 4 == w.readyState) {
                            var a = null,
                                b = null,
                                c = "";
                            t !== h && (a = w.getAllResponseHeaders(), b = "response" in w ? w.response : w.responseText), t === h && 10 > vc || (c = w.statusText), r(k, t || w.status, b, a, c)
                        }
                    }, n && (w.withCredentials = !0), p) try {
                    w.responseType = p
                } catch (x) {
                    if ("json" !== p) throw x
                }
                w.send(j || null)
            }
            if (m > 0) var y = c(q, m);
            else D(m) && m.then(q)
        }
    }

    function ab() {
        var a = "{{",
            b = "}}";
        this.startSymbol = function(b) {
            return b ? (a = b, this) : a
        }, this.endSymbol = function(a) {
            return a ? (b = a, this) : b
        }, this.$get = ["$parse", "$exceptionHandler", "$sce", function(c, d, e) {
            function f(f, i, j) {
                for (var k, l, m, n, o = 0, p = [], q = f.length, r = !1, s = []; q > o;) - 1 != (k = f.indexOf(a, o)) && -1 != (l = f.indexOf(b, k + g)) ? (o != k && p.push(f.substring(o, k)), p.push(m = c(n = f.substring(k + g, l))), m.exp = n, o = l + h, r = !0) : (o != q && p.push(f.substring(o)), o = q);
                if ((q = p.length) || (p.push(""), q = 1), j && p.length > 1) throw hd("noconcat", "Error while interpolating: {0}\nStrict Contextual Escaping disallows interpolations that concatenate multiple expressions when a trusted value is required.  See http://docs.angularjs.org/api/ng.$sce", f);
                return !i || r ? (s.length = q, m = function(a) {
                    try {
                        for (var b, c = 0, g = q; g > c; c++) {
                            if ("function" == typeof(b = p[c]))
                                if (b = b(a), b = j ? e.getTrusted(j, b) : e.valueOf(b), null == b) b = "";
                                else switch (typeof b) {
                                    case "string":
                                        break;
                                    case "number":
                                        b = "" + b;
                                        break;
                                    default:
                                        b = Q(b)
                                }
                            s[c] = b
                        }
                        return s.join("")
                    } catch (h) {
                        var i = hd("interr", "Can't interpolate: {0}\n{1}", f, h.toString());
                        d(i)
                    }
                }, m.exp = f, m.parts = p, m) : void 0
            }
            var g = a.length,
                h = b.length;
            return f.startSymbol = function() {
                return a
            }, f.endSymbol = function() {
                return b
            }, f
        }]
    }

    function bb() {
        this.$get = ["$rootScope", "$window", "$q", function(a, b, c) {
            function d(d, f, g, h) {
                var i = b.setInterval,
                    j = b.clearInterval,
                    k = c.defer(),
                    l = k.promise,
                    m = 0,
                    n = s(h) && !h;
                return g = s(g) ? g : 0, l.then(null, null, d), l.$$intervalId = i(function() {
                    k.notify(m++), g > 0 && m >= g && (k.resolve(m), j(l.$$intervalId), delete e[l.$$intervalId]), n || a.$apply()
                }, f), e[l.$$intervalId] = k, l
            }
            var e = {};
            return d.cancel = function(a) {
                return a && a.$$intervalId in e ? (e[a.$$intervalId].reject("canceled"), b.clearInterval(a.$$intervalId), delete e[a.$$intervalId], !0) : !1
            }, d
        }]
    }

    function cb() {
        this.$get = function() {
            return {
                id: "en-us",
                NUMBER_FORMATS: {
                    DECIMAL_SEP: ".",
                    GROUP_SEP: ",",
                    PATTERNS: [{
                        minInt: 1,
                        minFrac: 0,
                        maxFrac: 3,
                        posPre: "",
                        posSuf: "",
                        negPre: "-",
                        negSuf: "",
                        gSize: 3,
                        lgSize: 3
                    }, {
                        minInt: 1,
                        minFrac: 2,
                        maxFrac: 2,
                        posPre: "¤",
                        posSuf: "",
                        negPre: "(¤",
                        negSuf: ")",
                        gSize: 3,
                        lgSize: 3
                    }],
                    CURRENCY_SYM: "$"
                },
                DATETIME_FORMATS: {
                    MONTH: "January,February,March,April,May,June,July,August,September,October,November,December".split(","),
                    SHORTMONTH: "Jan,Feb,Mar,Apr,May,Jun,Jul,Aug,Sep,Oct,Nov,Dec".split(","),
                    DAY: "Sunday,Monday,Tuesday,Wednesday,Thursday,Friday,Saturday".split(","),
                    SHORTDAY: "Sun,Mon,Tue,Wed,Thu,Fri,Sat".split(","),
                    AMPMS: ["AM", "PM"],
                    medium: "MMM d, y h:mm:ss a",
                    "short": "M/d/yy h:mm a",
                    fullDate: "EEEE, MMMM d, y",
                    longDate: "MMMM d, y",
                    mediumDate: "MMM d, y",
                    shortDate: "M/d/yy",
                    mediumTime: "h:mm:ss a",
                    shortTime: "h:mm a"
                },
                pluralCat: function(a) {
                    return 1 === a ? "one" : "other"
                }
            }
        }
    }

    function db(a) {
        for (var b = a.split("/"), c = b.length; c--;) b[c] = X(b[c]);
        return b.join("/")
    }

    function eb(a, b, c) {
        var d = Ob(a, c);
        b.$$protocol = d.protocol, b.$$host = d.hostname, b.$$port = m(d.port) || jd[d.protocol] || null
    }

    function fb(a, b, c) {
        var d = "/" !== a.charAt(0);
        d && (a = "/" + a);
        var e = Ob(a, c);
        b.$$path = decodeURIComponent(d && "/" === e.pathname.charAt(0) ? e.pathname.substring(1) : e.pathname), b.$$search = V(e.search), b.$$hash = decodeURIComponent(e.hash), b.$$path && "/" != b.$$path.charAt(0) && (b.$$path = "/" + b.$$path)
    }

    function gb(a, b) {
        return 0 === b.indexOf(a) ? b.substr(a.length) : void 0
    }

    function hb(a) {
        var b = a.indexOf("#");
        return -1 == b ? a : a.substr(0, b)
    }

    function ib(a) {
        return a.replace(/(#.+)|#$/, "$1")
    }

    function jb(a) {
        return a.substr(0, hb(a).lastIndexOf("/") + 1)
    }

    function kb(a) {
        return a.substring(0, a.indexOf("/", a.indexOf("//") + 2))
    }

    function lb(a, b) {
        this.$$html5 = !0, b = b || "";
        var d = jb(a);
        eb(a, this, a), this.$$parse = function(b) {
            var c = gb(d, b);
            if (!u(c)) throw kd("ipthprfx", 'Invalid url "{0}", missing path prefix "{1}".', b, d);
            fb(c, this, a), this.$$path || (this.$$path = "/"), this.$$compose()
        }, this.$$compose = function() {
            var a = W(this.$$search),
                b = this.$$hash ? "#" + X(this.$$hash) : "";
            this.$$url = db(this.$$path) + (a ? "?" + a : "") + b, this.$$absUrl = d + this.$$url.substr(1)
        }, this.$$parseLinkUrl = function(e, f) {
            var g, h, i;
            return (g = gb(a, e)) !== c ? (h = g, i = (g = gb(b, g)) !== c ? d + (gb("/", g) || g) : a + h) : (g = gb(d, e)) !== c ? i = d + g : d == e + "/" && (i = d), i && this.$$parse(i), !!i
        }
    }

    function mb(a, b) {
        var c = jb(a);
        eb(a, this, a), this.$$parse = function(d) {
            function e(a, b, c) {
                var d, e = /^\/[A-Z]:(\/.*)/;
                return 0 === b.indexOf(c) && (b = b.replace(c, "")), e.exec(b) ? a : (d = e.exec(a), d ? d[1] : a)
            }
            var f = gb(a, d) || gb(c, d),
                g = "#" == f.charAt(0) ? gb(b, f) : this.$$html5 ? f : "";
            if (!u(g)) throw kd("ihshprfx", 'Invalid url "{0}", missing hash prefix "{1}".', d, b);
            fb(g, this, a), this.$$path = e(this.$$path, g, a), this.$$compose()
        }, this.$$compose = function() {
            var c = W(this.$$search),
                d = this.$$hash ? "#" + X(this.$$hash) : "";
            this.$$url = db(this.$$path) + (c ? "?" + c : "") + d, this.$$absUrl = a + (this.$$url ? b + this.$$url : "")
        }, this.$$parseLinkUrl = function(b, c) {
            return hb(a) == hb(b) ? (this.$$parse(b), !0) : !1
        }
    }

    function nb(a, b) {
        this.$$html5 = !0, mb.apply(this, arguments);
        var c = jb(a);
        this.$$parseLinkUrl = function(d, e) {
            var f, g;
            return a == hb(d) ? f = d : (g = gb(c, d)) ? f = a + b + g : c === d + "/" && (f = c), f && this.$$parse(f), !!f
        }, this.$$compose = function() {
            var c = W(this.$$search),
                d = this.$$hash ? "#" + X(this.$$hash) : "";
            this.$$url = db(this.$$path) + (c ? "?" + c : "") + d, this.$$absUrl = a + b + this.$$url
        }
    }

    function ob(a) {
        return function() {
            return this[a]
        }
    }

    function pb(a, b) {
        return function(c) {
            return r(c) ? this[a] : (this[a] = b(c), this.$$compose(), this)
        }
    }

    function qb() {
        var b = "",
            c = !1;
        this.hashPrefix = function(a) {
            return s(a) ? (b = a, this) : b
        }, this.html5Mode = function(a) {
            return s(a) ? (c = a, this) : c
        }, this.$get = ["$rootScope", "$browser", "$sniffer", "$rootElement", function(d, e, f, g) {
            function h(a) {
                d.$broadcast("$locationChangeSuccess", i.absUrl(), a)
            }
            var i, j, k, l = e.baseHref(),
                m = e.url();
            c ? (k = kb(m) + (l || "/"), j = f.history ? lb : nb) : (k = hb(m), j = mb), i = new j(k, "#" + b), i.$$parseLinkUrl(m, m);
            var n = /^\s*(javascript|mailto):/i;
            g.on("click", function(b) {
                if (!b.ctrlKey && !b.metaKey && 2 != b.which) {
                    for (var c = wc(b.target);
                        "a" !== qc(c[0].nodeName);)
                        if (c[0] === g[0] || !(c = c.parent())[0]) return;
                    var f = c.prop("href"),
                        h = c.attr("href") || c.attr("xlink:href");
                    t(f) && "[object SVGAnimatedString]" === f.toString() && (f = Ob(f.animVal).href), n.test(f) || !f || c.attr("target") || b.isDefaultPrevented() || i.$$parseLinkUrl(f, h) && (b.preventDefault(), i.absUrl() != e.url() && (d.$apply(), a.angular["ff-684208-preventDefault"] = !0))
                }
            }), i.absUrl() != m && e.url(i.absUrl(), !0), e.onUrlChange(function(a) {
                i.absUrl() != a && (d.$evalAsync(function() {
                    var b = i.absUrl();
                    i.$$parse(a), d.$broadcast("$locationChangeStart", a, b).defaultPrevented ? (i.$$parse(b), e.url(b)) : h(b)
                }), d.$$phase || d.$digest())
            });
            var o = 0;
            return d.$watch(function() {
                var a = ib(e.url()),
                    b = ib(i.absUrl()),
                    c = i.$$replace;
                return o && a == b || (o++, d.$evalAsync(function() {
                    d.$broadcast("$locationChangeStart", i.absUrl(), a).defaultPrevented ? i.$$parse(a) : (e.url(i.absUrl(), c), h(a))
                })), i.$$replace = !1, o
            }), i
        }]
    }

    function rb() {
        var a = !0,
            b = this;
        this.debugEnabled = function(b) {
            return s(b) ? (a = b, this) : a
        }, this.$get = ["$window", function(c) {
            function d(a) {
                return a instanceof Error && (a.stack ? a = a.message && -1 === a.stack.indexOf(a.message) ? "Error: " + a.message + "\n" + a.stack : a.stack : a.sourceURL && (a = a.message + "\n" + a.sourceURL + ":" + a.line)), a
            }

            function e(a) {
                var b = c.console || {},
                    e = b[a] || b.log || o,
                    g = !1;
                try {
                    g = !!e.apply
                } catch (h) {}
                return g ? function() {
                    var a = [];
                    return f(arguments, function(b) {
                        a.push(d(b))
                    }), e.apply(b, a)
                } : function(a, b) {
                    e(a, null == b ? "" : b)
                }
            }
            return {
                log: e("log"),
                info: e("info"),
                warn: e("warn"),
                error: e("error"),
                debug: function() {
                    var c = e("debug");
                    return function() {
                        a && c.apply(b, arguments)
                    }
                }()
            }
        }]
    }

    function sb(a, b) {
        if ("__defineGetter__" === a || "__defineSetter__" === a || "__lookupGetter__" === a || "__lookupSetter__" === a || "__proto__" === a) throw md("isecfld", "Attempting to access a disallowed field in Angular expressions! Expression: {0}", b);
        return a
    }

    function tb(a, b) {
        if (a += "", !u(a)) throw md("iseccst", "Cannot convert object to primitive value! Expression: {0}", b);
        return a
    }

    function ub(a, b) {
        if (a) {
            if (a.constructor === a) throw md("isecfn", "Referencing Function in Angular expressions is disallowed! Expression: {0}", b);
            if (a.document && a.location && a.alert && a.setInterval) throw md("isecwindow", "Referencing the Window in Angular expressions is disallowed! Expression: {0}", b);
            if (a.children && (a.nodeName || a.prop && a.attr && a.find)) throw md("isecdom", "Referencing DOM nodes in Angular expressions is disallowed! Expression: {0}", b);
            if (a === Object) throw md("isecobj", "Referencing Object in Angular expressions is disallowed! Expression: {0}", b)
        }
        return a
    }

    function vb(a, b) {
        if (a) {
            if (a.constructor === a) throw md("isecfn", "Referencing Function in Angular expressions is disallowed! Expression: {0}", b);
            if (a === od || a === pd || qd && a === qd) throw md("isecff", "Referencing call, apply or bind in Angular expressions is disallowed! Expression: {0}", b)
        }
    }

    function wb(a, b, d, e, f) {
        ub(a, e), f = f || {};
        for (var g, h = b.split("."), i = 0; h.length > 1; i++) {
            g = sb(h.shift(), e);
            var j = ub(a[g], e);
            j || (j = {}, a[g] = j), a = j, a.then && f.unwrapPromises && (ld(e), "$$v" in a || ! function(a) {
                a.then(function(b) {
                    a.$$v = b
                })
            }(a), a.$$v === c && (a.$$v = {}), a = a.$$v)
        }
        return g = sb(h.shift(), e), ub(a[g], e), a[g] = d, d
    }

    function xb(a) {
        return "constructor" == a
    }

    function yb(a, b, d, e, f, g, h) {
        sb(a, g), sb(b, g), sb(d, g), sb(e, g), sb(f, g);
        var i = function(a) {
                return ub(a, g)
            },
            j = h.expensiveChecks,
            k = j || xb(a) ? i : p,
            l = j || xb(b) ? i : p,
            m = j || xb(d) ? i : p,
            n = j || xb(e) ? i : p,
            o = j || xb(f) ? i : p;
        return h.unwrapPromises ? function(h, i) {
            var j, p = i && i.hasOwnProperty(a) ? i : h;
            return null == p ? p : (p = k(p[a]), p && p.then && (ld(g), "$$v" in p || (j = p, j.$$v = c, j.then(function(a) {
                j.$$v = k(a)
            })), p = k(p.$$v)), b ? null == p ? c : (p = l(p[b]), p && p.then && (ld(g), "$$v" in p || (j = p, j.$$v = c, j.then(function(a) {
                j.$$v = l(a)
            })), p = l(p.$$v)), d ? null == p ? c : (p = m(p[d]), p && p.then && (ld(g), "$$v" in p || (j = p, j.$$v = c, j.then(function(a) {
                j.$$v = m(a)
            })), p = m(p.$$v)), e ? null == p ? c : (p = n(p[e]), p && p.then && (ld(g), "$$v" in p || (j = p, j.$$v = c, j.then(function(a) {
                j.$$v = n(a)
            })), p = n(p.$$v)), f ? null == p ? c : (p = o(p[f]), p && p.then && (ld(g), "$$v" in p || (j = p, j.$$v = c, j.then(function(a) {
                j.$$v = o(a)
            })), p = o(p.$$v)), p) : p) : p) : p) : p)
        } : function(g, h) {
            var i = h && h.hasOwnProperty(a) ? h : g;
            return null == i ? i : (i = k(i[a]), b ? null == i ? c : (i = l(i[b]), d ? null == i ? c : (i = m(i[d]), e ? null == i ? c : (i = n(i[e]), f ? null == i ? c : i = o(i[f]) : i) : i) : i) : i)
        }
    }

    function zb(a, b) {
        return function(c, d) {
            return a(c, d, ld, ub, b)
        }
    }

    function Ab(a, b, d) {
        var e = b.expensiveChecks,
            g = e ? wd : vd;
        if (g.hasOwnProperty(a)) return g[a];
        var h, i = a.split("."),
            j = i.length;
        if (b.csp) h = 6 > j ? yb(i[0], i[1], i[2], i[3], i[4], d, b) : function(a, e) {
            var f, g = 0;
            do f = yb(i[g++], i[g++], i[g++], i[g++], i[g++], d, b)(a, e), e = c, a = f; while (j > g);
            return f
        };
        else {
            var k = "var p;\n";
            e && (k += "s = eso(s, fe);\nl = eso(l, fe);\n");
            var l = e;
            f(i, function(a, c) {
                sb(a, d);
                var f = (c ? "s" : '((l&&l.hasOwnProperty("' + a + '"))?l:s)') + '["' + a + '"]',
                    g = e || xb(a);
                g && (f = "eso(" + f + ", fe)", l = !0), k += "if(s == null) return undefined;\ns=" + f + ";\n", b.unwrapPromises && (k += 'if (s && s.then) {\n pw("' + d.replace(/(["\r\n])/g, "\\$1") + '");\n if (!("$$v" in s)) {\n p=s;\n p.$$v = undefined;\n p.then(function(v) {p.$$v=' + (g ? "eso(v)" : "v") + ";});\n}\n s=" + (g ? "eso(s.$$v)" : "s.$$v") + "\n}\n")
            }), k += "return s;";
            var m = new Function("s", "l", "pw", "eso", "fe", k);
            m.toString = q(k), (l || b.unwrapPromises) && (m = zb(m, d)), h = m
        }
        return "hasOwnProperty" !== a && (g[a] = h), h
    }

    function Bb() {
        var a = {},
            b = {},
            c = {
                csp: !1,
                unwrapPromises: !1,
                logPromiseWarnings: !0,
                expensiveChecks: !1
            };
        this.unwrapPromises = function(a) {
            return s(a) ? (c.unwrapPromises = !!a, this) : c.unwrapPromises
        }, this.logPromiseWarnings = function(a) {
            return s(a) ? (c.logPromiseWarnings = a, this) : c.logPromiseWarnings
        }, this.$get = ["$filter", "$sniffer", "$log", function(d, e, f) {
            c.csp = e.csp;
            var g = {
                csp: c.csp,
                unwrapPromises: c.unwrapPromises,
                logPromiseWarnings: c.logPromiseWarnings,
                expensiveChecks: !0
            };
            return ld = function(a) {
                    c.logPromiseWarnings && !nd.hasOwnProperty(a) && (nd[a] = !0, f.warn("[$parse] Promise found in the expression `" + a + "`. Automatic unwrapping of promises in Angular expressions is deprecated."))
                },
                function(e, f) {
                    var h;
                    switch (typeof e) {
                        case "string":
                            var i = f ? b : a;
                            if (i.hasOwnProperty(e)) return i[e];
                            var j = f ? g : c,
                                k = new td(j),
                                l = new ud(k, d, j);
                            return h = l.parse(e), "hasOwnProperty" !== e && (i[e] = h), h;
                        case "function":
                            return e;
                        default:
                            return o
                    }
                }
        }]
    }

    function Cb() {
        this.$get = ["$rootScope", "$exceptionHandler", function(a, b) {
            return Db(function(b) {
                a.$evalAsync(b)
            }, b)
        }]
    }

    function Db(a, b) {
        function d(a) {
            return a
        }

        function e(a) {
            return j(a)
        }

        function g(a) {
            var b = h(),
                c = 0,
                d = Gc(a) ? [] : {};
            return f(a, function(a, e) {
                c++, i(a).then(function(a) {
                    d.hasOwnProperty(e) || (d[e] = a, --c || b.resolve(d))
                }, function(a) {
                    d.hasOwnProperty(e) || b.reject(a)
                })
            }), 0 === c && b.resolve(d), b.promise
        }
        var h = function() {
                var f, g, j = [];
                return g = {
                    resolve: function(b) {
                        if (j) {
                            var d = j;
                            j = c, f = i(b), d.length && a(function() {
                                for (var a, b = 0, c = d.length; c > b; b++) a = d[b], f.then(a[0], a[1], a[2])
                            })
                        }
                    },
                    reject: function(a) {
                        g.resolve(k(a))
                    },
                    notify: function(b) {
                        if (j) {
                            var c = j;
                            j.length && a(function() {
                                for (var a, d = 0, e = c.length; e > d; d++) a = c[d], a[2](b)
                            })
                        }
                    },
                    promise: {
                        then: function(a, c, g) {
                            var i = h(),
                                k = function(c) {
                                    try {
                                        i.resolve((x(a) ? a : d)(c))
                                    } catch (e) {
                                        i.reject(e), b(e)
                                    }
                                },
                                l = function(a) {
                                    try {
                                        i.resolve((x(c) ? c : e)(a))
                                    } catch (d) {
                                        i.reject(d), b(d)
                                    }
                                },
                                m = function(a) {
                                    try {
                                        i.notify((x(g) ? g : d)(a))
                                    } catch (c) {
                                        b(c)
                                    }
                                };
                            return j ? j.push([k, l, m]) : f.then(k, l, m), i.promise
                        },
                        "catch": function(a) {
                            return this.then(null, a)
                        },
                        "finally": function(a) {
                            function b(a, b) {
                                var c = h();
                                return b ? c.resolve(a) : c.reject(a), c.promise
                            }

                            function c(c, e) {
                                var f = null;
                                try {
                                    f = (a || d)()
                                } catch (g) {
                                    return b(g, !1)
                                }
                                return D(f) ? f.then(function() {
                                    return b(c, e)
                                }, function(a) {
                                    return b(a, !1)
                                }) : b(c, e)
                            }
                            return this.then(function(a) {
                                return c(a, !0)
                            }, function(a) {
                                return c(a, !1)
                            })
                        }
                    }
                }
            },
            i = function(b) {
                return D(b) ? b : {
                    then: function(c) {
                        var d = h();
                        return a(function() {
                            d.resolve(c(b))
                        }), d.promise
                    }
                }
            },
            j = function(a) {
                var b = h();
                return b.reject(a), b.promise
            },
            k = function(c) {
                return {
                    then: function(d, f) {
                        var g = h();
                        return a(function() {
                            try {
                                g.resolve((x(f) ? f : e)(c))
                            } catch (a) {
                                g.reject(a), b(a)
                            }
                        }), g.promise
                    }
                }
            },
            l = function(c, f, g, k) {
                var l, m = h(),
                    n = function(a) {
                        try {
                            return (x(f) ? f : d)(a)
                        } catch (c) {
                            return b(c), j(c)
                        }
                    },
                    o = function(a) {
                        try {
                            return (x(g) ? g : e)(a)
                        } catch (c) {
                            return b(c), j(c)
                        }
                    },
                    p = function(a) {
                        try {
                            return (x(k) ? k : d)(a)
                        } catch (c) {
                            b(c)
                        }
                    };
                return a(function() {
                    i(c).then(function(a) {
                        l || (l = !0, m.resolve(i(a).then(n, o, p)))
                    }, function(a) {
                        l || (l = !0, m.resolve(o(a)))
                    }, function(a) {
                        l || m.notify(p(a))
                    })
                }), m.promise
            };
        return {
            defer: h,
            reject: j,
            when: l,
            all: g
        }
    }

    function Eb() {
        this.$get = ["$window", "$timeout", function(a, b) {
            var c = a.requestAnimationFrame || a.webkitRequestAnimationFrame || a.mozRequestAnimationFrame,
                d = a.cancelAnimationFrame || a.webkitCancelAnimationFrame || a.mozCancelAnimationFrame || a.webkitCancelRequestAnimationFrame,
                e = !!c,
                f = e ? function(a) {
                    var b = c(a);
                    return function() {
                        d(b)
                    }
                } : function(a) {
                    var c = b(a, 16.66, !1);
                    return function() {
                        b.cancel(c)
                    }
                };
            return f.supported = e, f
        }]
    }

    function Fb() {
        var a = 10,
            b = d("$rootScope"),
            c = null;
        this.digestTtl = function(b) {
            return arguments.length && (a = b), a
        }, this.$get = ["$injector", "$exceptionHandler", "$parse", "$browser", function(d, g, h, i) {
            function k() {
                this.$id = j(), this.$$phase = this.$parent = this.$$watchers = this.$$nextSibling = this.$$prevSibling = this.$$childHead = this.$$childTail = null, this["this"] = this.$root = this, this.$$destroyed = !1, this.$$asyncQueue = [], this.$$postDigestQueue = [], this.$$listeners = {}, this.$$listenerCount = {}, this.$$isolateBindings = {}
            }

            function l(a) {
                if (r.$$phase) throw b("inprog", "{0} already in progress", r.$$phase);
                r.$$phase = a
            }

            function m() {
                r.$$phase = null
            }

            function n(a, b) {
                var c = h(a);
                return ca(c, b), c
            }

            function p(a, b, c) {
                do a.$$listenerCount[c] -= b, 0 === a.$$listenerCount[c] && delete a.$$listenerCount[c]; while (a = a.$parent)
            }

            function q() {}
            k.prototype = {
                constructor: k,
                $new: function(a) {
                    var b;
                    return a ? (b = new k, b.$root = this.$root, b.$$asyncQueue = this.$$asyncQueue, b.$$postDigestQueue = this.$$postDigestQueue) : (this.$$childScopeClass || (this.$$childScopeClass = function() {
                        this.$$watchers = this.$$nextSibling = this.$$childHead = this.$$childTail = null, this.$$listeners = {}, this.$$listenerCount = {}, this.$id = j(), this.$$childScopeClass = null
                    }, this.$$childScopeClass.prototype = this), b = new this.$$childScopeClass), b["this"] = b, b.$parent = this, b.$$prevSibling = this.$$childTail, this.$$childHead ? (this.$$childTail.$$nextSibling = b, this.$$childTail = b) : this.$$childHead = this.$$childTail = b, b
                },
                $watch: function(a, b, d) {
                    var e = this,
                        f = n(a, "watch"),
                        g = e.$$watchers,
                        h = {
                            fn: b,
                            last: q,
                            get: f,
                            exp: a,
                            eq: !!d
                        };
                    if (c = null, !x(b)) {
                        var i = n(b || o, "listener");
                        h.fn = function(a, b, c) {
                            i(c)
                        }
                    }
                    if ("string" == typeof a && f.constant) {
                        var j = h.fn;
                        h.fn = function(a, b, c) {
                            j.call(this, a, b, c), I(g, h)
                        }
                    }
                    return g || (g = e.$$watchers = []), g.unshift(h),
                        function() {
                            I(g, h), c = null
                        }
                },
                $watchCollection: function(a, b) {
                    function c() {
                        f = m(j);
                        var a, b, c;
                        if (t(f))
                            if (e(f)) {
                                g !== n && (g = n, q = g.length = 0, l++), a = f.length, q !== a && (l++, g.length = q = a);
                                for (var d = 0; a > d; d++) c = g[d] !== g[d] && f[d] !== f[d], c || g[d] === f[d] || (l++, g[d] = f[d])
                            } else {
                                g !== o && (g = o = {}, q = 0, l++), a = 0;
                                for (b in f) f.hasOwnProperty(b) && (a++, g.hasOwnProperty(b) ? (c = g[b] !== g[b] && f[b] !== f[b], c || g[b] === f[b] || (l++, g[b] = f[b])) : (q++, g[b] = f[b], l++));
                                if (q > a) {
                                    l++;
                                    for (b in g) g.hasOwnProperty(b) && !f.hasOwnProperty(b) && (q--, delete g[b])
                                }
                            }
                        else g !== f && (g = f, l++);
                        return l
                    }

                    function d() {
                        if (p ? (p = !1, b(f, f, j)) : b(f, i, j), k)
                            if (t(f))
                                if (e(f)) {
                                    i = new Array(f.length);
                                    for (var a = 0; a < f.length; a++) i[a] = f[a]
                                } else {
                                    i = {};
                                    for (var c in f) rc.call(f, c) && (i[c] = f[c])
                                }
                        else i = f
                    }
                    var f, g, i, j = this,
                        k = b.length > 1,
                        l = 0,
                        m = h(a),
                        n = [],
                        o = {},
                        p = !0,
                        q = 0;
                    return this.$watch(c, d)
                },
                $digest: function() {
                    var d, e, f, h, j, k, n, o, p, r, s, t = this.$$asyncQueue,
                        u = this.$$postDigestQueue,
                        v = a,
                        w = this,
                        y = [];
                    l("$digest"), i.$$checkUrlChange(), c = null;
                    do {
                        for (k = !1, o = w; t.length;) {
                            try {
                                s = t.shift(), s.scope.$eval(s.expression)
                            } catch (z) {
                                m(), g(z)
                            }
                            c = null
                        }
                        a: do {
                            if (h = o.$$watchers)
                                for (j = h.length; j--;) try {
                                    if (d = h[j])
                                        if ((e = d.get(o)) === (f = d.last) || (d.eq ? L(e, f) : "number" == typeof e && "number" == typeof f && isNaN(e) && isNaN(f))) {
                                            if (d === c) {
                                                k = !1;
                                                break a
                                            }
                                        } else k = !0, c = d, d.last = d.eq ? J(e, null) : e, d.fn(e, f === q ? e : f, o), 5 > v && (p = 4 - v, y[p] || (y[p] = []), r = x(d.exp) ? "fn: " + (d.exp.name || d.exp.toString()) : d.exp, r += "; newVal: " + Q(e) + "; oldVal: " + Q(f), y[p].push(r))
                                } catch (z) {
                                    m(), g(z)
                                }
                            if (!(n = o.$$childHead || o !== w && o.$$nextSibling))
                                for (; o !== w && !(n = o.$$nextSibling);) o = o.$parent
                        } while (o = n);
                        if ((k || t.length) && !v--) throw m(), b("infdig", "{0} $digest() iterations reached. Aborting!\nWatchers fired in the last 5 iterations: {1}", a, Q(y))
                    } while (k || t.length);
                    for (m(); u.length;) try {
                        u.shift()()
                    } catch (z) {
                        g(z)
                    }
                },
                $destroy: function() {
                    if (!this.$$destroyed) {
                        var a = this.$parent;
                        this.$broadcast("$destroy"), this.$$destroyed = !0, this !== r && (f(this.$$listenerCount, O(null, p, this)), a.$$childHead == this && (a.$$childHead = this.$$nextSibling), a.$$childTail == this && (a.$$childTail = this.$$prevSibling), this.$$prevSibling && (this.$$prevSibling.$$nextSibling = this.$$nextSibling), this.$$nextSibling && (this.$$nextSibling.$$prevSibling = this.$$prevSibling), this.$parent = this.$$nextSibling = this.$$prevSibling = this.$$childHead = this.$$childTail = this.$root = null, this.$$listeners = {}, this.$$watchers = this.$$asyncQueue = this.$$postDigestQueue = [], this.$destroy = this.$digest = this.$apply = o, this.$on = this.$watch = function() {
                            return o
                        })
                    }
                },
                $eval: function(a, b) {
                    return h(a)(this, b)
                },
                $evalAsync: function(a) {
                    r.$$phase || r.$$asyncQueue.length || i.defer(function() {
                        r.$$asyncQueue.length && r.$digest()
                    }), this.$$asyncQueue.push({
                        scope: this,
                        expression: a
                    })
                },
                $$postDigest: function(a) {
                    this.$$postDigestQueue.push(a)
                },
                $apply: function(a) {
                    try {
                        return l("$apply"), this.$eval(a)
                    } catch (b) {
                        g(b)
                    } finally {
                        m();
                        try {
                            r.$digest()
                        } catch (b) {
                            throw g(b), b
                        }
                    }
                },
                $on: function(a, b) {
                    var c = this.$$listeners[a];
                    c || (this.$$listeners[a] = c = []), c.push(b);
                    var d = this;
                    do d.$$listenerCount[a] || (d.$$listenerCount[a] = 0), d.$$listenerCount[a]++; while (d = d.$parent);
                    var e = this;
                    return function() {
                        var d = H(c, b); - 1 !== d && (c[d] = null, p(e, 1, a))
                    }
                },
                $emit: function(a, b) {
                    var c, d, e, f = [],
                        h = this,
                        i = !1,
                        j = {
                            name: a,
                            targetScope: h,
                            stopPropagation: function() {
                                i = !0
                            },
                            preventDefault: function() {
                                j.defaultPrevented = !0
                            },
                            defaultPrevented: !1
                        },
                        k = M([j], arguments, 1);
                    do {
                        for (c = h.$$listeners[a] || f, j.currentScope = h, d = 0, e = c.length; e > d; d++)
                            if (c[d]) try {
                                c[d].apply(null, k)
                            } catch (l) {
                                g(l)
                            } else c.splice(d, 1), d--, e--;
                        if (i) return j;
                        h = h.$parent
                    } while (h);
                    return j
                },
                $broadcast: function(a, b) {
                    for (var c, d, e, f = this, h = f, i = f, j = {
                            name: a,
                            targetScope: f,
                            preventDefault: function() {
                                j.defaultPrevented = !0
                            },
                            defaultPrevented: !1
                        }, k = M([j], arguments, 1); h = i;) {
                        for (j.currentScope = h, c = h.$$listeners[a] || [], d = 0, e = c.length; e > d; d++)
                            if (c[d]) try {
                                c[d].apply(null, k)
                            } catch (l) {
                                g(l)
                            } else c.splice(d, 1), d--, e--;
                        if (!(i = h.$$listenerCount[a] && h.$$childHead || h !== f && h.$$nextSibling))
                            for (; h !== f && !(i = h.$$nextSibling);) h = h.$parent
                    }
                    return j
                }
            };
            var r = new k;
            return r
        }]
    }

    function Gb() {
        var a = /^\s*(https?|ftp|mailto|tel|file):/,
            b = /^\s*((https?|ftp|file):|data:image\/)/;
        this.aHrefSanitizationWhitelist = function(b) {
            return s(b) ? (a = b, this) : a
        }, this.imgSrcSanitizationWhitelist = function(a) {
            return s(a) ? (b = a, this) : b
        }, this.$get = function() {
            return function(c, d) {
                var e, f = d ? b : a;
                return vc && !(vc >= 8) || (e = Ob(c).href, "" === e || e.match(f)) ? c : "unsafe:" + e
            }
        }
    }

    function Hb(a) {
        return a.replace(/([-()\[\]{}+?*.$\^|,:#<!\\])/g, "\\$1").replace(/\x08/g, "\\x08")
    }

    function Ib(a) {
        if ("self" === a) return a;
        if (u(a)) {
            if (a.indexOf("***") > -1) throw xd("iwcard", "Illegal sequence *** in string matcher.  String: {0}", a);
            return a = Hb(a).replace("\\*\\*", ".*").replace("\\*", "[^:/.?&;]*"), new RegExp("^" + a + "$")
        }
        if (y(a)) return new RegExp("^" + a.source + "$");
        throw xd("imatcher", 'Matchers may only be "self", string patterns or RegExp objects')
    }

    function Jb(a) {
        var b = [];
        return s(a) && f(a, function(a) {
            b.push(Ib(a))
        }), b
    }

    function Kb() {
        this.SCE_CONTEXTS = yd;
        var a = ["self"],
            b = [];
        this.resourceUrlWhitelist = function(b) {
            return arguments.length && (a = Jb(b)), a
        }, this.resourceUrlBlacklist = function(a) {
            return arguments.length && (b = Jb(a)), b
        }, this.$get = ["$injector", function(d) {
            function e(a, b) {
                return "self" === a ? Pb(b) : !!a.exec(b.href)
            }

            function f(c) {
                var d, f, g = Ob(c.toString()),
                    h = !1;
                for (d = 0, f = a.length; f > d; d++)
                    if (e(a[d], g)) {
                        h = !0;
                        break
                    }
                if (h)
                    for (d = 0, f = b.length; f > d; d++)
                        if (e(b[d], g)) {
                            h = !1;
                            break
                        }
                return h
            }

            function g(a) {
                var b = function(a) {
                    this.$$unwrapTrustedValue = function() {
                        return a
                    }
                };
                return a && (b.prototype = new a), b.prototype.valueOf = function() {
                    return this.$$unwrapTrustedValue()
                }, b.prototype.toString = function() {
                    return this.$$unwrapTrustedValue().toString()
                }, b
            }

            function h(a, b) {
                var d = m.hasOwnProperty(a) ? m[a] : null;
                if (!d) throw xd("icontext", "Attempted to trust a value in invalid context. Context: {0}; Value: {1}", a, b);
                if (null === b || b === c || "" === b) return b;
                if ("string" != typeof b) throw xd("itype", "Attempted to trust a non-string value in a content requiring a string: Context: {0}", a);
                return new d(b)
            }

            function i(a) {
                return a instanceof l ? a.$$unwrapTrustedValue() : a
            }

            function j(a, b) {
                if (null === b || b === c || "" === b) return b;
                var d = m.hasOwnProperty(a) ? m[a] : null;
                if (d && b instanceof d) return b.$$unwrapTrustedValue();
                if (a === yd.RESOURCE_URL) {
                    if (f(b)) return b;
                    throw xd("insecurl", "Blocked loading resource from url not allowed by $sceDelegate policy.  URL: {0}", b.toString())
                }
                if (a === yd.HTML) return k(b);
                throw xd("unsafe", "Attempting to use an unsafe value in a safe context.")
            }
            var k = function(a) {
                throw xd("unsafe", "Attempting to use an unsafe value in a safe context.")
            };
            d.has("$sanitize") && (k = d.get("$sanitize"));
            var l = g(),
                m = {};
            return m[yd.HTML] = g(l), m[yd.CSS] = g(l), m[yd.URL] = g(l), m[yd.JS] = g(l), m[yd.RESOURCE_URL] = g(m[yd.URL]), {
                trustAs: h,
                getTrusted: j,
                valueOf: i
            }
        }]
    }

    function Lb() {
        var a = !0;
        this.enabled = function(b) {
            return arguments.length && (a = !!b), a
        }, this.$get = ["$parse", "$sniffer", "$sceDelegate", function(b, c, d) {
            if (a && c.msie && c.msieDocumentMode < 8) throw xd("iequirks", "Strict Contextual Escaping does not support Internet Explorer version < 9 in quirks mode.  You can fix this by adding the text <!doctype html> to the top of your HTML document.  See http://docs.angularjs.org/api/ng.$sce for more information.");
            var e = K(yd);
            e.isEnabled = function() {
                return a
            }, e.trustAs = d.trustAs, e.getTrusted = d.getTrusted, e.valueOf = d.valueOf, a || (e.trustAs = e.getTrusted = function(a, b) {
                return b
            }, e.valueOf = p), e.parseAs = function(a, c) {
                var d = b(c);
                return d.literal && d.constant ? d : function(b, c) {
                    return e.getTrusted(a, d(b, c))
                }
            };
            var g = e.parseAs,
                h = e.getTrusted,
                i = e.trustAs;
            return f(yd, function(a, b) {
                var c = qc(b);
                e[ja("parse_as_" + c)] = function(b) {
                    return g(a, b)
                }, e[ja("get_trusted_" + c)] = function(b) {
                    return h(a, b)
                }, e[ja("trust_as_" + c)] = function(b) {
                    return i(a, b)
                }
            }), e
        }]
    }

    function Mb() {
        this.$get = ["$window", "$document", function(a, b) {
            var c, d, e = {},
                f = m((/android (\d+)/.exec(qc((a.navigator || {}).userAgent)) || [])[1]),
                g = /Boxee/i.test((a.navigator || {}).userAgent),
                h = b[0] || {},
                i = h.documentMode,
                j = /^(Moz|webkit|O|ms)(?=[A-Z])/,
                k = h.body && h.body.style,
                l = !1,
                n = !1;
            if (k) {
                for (var o in k)
                    if (d = j.exec(o)) {
                        c = d[0], c = c.substr(0, 1).toUpperCase() + c.substr(1);
                        break
                    }
                c || (c = "WebkitOpacity" in k && "webkit"), l = !!("transition" in k || c + "Transition" in k), n = !!("animation" in k || c + "Animation" in k), !f || l && n || (l = u(h.body.style.webkitTransition), n = u(h.body.style.webkitAnimation))
            }
            return {
                history: !(!a.history || !a.history.pushState || 4 > f || g),
                hashchange: "onhashchange" in a && (!i || i > 7),
                hasEvent: function(a) {
                    if ("input" == a && 9 == vc) return !1;
                    if (r(e[a])) {
                        var b = h.createElement("div");
                        e[a] = "on" + a in b
                    }
                    return e[a]
                },
                csp: Ic(),
                vendorPrefix: c,
                transitions: l,
                animations: n,
                android: f,
                msie: vc,
                msieDocumentMode: i
            }
        }]
    }

    function Nb() {
        this.$get = ["$rootScope", "$browser", "$q", "$exceptionHandler", function(a, b, c, d) {
            function e(e, g, h) {
                var i, j = c.defer(),
                    k = j.promise,
                    l = s(h) && !h;
                return i = b.defer(function() {
                    try {
                        j.resolve(e())
                    } catch (b) {
                        j.reject(b), d(b)
                    } finally {
                        delete f[k.$$timeoutId]
                    }
                    l || a.$apply()
                }, g), k.$$timeoutId = i, f[i] = j, k
            }
            var f = {};
            return e.cancel = function(a) {
                return a && a.$$timeoutId in f ? (f[a.$$timeoutId].reject("canceled"), delete f[a.$$timeoutId], b.defer.cancel(a.$$timeoutId)) : !1
            }, e
        }]
    }

    function Ob(a, b) {
        var c = a;
        return vc && (zd.setAttribute("href", c), c = zd.href), zd.setAttribute("href", c), {
            href: zd.href,
            protocol: zd.protocol ? zd.protocol.replace(/:$/, "") : "",
            host: zd.host,
            search: zd.search ? zd.search.replace(/^\?/, "") : "",
            hash: zd.hash ? zd.hash.replace(/^#/, "") : "",
            hostname: zd.hostname,
            port: zd.port,
            pathname: "/" === zd.pathname.charAt(0) ? zd.pathname : "/" + zd.pathname
        }
    }

    function Pb(a) {
        var b = u(a) ? Ob(a) : a;
        return b.protocol === Ad.protocol && b.host === Ad.host
    }

    function Qb() {
        this.$get = q(a)
    }

    function Rb(a) {
        function b(d, e) {
            if (t(d)) {
                var g = {};
                return f(d, function(a, c) {
                    g[c] = b(c, a)
                }), g
            }
            return a.factory(d + c, e)
        }
        var c = "Filter";
        this.register = b, this.$get = ["$injector", function(a) {
            return function(b) {
                return a.get(b + c)
            }
        }], b("currency", Tb), b("date", _b), b("filter", Sb), b("json", ac), b("limitTo", bc), b("lowercase", Fd), b("number", Ub), b("orderBy", cc), b("uppercase", Gd)
    }

    function Sb() {
        return function(a, b, c) {
            if (!Gc(a)) return a;
            var d = typeof c,
                e = [];
            e.check = function(a) {
                for (var b = 0; b < e.length; b++)
                    if (!e[b](a)) return !1;
                return !0
            }, "function" !== d && (c = "boolean" === d && c ? function(a, b) {
                return Ec.equals(a, b)
            } : function(a, b) {
                if (a && b && "object" == typeof a && "object" == typeof b) {
                    for (var d in a)
                        if ("$" !== d.charAt(0) && rc.call(a, d) && c(a[d], b[d])) return !0;
                    return !1
                }
                return b = ("" + b).toLowerCase(), ("" + a).toLowerCase().indexOf(b) > -1
            });
            var f = function(a, b) {
                if ("string" == typeof b && "!" === b.charAt(0)) return !f(a, b.substr(1));
                switch (typeof a) {
                    case "boolean":
                    case "number":
                    case "string":
                        return c(a, b);
                    case "object":
                        switch (typeof b) {
                            case "object":
                                return c(a, b);
                            default:
                                for (var d in a)
                                    if ("$" !== d.charAt(0) && f(a[d], b)) return !0
                        }
                        return !1;
                    case "array":
                        for (var e = 0; e < a.length; e++)
                            if (f(a[e], b)) return !0;
                        return !1;
                    default:
                        return !1
                }
            };
            switch (typeof b) {
                case "boolean":
                case "number":
                case "string":
                    b = {
                        $: b
                    };
                case "object":
                    for (var g in b) ! function(a) {
                        "undefined" != typeof b[a] && e.push(function(c) {
                            return f("$" == a ? c : c && c[a], b[a])
                        })
                    }(g);
                    break;
                case "function":
                    e.push(b);
                    break;
                default:
                    return a
            }
            for (var h = [], i = 0; i < a.length; i++) {
                var j = a[i];
                e.check(j) && h.push(j)
            }
            return h
        }
    }

    function Tb(a) {
        var b = a.NUMBER_FORMATS;
        return function(a, c) {
            return r(c) && (c = b.CURRENCY_SYM), Vb(a, b.PATTERNS[1], b.GROUP_SEP, b.DECIMAL_SEP, 2).replace(/\u00A4/g, c)
        }
    }

    function Ub(a) {
        var b = a.NUMBER_FORMATS;
        return function(a, c) {
            return Vb(a, b.PATTERNS[0], b.GROUP_SEP, b.DECIMAL_SEP, c)
        }
    }

    function Vb(a, b, c, d, e) {
        if (null == a || !isFinite(a) || t(a)) return "";
        var f = 0 > a;
        a = Math.abs(a);
        var g = a + "",
            h = "",
            i = [],
            j = !1;
        if (-1 !== g.indexOf("e")) {
            var k = g.match(/([\d\.]+)e(-?)(\d+)/);
            k && "-" == k[2] && k[3] > e + 1 ? (g = "0", a = 0) : (h = g, j = !0)
        }
        if (j) e > 0 && a > -1 && 1 > a && (h = a.toFixed(e));
        else {
            var l = (g.split(Bd)[1] || "").length;
            r(e) && (e = Math.min(Math.max(b.minFrac, l), b.maxFrac)), a = +(Math.round(+(a.toString() + "e" + e)).toString() + "e" + -e), 0 === a && (f = !1);
            var m = ("" + a).split(Bd),
                n = m[0];
            m = m[1] || "";
            var o, p = 0,
                q = b.lgSize,
                s = b.gSize;
            if (n.length >= q + s)
                for (p = n.length - q, o = 0; p > o; o++)(p - o) % s === 0 && 0 !== o && (h += c), h += n.charAt(o);
            for (o = p; o < n.length; o++)(n.length - o) % q === 0 && 0 !== o && (h += c), h += n.charAt(o);
            for (; m.length < e;) m += "0";
            e && "0" !== e && (h += d + m.substr(0, e))
        }
        return i.push(f ? b.negPre : b.posPre), i.push(h), i.push(f ? b.negSuf : b.posSuf), i.join("")
    }

    function Wb(a, b, c) {
        var d = "";
        for (0 > a && (d = "-", a = -a), a = "" + a; a.length < b;) a = "0" + a;
        return c && (a = a.substr(a.length - b)), d + a
    }

    function Xb(a, b, c, d) {
        return c = c || 0,
            function(e) {
                var f = e["get" + a]();
                return (c > 0 || f > -c) && (f += c), 0 === f && -12 == c && (f = 12), Wb(f, b, d)
            }
    }

    function Yb(a, b) {
        return function(c, d) {
            var e = c["get" + a](),
                f = sc(b ? "SHORT" + a : a);
            return d[f][e]
        }
    }

    function Zb(a) {
        var b = -1 * a.getTimezoneOffset(),
            c = b >= 0 ? "+" : "";
        return c += Wb(Math[b > 0 ? "floor" : "ceil"](b / 60), 2) + Wb(Math.abs(b % 60), 2)
    }

    function $b(a, b) {
        return a.getHours() < 12 ? b.AMPMS[0] : b.AMPMS[1]
    }

    function _b(a) {
        function b(a) {
            var b;
            if (b = a.match(c)) {
                var d = new Date(0),
                    e = 0,
                    f = 0,
                    g = b[8] ? d.setUTCFullYear : d.setFullYear,
                    h = b[8] ? d.setUTCHours : d.setHours;
                b[9] && (e = m(b[9] + b[10]), f = m(b[9] + b[11])), g.call(d, m(b[1]), m(b[2]) - 1, m(b[3]));
                var i = m(b[4] || 0) - e,
                    j = m(b[5] || 0) - f,
                    k = m(b[6] || 0),
                    l = Math.round(1e3 * parseFloat("0." + (b[7] || 0)));
                return h.call(d, i, j, k, l), d
            }
            return a
        }
        var c = /^(\d{4})-?(\d\d)-?(\d\d)(?:T(\d\d)(?::?(\d\d)(?::?(\d\d)(?:\.(\d+))?)?)?(Z|([+-])(\d\d):?(\d\d))?)?$/;
        return function(c, d) {
            var e, g, h = "",
                i = [];
            if (d = d || "mediumDate", d = a.DATETIME_FORMATS[d] || d, u(c) && (c = Ed.test(c) ? m(c) : b(c)), v(c) && (c = new Date(c)), !w(c)) return c;
            for (; d;) g = Dd.exec(d), g ? (i = M(i, g, 1), d = i.pop()) : (i.push(d), d = null);
            return f(i, function(b) {
                e = Cd[b], h += e ? e(c, a.DATETIME_FORMATS) : b.replace(/(^'|'$)/g, "").replace(/''/g, "'")
            }), h
        }
    }

    function ac() {
        return function(a) {
            return Q(a, !0)
        }
    }

    function bc() {
        return function(a, b) {
            return Gc(a) || u(a) ? (b = Math.abs(Number(b)) === 1 / 0 ? Number(b) : m(b), b ? b > 0 ? a.slice(0, b) : a.slice(b) : u(a) ? "" : []) : a
        }
    }

    function cc(a) {
        return function(b, c, d) {
            function f(a, b) {
                for (var d = 0; d < c.length; d++) {
                    var e = c[d](a, b);
                    if (0 !== e) return e
                }
                return 0
            }

            function g(a, b) {
                return S(b) ? function(b, c) {
                    return a(c, b)
                } : a
            }

            function h(a, b) {
                var c = typeof a,
                    d = typeof b;
                return c == d ? (w(a) && w(b) && (a = a.valueOf(), b = b.valueOf()), "string" == c && (a = a.toLowerCase(), b = b.toLowerCase()), a === b ? 0 : b > a ? -1 : 1) : d > c ? -1 : 1
            }
            return e(b) ? (c = Gc(c) ? c : [c], 0 === c.length && (c = ["+"]), c = F(c, function(b) {
                var c = !1,
                    d = b || p;
                if (u(b)) {
                    if (("+" == b.charAt(0) || "-" == b.charAt(0)) && (c = "-" == b.charAt(0), b = b.substring(1)), "" === b) return g(function(a, b) {
                        return h(a, b)
                    }, c);
                    if (d = a(b), d.constant) {
                        var e = d();
                        return g(function(a, b) {
                            return h(a[e], b[e])
                        }, c)
                    }
                }
                return g(function(a, b) {
                    return h(d(a), d(b))
                }, c)
            }), Ac.call(b).sort(g(f, d))) : b
        }
    }

    function dc(a) {
        return x(a) && (a = {
            link: a
        }), a.restrict = a.restrict || "AC", q(a)
    }

    function ec(a, b, c, d) {
        function e(b, c) {
            c = c ? "-" + _(c, "-") : "", d.setClass(a, (b ? Td : Ud) + c, (b ? Ud : Td) + c)
        }
        var g = this,
            h = a.parent().controller("form") || Jd,
            i = 0,
            j = g.$error = {},
            k = [];
        g.$name = b.name || b.ngForm, g.$dirty = !1, g.$pristine = !0, g.$valid = !0, g.$invalid = !1, h.$addControl(g), a.addClass(Vd), e(!0), g.$addControl = function(a) {
            da(a.$name, "input"), k.push(a), a.$name && (g[a.$name] = a)
        }, g.$removeControl = function(a) {
            a.$name && g[a.$name] === a && delete g[a.$name], f(j, function(b, c) {
                g.$setValidity(c, !0, a)
            }), I(k, a)
        }, g.$setValidity = function(a, b, c) {
            var d = j[a];
            if (b) d && (I(d, c), d.length || (i--, i || (e(b), g.$valid = !0, g.$invalid = !1), j[a] = !1, e(!0, a), h.$setValidity(a, !0, g)));
            else {
                if (i || e(b), d) {
                    if (G(d, c)) return
                } else j[a] = d = [], i++, e(!1, a), h.$setValidity(a, !1, g);
                d.push(c), g.$valid = !1, g.$invalid = !0
            }
        }, g.$setDirty = function() {
            d.removeClass(a, Vd), d.addClass(a, Wd), g.$dirty = !0, g.$pristine = !1, h.$setDirty()
        }, g.$setPristine = function() {
            d.removeClass(a, Wd), d.addClass(a, Vd), g.$dirty = !1, g.$pristine = !0, f(k, function(a) {
                a.$setPristine()
            })
        }
    }

    function fc(a, b, d, e) {
        return a.$setValidity(b, d), d ? e : c
    }

    function gc(a, b) {
        var c, d;
        if (b)
            for (c = 0; c < b.length; ++c)
                if (d = b[c], a[d]) return !0;
        return !1
    }

    function hc(a, b, c, d, e) {
        if (t(e)) {
            a.$$hasNativeValidators = !0;
            var f = function(f) {
                return a.$error[b] || gc(e, d) || !gc(e, c) ? f : void a.$setValidity(b, !1)
            };
            a.$parsers.push(f)
        }
    }

    function ic(a, b, c, e, f, g) {
        var h = b.prop(pc),
            i = b[0].placeholder,
            j = {},
            k = qc(b[0].type);
        if (e.$$validityState = h, !f.android) {
            var l = !1;
            b.on("compositionstart", function(a) {
                l = !0
            }), b.on("compositionend", function() {
                l = !1, n()
            })
        }
        var n = function(d) {
            if (!l) {
                var f = b.val();
                if (vc && "input" === (d || j).type && b[0].placeholder !== i) return void(i = b[0].placeholder);
                "password" !== k && S(c.ngTrim || "T") && (f = Hc(f));
                var g = h && e.$$hasNativeValidators;
                (e.$viewValue !== f || "" === f && g) && (a.$root.$$phase ? e.$setViewValue(f) : a.$apply(function() {
                    e.$setViewValue(f)
                }))
            }
        };
        if (f.hasEvent("input")) b.on("input", n);
        else {
            var o, p = function() {
                o || (o = g.defer(function() {
                    n(), o = null
                }))
            };
            b.on("keydown", function(a) {
                var b = a.keyCode;
                91 === b || b > 15 && 19 > b || b >= 37 && 40 >= b || p()
            }), f.hasEvent("paste") && b.on("paste cut", p)
        }
        b.on("change", n), e.$render = function() {
            b.val(e.$isEmpty(e.$viewValue) ? "" : e.$viewValue)
        };
        var q, r, s = c.ngPattern;
        if (s) {
            var t = function(a, b) {
                return fc(e, "pattern", e.$isEmpty(b) || a.test(b), b)
            };
            r = s.match(/^\/(.*)\/([gim]*)$/), r ? (s = new RegExp(r[1], r[2]), q = function(a) {
                return t(s, a)
            }) : q = function(c) {
                var e = a.$eval(s);
                if (!e || !e.test) throw d("ngPattern")("noregexp", "Expected {0} to be a RegExp but was {1}. Element: {2}", s, e, T(b));
                return t(e, c)
            }, e.$formatters.push(q), e.$parsers.push(q)
        }
        if (c.ngMinlength) {
            var u = m(c.ngMinlength),
                v = function(a) {
                    return fc(e, "minlength", e.$isEmpty(a) || a.length >= u, a)
                };
            e.$parsers.push(v), e.$formatters.push(v)
        }
        if (c.ngMaxlength) {
            var w = m(c.ngMaxlength),
                x = function(a) {
                    return fc(e, "maxlength", e.$isEmpty(a) || a.length <= w, a)
                };
            e.$parsers.push(x), e.$formatters.push(x)
        }
    }

    function jc(a, b, d, e, f, g) {
        if (ic(a, b, d, e, f, g), e.$parsers.push(function(a) {
                var b = e.$isEmpty(a);
                return b || Pd.test(a) ? (e.$setValidity("number", !0), "" === a ? null : b ? a : parseFloat(a)) : (e.$setValidity("number", !1), c)
            }), hc(e, "number", Rd, null, e.$$validityState), e.$formatters.push(function(a) {
                return e.$isEmpty(a) ? "" : "" + a
            }), d.min) {
            var h = function(a) {
                var b = parseFloat(d.min);
                return fc(e, "min", e.$isEmpty(a) || a >= b, a)
            };
            e.$parsers.push(h), e.$formatters.push(h)
        }
        if (d.max) {
            var i = function(a) {
                var b = parseFloat(d.max);
                return fc(e, "max", e.$isEmpty(a) || b >= a, a)
            };
            e.$parsers.push(i), e.$formatters.push(i)
        }
        e.$formatters.push(function(a) {
            return fc(e, "number", e.$isEmpty(a) || v(a), a)
        })
    }

    function kc(a, b, c, d, e, f) {
        ic(a, b, c, d, e, f);
        var g = function(a) {
            return fc(d, "url", d.$isEmpty(a) || Nd.test(a), a)
        };
        d.$formatters.push(g), d.$parsers.push(g)
    }

    function lc(a, b, c, d, e, f) {
        ic(a, b, c, d, e, f);
        var g = function(a) {
            return fc(d, "email", d.$isEmpty(a) || Od.test(a), a)
        };
        d.$formatters.push(g), d.$parsers.push(g)
    }

    function mc(a, b, c, d) {
        r(c.name) && b.attr("name", j()), b.on("click", function() {
            b[0].checked && a.$apply(function() {
                d.$setViewValue(c.value)
            })
        }), d.$render = function() {
            var a = c.value;
            b[0].checked = a == d.$viewValue
        }, c.$observe("value", d.$render)
    }

    function nc(a, b, c, d) {
        var e = c.ngTrueValue,
            f = c.ngFalseValue;
        u(e) || (e = !0), u(f) || (f = !1), b.on("click", function() {
            a.$apply(function() {
                d.$setViewValue(b[0].checked)
            })
        }), d.$render = function() {
            b[0].checked = d.$viewValue
        }, d.$isEmpty = function(a) {
            return a !== e
        }, d.$formatters.push(function(a) {
            return a === e
        }), d.$parsers.push(function(a) {
            return a ? e : f
        })
    }

    function oc(a, b) {
        return a = "ngClass" + a, ["$animate", function(c) {
            function d(a, b) {
                var c = [];
                a: for (var d = 0; d < a.length; d++) {
                    for (var e = a[d], f = 0; f < b.length; f++)
                        if (e == b[f]) continue a;
                    c.push(e)
                }
                return c
            }

            function e(a) {
                if (Gc(a)) return a;
                if (u(a)) return a.split(" ");
                if (t(a)) {
                    var b = [];
                    return f(a, function(a, c) {
                        a && (b = b.concat(c.split(" ")))
                    }), b
                }
                return a
            }
            return {
                restrict: "AC",
                link: function(g, h, i) {
                    function j(a) {
                        var b = l(a, 1);
                        i.$addClass(b)
                    }

                    function k(a) {
                        var b = l(a, -1);
                        i.$removeClass(b)
                    }

                    function l(a, b) {
                        var c = h.data("$classCounts") || {},
                            d = [];
                        return f(a, function(a) {
                            (b > 0 || c[a]) && (c[a] = (c[a] || 0) + b, c[a] === +(b > 0) && d.push(a))
                        }), h.data("$classCounts", c), d.join(" ")
                    }

                    function m(a, b) {
                        var e = d(b, a),
                            f = d(a, b);
                        f = l(f, -1), e = l(e, 1), 0 === e.length ? c.removeClass(h, f) : 0 === f.length ? c.addClass(h, e) : c.setClass(h, e, f)
                    }

                    function n(a) {
                        if (b === !0 || g.$index % 2 === b) {
                            var c = e(a || []);
                            if (o) {
                                if (!L(a, o)) {
                                    var d = e(o);
                                    m(d, c)
                                }
                            } else j(c)
                        }
                        o = K(a)
                    }
                    var o;
                    g.$watch(i[a], n, !0), i.$observe("class", function(b) {
                        n(g.$eval(i[a]))
                    }), "ngClass" !== a && g.$watch("$index", function(c, d) {
                        var f = 1 & c;
                        if (f !== (1 & d)) {
                            var h = e(g.$eval(i[a]));
                            f === b ? j(h) : k(h)
                        }
                    })
                }
            }
        }]
    }
    var pc = "validity",
        qc = function(a) {
            return u(a) ? a.toLowerCase() : a
        },
        rc = Object.prototype.hasOwnProperty,
        sc = function(a) {
            return u(a) ? a.toUpperCase() : a
        },
        tc = function(a) {
            return u(a) ? a.replace(/[A-Z]/g, function(a) {
                return String.fromCharCode(32 | a.charCodeAt(0))
            }) : a
        },
        uc = function(a) {
            return u(a) ? a.replace(/[a-z]/g, function(a) {
                return String.fromCharCode(-33 & a.charCodeAt(0))
            }) : a
        };
    "i" !== "I".toLowerCase() && (qc = tc, sc = uc);
    var vc, wc, xc, yc, zc, Ac = [].slice,
        Bc = [].push,
        Cc = Object.prototype.toString,
        Dc = d("ng"),
        Ec = a.angular || (a.angular = {}),
        Fc = ["0", "0", "0"];
    vc = m((/msie (\d+)/.exec(qc(navigator.userAgent)) || [])[1]), isNaN(vc) && (vc = m((/trident\/.*; rv:(\d+)/.exec(qc(navigator.userAgent)) || [])[1])), o.$inject = [], p.$inject = [];
    var Gc = function() {
            return x(Array.isArray) ? Array.isArray : function(a) {
                return "[object Array]" === Cc.call(a)
            }
        }(),
        Hc = function() {
            return String.prototype.trim ? function(a) {
                return u(a) ? a.trim() : a
            } : function(a) {
                return u(a) ? a.replace(/^\s\s*/, "").replace(/\s\s*$/, "") : a
            }
        }();
    zc = 9 > vc ? function(a) {
        return a = a.nodeName ? a : a[0], a.scopeName && "HTML" != a.scopeName ? sc(a.scopeName + ":" + a.nodeName) : a.nodeName
    } : function(a) {
        return a.nodeName ? a.nodeName : a[0].nodeName
    };
    var Ic = function() {
            if (s(Ic.isActive_)) return Ic.isActive_;
            var a = !(!b.querySelector("[ng-csp]") && !b.querySelector("[data-ng-csp]"));
            if (!a) try {
                new Function("")
            } catch (c) {
                a = !0
            }
            return Ic.isActive_ = a
        },
        Jc = /[A-Z]/g,
        Kc = {
            full: "1.2.30",
            major: 1,
            minor: 2,
            dot: 30,
            codeName: "patronal-resurrection"
        };
    oa.expando = "ng339";
    var Lc = oa.cache = {},
        Mc = 1,
        Nc = a.document.addEventListener ? function(a, b, c) {
            a.addEventListener(b, c, !1)
        } : function(a, b, c) {
            a.attachEvent("on" + b, c)
        },
        Oc = a.document.removeEventListener ? function(a, b, c) {
            a.removeEventListener(b, c, !1)
        } : function(a, b, c) {
            a.detachEvent("on" + b, c)
        },
        Pc = (oa._data = function(a) {
            return this.cache[a[this.expando]] || {}
        }, /([\:\-\_]+(.))/g),
        Qc = /^moz([A-Z])/,
        Rc = d("jqLite"),
        Sc = /^<(\w+)\s*\/?>(?:<\/\1>|)$/,
        Tc = /<|&#?\w+;/,
        Uc = /<([\w:]+)/,
        Vc = /<(?!area|br|col|embed|hr|img|input|link|meta|param)(([\w:]+)[^>]*)\/>/gi,
        Wc = {
            option: [1, '<select multiple="multiple">', "</select>"],
            thead: [1, "<table>", "</table>"],
            col: [2, "<table><colgroup>", "</colgroup></table>"],
            tr: [2, "<table><tbody>", "</tbody></table>"],
            td: [3, "<table><tbody><tr>", "</tr></tbody></table>"],
            _default: [0, "", ""]
        };
    Wc.optgroup = Wc.option, Wc.tbody = Wc.tfoot = Wc.colgroup = Wc.caption = Wc.thead, Wc.th = Wc.td;
    var Xc = oa.prototype = {
            ready: function(c) {
                function d() {
                    e || (e = !0, c())
                }
                var e = !1;
                "complete" === b.readyState ? setTimeout(d) : (this.on("DOMContentLoaded", d), oa(a).on("load", d))
            },
            toString: function() {
                var a = [];
                return f(this, function(b) {
                    a.push("" + b)
                }), "[" + a.join(", ") + "]"
            },
            eq: function(a) {
                return wc(a >= 0 ? this[a] : this[this.length + a])
            },
            length: 0,
            push: Bc,
            sort: [].sort,
            splice: [].splice
        },
        Yc = {};
    f("multiple,selected,checked,disabled,readOnly,required,open".split(","), function(a) {
        Yc[qc(a)] = a
    });
    var Zc = {};
    f("input,select,option,textarea,button,form,details".split(","), function(a) {
        Zc[sc(a)] = !0
    }), f({
        data: ua,
        removeData: sa
    }, function(a, b) {
        oa[b] = a
    }), f({
        data: ua,
        inheritedData: Aa,
        scope: function(a) {
            return wc.data(a, "$scope") || Aa(a.parentNode || a, ["$isolateScope", "$scope"])
        },
        isolateScope: function(a) {
            return wc.data(a, "$isolateScope") || wc.data(a, "$isolateScopeNoTemplate")
        },
        controller: za,
        injector: function(a) {
            return Aa(a, "$injector")
        },
        removeAttr: function(a, b) {
            a.removeAttribute(b)
        },
        hasClass: va,
        css: function(a, b, d) {
            if (b = ja(b), !s(d)) {
                var e;
                return 8 >= vc && (e = a.currentStyle && a.currentStyle[b], "" === e && (e = "auto")), e = e || a.style[b], 8 >= vc && (e = "" === e ? c : e), e
            }
            a.style[b] = d
        },
        attr: function(a, b, d) {
            var e = qc(b);
            if (Yc[e]) {
                if (!s(d)) return a[b] || (a.attributes.getNamedItem(b) || o).specified ? e : c;
                d ? (a[b] = !0, a.setAttribute(b, e)) : (a[b] = !1, a.removeAttribute(e))
            } else if (s(d)) a.setAttribute(b, d);
            else if (a.getAttribute) {
                var f = a.getAttribute(b, 2);
                return null === f ? c : f
            }
        },
        prop: function(a, b, c) {
            return s(c) ? void(a[b] = c) : a[b]
        },
        text: function() {
            function a(a, c) {
                var d = b[a.nodeType];
                return r(c) ? d ? a[d] : "" : void(a[d] = c)
            }
            var b = [];
            return 9 > vc ? (b[1] = "innerText", b[3] = "nodeValue") : b[1] = b[3] = "textContent", a.$dv = "", a
        }(),
        val: function(a, b) {
            if (r(b)) {
                if ("SELECT" === zc(a) && a.multiple) {
                    var c = [];
                    return f(a.options, function(a) {
                        a.selected && c.push(a.value || a.text)
                    }), 0 === c.length ? null : c
                }
                return a.value
            }
            a.value = b
        },
        html: function(a, b) {
            if (r(b)) return a.innerHTML;
            for (var c = 0, d = a.childNodes; c < d.length; c++) qa(d[c]);
            a.innerHTML = b
        },
        empty: Ba
    }, function(a, b) {
        oa.prototype[b] = function(b, d) {
            var e, f, g = this.length;
            if (a !== Ba && (2 == a.length && a !== va && a !== za ? b : d) === c) {
                if (t(b)) {
                    for (e = 0; g > e; e++)
                        if (a === ua) a(this[e], b);
                        else
                            for (f in b) a(this[e], f, b[f]);
                    return this
                }
                for (var h = a.$dv, i = h === c ? Math.min(g, 1) : g, j = 0; i > j; j++) {
                    var k = a(this[j], b, d);
                    h = h ? h + k : k
                }
                return h
            }
            for (e = 0; g > e; e++) a(this[e], b, d);
            return this
        }
    }), f({
        removeData: sa,
        dealoc: qa,
        on: function Ge(a, c, d, e) {
            if (s(e)) throw Rc("onargs", "jqLite#on() does not support the `selector` or `eventData` parameters");
            var g = ta(a, "events"),
                h = ta(a, "handle");
            g || ta(a, "events", g = {}), h || ta(a, "handle", h = Da(a, g)), f(c.split(" "), function(c) {
                var e = g[c];
                if (!e) {
                    if ("mouseenter" == c || "mouseleave" == c) {
                        var f = b.body.contains || b.body.compareDocumentPosition ? function(a, b) {
                            var c = 9 === a.nodeType ? a.documentElement : a,
                                d = b && b.parentNode;
                            return a === d || !(!d || 1 !== d.nodeType || !(c.contains ? c.contains(d) : a.compareDocumentPosition && 16 & a.compareDocumentPosition(d)))
                        } : function(a, b) {
                            if (b)
                                for (; b = b.parentNode;)
                                    if (b === a) return !0;
                            return !1
                        };
                        g[c] = [];
                        var i = {
                            mouseleave: "mouseout",
                            mouseenter: "mouseover"
                        };
                        Ge(a, i[c], function(a) {
                            var b = this,
                                d = a.relatedTarget;
                            (!d || d !== b && !f(b, d)) && h(a, c)
                        })
                    } else Nc(a, c, h), g[c] = [];
                    e = g[c]
                }
                e.push(d)
            })
        },
        off: ra,
        one: function(a, b, c) {
            a = wc(a), a.on(b, function d() {
                a.off(b, c), a.off(b, d)
            }), a.on(b, c)
        },
        replaceWith: function(a, b) {
            var c, d = a.parentNode;
            qa(a), f(new oa(b), function(b) {
                c ? d.insertBefore(b, c.nextSibling) : d.replaceChild(b, a), c = b
            })
        },
        children: function(a) {
            var b = [];
            return f(a.childNodes, function(a) {
                1 === a.nodeType && b.push(a)
            }), b
        },
        contents: function(a) {
            return a.contentDocument || a.childNodes || []
        },
        append: function(a, b) {
            f(new oa(b), function(b) {
                (1 === a.nodeType || 11 === a.nodeType) && a.appendChild(b)
            })
        },
        prepend: function(a, b) {
            if (1 === a.nodeType) {
                var c = a.firstChild;
                f(new oa(b), function(b) {
                    a.insertBefore(b, c)
                })
            }
        },
        wrap: function(a, b) {
            b = wc(b)[0];
            var c = a.parentNode;
            c && c.replaceChild(b, a), b.appendChild(a)
        },
        remove: function(a) {
            qa(a);
            var b = a.parentNode;
            b && b.removeChild(a)
        },
        after: function(a, b) {
            var c = a,
                d = a.parentNode;
            f(new oa(b), function(a) {
                d.insertBefore(a, c.nextSibling), c = a
            })
        },
        addClass: xa,
        removeClass: wa,
        toggleClass: function(a, b, c) {
            b && f(b.split(" "), function(b) {
                var d = c;
                r(d) && (d = !va(a, b)), (d ? xa : wa)(a, b)
            })
        },
        parent: function(a) {
            var b = a.parentNode;
            return b && 11 !== b.nodeType ? b : null
        },
        next: function(a) {
            if (a.nextElementSibling) return a.nextElementSibling;
            for (var b = a.nextSibling; null != b && 1 !== b.nodeType;) b = b.nextSibling;
            return b
        },
        find: function(a, b) {
            return a.getElementsByTagName ? a.getElementsByTagName(b) : []
        },
        clone: pa,
        triggerHandler: function(a, b, c) {
            var d, e, g, h = b.type || b,
                i = (ta(a, "events") || {})[h];
            i && (d = {
                preventDefault: function() {
                    this.defaultPrevented = !0
                },
                isDefaultPrevented: function() {
                    return this.defaultPrevented === !0
                },
                stopPropagation: o,
                type: h,
                target: a
            }, b.type && (d = l(d, b)), e = K(i), g = c ? [d].concat(c) : [d], f(e, function(b) {
                b.apply(a, g)
            }))
        }
    }, function(a, b) {
        oa.prototype[b] = function(b, c, d) {
            for (var e, f = 0; f < this.length; f++) r(e) ? (e = a(this[f], b, c, d), s(e) && (e = wc(e))) : ya(e, a(this[f], b, c, d));
            return s(e) ? e : this
        }, oa.prototype.bind = oa.prototype.on, oa.prototype.unbind = oa.prototype.off
    }), Fa.prototype = {
        put: function(a, b) {
            this[Ea(a, this.nextUid)] = b
        },
        get: function(a) {
            return this[Ea(a, this.nextUid)]
        },
        remove: function(a) {
            var b = this[a = Ea(a, this.nextUid)];
            return delete this[a], b
        }
    };
    var $c = /^function\s*[^\(]*\(\s*([^\)]*)\)/m,
        _c = /,/,
        ad = /^\s*(_?)(\S+?)\1\s*$/,
        bd = /((\/\/.*$)|(\/\*[\s\S]*?\*\/))/gm,
        cd = d("$injector"),
        dd = d("$animate"),
        ed = ["$provide", function(a) {
            this.$$selectors = {}, this.register = function(b, c) {
                var d = b + "-animation";
                if (b && "." != b.charAt(0)) throw dd("notcsel", "Expecting class selector starting with '.' got '{0}'.", b);
                this.$$selectors[b.substr(1)] = d, a.factory(d, c)
            }, this.classNameFilter = function(a) {
                return 1 === arguments.length && (this.$$classNameFilter = a instanceof RegExp ? a : null), this.$$classNameFilter
            }, this.$get = ["$timeout", "$$asyncCallback", function(a, b) {
                function c(a) {
                    a && b(a)
                }
                return {
                    enter: function(a, b, d, e) {
                        d ? d.after(a) : (b && b[0] || (b = d.parent()), b.append(a)), c(e)
                    },
                    leave: function(a, b) {
                        a.remove(), c(b)
                    },
                    move: function(a, b, c, d) {
                        this.enter(a, b, c, d)
                    },
                    addClass: function(a, b, d) {
                        b = u(b) ? b : Gc(b) ? b.join(" ") : "", f(a, function(a) {
                            xa(a, b)
                        }), c(d)
                    },
                    removeClass: function(a, b, d) {
                        b = u(b) ? b : Gc(b) ? b.join(" ") : "", f(a, function(a) {
                            wa(a, b)
                        }), c(d)
                    },
                    setClass: function(a, b, d, e) {
                        f(a, function(a) {
                            xa(a, b), wa(a, d)
                        }), c(e)
                    },
                    enabled: o
                }
            }]
        }],
        fd = d("$compile");
    Oa.$inject = ["$provide", "$$sanitizeUriProvider"];
    var gd = /^(x[\:\-_]|data[\:\-_])/i,
        hd = d("$interpolate"),
        id = /^([^\?#]*)(\?([^#]*))?(#(.*))?$/,
        jd = {
            http: 80,
            https: 443,
            ftp: 21
        },
        kd = d("$location");
    nb.prototype = mb.prototype = lb.prototype = {
        $$html5: !1,
        $$replace: !1,
        absUrl: ob("$$absUrl"),
        url: function(a) {
            if (r(a)) return this.$$url;
            var b = id.exec(a);
            return b[1] && this.path(decodeURIComponent(b[1])), (b[2] || b[1]) && this.search(b[3] || ""), this.hash(b[5] || ""), this
        },
        protocol: ob("$$protocol"),
        host: ob("$$host"),
        port: ob("$$port"),
        path: pb("$$path", function(a) {
            return a = null !== a ? a.toString() : "", "/" == a.charAt(0) ? a : "/" + a
        }),
        search: function(a, b) {
            switch (arguments.length) {
                case 0:
                    return this.$$search;
                case 1:
                    if (u(a) || v(a)) a = a.toString(), this.$$search = V(a);
                    else {
                        if (!t(a)) throw kd("isrcharg", "The first argument of the `$location#search()` call must be a string or an object.");
                        f(a, function(b, c) {
                            null == b && delete a[c]
                        }), this.$$search = a
                    }
                    break;
                default:
                    r(b) || null === b ? delete this.$$search[a] : this.$$search[a] = b
            }
            return this.$$compose(), this
        },
        hash: pb("$$hash", function(a) {
            return null !== a ? a.toString() : ""
        }),
        replace: function() {
            return this.$$replace = !0, this
        }
    };
    var ld, md = d("$parse"),
        nd = {},
        od = Function.prototype.call,
        pd = Function.prototype.apply,
        qd = Function.prototype.bind,
        rd = {
            "null": function() {
                return null
            },
            "true": function() {
                return !0
            },
            "false": function() {
                return !1
            },
            undefined: o,
            "+": function(a, b, d, e) {
                return d = d(a, b), e = e(a, b), s(d) ? s(e) ? d + e : d : s(e) ? e : c
            },
            "-": function(a, b, c, d) {
                return c = c(a, b), d = d(a, b), (s(c) ? c : 0) - (s(d) ? d : 0)
            },
            "*": function(a, b, c, d) {
                return c(a, b) * d(a, b)
            },
            "/": function(a, b, c, d) {
                return c(a, b) / d(a, b)
            },
            "%": function(a, b, c, d) {
                return c(a, b) % d(a, b)
            },
            "^": function(a, b, c, d) {
                return c(a, b) ^ d(a, b)
            },
            "=": o,
            "===": function(a, b, c, d) {
                return c(a, b) === d(a, b)
            },
            "!==": function(a, b, c, d) {
                return c(a, b) !== d(a, b)
            },
            "==": function(a, b, c, d) {
                return c(a, b) == d(a, b)
            },
            "!=": function(a, b, c, d) {
                return c(a, b) != d(a, b)
            },
            "<": function(a, b, c, d) {
                return c(a, b) < d(a, b)
            },
            ">": function(a, b, c, d) {
                return c(a, b) > d(a, b)
            },
            "<=": function(a, b, c, d) {
                return c(a, b) <= d(a, b)
            },
            ">=": function(a, b, c, d) {
                return c(a, b) >= d(a, b)
            },
            "&&": function(a, b, c, d) {
                return c(a, b) && d(a, b)
            },
            "||": function(a, b, c, d) {
                return c(a, b) || d(a, b)
            },
            "&": function(a, b, c, d) {
                return c(a, b) & d(a, b)
            },
            "|": function(a, b, c, d) {
                return d(a, b)(a, b, c(a, b))
            },
            "!": function(a, b, c) {
                return !c(a, b)
            }
        },
        sd = {
            n: "\n",
            f: "\f",
            r: "\r",
            t: "	",
            v: "",
            "'": "'",
            '"': '"'
        },
        td = function(a) {
            this.options = a
        };
    td.prototype = {
        constructor: td,
        lex: function(a) {
            for (this.text = a, this.index = 0, this.ch = c, this.lastCh = ":", this.tokens = []; this.index < this.text.length;) {
                if (this.ch = this.text.charAt(this.index), this.is("\"'")) this.readString(this.ch);
                else if (this.isNumber(this.ch) || this.is(".") && this.isNumber(this.peek())) this.readNumber();
                else if (this.isIdent(this.ch)) this.readIdent();
                else if (this.is("(){}[].,;:?")) this.tokens.push({
                    index: this.index,
                    text: this.ch
                }), this.index++;
                else {
                    if (this.isWhitespace(this.ch)) {
                        this.index++;
                        continue
                    }
                    var b = this.ch + this.peek(),
                        d = b + this.peek(2),
                        e = rd[this.ch],
                        f = rd[b],
                        g = rd[d];
                    g ? (this.tokens.push({
                        index: this.index,
                        text: d,
                        fn: g
                    }), this.index += 3) : f ? (this.tokens.push({
                        index: this.index,
                        text: b,
                        fn: f
                    }), this.index += 2) : e ? (this.tokens.push({
                        index: this.index,
                        text: this.ch,
                        fn: e
                    }), this.index += 1) : this.throwError("Unexpected next character ", this.index, this.index + 1)
                }
                this.lastCh = this.ch
            }
            return this.tokens
        },
        is: function(a) {
            return -1 !== a.indexOf(this.ch)
        },
        was: function(a) {
            return -1 !== a.indexOf(this.lastCh)
        },
        peek: function(a) {
            var b = a || 1;
            return this.index + b < this.text.length ? this.text.charAt(this.index + b) : !1
        },
        isNumber: function(a) {
            return a >= "0" && "9" >= a
        },
        isWhitespace: function(a) {
            return " " === a || "\r" === a || "	" === a || "\n" === a || "" === a || " " === a
        },
        isIdent: function(a) {
            return a >= "a" && "z" >= a || a >= "A" && "Z" >= a || "_" === a || "$" === a
        },
        isExpOperator: function(a) {
            return "-" === a || "+" === a || this.isNumber(a)
        },
        throwError: function(a, b, c) {
            c = c || this.index;
            var d = s(b) ? "s " + b + "-" + this.index + " [" + this.text.substring(b, c) + "]" : " " + c;
            throw md("lexerr", "Lexer Error: {0} at column{1} in expression [{2}].", a, d, this.text)
        },
        readNumber: function() {
            for (var a = "", b = this.index; this.index < this.text.length;) {
                var c = qc(this.text.charAt(this.index));
                if ("." == c || this.isNumber(c)) a += c;
                else {
                    var d = this.peek();
                    if ("e" == c && this.isExpOperator(d)) a += c;
                    else if (this.isExpOperator(c) && d && this.isNumber(d) && "e" == a.charAt(a.length - 1)) a += c;
                    else {
                        if (!this.isExpOperator(c) || d && this.isNumber(d) || "e" != a.charAt(a.length - 1)) break;
                        this.throwError("Invalid exponent")
                    }
                }
                this.index++
            }
            a = 1 * a, this.tokens.push({
                index: b,
                text: a,
                literal: !0,
                constant: !0,
                fn: function() {
                    return a
                }
            })
        },
        readIdent: function() {
            for (var a, b, c, d, e = this, f = "", g = this.index; this.index < this.text.length && (d = this.text.charAt(this.index), "." === d || this.isIdent(d) || this.isNumber(d));) "." === d && (a = this.index), f += d, this.index++;
            if (a)
                for (b = this.index; b < this.text.length;) {
                    if (d = this.text.charAt(b), "(" === d) {
                        c = f.substr(a - g + 1), f = f.substr(0, a - g), this.index = b;
                        break
                    }
                    if (!this.isWhitespace(d)) break;
                    b++
                }
            var h = {
                index: g,
                text: f
            };
            if (rd.hasOwnProperty(f)) h.fn = rd[f], h.literal = !0, h.constant = !0;
            else {
                var i = Ab(f, this.options, this.text);
                h.fn = l(function(a, b) {
                    return i(a, b)
                }, {
                    assign: function(a, b) {
                        return wb(a, f, b, e.text, e.options)
                    }
                })
            }
            this.tokens.push(h), c && (this.tokens.push({
                index: a,
                text: "."
            }), this.tokens.push({
                index: a + 1,
                text: c
            }))
        },
        readString: function(a) {
            var b = this.index;
            this.index++;
            for (var c = "", d = a, e = !1; this.index < this.text.length;) {
                var f = this.text.charAt(this.index);
                if (d += f, e) {
                    if ("u" === f) {
                        var g = this.text.substring(this.index + 1, this.index + 5);
                        g.match(/[\da-f]{4}/i) || this.throwError("Invalid unicode escape [\\u" + g + "]"), this.index += 4, c += String.fromCharCode(parseInt(g, 16))
                    } else {
                        var h = sd[f];
                        c += h || f
                    }
                    e = !1
                } else if ("\\" === f) e = !0;
                else {
                    if (f === a) return this.index++, void this.tokens.push({
                        index: b,
                        text: d,
                        string: c,
                        literal: !0,
                        constant: !0,
                        fn: function() {
                            return c
                        }
                    });
                    c += f
                }
                this.index++
            }
            this.throwError("Unterminated quote", b)
        }
    };
    var ud = function(a, b, c) {
        this.lexer = a, this.$filter = b, this.options = c
    };
    ud.ZERO = l(function() {
        return 0
    }, {
        constant: !0
    }), ud.prototype = {
        constructor: ud,
        parse: function(a) {
            this.text = a, this.tokens = this.lexer.lex(a);
            var b = this.statements();
            return 0 !== this.tokens.length && this.throwError("is an unexpected token", this.tokens[0]), b.literal = !!b.literal, b.constant = !!b.constant, b
        },
        primary: function() {
            var a;
            if (this.expect("(")) a = this.filterChain(), this.consume(")");
            else if (this.expect("[")) a = this.arrayDeclaration();
            else if (this.expect("{")) a = this.object();
            else {
                var b = this.expect();
                a = b.fn, a || this.throwError("not a primary expression", b), a.literal = !!b.literal, a.constant = !!b.constant
            }
            for (var c, d; c = this.expect("(", "[", ".");) "(" === c.text ? (a = this.functionCall(a, d), d = null) : "[" === c.text ? (d = a, a = this.objectIndex(a)) : "." === c.text ? (d = a, a = this.fieldAccess(a)) : this.throwError("IMPOSSIBLE");
            return a
        },
        throwError: function(a, b) {
            throw md("syntax", "Syntax Error: Token '{0}' {1} at column {2} of the expression [{3}] starting at [{4}].", b.text, a, b.index + 1, this.text, this.text.substring(b.index))
        },
        peekToken: function() {
            if (0 === this.tokens.length) throw md("ueoe", "Unexpected end of expression: {0}", this.text);
            return this.tokens[0]
        },
        peek: function(a, b, c, d) {
            if (this.tokens.length > 0) {
                var e = this.tokens[0],
                    f = e.text;
                if (f === a || f === b || f === c || f === d || !a && !b && !c && !d) return e
            }
            return !1
        },
        expect: function(a, b, c, d) {
            var e = this.peek(a, b, c, d);
            return e ? (this.tokens.shift(), e) : !1
        },
        consume: function(a) {
            this.expect(a) || this.throwError("is unexpected, expecting [" + a + "]", this.peek())
        },
        unaryFn: function(a, b) {
            return l(function(c, d) {
                return a(c, d, b)
            }, {
                constant: b.constant
            })
        },
        ternaryFn: function(a, b, c) {
            return l(function(d, e) {
                return a(d, e) ? b(d, e) : c(d, e)
            }, {
                constant: a.constant && b.constant && c.constant
            })
        },
        binaryFn: function(a, b, c) {
            return l(function(d, e) {
                return b(d, e, a, c)
            }, {
                constant: a.constant && c.constant
            })
        },
        statements: function() {
            for (var a = [];;)
                if (this.tokens.length > 0 && !this.peek("}", ")", ";", "]") && a.push(this.filterChain()), !this.expect(";")) return 1 === a.length ? a[0] : function(b, c) {
                    for (var d, e = 0; e < a.length; e++) {
                        var f = a[e];
                        f && (d = f(b, c))
                    }
                    return d
                }
        },
        filterChain: function() {
            for (var a, b = this.expression();;) {
                if (!(a = this.expect("|"))) return b;
                b = this.binaryFn(b, a.fn, this.filter())
            }
        },
        filter: function() {
            for (var a = this.expect(), b = this.$filter(a.text), c = [];;) {
                if (!(a = this.expect(":"))) {
                    var d = function(a, d, e) {
                        for (var f = [e], g = 0; g < c.length; g++) f.push(c[g](a, d));
                        return b.apply(a, f)
                    };
                    return function() {
                        return d
                    }
                }
                c.push(this.expression())
            }
        },
        expression: function() {
            return this.assignment()
        },
        assignment: function() {
            var a, b, c = this.ternary();
            return (b = this.expect("=")) ? (c.assign || this.throwError("implies assignment but [" + this.text.substring(0, b.index) + "] can not be assigned to", b), a = this.ternary(), function(b, d) {
                return c.assign(b, a(b, d), d)
            }) : c
        },
        ternary: function() {
            var a, b, c = this.logicalOR();
            return (b = this.expect("?")) ? (a = this.assignment(), (b = this.expect(":")) ? this.ternaryFn(c, a, this.assignment()) : void this.throwError("expected :", b)) : c
        },
        logicalOR: function() {
            for (var a, b = this.logicalAND();;) {
                if (!(a = this.expect("||"))) return b;
                b = this.binaryFn(b, a.fn, this.logicalAND())
            }
        },
        logicalAND: function() {
            var a, b = this.equality();
            return (a = this.expect("&&")) && (b = this.binaryFn(b, a.fn, this.logicalAND())), b
        },
        equality: function() {
            var a, b = this.relational();
            return (a = this.expect("==", "!=", "===", "!==")) && (b = this.binaryFn(b, a.fn, this.equality())), b
        },
        relational: function() {
            var a, b = this.additive();
            return (a = this.expect("<", ">", "<=", ">=")) && (b = this.binaryFn(b, a.fn, this.relational())), b
        },
        additive: function() {
            for (var a, b = this.multiplicative(); a = this.expect("+", "-");) b = this.binaryFn(b, a.fn, this.multiplicative());
            return b
        },
        multiplicative: function() {
            for (var a, b = this.unary(); a = this.expect("*", "/", "%");) b = this.binaryFn(b, a.fn, this.unary());
            return b
        },
        unary: function() {
            var a;
            return this.expect("+") ? this.primary() : (a = this.expect("-")) ? this.binaryFn(ud.ZERO, a.fn, this.unary()) : (a = this.expect("!")) ? this.unaryFn(a.fn, this.unary()) : this.primary()
        },
        fieldAccess: function(a) {
            var b = this,
                c = this.expect().text,
                d = Ab(c, this.options, this.text);
            return l(function(b, c, e) {
                return d(e || a(b, c))
            }, {
                assign: function(d, e, f) {
                    var g = a(d, f);
                    return g || a.assign(d, g = {}), wb(g, c, e, b.text, b.options)
                }
            })
        },
        objectIndex: function(a) {
            var b = this,
                d = this.expression();
            return this.consume("]"), l(function(e, f) {
                var g, h, i = a(e, f),
                    j = tb(d(e, f), b.text);
                return sb(j, b.text), i ? (g = ub(i[j], b.text), g && g.then && b.options.unwrapPromises && (h = g, "$$v" in g || (h.$$v = c, h.then(function(a) {
                    h.$$v = a
                })), g = g.$$v), g) : c
            }, {
                assign: function(c, e, f) {
                    var g = sb(tb(d(c, f), b.text), b.text),
                        h = ub(a(c, f), b.text);
                    return h || a.assign(c, h = {}), h[g] = e
                }
            })
        },
        functionCall: function(a, b) {
            var c = [];
            if (")" !== this.peekToken().text)
                do c.push(this.expression()); while (this.expect(","));
            this.consume(")");
            var d = this;
            return function(e, f) {
                for (var g = [], h = b ? b(e, f) : e, i = 0; i < c.length; i++) g.push(ub(c[i](e, f), d.text));
                var j = a(e, f, h) || o;
                ub(h, d.text), vb(j, d.text);
                var k = j.apply ? j.apply(h, g) : j(g[0], g[1], g[2], g[3], g[4]);
                return ub(k, d.text)
            }
        },
        arrayDeclaration: function() {
            var a = [],
                b = !0;
            if ("]" !== this.peekToken().text)
                do {
                    if (this.peek("]")) break;
                    var c = this.expression();
                    a.push(c), c.constant || (b = !1)
                } while (this.expect(","));
            return this.consume("]"), l(function(b, c) {
                for (var d = [], e = 0; e < a.length; e++) d.push(a[e](b, c));
                return d
            }, {
                literal: !0,
                constant: b
            })
        },
        object: function() {
            var a = [],
                b = !0;
            if ("}" !== this.peekToken().text)
                do {
                    if (this.peek("}")) break;
                    var c = this.expect(),
                        d = c.string || c.text;
                    this.consume(":");
                    var e = this.expression();
                    a.push({
                        key: d,
                        value: e
                    }), e.constant || (b = !1)
                } while (this.expect(","));
            return this.consume("}"), l(function(b, c) {
                for (var d = {}, e = 0; e < a.length; e++) {
                    var f = a[e];
                    d[f.key] = f.value(b, c)
                }
                return d
            }, {
                literal: !0,
                constant: b
            })
        }
    };
    var vd = {},
        wd = {},
        xd = d("$sce"),
        yd = {
            HTML: "html",
            CSS: "css",
            URL: "url",
            RESOURCE_URL: "resourceUrl",
            JS: "js"
        },
        zd = b.createElement("a"),
        Ad = Ob(a.location.href, !0);
    Rb.$inject = ["$provide"], Tb.$inject = ["$locale"], Ub.$inject = ["$locale"];
    var Bd = ".",
        Cd = {
            yyyy: Xb("FullYear", 4),
            yy: Xb("FullYear", 2, 0, !0),
            y: Xb("FullYear", 1),
            MMMM: Yb("Month"),
            MMM: Yb("Month", !0),
            MM: Xb("Month", 2, 1),
            M: Xb("Month", 1, 1),
            dd: Xb("Date", 2),
            d: Xb("Date", 1),
            HH: Xb("Hours", 2),
            H: Xb("Hours", 1),
            hh: Xb("Hours", 2, -12),
            h: Xb("Hours", 1, -12),
            mm: Xb("Minutes", 2),
            m: Xb("Minutes", 1),
            ss: Xb("Seconds", 2),
            s: Xb("Seconds", 1),
            sss: Xb("Milliseconds", 3),
            EEEE: Yb("Day"),
            EEE: Yb("Day", !0),
            a: $b,
            Z: Zb
        },
        Dd = /((?:[^yMdHhmsaZE']+)|(?:'(?:[^']|'')*')|(?:E+|y+|M+|d+|H+|h+|m+|s+|a|Z))(.*)/,
        Ed = /^\-?\d+$/;
    _b.$inject = ["$locale"];
    var Fd = q(qc),
        Gd = q(sc);
    cc.$inject = ["$parse"];
    var Hd = q({
            restrict: "E",
            compile: function(a, c) {
                return 8 >= vc && (c.href || c.name || c.$set("href", ""), a.append(b.createComment("IE fix"))), c.href || c.xlinkHref || c.name ? void 0 : function(a, b) {
                    var c = "[object SVGAnimatedString]" === Cc.call(b.prop("href")) ? "xlink:href" : "href";
                    b.on("click", function(a) {
                        b.attr(c) || a.preventDefault()
                    })
                }
            }
        }),
        Id = {};
    f(Yc, function(a, b) {
        if ("multiple" != a) {
            var c = Pa("ng-" + b);
            Id[c] = function() {
                return {
                    priority: 100,
                    link: function(a, d, e) {
                        a.$watch(e[c], function(a) {
                            e.$set(b, !!a)
                        })
                    }
                }
            }
        }
    }), f(["src", "srcset", "href"], function(a) {
        var b = Pa("ng-" + a);
        Id[b] = function() {
            return {
                priority: 99,
                link: function(c, d, e) {
                    var f = a,
                        g = a;
                    "href" === a && "[object SVGAnimatedString]" === Cc.call(d.prop("href")) && (g = "xlinkHref", e.$attr[g] = "xlink:href", f = null), e.$observe(b, function(b) {
                        return b ? (e.$set(g, b), void(vc && f && d.prop(f, e[g]))) : void("href" === a && e.$set(g, null))
                    })
                }
            }
        }
    });
    var Jd = {
        $addControl: o,
        $removeControl: o,
        $setValidity: o,
        $setDirty: o,
        $setPristine: o
    };
    ec.$inject = ["$element", "$attrs", "$scope", "$animate"];
    var Kd = function(a) {
            return ["$timeout", function(b) {
                var d = {
                    name: "form",
                    restrict: a ? "EAC" : "E",
                    controller: ec,
                    compile: function() {
                        return {
                            pre: function(a, d, e, f) {
                                if (!e.action) {
                                    var g = function(a) {
                                        a.preventDefault ? a.preventDefault() : a.returnValue = !1
                                    };
                                    Nc(d[0], "submit", g), d.on("$destroy", function() {
                                        b(function() {
                                            Oc(d[0], "submit", g)
                                        }, 0, !1)
                                    })
                                }
                                var h = d.parent().controller("form"),
                                    i = e.name || e.ngForm;
                                i && wb(a, i, f, i), h && d.on("$destroy", function() {
                                    h.$removeControl(f), i && wb(a, i, c, i), l(f, Jd)
                                })
                            }
                        }
                    }
                };
                return d
            }]
        },
        Ld = Kd(),
        Md = Kd(!0),
        Nd = /^(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?$/,
        Od = /^[a-z0-9!#$%&'*+\/=?^_`{|}~.-]+@[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)*$/i,
        Pd = /^\s*(\-|\+)?(\d+|(\d*(\.\d*)))\s*$/,
        Qd = {
            text: ic,
            number: jc,
            url: kc,
            email: lc,
            radio: mc,
            checkbox: nc,
            hidden: o,
            button: o,
            submit: o,
            reset: o,
            file: o
        },
        Rd = ["badInput"],
        Sd = ["$browser", "$sniffer", function(a, b) {
            return {
                restrict: "E",
                require: "?ngModel",
                link: function(c, d, e, f) {
                    f && (Qd[qc(e.type)] || Qd.text)(c, d, e, f, b, a)
                }
            }
        }],
        Td = "ng-valid",
        Ud = "ng-invalid",
        Vd = "ng-pristine",
        Wd = "ng-dirty",
        Xd = ["$scope", "$exceptionHandler", "$attrs", "$element", "$parse", "$animate", function(a, b, c, e, g, h) {
            function i(a, b) {
                b = b ? "-" + _(b, "-") : "", h.removeClass(e, (a ? Ud : Td) + b), h.addClass(e, (a ? Td : Ud) + b)
            }
            this.$viewValue = Number.NaN, this.$modelValue = Number.NaN, this.$parsers = [], this.$formatters = [], this.$viewChangeListeners = [], this.$pristine = !0, this.$dirty = !1, this.$valid = !0, this.$invalid = !1, this.$name = c.name;
            var j = g(c.ngModel),
                k = j.assign;
            if (!k) throw d("ngModel")("nonassign", "Expression '{0}' is non-assignable. Element: {1}", c.ngModel, T(e));
            this.$render = o, this.$isEmpty = function(a) {
                return r(a) || "" === a || null === a || a !== a
            };
            var l = e.inheritedData("$formController") || Jd,
                m = 0,
                n = this.$error = {};
            e.addClass(Vd), i(!0), this.$setValidity = function(a, b) {
                n[a] !== !b && (b ? (n[a] && m--, m || (i(!0), this.$valid = !0, this.$invalid = !1)) : (i(!1), this.$invalid = !0, this.$valid = !1, m++), n[a] = !b, i(b, a), l.$setValidity(a, b, this))
            }, this.$setPristine = function() {
                this.$dirty = !1, this.$pristine = !0, h.removeClass(e, Wd), h.addClass(e, Vd)
            }, this.$setViewValue = function(c) {
                this.$viewValue = c, this.$pristine && (this.$dirty = !0, this.$pristine = !1, h.removeClass(e, Vd), h.addClass(e, Wd), l.$setDirty()), f(this.$parsers, function(a) {
                    c = a(c)
                }), this.$modelValue !== c && (this.$modelValue = c, k(a, c), f(this.$viewChangeListeners, function(a) {
                    try {
                        a()
                    } catch (c) {
                        b(c)
                    }
                }))
            };
            var p = this;
            a.$watch(function() {
                var b = j(a);
                if (p.$modelValue !== b) {
                    var c = p.$formatters,
                        d = c.length;
                    for (p.$modelValue = b; d--;) b = c[d](b);
                    p.$viewValue !== b && (p.$viewValue = b, p.$render())
                }
                return b
            })
        }],
        Yd = function() {
            return {
                require: ["ngModel", "^?form"],
                controller: Xd,
                link: function(a, b, c, d) {
                    var e = d[0],
                        f = d[1] || Jd;
                    f.$addControl(e), a.$on("$destroy", function() {
                        f.$removeControl(e)
                    })
                }
            }
        },
        Zd = q({
            require: "ngModel",
            link: function(a, b, c, d) {
                d.$viewChangeListeners.push(function() {
                    a.$eval(c.ngChange)
                })
            }
        }),
        $d = function() {
            return {
                require: "?ngModel",
                link: function(a, b, c, d) {
                    if (d) {
                        c.required = !0;
                        var e = function(a) {
                            return c.required && d.$isEmpty(a) ? void d.$setValidity("required", !1) : (d.$setValidity("required", !0), a)
                        };
                        d.$formatters.push(e), d.$parsers.unshift(e), c.$observe("required", function() {
                            e(d.$viewValue)
                        })
                    }
                }
            }
        },
        _d = function() {
            return {
                require: "ngModel",
                link: function(a, b, d, e) {
                    var g = /\/(.*)\//.exec(d.ngList),
                        h = g && new RegExp(g[1]) || d.ngList || ",",
                        i = function(a) {
                            if (!r(a)) {
                                var b = [];
                                return a && f(a.split(h), function(a) {
                                    a && b.push(Hc(a))
                                }), b
                            }
                        };
                    e.$parsers.push(i), e.$formatters.push(function(a) {
                        return Gc(a) ? a.join(", ") : c
                    }), e.$isEmpty = function(a) {
                        return !a || !a.length
                    }
                }
            }
        },
        ae = /^(true|false|\d+)$/,
        be = function() {
            return {
                priority: 100,
                compile: function(a, b) {
                    return ae.test(b.ngValue) ? function(a, b, c) {
                        c.$set("value", a.$eval(c.ngValue))
                    } : function(a, b, c) {
                        a.$watch(c.ngValue, function(a) {
                            c.$set("value", a)
                        })
                    }
                }
            }
        },
        ce = dc({
            compile: function(a) {
                return a.addClass("ng-binding"),
                    function(a, b, d) {
                        b.data("$binding", d.ngBind), a.$watch(d.ngBind, function(a) {
                            b.text(a == c ? "" : a)
                        })
                    }
            }
        }),
        de = ["$interpolate", function(a) {
            return function(b, c, d) {
                var e = a(c.attr(d.$attr.ngBindTemplate));
                c.addClass("ng-binding").data("$binding", e), d.$observe("ngBindTemplate", function(a) {
                    c.text(a)
                })
            }
        }],
        ee = ["$sce", "$parse", function(a, b) {
            return {
                compile: function(c) {
                    return c.addClass("ng-binding"),
                        function(c, d, e) {
                            function f() {
                                return (g(c) || "").toString()
                            }
                            d.data("$binding", e.ngBindHtml);
                            var g = b(e.ngBindHtml);
                            c.$watch(f, function(b) {
                                d.html(a.getTrustedHtml(g(c)) || "")
                            })
                        }
                }
            }
        }],
        fe = oc("", !0),
        ge = oc("Odd", 0),
        he = oc("Even", 1),
        ie = dc({
            compile: function(a, b) {
                b.$set("ngCloak", c), a.removeClass("ng-cloak")
            }
        }),
        je = [function() {
            return {
                scope: !0,
                controller: "@",
                priority: 500
            }
        }],
        ke = {},
        le = {
            blur: !0,
            focus: !0
        };
    f("click dblclick mousedown mouseup mouseover mouseout mousemove mouseenter mouseleave keydown keyup keypress submit focus blur copy cut paste".split(" "), function(a) {
        var b = Pa("ng-" + a);
        ke[b] = ["$parse", "$rootScope", function(c, d) {
            return {
                compile: function(e, f) {
                    var g = c(f[b], !0);
                    return function(b, c) {
                        c.on(a, function(c) {
                            var e = function() {
                                g(b, {
                                    $event: c
                                })
                            };
                            le[a] && d.$$phase ? b.$evalAsync(e) : b.$apply(e)
                        })
                    }
                }
            }
        }]
    });
    var me = ["$animate", function(a) {
            return {
                transclude: "element",
                priority: 600,
                terminal: !0,
                restrict: "A",
                $$tlb: !0,
                link: function(c, d, e, f, g) {
                    var h, i, j;
                    c.$watch(e.ngIf, function(f) {
                        S(f) ? i || (i = c.$new(), g(i, function(c) {
                            c[c.length++] = b.createComment(" end ngIf: " + e.ngIf + " "), h = {
                                clone: c
                            }, a.enter(c, d.parent(), d)
                        })) : (j && (j.remove(), j = null), i && (i.$destroy(), i = null), h && (j = fa(h.clone), a.leave(j, function() {
                            j = null
                        }), h = null))
                    })
                }
            }
        }],
        ne = ["$http", "$templateCache", "$anchorScroll", "$animate", "$sce", function(a, b, c, d, e) {
            return {
                restrict: "ECA",
                priority: 400,
                terminal: !0,
                transclude: "element",
                controller: Ec.noop,
                compile: function(f, g) {
                    var h = g.ngInclude || g.src,
                        i = g.onload || "",
                        j = g.autoscroll;
                    return function(f, g, k, l, m) {
                        var n, o, p, q = 0,
                            r = function() {
                                o && (o.remove(), o = null), n && (n.$destroy(), n = null), p && (d.leave(p, function() {
                                    o = null
                                }), o = p, p = null)
                            };
                        f.$watch(e.parseAsResourceUrl(h), function(e) {
                            var h = function() {
                                    !s(j) || j && !f.$eval(j) || c()
                                },
                                k = ++q;
                            e ? (a.get(e, {
                                cache: b
                            }).success(function(a) {
                                if (k === q) {
                                    var b = f.$new();
                                    l.template = a;
                                    var c = m(b, function(a) {
                                        r(), d.enter(a, null, g, h)
                                    });
                                    n = b, p = c, n.$emit("$includeContentLoaded"), f.$eval(i)
                                }
                            }).error(function() {
                                k === q && r()
                            }), f.$emit("$includeContentRequested")) : (r(), l.template = null)
                        })
                    }
                }
            }
        }],
        oe = ["$compile", function(a) {
            return {
                restrict: "ECA",
                priority: -400,
                require: "ngInclude",
                link: function(b, c, d, e) {
                    c.html(e.template), a(c.contents())(b)
                }
            }
        }],
        pe = dc({
            priority: 450,
            compile: function() {
                return {
                    pre: function(a, b, c) {
                        a.$eval(c.ngInit)
                    }
                }
            }
        }),
        qe = dc({
            terminal: !0,
            priority: 1e3
        }),
        re = ["$locale", "$interpolate", function(a, b) {
            var c = /{}/g;
            return {
                restrict: "EA",
                link: function(d, e, g) {
                    var h = g.count,
                        i = g.$attr.when && e.attr(g.$attr.when),
                        j = g.offset || 0,
                        k = d.$eval(i) || {},
                        l = {},
                        m = b.startSymbol(),
                        n = b.endSymbol(),
                        o = /^when(Minus)?(.+)$/;
                    f(g, function(a, b) {
                        o.test(b) && (k[qc(b.replace("when", "").replace("Minus", "-"))] = e.attr(g.$attr[b]))
                    }), f(k, function(a, d) {
                        l[d] = b(a.replace(c, m + h + "-" + j + n))
                    }), d.$watch(function() {
                        var b = parseFloat(d.$eval(h));
                        return isNaN(b) ? "" : (b in k || (b = a.pluralCat(b - j)), l[b](d, e, !0))
                    }, function(a) {
                        e.text(a)
                    })
                }
            }
        }],
        se = ["$parse", "$animate", function(a, c) {
            function g(a) {
                return a.clone[0]
            }

            function h(a) {
                return a.clone[a.clone.length - 1]
            }
            var i = "$$NG_REMOVED",
                j = d("ngRepeat");
            return {
                transclude: "element",
                priority: 1e3,
                terminal: !0,
                $$tlb: !0,
                link: function(d, k, l, m, n) {
                    var o, p, q, r, s, t, u, v, w, x = l.ngRepeat,
                        y = x.match(/^\s*([\s\S]+?)\s+in\s+([\s\S]+?)(?:\s+track\s+by\s+([\s\S]+?))?\s*$/),
                        z = {
                            $id: Ea
                        };
                    if (!y) throw j("iexp", "Expected expression in form of '_item_ in _collection_[ track by _id_]' but got '{0}'.", x);
                    if (t = y[1], u = y[2], o = y[3], o ? (p = a(o), q = function(a, b, c) {
                            return w && (z[w] = a), z[v] = b, z.$index = c, p(d, z)
                        }) : (r = function(a, b) {
                            return Ea(b)
                        }, s = function(a) {
                            return a
                        }), y = t.match(/^(?:([\$\w]+)|\(([\$\w]+)\s*,\s*([\$\w]+)\))$/), !y) throw j("iidexp", "'_item_' in '_item_ in _collection_' should be an identifier or '(_key_, _value_)' expression, but got '{0}'.", t);
                    v = y[3] || y[1], w = y[2];
                    var A = {};
                    d.$watchCollection(u, function(a) {
                        var l, m, o, p, t, u, y, z, B, C, D, E, F = k[0],
                            G = {},
                            H = [];
                        if (e(a)) C = a, B = q || r;
                        else {
                            B = q || s, C = [];
                            for (u in a) a.hasOwnProperty(u) && "$" != u.charAt(0) && C.push(u);
                            C.sort()
                        }
                        for (p = C.length, m = H.length = C.length, l = 0; m > l; l++)
                            if (u = a === C ? l : C[l], y = a[u], z = B(u, y, l), da(z, "`track by` id"), A.hasOwnProperty(z)) D = A[z], delete A[z], G[z] = D, H[l] = D;
                            else {
                                if (G.hasOwnProperty(z)) throw f(H, function(a) {
                                    a && a.scope && (A[a.id] = a)
                                }), j("dupes", "Duplicates in a repeater are not allowed. Use 'track by' expression to specify unique keys. Repeater: {0}, Duplicate key: {1}, Duplicate value: {2}", x, z, Q(y));
                                H[l] = {
                                    id: z
                                }, G[z] = !1
                            }
                        for (u in A) A.hasOwnProperty(u) && (D = A[u], E = fa(D.clone), c.leave(E), f(E, function(a) {
                            a[i] = !0
                        }), D.scope.$destroy());
                        for (l = 0, m = C.length; m > l; l++) {
                            if (u = a === C ? l : C[l], y = a[u], D = H[l], H[l - 1] && (F = h(H[l - 1])), D.scope) {
                                t = D.scope, o = F;
                                do o = o.nextSibling; while (o && o[i]);
                                g(D) != o && c.move(fa(D.clone), null, wc(F)), F = h(D)
                            } else t = d.$new();
                            t[v] = y, w && (t[w] = u), t.$index = l, t.$first = 0 === l, t.$last = l === p - 1, t.$middle = !(t.$first || t.$last), t.$odd = !(t.$even = 0 === (1 & l)), D.scope || n(t, function(a) {
                                a[a.length++] = b.createComment(" end ngRepeat: " + x + " "), c.enter(a, null, wc(F)), F = a, D.scope = t, D.clone = a, G[D.id] = D
                            })
                        }
                        A = G
                    })
                }
            }
        }],
        te = ["$animate", function(a) {
            return function(b, c, d) {
                b.$watch(d.ngShow, function(b) {
                    a[S(b) ? "removeClass" : "addClass"](c, "ng-hide")
                })
            }
        }],
        ue = ["$animate", function(a) {
            return function(b, c, d) {
                b.$watch(d.ngHide, function(b) {
                    a[S(b) ? "addClass" : "removeClass"](c, "ng-hide")
                })
            }
        }],
        ve = dc(function(a, b, c) {
            a.$watch(c.ngStyle, function(a, c) {
                c && a !== c && f(c, function(a, c) {
                    b.css(c, "")
                }), a && b.css(a)
            }, !0)
        }),
        we = ["$animate", function(a) {
            return {
                restrict: "EA",
                require: "ngSwitch",
                controller: ["$scope", function() {
                    this.cases = {}
                }],
                link: function(b, c, d, e) {
                    var g = d.ngSwitch || d.on,
                        h = [],
                        i = [],
                        j = [],
                        k = [];
                    b.$watch(g, function(c) {
                        var g, l;
                        for (g = 0, l = j.length; l > g; ++g) j[g].remove();
                        for (j.length = 0, g = 0, l = k.length; l > g; ++g) {
                            var m = i[g];
                            k[g].$destroy(), j[g] = m, a.leave(m, function() {
                                j.splice(g, 1)
                            })
                        }
                        i.length = 0, k.length = 0, (h = e.cases["!" + c] || e.cases["?"]) && (b.$eval(d.change), f(h, function(c) {
                            var d = b.$new();
                            k.push(d), c.transclude(d, function(b) {
                                var d = c.element;
                                i.push(b), a.enter(b, d.parent(), d)
                            })
                        }))
                    })
                }
            }
        }],
        xe = dc({
            transclude: "element",
            priority: 800,
            require: "^ngSwitch",
            link: function(a, b, c, d, e) {
                d.cases["!" + c.ngSwitchWhen] = d.cases["!" + c.ngSwitchWhen] || [], d.cases["!" + c.ngSwitchWhen].push({
                    transclude: e,
                    element: b
                })
            }
        }),
        ye = dc({
            transclude: "element",
            priority: 800,
            require: "^ngSwitch",
            link: function(a, b, c, d, e) {
                d.cases["?"] = d.cases["?"] || [], d.cases["?"].push({
                    transclude: e,
                    element: b
                })
            }
        }),
        ze = dc({
            link: function(a, b, c, e, f) {
                if (!f) throw d("ngTransclude")("orphan", "Illegal use of ngTransclude directive in the template! No parent directive that requires a transclusion found. Element: {0}", T(b));
                f(function(a) {
                    b.empty(), b.append(a)
                })
            }
        }),
        Ae = ["$templateCache", function(a) {
            return {
                restrict: "E",
                terminal: !0,
                compile: function(b, c) {
                    if ("text/ng-template" == c.type) {
                        var d = c.id,
                            e = b[0].text;
                        a.put(d, e)
                    }
                }
            }
        }],
        Be = d("ngOptions"),
        Ce = q({
            terminal: !0
        }),
        De = ["$compile", "$parse", function(a, d) {
            var e = /^\s*([\s\S]+?)(?:\s+as\s+([\s\S]+?))?(?:\s+group\s+by\s+([\s\S]+?))?\s+for\s+(?:([\$\w][\$\w]*)|(?:\(\s*([\$\w][\$\w]*)\s*,\s*([\$\w][\$\w]*)\s*\)))\s+in\s+([\s\S]+?)(?:\s+track\s+by\s+([\s\S]+?))?$/,
                h = {
                    $setViewValue: o
                };
            return {
                restrict: "E",
                require: ["select", "?ngModel"],
                controller: ["$element", "$scope", "$attrs", function(a, b, c) {
                    var d, e, f = this,
                        g = {},
                        i = h;
                    f.databound = c.ngModel, f.init = function(a, b, c) {
                        i = a, d = b, e = c
                    }, f.addOption = function(b) {
                        da(b, '"option value"'), g[b] = !0, i.$viewValue == b && (a.val(b), e.parent() && e.remove())
                    }, f.removeOption = function(a) {
                        this.hasOption(a) && (delete g[a], i.$viewValue == a && this.renderUnknownOption(a))
                    }, f.renderUnknownOption = function(b) {
                        var c = "? " + Ea(b) + " ?";
                        e.val(c), a.prepend(e), a.val(c), e.prop("selected", !0)
                    }, f.hasOption = function(a) {
                        return g.hasOwnProperty(a)
                    }, b.$on("$destroy", function() {
                        f.renderUnknownOption = o
                    })
                }],
                link: function(h, i, j, k) {
                    function l(a, b, c, d) {
                        c.$render = function() {
                            var a = c.$viewValue;
                            d.hasOption(a) ? (y.parent() && y.remove(), b.val(a), "" === a && o.prop("selected", !0)) : r(a) && o ? b.val("") : d.renderUnknownOption(a)
                        }, b.on("change", function() {
                            a.$apply(function() {
                                y.parent() && y.remove(), c.$setViewValue(b.val())
                            })
                        })
                    }

                    function m(a, b, c) {
                        var d;
                        c.$render = function() {
                            var a = new Fa(c.$viewValue);
                            f(b.find("option"), function(b) {
                                b.selected = s(a.get(b.value))
                            })
                        }, a.$watch(function() {
                            L(d, c.$viewValue) || (d = K(c.$viewValue), c.$render())
                        }), b.on("change", function() {
                            a.$apply(function() {
                                var a = [];
                                f(b.find("option"), function(b) {
                                    b.selected && a.push(b.value)
                                }), c.$setViewValue(a)
                            })
                        })
                    }

                    function n(b, f, h) {
                        function i() {
                            var a = !1;
                            if (t) {
                                var c = h.$modelValue;
                                if (z && Gc(c)) {
                                    a = new Fa([]);
                                    for (var d = {}, e = 0; e < c.length; e++) d[m] = c[e], a.put(z(b, d), c[e])
                                } else a = new Fa(c)
                            }
                            return a
                        }

                        function j() {
                            var a, c, d, e, j, k, u, y, B, C, D, E, F, G, H, I = {
                                    "": []
                                },
                                J = [""],
                                K = h.$modelValue,
                                L = r(b) || [],
                                M = n ? g(L) : L,
                                N = {},
                                O = i();
                            for (D = 0; B = M.length, B > D; D++) {
                                if (u = D, n) {
                                    if (u = M[D], "$" === u.charAt(0)) continue;
                                    N[n] = u
                                }
                                if (N[m] = L[u], a = o(b, N) || "", (c = I[a]) || (c = I[a] = [], J.push(a)), t) E = s(O.remove(z ? z(b, N) : q(b, N)));
                                else {
                                    if (z) {
                                        var P = {};
                                        P[m] = K, E = z(b, P) === z(b, N)
                                    } else E = K === q(b, N);
                                    O = O || E
                                }
                                H = l(b, N), H = s(H) ? H : "", c.push({
                                    id: z ? z(b, N) : n ? M[D] : D,
                                    label: H,
                                    selected: E
                                })
                            }
                            for (t || (v || null === K ? I[""].unshift({
                                    id: "",
                                    label: "",
                                    selected: !O
                                }) : O || I[""].unshift({
                                    id: "?",
                                    label: "",
                                    selected: !0
                                })), C = 0, y = J.length; y > C; C++) {
                                for (a = J[C], c = I[a], A.length <= C ? (e = {
                                        element: x.clone().attr("label", a),
                                        label: c.label
                                    }, j = [e], A.push(j), f.append(e.element)) : (j = A[C], e = j[0], e.label != a && e.element.attr("label", e.label = a)), F = null, D = 0, B = c.length; B > D; D++) d = c[D], (k = j[D + 1]) ? (F = k.element, k.label !== d.label && (F.text(k.label = d.label), F.prop("label", k.label)), k.id !== d.id && F.val(k.id = d.id), F[0].selected !== d.selected && (F.prop("selected", k.selected = d.selected), vc && F.prop("selected", k.selected))) : ("" === d.id && v ? G = v : (G = w.clone()).val(d.id).prop("selected", d.selected).attr("selected", d.selected).prop("label", d.label).text(d.label), j.push(k = {
                                    element: G,
                                    label: d.label,
                                    id: d.id,
                                    selected: d.selected
                                }), p.addOption(d.label, G), F ? F.after(G) : e.element.append(G), F = G);
                                for (D++; j.length > D;) d = j.pop(), p.removeOption(d.label), d.element.remove()
                            }
                            for (; A.length > C;) A.pop()[0].element.remove()
                        }
                        var k;
                        if (!(k = u.match(e))) throw Be("iexp", "Expected expression in form of '_select_ (as _label_)? for (_key_,)?_value_ in _collection_' but got '{0}'. Element: {1}", u, T(f));
                        var l = d(k[2] || k[1]),
                            m = k[4] || k[6],
                            n = k[5],
                            o = d(k[3] || ""),
                            q = d(k[2] ? k[1] : m),
                            r = d(k[7]),
                            y = k[8],
                            z = y ? d(k[8]) : null,
                            A = [
                                [{
                                    element: f,
                                    label: ""
                                }]
                            ];
                        v && (a(v)(b), v.removeClass("ng-scope"), v.remove()), f.empty(), f.on("change", function() {
                            b.$apply(function() {
                                var a, d, e, g, i, k, l, o, p, s = r(b) || [],
                                    u = {};
                                if (t) {
                                    for (e = [], k = 0, o = A.length; o > k; k++)
                                        for (a = A[k], i = 1, l = a.length; l > i; i++)
                                            if ((g = a[i].element)[0].selected) {
                                                if (d = g.val(), n && (u[n] = d), z)
                                                    for (p = 0; p < s.length && (u[m] = s[p], z(b, u) != d); p++);
                                                else u[m] = s[d];
                                                e.push(q(b, u))
                                            }
                                } else if (d = f.val(), "?" == d) e = c;
                                else if ("" === d) e = null;
                                else if (z) {
                                    for (p = 0; p < s.length; p++)
                                        if (u[m] = s[p], z(b, u) == d) {
                                            e = q(b, u);
                                            break
                                        }
                                } else u[m] = s[d], n && (u[n] = d), e = q(b, u);
                                h.$setViewValue(e), j()
                            })
                        }), h.$render = j, b.$watchCollection(r, j), b.$watchCollection(function() {
                            var a = {},
                                c = r(b);
                            if (c) {
                                for (var d = new Array(c.length), e = 0, f = c.length; f > e; e++) a[m] = c[e], d[e] = l(b, a);
                                return d
                            }
                        }, j), t && b.$watchCollection(function() {
                            return h.$modelValue
                        }, j)
                    }
                    if (k[1]) {
                        for (var o, p = k[0], q = k[1], t = j.multiple, u = j.ngOptions, v = !1, w = wc(b.createElement("option")), x = wc(b.createElement("optgroup")), y = w.clone(), z = 0, A = i.children(), B = A.length; B > z; z++)
                            if ("" === A[z].value) {
                                o = v = A.eq(z);
                                break
                            }
                        p.init(q, v, y), t && (q.$isEmpty = function(a) {
                            return !a || 0 === a.length
                        }), u ? n(h, i, q) : t ? m(h, i, q) : l(h, i, q, p)
                    }
                }
            }
        }],
        Ee = ["$interpolate", function(a) {
            var b = {
                addOption: o,
                removeOption: o
            };
            return {
                restrict: "E",
                priority: 100,
                compile: function(c, d) {
                    if (r(d.value)) {
                        var e = a(c.text(), !0);
                        e || d.$set("value", c.text())
                    }
                    return function(a, c, d) {
                        var f = "$selectController",
                            g = c.parent(),
                            h = g.data(f) || g.parent().data(f);
                        h && h.databound ? c.prop("selected", !1) : h = b, e ? a.$watch(e, function(a, b) {
                            d.$set("value", a), a !== b && h.removeOption(b), h.addOption(a)
                        }) : h.addOption(d.value), c.on("$destroy", function() {
                            h.removeOption(d.value)
                        })
                    }
                }
            }
        }],
        Fe = q({
            restrict: "E",
            terminal: !0
        });
    return a.angular.bootstrap ? void console.log("WARNING: Tried to load angular more than once.") : (aa(), ha(Ec), void wc(b).ready(function() {
        Z(b, $)
    }))
}(window, document), !window.angular.$$csp() && window.angular.element(document).find("head").prepend('<style type="text/css">@charset "UTF-8";[ng\\:cloak],[ng-cloak],[data-ng-cloak],[x-ng-cloak],.ng-cloak,.x-ng-cloak,.ng-hide{display:none !important;}ng\\:form{display:block;}.ng-animate-block-transitions{transition:0s all!important;-webkit-transition:0s all!important;}.ng-hide-add-active,.ng-hide-remove{display:block!important;}</style>'),
    function(a, b, c) {
        "use strict";

        function d() {
            this.$get = ["$$sanitizeUri", function(a) {
                return function(b) {
                    var c = [];
                    return g(b, j(c, function(b, c) {
                        return !/^unsafe/.test(a(b, c))
                    })), c.join("")
                }
            }]
        }

        function e(a) {
            var c = [],
                d = j(c, b.noop);
            return d.chars(a), c.join("")
        }

        function f(a) {
            var b, c = {},
                d = a.split(",");
            for (b = 0; b < d.length; b++) c[d[b]] = !0;
            return c
        }

        function g(a, c) {
            function d(a, d, f, g) {
                if (d = b.lowercase(d), z[d])
                    for (; t.last() && A[t.last()];) e("", t.last());
                y[d] && t.last() == d && e("", d), g = v[d] || !!g, g || t.push(d);
                var i = {};
                f.replace(n, function(a, b, c, d, e) {
                    var f = c || d || e || "";
                    i[b] = h(f)
                }), c.start && c.start(d, i, g)
            }

            function e(a, d) {
                var e, f = 0;
                if (d = b.lowercase(d))
                    for (f = t.length - 1; f >= 0 && t[f] != d; f--);
                if (f >= 0) {
                    for (e = t.length - 1; e >= f; e--) c.end && c.end(t[e]);
                    t.length = f
                }
            }
            "string" != typeof a && (a = null === a || "undefined" == typeof a ? "" : "" + a);
            var f, g, i, j, t = [],
                u = a;
            for (t.last = function() {
                    return t[t.length - 1]
                }; a;) {
                if (j = "", g = !0, t.last() && B[t.last()] ? (a = a.replace(new RegExp("(.*)<\\s*\\/\\s*" + t.last() + "[^>]*>", "i"), function(a, b) {
                        return b = b.replace(q, "$1").replace(s, "$1"), c.chars && c.chars(h(b)), ""
                    }), e("", t.last())) : (0 === a.indexOf("<!--") ? (f = a.indexOf("--", 4), f >= 0 && a.lastIndexOf("-->", f) === f && (c.comment && c.comment(a.substring(4, f)), a = a.substring(f + 3), g = !1)) : r.test(a) ? (i = a.match(r), i && (a = a.replace(i[0], ""), g = !1)) : p.test(a) ? (i = a.match(m), i && (a = a.substring(i[0].length), i[0].replace(m, e), g = !1)) : o.test(a) && (i = a.match(l), i ? (i[4] && (a = a.substring(i[0].length), i[0].replace(l, d)), g = !1) : (j += "<", a = a.substring(1))), g && (f = a.indexOf("<"), j += 0 > f ? a : a.substring(0, f), a = 0 > f ? "" : a.substring(f), c.chars && c.chars(h(j)))), a == u) throw k("badparse", "The sanitizer was unable to parse the following block of html: {0}", a);
                u = a
            }
            e()
        }

        function h(a) {
            if (!a) return "";
            var b = G.exec(a),
                c = b[1],
                d = b[3],
                e = b[2];
            return e && (F.innerHTML = e.replace(/</g, "&lt;"), e = "textContent" in F ? F.textContent : F.innerText), c + e + d
        }

        function i(a) {
            return a.replace(/&/g, "&amp;").replace(t, function(a) {
                var b = a.charCodeAt(0),
                    c = a.charCodeAt(1);
                return "&#" + (1024 * (b - 55296) + (c - 56320) + 65536) + ";"
            }).replace(u, function(a) {
                return "&#" + a.charCodeAt(0) + ";"
            }).replace(/</g, "&lt;").replace(/>/g, "&gt;")
        }

        function j(a, c) {
            var d = !1,
                e = b.bind(a, a.push);
            return {
                start: function(a, f, g) {
                    a = b.lowercase(a), !d && B[a] && (d = a), d || C[a] !== !0 || (e("<"), e(a), b.forEach(f, function(d, f) {
                        var g = b.lowercase(f),
                            h = "img" === a && "src" === g || "background" === g;
                        E[g] !== !0 || D[g] === !0 && !c(d, h) || (e(" "), e(f), e('="'), e(i(d)), e('"'))
                    }), e(g ? "/>" : ">"))
                },
                end: function(a) {
                    a = b.lowercase(a), d || C[a] !== !0 || (e("</"), e(a), e(">")), a == d && (d = !1)
                },
                chars: function(a) {
                    d || e(i(a))
                }
            }
        }
        var k = b.$$minErr("$sanitize"),
            l = /^<((?:[a-zA-Z])[\w:-]*)((?:\s+[\w:-]+(?:\s*=\s*(?:(?:"[^"]*")|(?:'[^']*')|[^>\s]+))?)*)\s*(\/?)\s*(>?)/,
            m = /^<\/\s*([\w:-]+)[^>]*>/,
            n = /([\w:-]+)(?:\s*=\s*(?:(?:"((?:[^"])*)")|(?:'((?:[^'])*)')|([^>\s]+)))?/g,
            o = /^</,
            p = /^<\//,
            q = /<!--(.*?)-->/g,
            r = /<!DOCTYPE([^>]*?)>/i,
            s = /<!\[CDATA\[(.*?)]]>/g,
            t = /[\uD800-\uDBFF][\uDC00-\uDFFF]/g,
            u = /([^\#-~| |!])/g,
            v = f("area,br,col,hr,img,wbr"),
            w = f("colgroup,dd,dt,li,p,tbody,td,tfoot,th,thead,tr"),
            x = f("rp,rt"),
            y = b.extend({}, x, w),
            z = b.extend({}, w, f("address,article,aside,blockquote,caption,center,del,dir,div,dl,figure,figcaption,footer,h1,h2,h3,h4,h5,h6,header,hgroup,hr,ins,map,menu,nav,ol,pre,script,section,table,ul")),
            A = b.extend({}, x, f("a,abbr,acronym,b,bdi,bdo,big,br,cite,code,del,dfn,em,font,i,img,ins,kbd,label,map,mark,q,ruby,rp,rt,s,samp,small,span,strike,strong,sub,sup,time,tt,u,var")),
            B = f("script,style"),
            C = b.extend({}, v, z, A, y),
            D = f("background,cite,href,longdesc,src,usemap"),
            E = b.extend({}, D, f("abbr,align,alt,axis,bgcolor,border,cellpadding,cellspacing,class,clear,color,cols,colspan,compact,coords,dir,face,headers,height,hreflang,hspace,ismap,lang,language,nohref,nowrap,rel,rev,rows,rowspan,rules,scope,scrolling,shape,size,span,start,summary,target,title,type,valign,value,vspace,width")),
            F = document.createElement("pre"),
            G = /^(\s*)([\s\S]*?)(\s*)$/;
        b.module("ngSanitize", []).provider("$sanitize", d), b.module("ngSanitize").filter("linky", ["$sanitize", function(a) {
            var c = /((ftp|https?):\/\/|(mailto:)?[A-Za-z0-9._%+-]+@)\S*[^\s.;,(){}<>"]/,
                d = /^mailto:/;
            return function(f, g) {
                function h(a) {
                    a && n.push(e(a))
                }

                function i(a, c) {
                    n.push("<a "), b.isDefined(g) && (n.push('target="'), n.push(g), n.push('" ')), n.push('href="', a.replace('"', "&quot;"), '">'), h(c), n.push("</a>")
                }
                if (!f) return f;
                for (var j, k, l, m = f, n = []; j = m.match(c);) k = j[0], j[2] == j[3] && (k = "mailto:" + k), l = j.index, h(m.substr(0, l)), i(k, j[0].replace(d, "")), m = m.substring(l + j[0].length);
                return h(m), a(n.join(""))
            }
        }])
    }(window, window.angular), angular.module("ui.bootstrap", ["ui.bootstrap.tpls", "ui.bootstrap.transition", "ui.bootstrap.collapse", "ui.bootstrap.accordion", "ui.bootstrap.alert", "ui.bootstrap.bindHtml", "ui.bootstrap.buttons", "ui.bootstrap.carousel", "ui.bootstrap.dateparser", "ui.bootstrap.position", "ui.bootstrap.datepicker", "ui.bootstrap.dropdown", "ui.bootstrap.modal", "ui.bootstrap.pagination", "ui.bootstrap.tooltip", "ui.bootstrap.popover", "ui.bootstrap.progressbar", "ui.bootstrap.rating", "ui.bootstrap.tabs", "ui.bootstrap.timepicker", "ui.bootstrap.typeahead"]), angular.module("ui.bootstrap.tpls", ["template/accordion/accordion-group.html", "template/accordion/accordion.html", "template/alert/alert.html", "template/carousel/carousel.html", "template/carousel/slide.html", "template/datepicker/datepicker.html", "template/datepicker/day.html", "template/datepicker/month.html", "template/datepicker/popup.html", "template/datepicker/year.html", "template/modal/backdrop.html", "template/modal/window.html", "template/pagination/pager.html", "template/pagination/pagination.html", "template/tooltip/tooltip-html-unsafe-popup.html", "template/tooltip/tooltip-popup.html", "template/popover/popover.html", "template/progressbar/bar.html", "template/progressbar/progress.html", "template/progressbar/progressbar.html", "template/rating/rating.html", "template/tabs/tab.html", "template/tabs/tabset.html", "template/timepicker/timepicker.html", "template/typeahead/typeahead-match.html", "template/typeahead/typeahead-popup.html"]), angular.module("ui.bootstrap.transition", []).factory("$transition", ["$q", "$timeout", "$rootScope", function(a, b, c) {
        function d(a) {
            for (var b in a)
                if (void 0 !== f.style[b]) return a[b]
        }
        var e = function(d, f, g) {
                g = g || {};
                var h = a.defer(),
                    i = e[g.animation ? "animationEndEventName" : "transitionEndEventName"],
                    j = function() {
                        c.$apply(function() {
                            d.unbind(i, j), h.resolve(d)
                        })
                    };
                return i && d.bind(i, j), b(function() {
                    angular.isString(f) ? d.addClass(f) : angular.isFunction(f) ? f(d) : angular.isObject(f) && d.css(f), i || h.resolve(d)
                }), h.promise.cancel = function() {
                    i && d.unbind(i, j), h.reject("Transition cancelled")
                }, h.promise
            },
            f = document.createElement("trans"),
            g = {
                WebkitTransition: "webkitTransitionEnd",
                MozTransition: "transitionend",
                OTransition: "oTransitionEnd",
                transition: "transitionend"
            },
            h = {
                WebkitTransition: "webkitAnimationEnd",
                MozTransition: "animationend",
                OTransition: "oAnimationEnd",
                transition: "animationend"
            };
        return e.transitionEndEventName = d(g), e.animationEndEventName = d(h), e
    }]), angular.module("ui.bootstrap.collapse", ["ui.bootstrap.transition"]).directive("collapse", ["$transition", function(a) {
        return {
            link: function(b, c, d) {
                function e(b) {
                    function d() {
                        j === e && (j = void 0)
                    }
                    var e = a(c, b);
                    return j && j.cancel(), j = e, e.then(d, d), e
                }

                function f() {
                    k ? (k = !1, g()) : (c.removeClass("collapse").addClass("collapsing"), e({
                        height: c[0].scrollHeight + "px"
                    }).then(g))
                }

                function g() {
                    c.removeClass("collapsing"), c.addClass("collapse in"), c.css({
                        height: "auto"
                    })
                }

                function h() {
                    k ? (k = !1, i(), c.css({
                        height: 0
                    })) : (c.css({
                        height: c[0].scrollHeight + "px"
                    }), c[0].offsetWidth, c.removeClass("collapse in").addClass("collapsing"), e({
                        height: 0
                    }).then(i))
                }

                function i() {
                    c.removeClass("collapsing"), c.addClass("collapse")
                }
                var j, k = !0;
                b.$watch(d.collapse, function(a) {
                    a ? h() : f()
                })
            }
        }
    }]), angular.module("ui.bootstrap.accordion", ["ui.bootstrap.collapse"]).constant("accordionConfig", {
        closeOthers: !0
    }).controller("AccordionController", ["$scope", "$attrs", "accordionConfig", function(a, b, c) {
        this.groups = [], this.closeOthers = function(d) {
            var e = angular.isDefined(b.closeOthers) ? a.$eval(b.closeOthers) : c.closeOthers;
            e && angular.forEach(this.groups, function(a) {
                a !== d && (a.isOpen = !1)
            })
        }, this.addGroup = function(a) {
            var b = this;
            this.groups.push(a), a.$on("$destroy", function() {
                b.removeGroup(a)
            })
        }, this.removeGroup = function(a) {
            var b = this.groups.indexOf(a); - 1 !== b && this.groups.splice(b, 1)
        }
    }]).directive("accordion", function() {
        return {
            restrict: "EA",
            controller: "AccordionController",
            transclude: !0,
            replace: !1,
            templateUrl: "template/accordion/accordion.html"
        }
    }).directive("accordionGroup", function() {
        return {
            require: "^accordion",
            restrict: "EA",
            transclude: !0,
            replace: !0,
            templateUrl: "template/accordion/accordion-group.html",
            scope: {
                heading: "@",
                isOpen: "=?",
                isDisabled: "=?"
            },
            controller: function() {
                this.setHeading = function(a) {
                    this.heading = a
                }
            },
            link: function(a, b, c, d) {
                d.addGroup(a), a.$watch("isOpen", function(b) {
                    b && d.closeOthers(a)
                }), a.toggleOpen = function() {
                    a.isDisabled || (a.isOpen = !a.isOpen)
                }
            }
        }
    }).directive("accordionHeading", function() {
        return {
            restrict: "EA",
            transclude: !0,
            template: "",
            replace: !0,
            require: "^accordionGroup",
            link: function(a, b, c, d, e) {
                d.setHeading(e(a, function() {}))
            }
        }
    }).directive("accordionTransclude", function() {
        return {
            require: "^accordionGroup",
            link: function(a, b, c, d) {
                a.$watch(function() {
                    return d[c.accordionTransclude]
                }, function(a) {
                    a && (b.html(""), b.append(a))
                })
            }
        }
    }), angular.module("ui.bootstrap.alert", []).controller("AlertController", ["$scope", "$attrs", function(a, b) {
        a.closeable = "close" in b
    }]).directive("alert", function() {
        return {
            restrict: "EA",
            controller: "AlertController",
            templateUrl: "template/alert/alert.html",
            transclude: !0,
            replace: !0,
            scope: {
                type: "@",
                close: "&"
            }
        }
    }), angular.module("ui.bootstrap.bindHtml", []).directive("bindHtmlUnsafe", function() {
        return function(a, b, c) {
            b.addClass("ng-binding").data("$binding", c.bindHtmlUnsafe), a.$watch(c.bindHtmlUnsafe, function(a) {
                b.html(a || "")
            })
        }
    }), angular.module("ui.bootstrap.buttons", []).constant("buttonConfig", {
        activeClass: "active",
        toggleEvent: "click"
    }).controller("ButtonsController", ["buttonConfig", function(a) {
        this.activeClass = a.activeClass || "active", this.toggleEvent = a.toggleEvent || "click"
    }]).directive("btnRadio", function() {
        return {
            require: ["btnRadio", "ngModel"],
            controller: "ButtonsController",
            link: function(a, b, c, d) {
                var e = d[0],
                    f = d[1];
                f.$render = function() {
                    b.toggleClass(e.activeClass, angular.equals(f.$modelValue, a.$eval(c.btnRadio)))
                }, b.bind(e.toggleEvent, function() {
                    var d = b.hasClass(e.activeClass);
                    (!d || angular.isDefined(c.uncheckable)) && a.$apply(function() {
                        f.$setViewValue(d ? null : a.$eval(c.btnRadio)), f.$render()
                    })
                })
            }
        }
    }).directive("btnCheckbox", function() {
        return {
            require: ["btnCheckbox", "ngModel"],
            controller: "ButtonsController",
            link: function(a, b, c, d) {
                function e() {
                    return g(c.btnCheckboxTrue, !0)
                }

                function f() {
                    return g(c.btnCheckboxFalse, !1)
                }

                function g(b, c) {
                    var d = a.$eval(b);
                    return angular.isDefined(d) ? d : c
                }
                var h = d[0],
                    i = d[1];
                i.$render = function() {
                    b.toggleClass(h.activeClass, angular.equals(i.$modelValue, e()))
                }, b.bind(h.toggleEvent, function() {
                    a.$apply(function() {
                        i.$setViewValue(b.hasClass(h.activeClass) ? f() : e()), i.$render()
                    })
                })
            }
        }
    }), angular.module("ui.bootstrap.carousel", ["ui.bootstrap.transition"]).controller("CarouselController", ["$scope", "$timeout", "$transition", function(a, b, c) {
        function d() {
            e();
            var c = +a.interval;
            !isNaN(c) && c >= 0 && (g = b(f, c))
        }

        function e() {
            g && (b.cancel(g), g = null)
        }

        function f() {
            h ? (a.next(), d()) : a.pause()
        }
        var g, h, i = this,
            j = i.slides = a.slides = [],
            k = -1;
        i.currentSlide = null;
        var l = !1;
        i.select = a.select = function(e, f) {
            function g() {
                l || (i.currentSlide && angular.isString(f) && !a.noTransition && e.$element ? (e.$element.addClass(f), e.$element[0].offsetWidth, angular.forEach(j, function(a) {
                    angular.extend(a, {
                        direction: "",
                        entering: !1,
                        leaving: !1,
                        active: !1
                    })
                }), angular.extend(e, {
                    direction: f,
                    active: !0,
                    entering: !0
                }), angular.extend(i.currentSlide || {}, {
                    direction: f,
                    leaving: !0
                }), a.$currentTransition = c(e.$element, {}), function(b, c) {
                    a.$currentTransition.then(function() {
                        h(b, c)
                    }, function() {
                        h(b, c)
                    })
                }(e, i.currentSlide)) : h(e, i.currentSlide), i.currentSlide = e, k = m, d())
            }

            function h(b, c) {
                angular.extend(b, {
                    direction: "",
                    active: !0,
                    leaving: !1,
                    entering: !1
                }), angular.extend(c || {}, {
                    direction: "",
                    active: !1,
                    leaving: !1,
                    entering: !1
                }), a.$currentTransition = null
            }
            var m = j.indexOf(e);
            void 0 === f && (f = m > k ? "next" : "prev"), e && e !== i.currentSlide && (a.$currentTransition ? (a.$currentTransition.cancel(), b(g)) : g())
        }, a.$on("$destroy", function() {
            l = !0
        }), i.indexOfSlide = function(a) {
            return j.indexOf(a)
        }, a.next = function() {
            var b = (k + 1) % j.length;
            return a.$currentTransition ? void 0 : i.select(j[b], "next")
        }, a.prev = function() {
            var b = 0 > k - 1 ? j.length - 1 : k - 1;
            return a.$currentTransition ? void 0 : i.select(j[b], "prev")
        }, a.isActive = function(a) {
            return i.currentSlide === a
        }, a.$watch("interval", d), a.$on("$destroy", e), a.play = function() {
            h || (h = !0, d())
        }, a.pause = function() {
            a.noPause || (h = !1, e())
        }, i.addSlide = function(b, c) {
            b.$element = c, j.push(b), 1 === j.length || b.active ? (i.select(j[j.length - 1]), 1 == j.length && a.play()) : b.active = !1
        }, i.removeSlide = function(a) {
            var b = j.indexOf(a);
            j.splice(b, 1), j.length > 0 && a.active ? i.select(b >= j.length ? j[b - 1] : j[b]) : k > b && k--
        }
    }]).directive("carousel", [function() {
        return {
            restrict: "EA",
            transclude: !0,
            replace: !0,
            controller: "CarouselController",
            require: "carousel",
            templateUrl: "template/carousel/carousel.html",
            scope: {
                interval: "=",
                noTransition: "=",
                noPause: "="
            }
        }
    }]).directive("slide", function() {
        return {
            require: "^carousel",
            restrict: "EA",
            transclude: !0,
            replace: !0,
            templateUrl: "template/carousel/slide.html",
            scope: {
                active: "=?"
            },
            link: function(a, b, c, d) {
                d.addSlide(a, b), a.$on("$destroy", function() {
                    d.removeSlide(a)
                }), a.$watch("active", function(b) {
                    b && d.select(a)
                })
            }
        }
    }), angular.module("ui.bootstrap.dateparser", []).service("dateParser", ["$locale", "orderByFilter", function(a, b) {
        function c(a) {
            var c = [],
                d = a.split("");
            return angular.forEach(e, function(b, e) {
                var f = a.indexOf(e);
                if (f > -1) {
                    a = a.split(""), d[f] = "(" + b.regex + ")", a[f] = "$";
                    for (var g = f + 1, h = f + e.length; h > g; g++) d[g] = "", a[g] = "$";
                    a = a.join(""), c.push({
                        index: f,
                        apply: b.apply
                    })
                }
            }), {
                regex: new RegExp("^" + d.join("") + "$"),
                map: b(c, "index")
            }
        }

        function d(a, b, c) {
            return 1 === b && c > 28 ? 29 === c && (a % 4 === 0 && a % 100 !== 0 || a % 400 === 0) : 3 === b || 5 === b || 8 === b || 10 === b ? 31 > c : !0
        }
        this.parsers = {};
        var e = {
            yyyy: {
                regex: "\\d{4}",
                apply: function(a) {
                    this.year = +a
                }
            },
            yy: {
                regex: "\\d{2}",
                apply: function(a) {
                    this.year = +a + 2e3
                }
            },
            y: {
                regex: "\\d{1,4}",
                apply: function(a) {
                    this.year = +a
                }
            },
            MMMM: {
                regex: a.DATETIME_FORMATS.MONTH.join("|"),
                apply: function(b) {
                    this.month = a.DATETIME_FORMATS.MONTH.indexOf(b)
                }
            },
            MMM: {
                regex: a.DATETIME_FORMATS.SHORTMONTH.join("|"),
                apply: function(b) {
                    this.month = a.DATETIME_FORMATS.SHORTMONTH.indexOf(b)
                }
            },
            MM: {
                regex: "0[1-9]|1[0-2]",
                apply: function(a) {
                    this.month = a - 1
                }
            },
            M: {
                regex: "[1-9]|1[0-2]",
                apply: function(a) {
                    this.month = a - 1
                }
            },
            dd: {
                regex: "[0-2][0-9]{1}|3[0-1]{1}",
                apply: function(a) {
                    this.date = +a
                }
            },
            d: {
                regex: "[1-2]?[0-9]{1}|3[0-1]{1}",
                apply: function(a) {
                    this.date = +a
                }
            },
            EEEE: {
                regex: a.DATETIME_FORMATS.DAY.join("|")
            },
            EEE: {
                regex: a.DATETIME_FORMATS.SHORTDAY.join("|")
            }
        };
        this.parse = function(b, e) {
            if (!angular.isString(b) || !e) return b;
            e = a.DATETIME_FORMATS[e] || e, this.parsers[e] || (this.parsers[e] = c(e));
            var f = this.parsers[e],
                g = f.regex,
                h = f.map,
                i = b.match(g);
            if (i && i.length) {
                for (var j, k = {
                        year: 1900,
                        month: 0,
                        date: 1,
                        hours: 0
                    }, l = 1, m = i.length; m > l; l++) {
                    var n = h[l - 1];
                    n.apply && n.apply.call(k, i[l])
                }
                return d(k.year, k.month, k.date) && (j = new Date(k.year, k.month, k.date, k.hours)), j
            }
        }
    }]), angular.module("ui.bootstrap.position", []).factory("$position", ["$document", "$window", function(a, b) {
        function c(a, c) {
            return a.currentStyle ? a.currentStyle[c] : b.getComputedStyle ? b.getComputedStyle(a)[c] : a.style[c]
        }

        function d(a) {
            return "static" === (c(a, "position") || "static")
        }
        var e = function(b) {
            for (var c = a[0], e = b.offsetParent || c; e && e !== c && d(e);) e = e.offsetParent;
            return e || c
        };
        return {
            position: function(b) {
                var c = this.offset(b),
                    d = {
                        top: 0,
                        left: 0
                    },
                    f = e(b[0]);
                f != a[0] && (d = this.offset(angular.element(f)), d.top += f.clientTop - f.scrollTop, d.left += f.clientLeft - f.scrollLeft);
                var g = b[0].getBoundingClientRect();
                return {
                    width: g.width || b.prop("offsetWidth"),
                    height: g.height || b.prop("offsetHeight"),
                    top: c.top - d.top,
                    left: c.left - d.left
                }
            },
            offset: function(c) {
                var d = c[0].getBoundingClientRect();
                return {
                    width: d.width || c.prop("offsetWidth"),
                    height: d.height || c.prop("offsetHeight"),
                    top: d.top + (b.pageYOffset || a[0].documentElement.scrollTop),
                    left: d.left + (b.pageXOffset || a[0].documentElement.scrollLeft)
                }
            },
            positionElements: function(a, b, c, d) {
                var e, f, g, h, i = c.split("-"),
                    j = i[0],
                    k = i[1] || "center";
                e = d ? this.offset(a) : this.position(a), f = b.prop("offsetWidth"), g = b.prop("offsetHeight");
                var l = {
                        center: function() {
                            return e.left + e.width / 2 - f / 2
                        },
                        left: function() {
                            return e.left
                        },
                        right: function() {
                            return e.left + e.width
                        }
                    },
                    m = {
                        center: function() {
                            return e.top + e.height / 2 - g / 2
                        },
                        top: function() {
                            return e.top
                        },
                        bottom: function() {
                            return e.top + e.height
                        }
                    };
                switch (j) {
                    case "right":
                        h = {
                            top: m[k](),
                            left: l[j]()
                        };
                        break;
                    case "left":
                        h = {
                            top: m[k](),
                            left: e.left - f
                        };
                        break;
                    case "bottom":
                        h = {
                            top: m[j](),
                            left: l[k]()
                        };
                        break;
                    default:
                        h = {
                            top: e.top - g,
                            left: l[k]()
                        }
                }
                return h
            }
        }
    }]), angular.module("ui.bootstrap.datepicker", ["ui.bootstrap.dateparser", "ui.bootstrap.position"]).constant("datepickerConfig", {
        formatDay: "dd",
        formatMonth: "MMMM",
        formatYear: "yyyy",
        formatDayHeader: "EEE",
        formatDayTitle: "MMMM yyyy",
        formatMonthTitle: "yyyy",
        datepickerMode: "day",
        minMode: "day",
        maxMode: "year",
        showWeeks: !0,
        startingDay: 0,
        yearRange: 20,
        minDate: null,
        maxDate: null
    }).controller("DatepickerController", ["$scope", "$attrs", "$parse", "$interpolate", "$timeout", "$log", "dateFilter", "datepickerConfig", function(a, b, c, d, e, f, g, h) {
        var i = this,
            j = {
                $setViewValue: angular.noop
            };
        this.modes = ["day", "month", "year"], angular.forEach(["formatDay", "formatMonth", "formatYear", "formatDayHeader", "formatDayTitle", "formatMonthTitle", "minMode", "maxMode", "showWeeks", "startingDay", "yearRange"], function(c, e) {
            i[c] = angular.isDefined(b[c]) ? 8 > e ? d(b[c])(a.$parent) : a.$parent.$eval(b[c]) : h[c]
        }), angular.forEach(["minDate", "maxDate"], function(d) {
            b[d] ? a.$parent.$watch(c(b[d]), function(a) {
                i[d] = a ? new Date(a) : null, i.refreshView()
            }) : i[d] = h[d] ? new Date(h[d]) : null
        }), a.datepickerMode = a.datepickerMode || h.datepickerMode, a.uniqueId = "datepicker-" + a.$id + "-" + Math.floor(1e4 * Math.random()), this.activeDate = angular.isDefined(b.initDate) ? a.$parent.$eval(b.initDate) : new Date, a.isActive = function(b) {
            return 0 === i.compare(b.date, i.activeDate) ? (a.activeDateId = b.uid, !0) : !1
        }, this.init = function(a) {
            j = a, j.$render = function() {
                i.render()
            }
        }, this.render = function() {
            if (j.$modelValue) {
                var a = new Date(j.$modelValue),
                    b = !isNaN(a);
                b ? this.activeDate = a : f.error('Datepicker directive: "ng-model" value must be a Date object, a number of milliseconds since 01.01.1970 or a string representing an RFC2822 or ISO 8601 date.'), j.$setValidity("date", b)
            }
            this.refreshView()
        }, this.refreshView = function() {
            if (this.element) {
                this._refreshView();
                var a = j.$modelValue ? new Date(j.$modelValue) : null;
                j.$setValidity("date-disabled", !a || this.element && !this.isDisabled(a))
            }
        }, this.createDateObject = function(a, b) {
            var c = j.$modelValue ? new Date(j.$modelValue) : null;
            return {
                date: a,
                label: g(a, b),
                selected: c && 0 === this.compare(a, c),
                disabled: this.isDisabled(a),
                current: 0 === this.compare(a, new Date)
            }
        }, this.isDisabled = function(c) {
            return this.minDate && this.compare(c, this.minDate) < 0 || this.maxDate && this.compare(c, this.maxDate) > 0 || b.dateDisabled && a.dateDisabled({
                date: c,
                mode: a.datepickerMode
            })
        }, this.split = function(a, b) {
            for (var c = []; a.length > 0;) c.push(a.splice(0, b));
            return c
        }, a.select = function(b) {
            if (a.datepickerMode === i.minMode) {
                var c = j.$modelValue ? new Date(j.$modelValue) : new Date(0, 0, 0, 0, 0, 0, 0);
                c.setFullYear(b.getFullYear(), b.getMonth(), b.getDate()), j.$setViewValue(c), j.$render()
            } else i.activeDate = b, a.datepickerMode = i.modes[i.modes.indexOf(a.datepickerMode) - 1]
        }, a.move = function(a) {
            var b = i.activeDate.getFullYear() + a * (i.step.years || 0),
                c = i.activeDate.getMonth() + a * (i.step.months || 0);
            i.activeDate.setFullYear(b, c, 1), i.refreshView()
        }, a.toggleMode = function(b) {
            b = b || 1, a.datepickerMode === i.maxMode && 1 === b || a.datepickerMode === i.minMode && -1 === b || (a.datepickerMode = i.modes[i.modes.indexOf(a.datepickerMode) + b])
        }, a.keys = {
            13: "enter",
            32: "space",
            33: "pageup",
            34: "pagedown",
            35: "end",
            36: "home",
            37: "left",
            38: "up",
            39: "right",
            40: "down"
        };
        var k = function() {
            e(function() {
                i.element[0].focus()
            }, 0, !1)
        };
        a.$on("datepicker.focus", k), a.keydown = function(b) {
            var c = a.keys[b.which];
            if (c && !b.shiftKey && !b.altKey)
                if (b.preventDefault(), b.stopPropagation(), "enter" === c || "space" === c) {
                    if (i.isDisabled(i.activeDate)) return;
                    a.select(i.activeDate), k()
                } else !b.ctrlKey || "up" !== c && "down" !== c ? (i.handleKeyDown(c, b), i.refreshView()) : (a.toggleMode("up" === c ? 1 : -1), k())
        }
    }]).directive("datepicker", function() {
        return {
            restrict: "EA",
            replace: !0,
            templateUrl: "template/datepicker/datepicker.html",
            scope: {
                datepickerMode: "=?",
                dateDisabled: "&"
            },
            require: ["datepicker", "?^ngModel"],
            controller: "DatepickerController",
            link: function(a, b, c, d) {
                var e = d[0],
                    f = d[1];
                f && e.init(f)
            }
        }
    }).directive("daypicker", ["dateFilter", function(a) {
        return {
            restrict: "EA",
            replace: !0,
            templateUrl: "template/datepicker/day.html",
            require: "^datepicker",
            link: function(b, c, d, e) {
                function f(a, b) {
                    return 1 !== b || a % 4 !== 0 || a % 100 === 0 && a % 400 !== 0 ? i[b] : 29
                }

                function g(a, b) {
                    var c = new Array(b),
                        d = new Date(a),
                        e = 0;
                    for (d.setHours(12); b > e;) c[e++] = new Date(d), d.setDate(d.getDate() + 1);
                    return c
                }

                function h(a) {
                    var b = new Date(a);
                    b.setDate(b.getDate() + 4 - (b.getDay() || 7));
                    var c = b.getTime();
                    return b.setMonth(0), b.setDate(1), Math.floor(Math.round((c - b) / 864e5) / 7) + 1
                }
                b.showWeeks = e.showWeeks, e.step = {
                    months: 1
                }, e.element = c;
                var i = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
                e._refreshView = function() {
                    var c = e.activeDate.getFullYear(),
                        d = e.activeDate.getMonth(),
                        f = new Date(c, d, 1),
                        i = e.startingDay - f.getDay(),
                        j = i > 0 ? 7 - i : -i,
                        k = new Date(f);
                    j > 0 && k.setDate(-j + 1);
                    for (var l = g(k, 42), m = 0; 42 > m; m++) l[m] = angular.extend(e.createDateObject(l[m], e.formatDay), {
                        secondary: l[m].getMonth() !== d,
                        uid: b.uniqueId + "-" + m
                    });
                    b.labels = new Array(7);
                    for (var n = 0; 7 > n; n++) b.labels[n] = {
                        abbr: a(l[n].date, e.formatDayHeader),
                        full: a(l[n].date, "EEEE")
                    };
                    if (b.title = a(e.activeDate, e.formatDayTitle), b.rows = e.split(l, 7), b.showWeeks) {
                        b.weekNumbers = [];
                        for (var o = h(b.rows[0][0].date), p = b.rows.length; b.weekNumbers.push(o++) < p;);
                    }
                }, e.compare = function(a, b) {
                    return new Date(a.getFullYear(), a.getMonth(), a.getDate()) - new Date(b.getFullYear(), b.getMonth(), b.getDate())
                }, e.handleKeyDown = function(a) {
                    var b = e.activeDate.getDate();
                    if ("left" === a) b -= 1;
                    else if ("up" === a) b -= 7;
                    else if ("right" === a) b += 1;
                    else if ("down" === a) b += 7;
                    else if ("pageup" === a || "pagedown" === a) {
                        var c = e.activeDate.getMonth() + ("pageup" === a ? -1 : 1);
                        e.activeDate.setMonth(c, 1), b = Math.min(f(e.activeDate.getFullYear(), e.activeDate.getMonth()), b)
                    } else "home" === a ? b = 1 : "end" === a && (b = f(e.activeDate.getFullYear(), e.activeDate.getMonth()));
                    e.activeDate.setDate(b)
                }, e.refreshView()
            }
        }
    }]).directive("monthpicker", ["dateFilter", function(a) {
        return {
            restrict: "EA",
            replace: !0,
            templateUrl: "template/datepicker/month.html",
            require: "^datepicker",
            link: function(b, c, d, e) {
                e.step = {
                    years: 1
                }, e.element = c, e._refreshView = function() {
                    for (var c = new Array(12), d = e.activeDate.getFullYear(), f = 0; 12 > f; f++) c[f] = angular.extend(e.createDateObject(new Date(d, f, 1), e.formatMonth), {
                        uid: b.uniqueId + "-" + f
                    });
                    b.title = a(e.activeDate, e.formatMonthTitle), b.rows = e.split(c, 3)
                }, e.compare = function(a, b) {
                    return new Date(a.getFullYear(), a.getMonth()) - new Date(b.getFullYear(), b.getMonth())
                }, e.handleKeyDown = function(a) {
                    var b = e.activeDate.getMonth();
                    if ("left" === a) b -= 1;
                    else if ("up" === a) b -= 3;
                    else if ("right" === a) b += 1;
                    else if ("down" === a) b += 3;
                    else if ("pageup" === a || "pagedown" === a) {
                        var c = e.activeDate.getFullYear() + ("pageup" === a ? -1 : 1);
                        e.activeDate.setFullYear(c)
                    } else "home" === a ? b = 0 : "end" === a && (b = 11);
                    e.activeDate.setMonth(b)
                }, e.refreshView()
            }
        }
    }]).directive("yearpicker", ["dateFilter", function() {
        return {
            restrict: "EA",
            replace: !0,
            templateUrl: "template/datepicker/year.html",
            require: "^datepicker",
            link: function(a, b, c, d) {
                function e(a) {
                    return parseInt((a - 1) / f, 10) * f + 1
                }
                var f = d.yearRange;
                d.step = {
                    years: f
                }, d.element = b, d._refreshView = function() {
                    for (var b = new Array(f), c = 0, g = e(d.activeDate.getFullYear()); f > c; c++) b[c] = angular.extend(d.createDateObject(new Date(g + c, 0, 1), d.formatYear), {
                        uid: a.uniqueId + "-" + c
                    });
                    a.title = [b[0].label, b[f - 1].label].join(" - "), a.rows = d.split(b, 5)
                }, d.compare = function(a, b) {
                    return a.getFullYear() - b.getFullYear()
                }, d.handleKeyDown = function(a) {
                    var b = d.activeDate.getFullYear();
                    "left" === a ? b -= 1 : "up" === a ? b -= 5 : "right" === a ? b += 1 : "down" === a ? b += 5 : "pageup" === a || "pagedown" === a ? b += ("pageup" === a ? -1 : 1) * d.step.years : "home" === a ? b = e(d.activeDate.getFullYear()) : "end" === a && (b = e(d.activeDate.getFullYear()) + f - 1), d.activeDate.setFullYear(b)
                }, d.refreshView()
            }
        }
    }]).constant("datepickerPopupConfig", {
        datepickerPopup: "yyyy-MM-dd",
        currentText: "Today",
        clearText: "Clear",
        closeText: "Done",
        closeOnDateSelection: !0,
        appendToBody: !1,
        showButtonBar: !0
    }).directive("datepickerPopup", ["$compile", "$parse", "$document", "$position", "dateFilter", "dateParser", "datepickerPopupConfig", function(a, b, c, d, e, f, g) {
        return {
            restrict: "EA",
            require: "ngModel",
            scope: {
                isOpen: "=?",
                currentText: "@",
                clearText: "@",
                closeText: "@",
                dateDisabled: "&"
            },
            link: function(h, i, j, k) {
                function l(a) {
                    return a.replace(/([A-Z])/g, function(a) {
                        return "-" + a.toLowerCase()
                    })
                }

                function m(a) {
                    if (a) {
                        if (angular.isDate(a) && !isNaN(a)) return k.$setValidity("date", !0), a;
                        if (angular.isString(a)) {
                            var b = f.parse(a, n) || new Date(a);
                            return isNaN(b) ? void k.$setValidity("date", !1) : (k.$setValidity("date", !0), b)
                        }
                        return void k.$setValidity("date", !1)
                    }
                    return k.$setValidity("date", !0), null
                }
                var n, o = angular.isDefined(j.closeOnDateSelection) ? h.$parent.$eval(j.closeOnDateSelection) : g.closeOnDateSelection,
                    p = angular.isDefined(j.datepickerAppendToBody) ? h.$parent.$eval(j.datepickerAppendToBody) : g.appendToBody;
                h.showButtonBar = angular.isDefined(j.showButtonBar) ? h.$parent.$eval(j.showButtonBar) : g.showButtonBar, h.getText = function(a) {
                    return h[a + "Text"] || g[a + "Text"]
                }, j.$observe("datepickerPopup", function(a) {
                    n = a || g.datepickerPopup, k.$render()
                });
                var q = angular.element("<div datepicker-popup-wrap><div datepicker></div></div>");
                q.attr({
                    "ng-model": "date",
                    "ng-change": "dateSelection()"
                });
                var r = angular.element(q.children()[0]);
                j.datepickerOptions && angular.forEach(h.$parent.$eval(j.datepickerOptions), function(a, b) {
                    r.attr(l(b), a)
                }), h.watchData = {}, angular.forEach(["minDate", "maxDate", "datepickerMode"], function(a) {
                    if (j[a]) {
                        var c = b(j[a]);
                        if (h.$parent.$watch(c, function(b) {
                                h.watchData[a] = b
                            }), r.attr(l(a), "watchData." + a), "datepickerMode" === a) {
                            var d = c.assign;
                            h.$watch("watchData." + a, function(a, b) {
                                a !== b && d(h.$parent, a);
                            })
                        }
                    }
                }), j.dateDisabled && r.attr("date-disabled", "dateDisabled({ date: date, mode: mode })"), k.$parsers.unshift(m), h.dateSelection = function(a) {
                    angular.isDefined(a) && (h.date = a), k.$setViewValue(h.date), k.$render(), o && (h.isOpen = !1, i[0].focus())
                }, i.bind("input change keyup", function() {
                    h.$apply(function() {
                        h.date = k.$modelValue
                    })
                }), k.$render = function() {
                    var a = k.$viewValue ? e(k.$viewValue, n) : "";
                    i.val(a), h.date = m(k.$modelValue)
                };
                var s = function(a) {
                        h.isOpen && a.target !== i[0] && h.$apply(function() {
                            h.isOpen = !1
                        })
                    },
                    t = function(a) {
                        h.keydown(a)
                    };
                i.bind("keydown", t), h.keydown = function(a) {
                    27 === a.which ? (a.preventDefault(), a.stopPropagation(), h.close()) : 40 !== a.which || h.isOpen || (h.isOpen = !0)
                }, h.$watch("isOpen", function(a) {
                    a ? (h.$broadcast("datepicker.focus"), h.position = p ? d.offset(i) : d.position(i), h.position.top = h.position.top + i.prop("offsetHeight"), c.bind("click", s)) : c.unbind("click", s)
                }), h.select = function(a) {
                    if ("today" === a) {
                        var b = new Date;
                        angular.isDate(k.$modelValue) ? (a = new Date(k.$modelValue), a.setFullYear(b.getFullYear(), b.getMonth(), b.getDate())) : a = new Date(b.setHours(0, 0, 0, 0))
                    }
                    h.dateSelection(a)
                }, h.close = function() {
                    h.isOpen = !1, i[0].focus()
                };
                var u = a(q)(h);
                q.remove(), p ? c.find("body").append(u) : i.after(u), h.$on("$destroy", function() {
                    u.remove(), i.unbind("keydown", t), c.unbind("click", s)
                })
            }
        }
    }]).directive("datepickerPopupWrap", function() {
        return {
            restrict: "EA",
            replace: !0,
            transclude: !0,
            templateUrl: "template/datepicker/popup.html",
            link: function(a, b) {
                b.bind("click", function(a) {
                    a.preventDefault(), a.stopPropagation()
                })
            }
        }
    }), angular.module("ui.bootstrap.dropdown", []).constant("dropdownConfig", {
        openClass: "open"
    }).service("dropdownService", ["$document", function(a) {
        var b = null;
        this.open = function(e) {
            b || (a.bind("click", c), a.bind("keydown", d)), b && b !== e && (b.isOpen = !1), b = e
        }, this.close = function(e) {
            b === e && (b = null, a.unbind("click", c), a.unbind("keydown", d))
        };
        var c = function(a) {
                var c = b.getToggleElement();
                a && c && c[0].contains(a.target) || b.$apply(function() {
                    b.isOpen = !1
                })
            },
            d = function(a) {
                27 === a.which && (b.focusToggleElement(), c())
            }
    }]).controller("DropdownController", ["$scope", "$attrs", "$parse", "dropdownConfig", "dropdownService", "$animate", function(a, b, c, d, e, f) {
        var g, h = this,
            i = a.$new(),
            j = d.openClass,
            k = angular.noop,
            l = b.onToggle ? c(b.onToggle) : angular.noop;
        this.init = function(d) {
            h.$element = d, b.isOpen && (g = c(b.isOpen), k = g.assign, a.$watch(g, function(a) {
                i.isOpen = !!a
            }))
        }, this.toggle = function(a) {
            return i.isOpen = arguments.length ? !!a : !i.isOpen
        }, this.isOpen = function() {
            return i.isOpen
        }, i.getToggleElement = function() {
            return h.toggleElement
        }, i.focusToggleElement = function() {
            h.toggleElement && h.toggleElement[0].focus()
        }, i.$watch("isOpen", function(b, c) {
            f[b ? "addClass" : "removeClass"](h.$element, j), b ? (i.focusToggleElement(), e.open(i)) : e.close(i), k(a, b), angular.isDefined(b) && b !== c && l(a, {
                open: !!b
            })
        }), a.$on("$locationChangeSuccess", function() {
            i.isOpen = !1
        }), a.$on("$destroy", function() {
            i.$destroy()
        })
    }]).directive("dropdown", function() {
        return {
            restrict: "CA",
            controller: "DropdownController",
            link: function(a, b, c, d) {
                d.init(b)
            }
        }
    }).directive("dropdownToggle", function() {
        return {
            restrict: "CA",
            require: "?^dropdown",
            link: function(a, b, c, d) {
                if (d) {
                    d.toggleElement = b;
                    var e = function(e) {
                        e.preventDefault(), b.hasClass("disabled") || c.disabled || a.$apply(function() {
                            d.toggle()
                        })
                    };
                    b.bind("click", e), b.attr({
                        "aria-haspopup": !0,
                        "aria-expanded": !1
                    }), a.$watch(d.isOpen, function(a) {
                        b.attr("aria-expanded", !!a)
                    }), a.$on("$destroy", function() {
                        b.unbind("click", e)
                    })
                }
            }
        }
    }), angular.module("ui.bootstrap.modal", ["ui.bootstrap.transition"]).factory("$$stackedMap", function() {
        return {
            createNew: function() {
                var a = [];
                return {
                    add: function(b, c) {
                        a.push({
                            key: b,
                            value: c
                        })
                    },
                    get: function(b) {
                        for (var c = 0; c < a.length; c++)
                            if (b == a[c].key) return a[c]
                    },
                    keys: function() {
                        for (var b = [], c = 0; c < a.length; c++) b.push(a[c].key);
                        return b
                    },
                    top: function() {
                        return a[a.length - 1]
                    },
                    remove: function(b) {
                        for (var c = -1, d = 0; d < a.length; d++)
                            if (b == a[d].key) {
                                c = d;
                                break
                            }
                        return a.splice(c, 1)[0]
                    },
                    removeTop: function() {
                        return a.splice(a.length - 1, 1)[0]
                    },
                    length: function() {
                        return a.length
                    }
                }
            }
        }
    }).directive("modalBackdrop", ["$timeout", function(a) {
        return {
            restrict: "EA",
            replace: !0,
            templateUrl: "template/modal/backdrop.html",
            link: function(b, c, d) {
                b.backdropClass = d.backdropClass || "", b.animate = !1, a(function() {
                    b.animate = !0
                })
            }
        }
    }]).directive("modalWindow", ["$modalStack", "$timeout", function(a, b) {
        return {
            restrict: "EA",
            scope: {
                index: "@",
                animate: "="
            },
            replace: !0,
            transclude: !0,
            templateUrl: function(a, b) {
                return b.templateUrl || "template/modal/window.html"
            },
            link: function(c, d, e) {
                d.addClass(e.windowClass || ""), c.size = e.size, b(function() {
                    c.animate = !0, d[0].querySelectorAll("[autofocus]").length || d[0].focus()
                }), c.close = function(b) {
                    var c = a.getTop();
                    c && c.value.backdrop && "static" != c.value.backdrop && b.target === b.currentTarget && (b.preventDefault(), b.stopPropagation(), a.dismiss(c.key, "backdrop click"))
                }
            }
        }
    }]).directive("modalTransclude", function() {
        return {
            link: function(a, b, c, d, e) {
                e(a.$parent, function(a) {
                    b.empty(), b.append(a)
                })
            }
        }
    }).factory("$modalStack", ["$transition", "$timeout", "$document", "$compile", "$rootScope", "$$stackedMap", function(a, b, c, d, e, f) {
        function g() {
            for (var a = -1, b = n.keys(), c = 0; c < b.length; c++) n.get(b[c]).value.backdrop && (a = c);
            return a
        }

        function h(a) {
            var b = c.find("body").eq(0),
                d = n.get(a).value;
            n.remove(a), j(d.modalDomEl, d.modalScope, 300, function() {
                d.modalScope.$destroy(), b.toggleClass(m, n.length() > 0), i()
            })
        }

        function i() {
            if (k && -1 == g()) {
                var a = l;
                j(k, l, 150, function() {
                    a.$destroy(), a = null
                }), k = void 0, l = void 0
            }
        }

        function j(c, d, e, f) {
            function g() {
                g.done || (g.done = !0, c.remove(), f && f())
            }
            d.animate = !1;
            var h = a.transitionEndEventName;
            if (h) {
                var i = b(g, e);
                c.bind(h, function() {
                    b.cancel(i), g(), d.$apply()
                })
            } else b(g)
        }
        var k, l, m = "modal-open",
            n = f.createNew(),
            o = {};
        return e.$watch(g, function(a) {
            l && (l.index = a)
        }), c.bind("keydown", function(a) {
            var b;
            27 === a.which && (b = n.top(), b && b.value.keyboard && (a.preventDefault(), e.$apply(function() {
                o.dismiss(b.key, "escape key press")
            })))
        }), o.open = function(a, b) {
            n.add(a, {
                deferred: b.deferred,
                modalScope: b.scope,
                backdrop: b.backdrop,
                keyboard: b.keyboard
            });
            var f = c.find("body").eq(0),
                h = g();
            if (h >= 0 && !k) {
                l = e.$new(!0), l.index = h;
                var i = angular.element("<div modal-backdrop></div>");
                i.attr("backdrop-class", b.backdropClass), k = d(i)(l), f.append(k)
            }
            var j = angular.element("<div modal-window></div>");
            j.attr({
                "template-url": b.windowTemplateUrl,
                "window-class": b.windowClass,
                size: b.size,
                index: n.length() - 1,
                animate: "animate"
            }).html(b.content);
            var o = d(j)(b.scope);
            n.top().value.modalDomEl = o, f.append(o), f.addClass(m)
        }, o.close = function(a, b) {
            var c = n.get(a);
            c && (c.value.deferred.resolve(b), h(a))
        }, o.dismiss = function(a, b) {
            var c = n.get(a);
            c && (c.value.deferred.reject(b), h(a))
        }, o.dismissAll = function(a) {
            for (var b = this.getTop(); b;) this.dismiss(b.key, a), b = this.getTop()
        }, o.getTop = function() {
            return n.top()
        }, o
    }]).provider("$modal", function() {
        var a = {
            options: {
                backdrop: !0,
                keyboard: !0
            },
            $get: ["$injector", "$rootScope", "$q", "$http", "$templateCache", "$controller", "$modalStack", function(b, c, d, e, f, g, h) {
                function i(a) {
                    return a.template ? d.when(a.template) : e.get(angular.isFunction(a.templateUrl) ? a.templateUrl() : a.templateUrl, {
                        cache: f
                    }).then(function(a) {
                        return a.data
                    })
                }

                function j(a) {
                    var c = [];
                    return angular.forEach(a, function(a) {
                        (angular.isFunction(a) || angular.isArray(a)) && c.push(d.when(b.invoke(a)))
                    }), c
                }
                var k = {};
                return k.open = function(b) {
                    var e = d.defer(),
                        f = d.defer(),
                        k = {
                            result: e.promise,
                            opened: f.promise,
                            close: function(a) {
                                h.close(k, a)
                            },
                            dismiss: function(a) {
                                h.dismiss(k, a)
                            }
                        };
                    if (b = angular.extend({}, a.options, b), b.resolve = b.resolve || {}, !b.template && !b.templateUrl) throw new Error("One of template or templateUrl options is required.");
                    var l = d.all([i(b)].concat(j(b.resolve)));
                    return l.then(function(a) {
                        var d = (b.scope || c).$new();
                        d.$close = k.close, d.$dismiss = k.dismiss;
                        var f, i = {},
                            j = 1;
                        b.controller && (i.$scope = d, i.$modalInstance = k, angular.forEach(b.resolve, function(b, c) {
                            i[c] = a[j++]
                        }), f = g(b.controller, i), b.controllerAs && (d[b.controllerAs] = f)), h.open(k, {
                            scope: d,
                            deferred: e,
                            content: a[0],
                            backdrop: b.backdrop,
                            keyboard: b.keyboard,
                            backdropClass: b.backdropClass,
                            windowClass: b.windowClass,
                            windowTemplateUrl: b.windowTemplateUrl,
                            size: b.size
                        })
                    }, function(a) {
                        e.reject(a)
                    }), l.then(function() {
                        f.resolve(!0)
                    }, function() {
                        f.reject(!1)
                    }), k
                }, k
            }]
        };
        return a
    }), angular.module("ui.bootstrap.pagination", []).controller("PaginationController", ["$scope", "$attrs", "$parse", function(a, b, c) {
        var d = this,
            e = {
                $setViewValue: angular.noop
            },
            f = b.numPages ? c(b.numPages).assign : angular.noop;
        this.init = function(f, g) {
            e = f, this.config = g, e.$render = function() {
                d.render()
            }, b.itemsPerPage ? a.$parent.$watch(c(b.itemsPerPage), function(b) {
                d.itemsPerPage = parseInt(b, 10), a.totalPages = d.calculateTotalPages()
            }) : this.itemsPerPage = g.itemsPerPage
        }, this.calculateTotalPages = function() {
            var b = this.itemsPerPage < 1 ? 1 : Math.ceil(a.totalItems / this.itemsPerPage);
            return Math.max(b || 0, 1)
        }, this.render = function() {
            a.page = parseInt(e.$viewValue, 10) || 1
        }, a.selectPage = function(b) {
            a.page !== b && b > 0 && b <= a.totalPages && (e.$setViewValue(b), e.$render())
        }, a.getText = function(b) {
            return a[b + "Text"] || d.config[b + "Text"]
        }, a.noPrevious = function() {
            return 1 === a.page
        }, a.noNext = function() {
            return a.page === a.totalPages
        }, a.$watch("totalItems", function() {
            a.totalPages = d.calculateTotalPages()
        }), a.$watch("totalPages", function(b) {
            f(a.$parent, b), a.page > b ? a.selectPage(b) : e.$render()
        })
    }]).constant("paginationConfig", {
        itemsPerPage: 10,
        boundaryLinks: !1,
        directionLinks: !0,
        firstText: "First",
        previousText: "Previous",
        nextText: "Next",
        lastText: "Last",
        rotate: !0
    }).directive("pagination", ["$parse", "paginationConfig", function(a, b) {
        return {
            restrict: "EA",
            scope: {
                totalItems: "=",
                firstText: "@",
                previousText: "@",
                nextText: "@",
                lastText: "@"
            },
            require: ["pagination", "?ngModel"],
            controller: "PaginationController",
            templateUrl: "template/pagination/pagination.html",
            replace: !0,
            link: function(c, d, e, f) {
                function g(a, b, c) {
                    return {
                        number: a,
                        text: b,
                        active: c
                    }
                }

                function h(a, b) {
                    var c = [],
                        d = 1,
                        e = b,
                        f = angular.isDefined(k) && b > k;
                    f && (l ? (d = Math.max(a - Math.floor(k / 2), 1), e = d + k - 1, e > b && (e = b, d = e - k + 1)) : (d = (Math.ceil(a / k) - 1) * k + 1, e = Math.min(d + k - 1, b)));
                    for (var h = d; e >= h; h++) {
                        var i = g(h, h, h === a);
                        c.push(i)
                    }
                    if (f && !l) {
                        if (d > 1) {
                            var j = g(d - 1, "...", !1);
                            c.unshift(j)
                        }
                        if (b > e) {
                            var m = g(e + 1, "...", !1);
                            c.push(m)
                        }
                    }
                    return c
                }
                var i = f[0],
                    j = f[1];
                if (j) {
                    var k = angular.isDefined(e.maxSize) ? c.$parent.$eval(e.maxSize) : b.maxSize,
                        l = angular.isDefined(e.rotate) ? c.$parent.$eval(e.rotate) : b.rotate;
                    c.boundaryLinks = angular.isDefined(e.boundaryLinks) ? c.$parent.$eval(e.boundaryLinks) : b.boundaryLinks, c.directionLinks = angular.isDefined(e.directionLinks) ? c.$parent.$eval(e.directionLinks) : b.directionLinks, i.init(j, b), e.maxSize && c.$parent.$watch(a(e.maxSize), function(a) {
                        k = parseInt(a, 10), i.render()
                    });
                    var m = i.render;
                    i.render = function() {
                        m(), c.page > 0 && c.page <= c.totalPages && (c.pages = h(c.page, c.totalPages))
                    }
                }
            }
        }
    }]).constant("pagerConfig", {
        itemsPerPage: 10,
        previousText: "« Previous",
        nextText: "Next »",
        align: !0
    }).directive("pager", ["pagerConfig", function(a) {
        return {
            restrict: "EA",
            scope: {
                totalItems: "=",
                previousText: "@",
                nextText: "@"
            },
            require: ["pager", "?ngModel"],
            controller: "PaginationController",
            templateUrl: "template/pagination/pager.html",
            replace: !0,
            link: function(b, c, d, e) {
                var f = e[0],
                    g = e[1];
                g && (b.align = angular.isDefined(d.align) ? b.$parent.$eval(d.align) : a.align, f.init(g, a))
            }
        }
    }]), angular.module("ui.bootstrap.tooltip", ["ui.bootstrap.position", "ui.bootstrap.bindHtml"]).provider("$tooltip", function() {
        function a(a) {
            var b = /[A-Z]/g,
                c = "-";
            return a.replace(b, function(a, b) {
                return (b ? c : "") + a.toLowerCase()
            })
        }
        var b = {
                placement: "top",
                animation: !0,
                popupDelay: 0
            },
            c = {
                mouseenter: "mouseleave",
                click: "click",
                focus: "blur"
            },
            d = {};
        this.options = function(a) {
            angular.extend(d, a)
        }, this.setTriggers = function(a) {
            angular.extend(c, a)
        }, this.$get = ["$window", "$compile", "$timeout", "$parse", "$document", "$position", "$interpolate", function(e, f, g, h, i, j, k) {
            return function(e, l, m) {
                function n(a) {
                    var b = a || o.trigger || m,
                        d = c[b] || b;
                    return {
                        show: b,
                        hide: d
                    }
                }
                var o = angular.extend({}, b, d),
                    p = a(e),
                    q = k.startSymbol(),
                    r = k.endSymbol(),
                    s = "<div " + p + '-popup title="' + q + "tt_title" + r + '" content="' + q + "tt_content" + r + '" placement="' + q + "tt_placement" + r + '" animation="tt_animation" is-open="tt_isOpen"></div>';
                return {
                    restrict: "EA",
                    scope: !0,
                    compile: function() {
                        var a = f(s);
                        return function(b, c, d) {
                            function f() {
                                b.tt_isOpen ? m() : k()
                            }

                            function k() {
                                (!y || b.$eval(d[l + "Enable"])) && (b.tt_popupDelay ? v || (v = g(p, b.tt_popupDelay, !1), v.then(function(a) {
                                    a()
                                })) : p()())
                            }

                            function m() {
                                b.$apply(function() {
                                    q()
                                })
                            }

                            function p() {
                                return v = null, u && (g.cancel(u), u = null), b.tt_content ? (r(), t.css({
                                    top: 0,
                                    left: 0,
                                    display: "block"
                                }), w ? i.find("body").append(t) : c.after(t), z(), b.tt_isOpen = !0, b.$digest(), z) : angular.noop
                            }

                            function q() {
                                b.tt_isOpen = !1, g.cancel(v), v = null, b.tt_animation ? u || (u = g(s, 500)) : s()
                            }

                            function r() {
                                t && s(), t = a(b, function() {}), b.$digest()
                            }

                            function s() {
                                u = null, t && (t.remove(), t = null)
                            }
                            var t, u, v, w = angular.isDefined(o.appendToBody) ? o.appendToBody : !1,
                                x = n(void 0),
                                y = angular.isDefined(d[l + "Enable"]),
                                z = function() {
                                    var a = j.positionElements(c, t, b.tt_placement, w);
                                    a.top += "px", a.left += "px", t.css(a)
                                };
                            b.tt_isOpen = !1, d.$observe(e, function(a) {
                                b.tt_content = a, !a && b.tt_isOpen && q()
                            }), d.$observe(l + "Title", function(a) {
                                b.tt_title = a
                            }), d.$observe(l + "Placement", function(a) {
                                b.tt_placement = angular.isDefined(a) ? a : o.placement
                            }), d.$observe(l + "PopupDelay", function(a) {
                                var c = parseInt(a, 10);
                                b.tt_popupDelay = isNaN(c) ? o.popupDelay : c
                            });
                            var A = function() {
                                c.unbind(x.show, k), c.unbind(x.hide, m)
                            };
                            d.$observe(l + "Trigger", function(a) {
                                A(), x = n(a), x.show === x.hide ? c.bind(x.show, f) : (c.bind(x.show, k), c.bind(x.hide, m))
                            });
                            var B = b.$eval(d[l + "Animation"]);
                            b.tt_animation = angular.isDefined(B) ? !!B : o.animation, d.$observe(l + "AppendToBody", function(a) {
                                w = angular.isDefined(a) ? h(a)(b) : w
                            }), w && b.$on("$locationChangeSuccess", function() {
                                b.tt_isOpen && q()
                            }), b.$on("$destroy", function() {
                                g.cancel(u), g.cancel(v), A(), s()
                            })
                        }
                    }
                }
            }
        }]
    }).directive("tooltipPopup", function() {
        return {
            restrict: "EA",
            replace: !0,
            scope: {
                content: "@",
                placement: "@",
                animation: "&",
                isOpen: "&"
            },
            templateUrl: "template/tooltip/tooltip-popup.html"
        }
    }).directive("tooltip", ["$tooltip", function(a) {
        return a("tooltip", "tooltip", "mouseenter")
    }]).directive("tooltipHtmlUnsafePopup", function() {
        return {
            restrict: "EA",
            replace: !0,
            scope: {
                content: "@",
                placement: "@",
                animation: "&",
                isOpen: "&"
            },
            templateUrl: "template/tooltip/tooltip-html-unsafe-popup.html"
        }
    }).directive("tooltipHtmlUnsafe", ["$tooltip", function(a) {
        return a("tooltipHtmlUnsafe", "tooltip", "mouseenter")
    }]), angular.module("ui.bootstrap.popover", ["ui.bootstrap.tooltip"]).directive("popoverPopup", function() {
        return {
            restrict: "EA",
            replace: !0,
            scope: {
                title: "@",
                content: "@",
                placement: "@",
                animation: "&",
                isOpen: "&"
            },
            templateUrl: "template/popover/popover.html"
        }
    }).directive("popover", ["$tooltip", function(a) {
        return a("popover", "popover", "click")
    }]), angular.module("ui.bootstrap.progressbar", []).constant("progressConfig", {
        animate: !0,
        max: 100
    }).controller("ProgressController", ["$scope", "$attrs", "progressConfig", function(a, b, c) {
        var d = this,
            e = angular.isDefined(b.animate) ? a.$parent.$eval(b.animate) : c.animate;
        this.bars = [], a.max = angular.isDefined(b.max) ? a.$parent.$eval(b.max) : c.max, this.addBar = function(b, c) {
            e || c.css({
                transition: "none"
            }), this.bars.push(b), b.$watch("value", function(c) {
                b.percent = +(100 * c / a.max).toFixed(2)
            }), b.$on("$destroy", function() {
                c = null, d.removeBar(b)
            })
        }, this.removeBar = function(a) {
            this.bars.splice(this.bars.indexOf(a), 1)
        }
    }]).directive("progress", function() {
        return {
            restrict: "EA",
            replace: !0,
            transclude: !0,
            controller: "ProgressController",
            require: "progress",
            scope: {},
            templateUrl: "template/progressbar/progress.html"
        }
    }).directive("bar", function() {
        return {
            restrict: "EA",
            replace: !0,
            transclude: !0,
            require: "^progress",
            scope: {
                value: "=",
                type: "@"
            },
            templateUrl: "template/progressbar/bar.html",
            link: function(a, b, c, d) {
                d.addBar(a, b)
            }
        }
    }).directive("progressbar", function() {
        return {
            restrict: "EA",
            replace: !0,
            transclude: !0,
            controller: "ProgressController",
            scope: {
                value: "=",
                type: "@"
            },
            templateUrl: "template/progressbar/progressbar.html",
            link: function(a, b, c, d) {
                d.addBar(a, angular.element(b.children()[0]))
            }
        }
    }), angular.module("ui.bootstrap.rating", []).constant("ratingConfig", {
        max: 5,
        stateOn: null,
        stateOff: null
    }).controller("RatingController", ["$scope", "$attrs", "ratingConfig", function(a, b, c) {
        var d = {
            $setViewValue: angular.noop
        };
        this.init = function(e) {
            d = e, d.$render = this.render, this.stateOn = angular.isDefined(b.stateOn) ? a.$parent.$eval(b.stateOn) : c.stateOn, this.stateOff = angular.isDefined(b.stateOff) ? a.$parent.$eval(b.stateOff) : c.stateOff;
            var f = angular.isDefined(b.ratingStates) ? a.$parent.$eval(b.ratingStates) : new Array(angular.isDefined(b.max) ? a.$parent.$eval(b.max) : c.max);
            a.range = this.buildTemplateObjects(f)
        }, this.buildTemplateObjects = function(a) {
            for (var b = 0, c = a.length; c > b; b++) a[b] = angular.extend({
                index: b
            }, {
                stateOn: this.stateOn,
                stateOff: this.stateOff
            }, a[b]);
            return a
        }, a.rate = function(b) {
            !a.readonly && b >= 0 && b <= a.range.length && (d.$setViewValue(b), d.$render())
        }, a.enter = function(b) {
            a.readonly || (a.value = b), a.onHover({
                value: b
            })
        }, a.reset = function() {
            a.value = d.$viewValue, a.onLeave()
        }, a.onKeydown = function(b) {
            /(37|38|39|40)/.test(b.which) && (b.preventDefault(), b.stopPropagation(), a.rate(a.value + (38 === b.which || 39 === b.which ? 1 : -1)))
        }, this.render = function() {
            a.value = d.$viewValue
        }
    }]).directive("rating", function() {
        return {
            restrict: "EA",
            require: ["rating", "ngModel"],
            scope: {
                readonly: "=?",
                onHover: "&",
                onLeave: "&"
            },
            controller: "RatingController",
            templateUrl: "template/rating/rating.html",
            replace: !0,
            link: function(a, b, c, d) {
                var e = d[0],
                    f = d[1];
                f && e.init(f)
            }
        }
    }), angular.module("ui.bootstrap.tabs", []).controller("TabsetController", ["$scope", function(a) {
        var b = this,
            c = b.tabs = a.tabs = [];
        b.select = function(a) {
            angular.forEach(c, function(b) {
                b.active && b !== a && (b.active = !1, b.onDeselect())
            }), a.active = !0, a.onSelect()
        }, b.addTab = function(a) {
            c.push(a), 1 === c.length ? a.active = !0 : a.active && b.select(a)
        }, b.removeTab = function(a) {
            var d = c.indexOf(a);
            if (a.active && c.length > 1) {
                var e = d == c.length - 1 ? d - 1 : d + 1;
                b.select(c[e])
            }
            c.splice(d, 1)
        }
    }]).directive("tabset", function() {
        return {
            restrict: "EA",
            transclude: !0,
            replace: !0,
            scope: {
                type: "@"
            },
            controller: "TabsetController",
            templateUrl: "template/tabs/tabset.html",
            link: function(a, b, c) {
                a.vertical = angular.isDefined(c.vertical) ? a.$parent.$eval(c.vertical) : !1, a.justified = angular.isDefined(c.justified) ? a.$parent.$eval(c.justified) : !1
            }
        }
    }).directive("tab", ["$parse", function(a) {
        return {
            require: "^tabset",
            restrict: "EA",
            replace: !0,
            templateUrl: "template/tabs/tab.html",
            transclude: !0,
            scope: {
                active: "=?",
                heading: "@",
                onSelect: "&select",
                onDeselect: "&deselect"
            },
            controller: function() {},
            compile: function(b, c, d) {
                return function(b, c, e, f) {
                    b.$watch("active", function(a) {
                        a && f.select(b)
                    }), b.disabled = !1, e.disabled && b.$parent.$watch(a(e.disabled), function(a) {
                        b.disabled = !!a
                    }), b.select = function() {
                        b.disabled || (b.active = !0)
                    }, f.addTab(b), b.$on("$destroy", function() {
                        f.removeTab(b)
                    }), b.$transcludeFn = d
                }
            }
        }
    }]).directive("tabHeadingTransclude", [function() {
        return {
            restrict: "A",
            require: "^tab",
            link: function(a, b) {
                a.$watch("headingElement", function(a) {
                    a && (b.html(""), b.append(a))
                })
            }
        }
    }]).directive("tabContentTransclude", function() {
        function a(a) {
            return a.tagName && (a.hasAttribute("tab-heading") || a.hasAttribute("data-tab-heading") || "tab-heading" === a.tagName.toLowerCase() || "data-tab-heading" === a.tagName.toLowerCase())
        }
        return {
            restrict: "A",
            require: "^tabset",
            link: function(b, c, d) {
                var e = b.$eval(d.tabContentTransclude);
                e.$transcludeFn(e.$parent, function(b) {
                    angular.forEach(b, function(b) {
                        a(b) ? e.headingElement = b : c.append(b)
                    })
                })
            }
        }
    }), angular.module("ui.bootstrap.timepicker", []).constant("timepickerConfig", {
        hourStep: 1,
        minuteStep: 1,
        showMeridian: !0,
        meridians: null,
        readonlyInput: !1,
        mousewheel: !0
    }).controller("TimepickerController", ["$scope", "$attrs", "$parse", "$log", "$locale", "timepickerConfig", function(a, b, c, d, e, f) {
        function g() {
            var b = parseInt(a.hours, 10),
                c = a.showMeridian ? b > 0 && 13 > b : b >= 0 && 24 > b;
            return c ? (a.showMeridian && (12 === b && (b = 0), a.meridian === p[1] && (b += 12)), b) : void 0
        }

        function h() {
            var b = parseInt(a.minutes, 10);
            return b >= 0 && 60 > b ? b : void 0
        }

        function i(a) {
            return angular.isDefined(a) && a.toString().length < 2 ? "0" + a : a
        }

        function j(a) {
            k(), o.$setViewValue(new Date(n)), l(a)
        }

        function k() {
            o.$setValidity("time", !0), a.invalidHours = !1, a.invalidMinutes = !1
        }

        function l(b) {
            var c = n.getHours(),
                d = n.getMinutes();
            a.showMeridian && (c = 0 === c || 12 === c ? 12 : c % 12), a.hours = "h" === b ? c : i(c), a.minutes = "m" === b ? d : i(d), a.meridian = n.getHours() < 12 ? p[0] : p[1]
        }

        function m(a) {
            var b = new Date(n.getTime() + 6e4 * a);
            n.setHours(b.getHours(), b.getMinutes()), j()
        }
        var n = new Date,
            o = {
                $setViewValue: angular.noop
            },
            p = angular.isDefined(b.meridians) ? a.$parent.$eval(b.meridians) : f.meridians || e.DATETIME_FORMATS.AMPMS;
        this.init = function(c, d) {
            o = c, o.$render = this.render;
            var e = d.eq(0),
                g = d.eq(1),
                h = angular.isDefined(b.mousewheel) ? a.$parent.$eval(b.mousewheel) : f.mousewheel;
            h && this.setupMousewheelEvents(e, g), a.readonlyInput = angular.isDefined(b.readonlyInput) ? a.$parent.$eval(b.readonlyInput) : f.readonlyInput, this.setupInputEvents(e, g)
        };
        var q = f.hourStep;
        b.hourStep && a.$parent.$watch(c(b.hourStep), function(a) {
            q = parseInt(a, 10)
        });
        var r = f.minuteStep;
        b.minuteStep && a.$parent.$watch(c(b.minuteStep), function(a) {
            r = parseInt(a, 10)
        }), a.showMeridian = f.showMeridian, b.showMeridian && a.$parent.$watch(c(b.showMeridian), function(b) {
            if (a.showMeridian = !!b, o.$error.time) {
                var c = g(),
                    d = h();
                angular.isDefined(c) && angular.isDefined(d) && (n.setHours(c), j())
            } else l()
        }), this.setupMousewheelEvents = function(b, c) {
            var d = function(a) {
                a.originalEvent && (a = a.originalEvent);
                var b = a.wheelDelta ? a.wheelDelta : -a.deltaY;
                return a.detail || b > 0
            };
            b.bind("mousewheel wheel", function(b) {
                a.$apply(d(b) ? a.incrementHours() : a.decrementHours()), b.preventDefault()
            }), c.bind("mousewheel wheel", function(b) {
                a.$apply(d(b) ? a.incrementMinutes() : a.decrementMinutes()), b.preventDefault()
            })
        }, this.setupInputEvents = function(b, c) {
            if (a.readonlyInput) return a.updateHours = angular.noop, void(a.updateMinutes = angular.noop);
            var d = function(b, c) {
                o.$setViewValue(null), o.$setValidity("time", !1), angular.isDefined(b) && (a.invalidHours = b), angular.isDefined(c) && (a.invalidMinutes = c)
            };
            a.updateHours = function() {
                var a = g();
                angular.isDefined(a) ? (n.setHours(a), j("h")) : d(!0)
            }, b.bind("blur", function() {
                !a.invalidHours && a.hours < 10 && a.$apply(function() {
                    a.hours = i(a.hours)
                })
            }), a.updateMinutes = function() {
                var a = h();
                angular.isDefined(a) ? (n.setMinutes(a), j("m")) : d(void 0, !0)
            }, c.bind("blur", function() {
                !a.invalidMinutes && a.minutes < 10 && a.$apply(function() {
                    a.minutes = i(a.minutes)
                })
            })
        }, this.render = function() {
            var a = o.$modelValue ? new Date(o.$modelValue) : null;
            isNaN(a) ? (o.$setValidity("time", !1), d.error('Timepicker directive: "ng-model" value must be a Date object, a number of milliseconds since 01.01.1970 or a string representing an RFC2822 or ISO 8601 date.')) : (a && (n = a), k(), l())
        }, a.incrementHours = function() {
            m(60 * q)
        }, a.decrementHours = function() {
            m(60 * -q)
        }, a.incrementMinutes = function() {
            m(r)
        }, a.decrementMinutes = function() {
            m(-r)
        }, a.toggleMeridian = function() {
            m(720 * (n.getHours() < 12 ? 1 : -1))
        }
    }]).directive("timepicker", function() {
        return {
            restrict: "EA",
            require: ["timepicker", "?^ngModel"],
            controller: "TimepickerController",
            replace: !0,
            scope: {},
            templateUrl: "template/timepicker/timepicker.html",
            link: function(a, b, c, d) {
                var e = d[0],
                    f = d[1];
                f && e.init(f, b.find("input"))
            }
        }
    }), angular.module("ui.bootstrap.typeahead", ["ui.bootstrap.position", "ui.bootstrap.bindHtml"]).factory("typeaheadParser", ["$parse", function(a) {
        var b = /^\s*([\s\S]+?)(?:\s+as\s+([\s\S]+?))?\s+for\s+(?:([\$\w][\$\w\d]*))\s+in\s+([\s\S]+?)$/;
        return {
            parse: function(c) {
                var d = c.match(b);
                if (!d) throw new Error('Expected typeahead specification in form of "_modelValue_ (as _label_)? for _item_ in _collection_" but got "' + c + '".');
                return {
                    itemName: d[3],
                    source: a(d[4]),
                    viewMapper: a(d[2] || d[1]),
                    modelMapper: a(d[1])
                }
            }
        }
    }]).directive("typeahead", ["$compile", "$parse", "$q", "$timeout", "$document", "$position", "typeaheadParser", function(a, b, c, d, e, f, g) {
        var h = [9, 13, 27, 38, 40];
        return {
            require: "ngModel",
            link: function(i, j, k, l) {
                var m, n = i.$eval(k.typeaheadMinLength) || 1,
                    o = i.$eval(k.typeaheadWaitMs) || 0,
                    p = i.$eval(k.typeaheadEditable) !== !1,
                    q = b(k.typeaheadLoading).assign || angular.noop,
                    r = b(k.typeaheadOnSelect),
                    s = k.typeaheadInputFormatter ? b(k.typeaheadInputFormatter) : void 0,
                    t = k.typeaheadAppendToBody ? i.$eval(k.typeaheadAppendToBody) : !1,
                    u = b(k.ngModel).assign,
                    v = g.parse(k.typeahead),
                    w = i.$new();
                i.$on("$destroy", function() {
                    w.$destroy()
                });
                var x = "typeahead-" + w.$id + "-" + Math.floor(1e4 * Math.random());
                j.attr({
                    "aria-autocomplete": "list",
                    "aria-expanded": !1,
                    "aria-owns": x
                });
                var y = angular.element("<div typeahead-popup></div>");
                y.attr({
                    id: x,
                    matches: "matches",
                    active: "activeIdx",
                    select: "select(activeIdx)",
                    query: "query",
                    position: "position"
                }), angular.isDefined(k.typeaheadTemplateUrl) && y.attr("template-url", k.typeaheadTemplateUrl);
                var z = function() {
                        w.matches = [], w.activeIdx = -1, j.attr("aria-expanded", !1)
                    },
                    A = function(a) {
                        return x + "-option-" + a
                    };
                w.$watch("activeIdx", function(a) {
                    0 > a ? j.removeAttr("aria-activedescendant") : j.attr("aria-activedescendant", A(a))
                });
                var B = function(a) {
                    var b = {
                        $viewValue: a
                    };
                    q(i, !0), c.when(v.source(i, b)).then(function(c) {
                        var d = a === l.$viewValue;
                        if (d && m)
                            if (c.length > 0) {
                                w.activeIdx = 0, w.matches.length = 0;
                                for (var e = 0; e < c.length; e++) b[v.itemName] = c[e], w.matches.push({
                                    id: A(e),
                                    label: v.viewMapper(w, b),
                                    model: c[e]
                                });
                                w.query = a, w.position = t ? f.offset(j) : f.position(j), w.position.top = w.position.top + j.prop("offsetHeight"), j.attr("aria-expanded", !0)
                            } else z();
                        d && q(i, !1)
                    }, function() {
                        z(), q(i, !1)
                    })
                };
                z(), w.query = void 0;
                var C, D = function(a) {
                        C = d(function() {
                            B(a)
                        }, o)
                    },
                    E = function() {
                        C && d.cancel(C)
                    };
                l.$parsers.unshift(function(a) {
                    return m = !0, a && a.length >= n ? o > 0 ? (E(), D(a)) : B(a) : (q(i, !1), E(), z()), p ? a : a ? void l.$setValidity("editable", !1) : (l.$setValidity("editable", !0), a)
                }), l.$formatters.push(function(a) {
                    var b, c, d = {};
                    return s ? (d.$model = a, s(i, d)) : (d[v.itemName] = a, b = v.viewMapper(i, d), d[v.itemName] = void 0, c = v.viewMapper(i, d), b !== c ? b : a)
                }), w.select = function(a) {
                    var b, c, e = {};
                    e[v.itemName] = c = w.matches[a].model, b = v.modelMapper(i, e), u(i, b), l.$setValidity("editable", !0), r(i, {
                        $item: c,
                        $model: b,
                        $label: v.viewMapper(i, e)
                    }), z(), d(function() {
                        j[0].focus()
                    }, 0, !1)
                }, j.bind("keydown", function(a) {
                    0 !== w.matches.length && -1 !== h.indexOf(a.which) && (a.preventDefault(), 40 === a.which ? (w.activeIdx = (w.activeIdx + 1) % w.matches.length, w.$digest()) : 38 === a.which ? (w.activeIdx = (w.activeIdx ? w.activeIdx : w.matches.length) - 1, w.$digest()) : 13 === a.which || 9 === a.which ? w.$apply(function() {
                        w.select(w.activeIdx)
                    }) : 27 === a.which && (a.stopPropagation(), z(), w.$digest()))
                }), j.bind("blur", function() {
                    m = !1
                });
                var F = function(a) {
                    j[0] !== a.target && (z(), w.$digest())
                };
                e.bind("click", F), i.$on("$destroy", function() {
                    e.unbind("click", F)
                });
                var G = a(y)(w);
                t ? e.find("body").append(G) : j.after(G)
            }
        }
    }]).directive("typeaheadPopup", function() {
        return {
            restrict: "EA",
            scope: {
                matches: "=",
                query: "=",
                active: "=",
                position: "=",
                select: "&"
            },
            replace: !0,
            templateUrl: "template/typeahead/typeahead-popup.html",
            link: function(a, b, c) {
                a.templateUrl = c.templateUrl, a.isOpen = function() {
                    return a.matches.length > 0
                }, a.isActive = function(b) {
                    return a.active == b
                }, a.selectActive = function(b) {
                    a.active = b
                }, a.selectMatch = function(b) {
                    a.select({
                        activeIdx: b
                    })
                }
            }
        }
    }).directive("typeaheadMatch", ["$http", "$templateCache", "$compile", "$parse", function(a, b, c, d) {
        return {
            restrict: "EA",
            scope: {
                index: "=",
                match: "=",
                query: "="
            },
            link: function(e, f, g) {
                var h = d(g.templateUrl)(e.$parent) || "template/typeahead/typeahead-match.html";
                a.get(h, {
                    cache: b
                }).success(function(a) {
                    f.replaceWith(c(a.trim())(e))
                })
            }
        }
    }]).filter("typeaheadHighlight", function() {
        function a(a) {
            return a.replace(/([.?*+^$[\]\\(){}|-])/g, "\\$1")
        }
        return function(b, c) {
            return c ? ("" + b).replace(new RegExp(a(c), "gi"), "<strong>$&</strong>") : b
        }
    }), angular.module("template/accordion/accordion-group.html", []).run(["$templateCache", function(a) {
        a.put("template/accordion/accordion-group.html", '<div class="panel panel-default">\n  <div class="panel-heading">\n    <h4 class="panel-title">\n      <a class="accordion-toggle" ng-click="toggleOpen()" accordion-transclude="heading"><span ng-class="{\'text-muted\': isDisabled}">{{heading}}</span></a>\n    </h4>\n  </div>\n  <div class="panel-collapse" collapse="!isOpen">\n	  <div class="panel-body" ng-transclude></div>\n  </div>\n</div>')
    }]), angular.module("template/accordion/accordion.html", []).run(["$templateCache", function(a) {
        a.put("template/accordion/accordion.html", '<div class="panel-group" ng-transclude></div>')
    }]), angular.module("template/alert/alert.html", []).run(["$templateCache", function(a) {
        a.put("template/alert/alert.html", '<div class="alert" ng-class="[\'alert-\' + (type || \'warning\'), closeable ? \'alert-dismissable\' : null]" role="alert">\n    <button ng-show="closeable" type="button" class="close" ng-click="close()">\n        <span aria-hidden="true">&times;</span>\n        <span class="sr-only">Close</span>\n    </button>\n    <div ng-transclude></div>\n</div>\n')
    }]), angular.module("template/carousel/carousel.html", []).run(["$templateCache", function(a) {
        a.put("template/carousel/carousel.html", '<div ng-mouseenter="pause()" ng-mouseleave="play()" class="carousel" ng-swipe-right="prev()" ng-swipe-left="next()">\n    <ol class="carousel-indicators" ng-show="slides.length > 1">\n        <li ng-repeat="slide in slides track by $index" ng-class="{active: isActive(slide)}" ng-click="select(slide)"></li>\n    </ol>\n    <div class="carousel-inner" ng-transclude></div>\n    <a class="left carousel-control" ng-click="prev()" ng-show="slides.length > 1"><span class="glyphicon glyphicon-chevron-left"></span></a>\n    <a class="right carousel-control" ng-click="next()" ng-show="slides.length > 1"><span class="glyphicon glyphicon-chevron-right"></span></a>\n</div>\n')
    }]), angular.module("template/carousel/slide.html", []).run(["$templateCache", function(a) {
        a.put("template/carousel/slide.html", "<div ng-class=\"{\n    'active': leaving || (active && !entering),\n    'prev': (next || active) && direction=='prev',\n    'next': (next || active) && direction=='next',\n    'right': direction=='prev',\n    'left': direction=='next'\n  }\" class=\"item text-center\" ng-transclude></div>\n")
    }]), angular.module("template/datepicker/datepicker.html", []).run(["$templateCache", function(a) {
        a.put("template/datepicker/datepicker.html", '<div ng-switch="datepickerMode" role="application" ng-keydown="keydown($event)">\n  <daypicker ng-switch-when="day" tabindex="0"></daypicker>\n  <monthpicker ng-switch-when="month" tabindex="0"></monthpicker>\n  <yearpicker ng-switch-when="year" tabindex="0"></yearpicker>\n</div>')
    }]), angular.module("template/datepicker/day.html", []).run(["$templateCache", function(a) {
        a.put("template/datepicker/day.html", '<table role="grid" aria-labelledby="{{uniqueId}}-title" aria-activedescendant="{{activeDateId}}">\n  <thead>\n    <tr>\n      <th><button type="button" class="btn btn-default btn-sm pull-left" ng-click="move(-1)" tabindex="-1"><i class="glyphicon glyphicon-chevron-left"></i></button></th>\n      <th colspan="{{5 + showWeeks}}"><button id="{{uniqueId}}-title" role="heading" aria-live="assertive" aria-atomic="true" type="button" class="btn btn-default btn-sm" ng-click="toggleMode()" tabindex="-1" style="width:100%;"><strong>{{title}}</strong></button></th>\n      <th><button type="button" class="btn btn-default btn-sm pull-right" ng-click="move(1)" tabindex="-1"><i class="glyphicon glyphicon-chevron-right"></i></button></th>\n    </tr>\n    <tr>\n      <th ng-show="showWeeks" class="text-center"></th>\n      <th ng-repeat="label in labels track by $index" class="text-center"><small aria-label="{{label.full}}">{{label.abbr}}</small></th>\n    </tr>\n  </thead>\n  <tbody>\n    <tr ng-repeat="row in rows track by $index">\n      <td ng-show="showWeeks" class="text-center h6"><em>{{ weekNumbers[$index] }}</em></td>\n      <td ng-repeat="dt in row track by dt.date" class="text-center" role="gridcell" id="{{dt.uid}}" aria-disabled="{{!!dt.disabled}}">\n        <button type="button" style="width:100%;" class="btn btn-default btn-sm" ng-class="{\'btn-info\': dt.selected, active: isActive(dt)}" ng-click="select(dt.date)" ng-disabled="dt.disabled" tabindex="-1"><span ng-class="{\'text-muted\': dt.secondary, \'text-info\': dt.current}">{{dt.label}}</span></button>\n      </td>\n    </tr>\n  </tbody>\n</table>\n')
    }]), angular.module("template/datepicker/month.html", []).run(["$templateCache", function(a) {
        a.put("template/datepicker/month.html", '<table role="grid" aria-labelledby="{{uniqueId}}-title" aria-activedescendant="{{activeDateId}}">\n  <thead>\n    <tr>\n      <th><button type="button" class="btn btn-default btn-sm pull-left" ng-click="move(-1)" tabindex="-1"><i class="glyphicon glyphicon-chevron-left"></i></button></th>\n      <th><button id="{{uniqueId}}-title" role="heading" aria-live="assertive" aria-atomic="true" type="button" class="btn btn-default btn-sm" ng-click="toggleMode()" tabindex="-1" style="width:100%;"><strong>{{title}}</strong></button></th>\n      <th><button type="button" class="btn btn-default btn-sm pull-right" ng-click="move(1)" tabindex="-1"><i class="glyphicon glyphicon-chevron-right"></i></button></th>\n    </tr>\n  </thead>\n  <tbody>\n    <tr ng-repeat="row in rows track by $index">\n      <td ng-repeat="dt in row track by dt.date" class="text-center" role="gridcell" id="{{dt.uid}}" aria-disabled="{{!!dt.disabled}}">\n        <button type="button" style="width:100%;" class="btn btn-default" ng-class="{\'btn-info\': dt.selected, active: isActive(dt)}" ng-click="select(dt.date)" ng-disabled="dt.disabled" tabindex="-1"><span ng-class="{\'text-info\': dt.current}">{{dt.label}}</span></button>\n      </td>\n    </tr>\n  </tbody>\n</table>\n');
    }]), angular.module("template/datepicker/popup.html", []).run(["$templateCache", function(a) {
        a.put("template/datepicker/popup.html", '<ul class="dropdown-menu" ng-style="{display: (isOpen && \'block\') || \'none\', top: position.top+\'px\', left: position.left+\'px\'}" ng-keydown="keydown($event)">\n	<li ng-transclude></li>\n	<li ng-if="showButtonBar" style="padding:10px 9px 2px">\n		<span class="btn-group">\n			<button type="button" class="btn btn-sm btn-info" ng-click="select(\'today\')">{{ getText(\'current\') }}</button>\n			<button type="button" class="btn btn-sm btn-danger" ng-click="select(null)">{{ getText(\'clear\') }}</button>\n		</span>\n		<button type="button" class="btn btn-sm btn-success pull-right" ng-click="close()">{{ getText(\'close\') }}</button>\n	</li>\n</ul>\n')
    }]), angular.module("template/datepicker/year.html", []).run(["$templateCache", function(a) {
        a.put("template/datepicker/year.html", '<table role="grid" aria-labelledby="{{uniqueId}}-title" aria-activedescendant="{{activeDateId}}">\n  <thead>\n    <tr>\n      <th><button type="button" class="btn btn-default btn-sm pull-left" ng-click="move(-1)" tabindex="-1"><i class="glyphicon glyphicon-chevron-left"></i></button></th>\n      <th colspan="3"><button id="{{uniqueId}}-title" role="heading" aria-live="assertive" aria-atomic="true" type="button" class="btn btn-default btn-sm" ng-click="toggleMode()" tabindex="-1" style="width:100%;"><strong>{{title}}</strong></button></th>\n      <th><button type="button" class="btn btn-default btn-sm pull-right" ng-click="move(1)" tabindex="-1"><i class="glyphicon glyphicon-chevron-right"></i></button></th>\n    </tr>\n  </thead>\n  <tbody>\n    <tr ng-repeat="row in rows track by $index">\n      <td ng-repeat="dt in row track by dt.date" class="text-center" role="gridcell" id="{{dt.uid}}" aria-disabled="{{!!dt.disabled}}">\n        <button type="button" style="width:100%;" class="btn btn-default" ng-class="{\'btn-info\': dt.selected, active: isActive(dt)}" ng-click="select(dt.date)" ng-disabled="dt.disabled" tabindex="-1"><span ng-class="{\'text-info\': dt.current}">{{dt.label}}</span></button>\n      </td>\n    </tr>\n  </tbody>\n</table>\n')
    }]), angular.module("template/modal/backdrop.html", []).run(["$templateCache", function(a) {
        a.put("template/modal/backdrop.html", '<div class="modal-backdrop fade {{ backdropClass }}"\n     ng-class="{in: animate}"\n     ng-style="{\'z-index\': 1040 + (index && 1 || 0) + index*10}"\n></div>\n')
    }]), angular.module("template/modal/window.html", []).run(["$templateCache", function(a) {
        a.put("template/modal/window.html", '<div tabindex="-1" role="dialog" class="modal fade" ng-class="{in: animate}" ng-style="{\'z-index\': 1050 + index*10, display: \'block\'}" ng-click="close($event)">\n    <div class="modal-dialog" ng-class="{\'modal-sm\': size == \'sm\', \'modal-lg\': size == \'lg\'}"><div class="modal-content" modal-transclude></div></div>\n</div>')
    }]), angular.module("template/pagination/pager.html", []).run(["$templateCache", function(a) {
        a.put("template/pagination/pager.html", '<ul class="pager">\n  <li ng-class="{disabled: noPrevious(), previous: align}"><a href ng-click="selectPage(page - 1)">{{getText(\'previous\')}}</a></li>\n  <li ng-class="{disabled: noNext(), next: align}"><a href ng-click="selectPage(page + 1)">{{getText(\'next\')}}</a></li>\n</ul>')
    }]), angular.module("template/pagination/pagination.html", []).run(["$templateCache", function(a) {
        a.put("template/pagination/pagination.html", '<ul class="pagination">\n  <li ng-if="boundaryLinks" ng-class="{disabled: noPrevious()}"><a href ng-click="selectPage(1)">{{getText(\'first\')}}</a></li>\n  <li ng-if="directionLinks" ng-class="{disabled: noPrevious()}"><a href ng-click="selectPage(page - 1)">{{getText(\'previous\')}}</a></li>\n  <li ng-repeat="page in pages track by $index" ng-class="{active: page.active}"><a href ng-click="selectPage(page.number)">{{page.text}}</a></li>\n  <li ng-if="directionLinks" ng-class="{disabled: noNext()}"><a href ng-click="selectPage(page + 1)">{{getText(\'next\')}}</a></li>\n  <li ng-if="boundaryLinks" ng-class="{disabled: noNext()}"><a href ng-click="selectPage(totalPages)">{{getText(\'last\')}}</a></li>\n</ul>')
    }]), angular.module("template/tooltip/tooltip-html-unsafe-popup.html", []).run(["$templateCache", function(a) {
        a.put("template/tooltip/tooltip-html-unsafe-popup.html", '<div class="tooltip {{placement}}" ng-class="{ in: isOpen(), fade: animation() }">\n  <div class="tooltip-arrow"></div>\n  <div class="tooltip-inner" bind-html-unsafe="content"></div>\n</div>\n')
    }]), angular.module("template/tooltip/tooltip-popup.html", []).run(["$templateCache", function(a) {
        a.put("template/tooltip/tooltip-popup.html", '<div class="tooltip {{placement}}" ng-class="{ in: isOpen(), fade: animation() }">\n  <div class="tooltip-arrow"></div>\n  <div class="tooltip-inner" ng-bind="content"></div>\n</div>\n')
    }]), angular.module("template/popover/popover.html", []).run(["$templateCache", function(a) {
        a.put("template/popover/popover.html", '<div class="popover {{placement}}" ng-class="{ in: isOpen(), fade: animation() }">\n  <div class="arrow"></div>\n\n  <div class="popover-inner">\n      <h3 class="popover-title" ng-bind="title" ng-show="title"></h3>\n      <div class="popover-content" ng-bind="content"></div>\n  </div>\n</div>\n')
    }]), angular.module("template/progressbar/bar.html", []).run(["$templateCache", function(a) {
        a.put("template/progressbar/bar.html", '<div class="progress-bar" ng-class="type && \'progress-bar-\' + type" role="progressbar" aria-valuenow="{{value}}" aria-valuemin="0" aria-valuemax="{{max}}" ng-style="{width: percent + \'%\'}" aria-valuetext="{{percent | number:0}}%" ng-transclude></div>')
    }]), angular.module("template/progressbar/progress.html", []).run(["$templateCache", function(a) {
        a.put("template/progressbar/progress.html", '<div class="progress" ng-transclude></div>')
    }]), angular.module("template/progressbar/progressbar.html", []).run(["$templateCache", function(a) {
        a.put("template/progressbar/progressbar.html", '<div class="progress">\n  <div class="progress-bar" ng-class="type && \'progress-bar-\' + type" role="progressbar" aria-valuenow="{{value}}" aria-valuemin="0" aria-valuemax="{{max}}" ng-style="{width: percent + \'%\'}" aria-valuetext="{{percent | number:0}}%" ng-transclude></div>\n</div>')
    }]), angular.module("template/rating/rating.html", []).run(["$templateCache", function(a) {
        a.put("template/rating/rating.html", '<span ng-mouseleave="reset()" ng-keydown="onKeydown($event)" tabindex="0" role="slider" aria-valuemin="0" aria-valuemax="{{range.length}}" aria-valuenow="{{value}}">\n    <i ng-repeat="r in range track by $index" ng-mouseenter="enter($index + 1)" ng-click="rate($index + 1)" class="glyphicon" ng-class="$index < value && (r.stateOn || \'glyphicon-star\') || (r.stateOff || \'glyphicon-star-empty\')">\n        <span class="sr-only">({{ $index < value ? \'*\' : \' \' }})</span>\n    </i>\n</span>')
    }]), angular.module("template/tabs/tab.html", []).run(["$templateCache", function(a) {
        a.put("template/tabs/tab.html", '<li ng-class="{active: active, disabled: disabled}">\n  <a ng-click="select()" tab-heading-transclude>{{heading}}</a>\n</li>\n')
    }]), angular.module("template/tabs/tabset.html", []).run(["$templateCache", function(a) {
        a.put("template/tabs/tabset.html", '<div>\n  <ul class="nav nav-{{type || \'tabs\'}}" ng-class="{\'nav-stacked\': vertical, \'nav-justified\': justified}" ng-transclude></ul>\n  <div class="tab-content">\n    <div class="tab-pane" \n         ng-repeat="tab in tabs" \n         ng-class="{active: tab.active}"\n         tab-content-transclude="tab">\n    </div>\n  </div>\n</div>\n')
    }]), angular.module("template/timepicker/timepicker.html", []).run(["$templateCache", function(a) {
        a.put("template/timepicker/timepicker.html", '<table>\n	<tbody>\n		<tr class="text-center">\n			<td><a ng-click="incrementHours()" class="btn btn-link"><span class="glyphicon glyphicon-chevron-up"></span></a></td>\n			<td>&nbsp;</td>\n			<td><a ng-click="incrementMinutes()" class="btn btn-link"><span class="glyphicon glyphicon-chevron-up"></span></a></td>\n			<td ng-show="showMeridian"></td>\n		</tr>\n		<tr>\n			<td style="width:50px;" class="form-group" ng-class="{\'has-error\': invalidHours}">\n				<input type="text" ng-model="hours" ng-change="updateHours()" class="form-control text-center" ng-mousewheel="incrementHours()" ng-readonly="readonlyInput" maxlength="2">\n			</td>\n			<td>:</td>\n			<td style="width:50px;" class="form-group" ng-class="{\'has-error\': invalidMinutes}">\n				<input type="text" ng-model="minutes" ng-change="updateMinutes()" class="form-control text-center" ng-readonly="readonlyInput" maxlength="2">\n			</td>\n			<td ng-show="showMeridian"><button type="button" class="btn btn-default text-center" ng-click="toggleMeridian()">{{meridian}}</button></td>\n		</tr>\n		<tr class="text-center">\n			<td><a ng-click="decrementHours()" class="btn btn-link"><span class="glyphicon glyphicon-chevron-down"></span></a></td>\n			<td>&nbsp;</td>\n			<td><a ng-click="decrementMinutes()" class="btn btn-link"><span class="glyphicon glyphicon-chevron-down"></span></a></td>\n			<td ng-show="showMeridian"></td>\n		</tr>\n	</tbody>\n</table>\n')
    }]), angular.module("template/typeahead/typeahead-match.html", []).run(["$templateCache", function(a) {
        a.put("template/typeahead/typeahead-match.html", '<a tabindex="-1" bind-html-unsafe="match.label | typeaheadHighlight:query"></a>')
    }]), angular.module("template/typeahead/typeahead-popup.html", []).run(["$templateCache", function(a) {
        a.put("template/typeahead/typeahead-popup.html", '<ul class="dropdown-menu" ng-show="isOpen()" ng-style="{top: position.top+\'px\', left: position.left+\'px\'}" style="display: block;" role="listbox" aria-hidden="{{!isOpen()}}">\n    <li ng-repeat="match in matches track by $index" ng-class="{active: isActive($index) }" ng-mouseenter="selectActive($index)" ng-click="selectMatch($index)" role="option" id="{{match.id}}">\n        <div typeahead-match index="$index" match="match" query="query" template-url="templateUrl"></div>\n    </li>\n</ul>\n')
    }]), "undefined" != typeof module && "undefined" != typeof exports && module.exports === exports && (module.exports = "ui.router"),
    function(a, b, c) {
        "use strict";

        function d(a, b) {
            return R(new(R(function() {}, {
                prototype: a
            })), b)
        }

        function e(a) {
            return Q(arguments, function(b) {
                b !== a && Q(b, function(b, c) {
                    a.hasOwnProperty(c) || (a[c] = b)
                })
            }), a
        }

        function f(a, b) {
            var c = [];
            for (var d in a.path) {
                if (a.path[d] !== b.path[d]) break;
                c.push(a.path[d])
            }
            return c
        }

        function g(a) {
            if (Object.keys) return Object.keys(a);
            var b = [];
            return Q(a, function(a, c) {
                b.push(c)
            }), b
        }

        function h(a, b) {
            if (Array.prototype.indexOf) return a.indexOf(b, Number(arguments[2]) || 0);
            var c = a.length >>> 0,
                d = Number(arguments[2]) || 0;
            for (d = 0 > d ? Math.ceil(d) : Math.floor(d), 0 > d && (d += c); c > d; d++)
                if (d in a && a[d] === b) return d;
            return -1
        }

        function i(a, b, c, d) {
            var e, i = f(c, d),
                j = {},
                k = [];
            for (var l in i)
                if (i[l] && i[l].params && (e = g(i[l].params), e.length))
                    for (var m in e) h(k, e[m]) >= 0 || (k.push(e[m]), j[e[m]] = a[e[m]]);
            return R({}, j, b)
        }

        function j(a, b, c) {
            if (!c) {
                c = [];
                for (var d in a) c.push(d)
            }
            for (var e = 0; e < c.length; e++) {
                var f = c[e];
                if (a[f] != b[f]) return !1
            }
            return !0
        }

        function k(a, b) {
            var c = {};
            return Q(a, function(a) {
                c[a] = b[a]
            }), c
        }

        function l(a) {
            var b = {},
                c = Array.prototype.concat.apply(Array.prototype, Array.prototype.slice.call(arguments, 1));
            return Q(c, function(c) {
                c in a && (b[c] = a[c])
            }), b
        }

        function m(a) {
            var b = {},
                c = Array.prototype.concat.apply(Array.prototype, Array.prototype.slice.call(arguments, 1));
            for (var d in a) - 1 == h(c, d) && (b[d] = a[d]);
            return b
        }

        function n(a, b) {
            var c = P(a),
                d = c ? [] : {};
            return Q(a, function(a, e) {
                b(a, e) && (d[c ? d.length : e] = a)
            }), d
        }

        function o(a, b) {
            var c = P(a) ? [] : {};
            return Q(a, function(a, d) {
                c[d] = b(a, d)
            }), c
        }

        function p(a, b) {
            var d = 1,
                f = 2,
                i = {},
                j = [],
                k = i,
                l = R(a.when(i), {
                    $$promises: i,
                    $$values: i
                });
            this.study = function(i) {
                function n(a, c) {
                    if (s[c] !== f) {
                        if (r.push(c), s[c] === d) throw r.splice(0, h(r, c)), new Error("Cyclic dependency: " + r.join(" -> "));
                        if (s[c] = d, N(a)) q.push(c, [function() {
                            return b.get(a)
                        }], j);
                        else {
                            var e = b.annotate(a);
                            Q(e, function(a) {
                                a !== c && i.hasOwnProperty(a) && n(i[a], a)
                            }), q.push(c, a, e)
                        }
                        r.pop(), s[c] = f
                    }
                }

                function o(a) {
                    return O(a) && a.then && a.$$promises
                }
                if (!O(i)) throw new Error("'invocables' must be an object");
                var p = g(i || {}),
                    q = [],
                    r = [],
                    s = {};
                return Q(i, n), i = r = s = null,
                    function(d, f, g) {
                        function h() {
                            --u || (v || e(t, f.$$values), r.$$values = t, r.$$promises = r.$$promises || !0, delete r.$$inheritedValues, n.resolve(t))
                        }

                        function i(a) {
                            r.$$failure = a, n.reject(a)
                        }

                        function j(c, e, f) {
                            function j(a) {
                                l.reject(a), i(a)
                            }

                            function k() {
                                if (!L(r.$$failure)) try {
                                    l.resolve(b.invoke(e, g, t)), l.promise.then(function(a) {
                                        t[c] = a, h()
                                    }, j)
                                } catch (a) {
                                    j(a)
                                }
                            }
                            var l = a.defer(),
                                m = 0;
                            Q(f, function(a) {
                                s.hasOwnProperty(a) && !d.hasOwnProperty(a) && (m++, s[a].then(function(b) {
                                    t[a] = b, --m || k()
                                }, j))
                            }), m || k(), s[c] = l.promise
                        }
                        if (o(d) && g === c && (g = f, f = d, d = null), d) {
                            if (!O(d)) throw new Error("'locals' must be an object")
                        } else d = k;
                        if (f) {
                            if (!o(f)) throw new Error("'parent' must be a promise returned by $resolve.resolve()")
                        } else f = l;
                        var n = a.defer(),
                            r = n.promise,
                            s = r.$$promises = {},
                            t = R({}, d),
                            u = 1 + q.length / 3,
                            v = !1;
                        if (L(f.$$failure)) return i(f.$$failure), r;
                        f.$$inheritedValues && e(t, m(f.$$inheritedValues, p)), R(s, f.$$promises), f.$$values ? (v = e(t, m(f.$$values, p)), r.$$inheritedValues = m(f.$$values, p), h()) : (f.$$inheritedValues && (r.$$inheritedValues = m(f.$$inheritedValues, p)), f.then(h, i));
                        for (var w = 0, x = q.length; x > w; w += 3) d.hasOwnProperty(q[w]) ? h() : j(q[w], q[w + 1], q[w + 2]);
                        return r
                    }
            }, this.resolve = function(a, b, c, d) {
                return this.study(a)(b, c, d)
            }
        }

        function q(a, b, c) {
            this.fromConfig = function(a, b, c) {
                return L(a.template) ? this.fromString(a.template, b) : L(a.templateUrl) ? this.fromUrl(a.templateUrl, b) : L(a.templateProvider) ? this.fromProvider(a.templateProvider, b, c) : null
            }, this.fromString = function(a, b) {
                return M(a) ? a(b) : a
            }, this.fromUrl = function(c, d) {
                return M(c) && (c = c(d)), null == c ? null : a.get(c, {
                    cache: b,
                    headers: {
                        Accept: "text/html"
                    }
                }).then(function(a) {
                    return a.data
                })
            }, this.fromProvider = function(a, b, d) {
                return c.invoke(a, null, d || {
                    params: b
                })
            }
        }

        function r(a, b, e) {
            function f(b, c, d, e) {
                if (q.push(b), o[b]) return o[b];
                if (!/^\w+([-.]+\w+)*(?:\[\])?$/.test(b)) throw new Error("Invalid parameter name '" + b + "' in pattern '" + a + "'");
                if (p[b]) throw new Error("Duplicate parameter name '" + b + "' in pattern '" + a + "'");
                return p[b] = new U.Param(b, c, d, e), p[b]
            }

            function g(a, b, c, d) {
                var e = ["", ""],
                    f = a.replace(/[\\\[\]\^$*+?.()|{}]/g, "\\$&");
                if (!b) return f;
                switch (c) {
                    case !1:
                        e = ["(", ")" + (d ? "?" : "")];
                        break;
                    case !0:
                        f = f.replace(/\/$/, ""), e = ["(?:/(", ")|/)?"];
                        break;
                    default:
                        e = ["(" + c + "|", ")?"]
                }
                return f + e[0] + b + e[1]
            }

            function h(e, f) {
                var g, h, i, j, k;
                return g = e[2] || e[3], k = b.params[g], i = a.substring(m, e.index), h = f ? e[4] : e[4] || ("*" == e[1] ? ".*" : null), h && (j = U.type(h) || d(U.type("string"), {
                    pattern: new RegExp(h, b.caseInsensitive ? "i" : c)
                })), {
                    id: g,
                    regexp: h,
                    segment: i,
                    type: j,
                    cfg: k
                }
            }
            b = R({
                params: {}
            }, O(b) ? b : {});
            var i, j = /([:*])([\w\[\]]+)|\{([\w\[\]]+)(?:\:\s*((?:[^{}\\]+|\\.|\{(?:[^{}\\]+|\\.)*\})+))?\}/g,
                k = /([:]?)([\w\[\].-]+)|\{([\w\[\].-]+)(?:\:\s*((?:[^{}\\]+|\\.|\{(?:[^{}\\]+|\\.)*\})+))?\}/g,
                l = "^",
                m = 0,
                n = this.segments = [],
                o = e ? e.params : {},
                p = this.params = e ? e.params.$$new() : new U.ParamSet,
                q = [];
            this.source = a;
            for (var r, s, t;
                (i = j.exec(a)) && (r = h(i, !1), !(r.segment.indexOf("?") >= 0));) s = f(r.id, r.type, r.cfg, "path"), l += g(r.segment, s.type.pattern.source, s.squash, s.isOptional), n.push(r.segment), m = j.lastIndex;
            t = a.substring(m);
            var u = t.indexOf("?");
            if (u >= 0) {
                var v = this.sourceSearch = t.substring(u);
                if (t = t.substring(0, u), this.sourcePath = a.substring(0, m + u), v.length > 0)
                    for (m = 0; i = k.exec(v);) r = h(i, !0), s = f(r.id, r.type, r.cfg, "search"), m = j.lastIndex
            } else this.sourcePath = a, this.sourceSearch = "";
            l += g(t) + (b.strict === !1 ? "/?" : "") + "$", n.push(t), this.regexp = new RegExp(l, b.caseInsensitive ? "i" : c), this.prefix = n[0], this.$$paramNames = q
        }

        function s(a) {
            R(this, a)
        }

        function t() {
            function a(a) {
                return null != a ? a.toString().replace(/~/g, "~~").replace(/\//g, "~2F") : a
            }

            function e(a) {
                return null != a ? a.toString().replace(/~2F/g, "/").replace(/~~/g, "~") : a
            }

            function f() {
                return {
                    strict: p,
                    caseInsensitive: m
                }
            }

            function i(a) {
                return M(a) || P(a) && M(a[a.length - 1])
            }

            function j() {
                for (; w.length;) {
                    var a = w.shift();
                    if (a.pattern) throw new Error("You cannot override a type's .pattern at runtime.");
                    b.extend(u[a.name], l.invoke(a.def))
                }
            }

            function k(a) {
                R(this, a || {})
            }
            U = this;
            var l, m = !1,
                p = !0,
                q = !1,
                u = {},
                v = !0,
                w = [],
                x = {
                    string: {
                        encode: a,
                        decode: e,
                        is: function(a) {
                            return null == a || !L(a) || "string" == typeof a
                        },
                        pattern: /[^\/]*/
                    },
                    "int": {
                        encode: a,
                        decode: function(a) {
                            return parseInt(a, 10)
                        },
                        is: function(a) {
                            return L(a) && this.decode(a.toString()) === a
                        },
                        pattern: /\d+/
                    },
                    bool: {
                        encode: function(a) {
                            return a ? 1 : 0
                        },
                        decode: function(a) {
                            return 0 !== parseInt(a, 10)
                        },
                        is: function(a) {
                            return a === !0 || a === !1
                        },
                        pattern: /0|1/
                    },
                    date: {
                        encode: function(a) {
                            return this.is(a) ? [a.getFullYear(), ("0" + (a.getMonth() + 1)).slice(-2), ("0" + a.getDate()).slice(-2)].join("-") : c
                        },
                        decode: function(a) {
                            if (this.is(a)) return a;
                            var b = this.capture.exec(a);
                            return b ? new Date(b[1], b[2] - 1, b[3]) : c
                        },
                        is: function(a) {
                            return a instanceof Date && !isNaN(a.valueOf())
                        },
                        equals: function(a, b) {
                            return this.is(a) && this.is(b) && a.toISOString() === b.toISOString()
                        },
                        pattern: /[0-9]{4}-(?:0[1-9]|1[0-2])-(?:0[1-9]|[1-2][0-9]|3[0-1])/,
                        capture: /([0-9]{4})-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])/
                    },
                    json: {
                        encode: b.toJson,
                        decode: b.fromJson,
                        is: b.isObject,
                        equals: b.equals,
                        pattern: /[^\/]*/
                    },
                    any: {
                        encode: b.identity,
                        decode: b.identity,
                        equals: b.equals,
                        pattern: /.*/
                    }
                };
            t.$$getDefaultValue = function(a) {
                if (!i(a.value)) return a.value;
                if (!l) throw new Error("Injectable functions cannot be called at configuration time");
                return l.invoke(a.value)
            }, this.caseInsensitive = function(a) {
                return L(a) && (m = a), m
            }, this.strictMode = function(a) {
                return L(a) && (p = a), p
            }, this.defaultSquashPolicy = function(a) {
                if (!L(a)) return q;
                if (a !== !0 && a !== !1 && !N(a)) throw new Error("Invalid squash policy: " + a + ". Valid policies: false, true, arbitrary-string");
                return q = a, a
            }, this.compile = function(a, b) {
                return new r(a, R(f(), b))
            }, this.isMatcher = function(a) {
                if (!O(a)) return !1;
                var b = !0;
                return Q(r.prototype, function(c, d) {
                    M(c) && (b = b && L(a[d]) && M(a[d]))
                }), b
            }, this.type = function(a, b, c) {
                if (!L(b)) return u[a];
                if (u.hasOwnProperty(a)) throw new Error("A type named '" + a + "' has already been defined.");
                return u[a] = new s(R({
                    name: a
                }, b)), c && (w.push({
                    name: a,
                    def: c
                }), v || j()), this
            }, Q(x, function(a, b) {
                u[b] = new s(R({
                    name: b
                }, a))
            }), u = d(u, {}), this.$get = ["$injector", function(a) {
                return l = a, v = !1, j(), Q(x, function(a, b) {
                    u[b] || (u[b] = new s(a))
                }), this
            }], this.Param = function(a, d, e, f) {
                function j(a) {
                    var b = O(a) ? g(a) : [],
                        c = -1 === h(b, "value") && -1 === h(b, "type") && -1 === h(b, "squash") && -1 === h(b, "array");
                    return c && (a = {
                        value: a
                    }), a.$$fn = i(a.value) ? a.value : function() {
                        return a.value
                    }, a
                }

                function k(c, d, e) {
                    if (c.type && d) throw new Error("Param '" + a + "' has two type configurations.");
                    return d ? d : c.type ? b.isString(c.type) ? u[c.type] : c.type instanceof s ? c.type : new s(c.type) : "config" === e ? u.any : u.string
                }

                function m() {
                    var b = {
                            array: "search" === f ? "auto" : !1
                        },
                        c = a.match(/\[\]$/) ? {
                            array: !0
                        } : {};
                    return R(b, c, e).array
                }

                function p(a, b) {
                    var c = a.squash;
                    if (!b || c === !1) return !1;
                    if (!L(c) || null == c) return q;
                    if (c === !0 || N(c)) return c;
                    throw new Error("Invalid squash policy: '" + c + "'. Valid policies: false, true, or arbitrary string")
                }

                function r(a, b, d, e) {
                    var f, g, i = [{
                        from: "",
                        to: d || b ? c : ""
                    }, {
                        from: null,
                        to: d || b ? c : ""
                    }];
                    return f = P(a.replace) ? a.replace : [], N(e) && f.push({
                        from: e,
                        to: c
                    }), g = o(f, function(a) {
                        return a.from
                    }), n(i, function(a) {
                        return -1 === h(g, a.from)
                    }).concat(f)
                }

                function t() {
                    if (!l) throw new Error("Injectable functions cannot be called at configuration time");
                    var a = l.invoke(e.$$fn);
                    if (null !== a && a !== c && !x.type.is(a)) throw new Error("Default value (" + a + ") for parameter '" + x.id + "' is not an instance of Type (" + x.type.name + ")");
                    return a
                }

                function v(a) {
                    function b(a) {
                        return function(b) {
                            return b.from === a
                        }
                    }

                    function c(a) {
                        var c = o(n(x.replace, b(a)), function(a) {
                            return a.to
                        });
                        return c.length ? c[0] : a
                    }
                    return a = c(a), L(a) ? x.type.$normalize(a) : t()
                }

                function w() {
                    return "{Param:" + a + " " + d + " squash: '" + A + "' optional: " + z + "}"
                }
                var x = this;
                e = j(e), d = k(e, d, f);
                var y = m();
                d = y ? d.$asArray(y, "search" === f) : d, "string" !== d.name || y || "path" !== f || e.value !== c || (e.value = "");
                var z = e.value !== c,
                    A = p(e, z),
                    B = r(e, y, z, A);
                R(this, {
                    id: a,
                    type: d,
                    location: f,
                    array: y,
                    squash: A,
                    replace: B,
                    isOptional: z,
                    value: v,
                    dynamic: c,
                    config: e,
                    toString: w
                })
            }, k.prototype = {
                $$new: function() {
                    return d(this, R(new k, {
                        $$parent: this
                    }))
                },
                $$keys: function() {
                    for (var a = [], b = [], c = this, d = g(k.prototype); c;) b.push(c), c = c.$$parent;
                    return b.reverse(), Q(b, function(b) {
                        Q(g(b), function(b) {
                            -1 === h(a, b) && -1 === h(d, b) && a.push(b)
                        })
                    }), a
                },
                $$values: function(a) {
                    var b = {},
                        c = this;
                    return Q(c.$$keys(), function(d) {
                        b[d] = c[d].value(a && a[d])
                    }), b
                },
                $$equals: function(a, b) {
                    var c = !0,
                        d = this;
                    return Q(d.$$keys(), function(e) {
                        var f = a && a[e],
                            g = b && b[e];
                        d[e].type.equals(f, g) || (c = !1)
                    }), c
                },
                $$validates: function(a) {
                    var d, e, f, g, h, i = this.$$keys();
                    for (d = 0; d < i.length && (e = this[i[d]], f = a[i[d]], f !== c && null !== f || !e.isOptional); d++) {
                        if (g = e.type.$normalize(f), !e.type.is(g)) return !1;
                        if (h = e.type.encode(g), b.isString(h) && !e.type.pattern.exec(h)) return !1
                    }
                    return !0
                },
                $$parent: c
            }, this.ParamSet = k
        }

        function u(a, d) {
            function e(a) {
                var b = /^\^((?:\\[^a-zA-Z0-9]|[^\\\[\]\^$*+?.()|{}]+)*)/.exec(a.source);
                return null != b ? b[1].replace(/\\(.)/g, "$1") : ""
            }

            function f(a, b) {
                return a.replace(/\$(\$|\d{1,2})/, function(a, c) {
                    return b["$" === c ? 0 : Number(c)]
                })
            }

            function g(a, b, c) {
                if (!c) return !1;
                var d = a.invoke(b, b, {
                    $match: c
                });
                return L(d) ? d : !0
            }

            function h(d, e, f, g, h) {
                function m(a, b, c) {
                    return "/" === q ? a : b ? q.slice(0, -1) + a : c ? q.slice(1) + a : a
                }

                function n(a) {
                    function b(a) {
                        var b = a(f, d);
                        return b ? (N(b) && d.replace().url(b), !0) : !1
                    }
                    if (!a || !a.defaultPrevented) {
                        p && d.url() === p, p = c;
                        var e, g = j.length;
                        for (e = 0; g > e; e++)
                            if (b(j[e])) return;
                        k && b(k)
                    }
                }

                function o() {
                    return i = i || e.$on("$locationChangeSuccess", n)
                }
                var p, q = g.baseHref(),
                    r = d.url();
                return l || o(), {
                    sync: function() {
                        n()
                    },
                    listen: function() {
                        return o()
                    },
                    update: function(a) {
                        return a ? void(r = d.url()) : void(d.url() !== r && (d.url(r), d.replace()))
                    },
                    push: function(a, b, e) {
                        var f = a.format(b || {});
                        null !== f && b && b["#"] && (f += "#" + b["#"]), d.url(f), p = e && e.$$avoidResync ? d.url() : c, e && e.replace && d.replace()
                    },
                    href: function(c, e, f) {
                        if (!c.validates(e)) return null;
                        var g = a.html5Mode();
                        b.isObject(g) && (g = g.enabled), g = g && h.history;
                        var i = c.format(e);
                        if (f = f || {}, g || null === i || (i = "#" + a.hashPrefix() + i), null !== i && e && e["#"] && (i += "#" + e["#"]), i = m(i, g, f.absolute), !f.absolute || !i) return i;
                        var j = !g && i ? "/" : "",
                            k = d.port();
                        return k = 80 === k || 443 === k ? "" : ":" + k, [d.protocol(), "://", d.host(), k, j, i].join("")
                    }
                }
            }
            var i, j = [],
                k = null,
                l = !1;
            this.rule = function(a) {
                if (!M(a)) throw new Error("'rule' must be a function");
                return j.push(a), this
            }, this.otherwise = function(a) {
                if (N(a)) {
                    var b = a;
                    a = function() {
                        return b
                    }
                } else if (!M(a)) throw new Error("'rule' must be a function");
                return k = a, this
            }, this.when = function(a, b) {
                var c, h = N(b);
                if (N(a) && (a = d.compile(a)), !h && !M(b) && !P(b)) throw new Error("invalid 'handler' in when()");
                var i = {
                        matcher: function(a, b) {
                            return h && (c = d.compile(b), b = ["$match", function(a) {
                                return c.format(a)
                            }]), R(function(c, d) {
                                return g(c, b, a.exec(d.path(), d.search()))
                            }, {
                                prefix: N(a.prefix) ? a.prefix : ""
                            })
                        },
                        regex: function(a, b) {
                            if (a.global || a.sticky) throw new Error("when() RegExp must not be global or sticky");
                            return h && (c = b, b = ["$match", function(a) {
                                return f(c, a)
                            }]), R(function(c, d) {
                                return g(c, b, a.exec(d.path()))
                            }, {
                                prefix: e(a)
                            })
                        }
                    },
                    j = {
                        matcher: d.isMatcher(a),
                        regex: a instanceof RegExp
                    };
                for (var k in j)
                    if (j[k]) return this.rule(i[k](a, b));
                throw new Error("invalid 'what' in when()")
            }, this.deferIntercept = function(a) {
                a === c && (a = !0), l = a
            }, this.$get = h, h.$inject = ["$location", "$rootScope", "$injector", "$browser", "$sniffer"]
        }

        function v(a, e) {
            function f(a) {
                return 0 === a.indexOf(".") || 0 === a.indexOf("^")
            }

            function m(a, b) {
                if (!a) return c;
                var d = N(a),
                    e = d ? a : a.name,
                    g = f(e);
                if (g) {
                    if (!b) throw new Error("No reference point given for path '" + e + "'");
                    b = m(b);
                    for (var h = e.split("."), i = 0, j = h.length, k = b; j > i; i++)
                        if ("" !== h[i] || 0 !== i) {
                            if ("^" !== h[i]) break;
                            if (!k.parent) throw new Error("Path '" + e + "' not valid for state '" + b.name + "'");
                            k = k.parent
                        } else k = b;
                    h = h.slice(i).join("."), e = k.name + (k.name && h ? "." : "") + h
                }
                var l = z[e];
                return !l || !d && (d || l !== a && l.self !== a) ? c : l
            }

            function n(a, b) {
                A[a] || (A[a] = []), A[a].push(b)
            }

            function p(a) {
                for (var b = A[a] || []; b.length;) q(b.shift())
            }

            function q(b) {
                b = d(b, {
                    self: b,
                    resolve: b.resolve || {},
                    toString: function() {
                        return this.name
                    }
                });
                var c = b.name;
                if (!N(c) || c.indexOf("@") >= 0) throw new Error("State must have a valid name");
                if (z.hasOwnProperty(c)) throw new Error("State '" + c + "' is already defined");
                var e = -1 !== c.indexOf(".") ? c.substring(0, c.lastIndexOf(".")) : N(b.parent) ? b.parent : O(b.parent) && N(b.parent.name) ? b.parent.name : "";
                if (e && !z[e]) return n(e, b.self);
                for (var f in C) M(C[f]) && (b[f] = C[f](b, C.$delegates[f]));
                return z[c] = b, !b[B] && b.url && a.when(b.url, ["$match", "$stateParams", function(a, c) {
                    y.$current.navigable == b && j(a, c) || y.transitionTo(b, a, {
                        inherit: !0,
                        location: !1
                    })
                }]), p(c), b
            }

            function r(a) {
                return a.indexOf("*") > -1
            }

            function s(a) {
                for (var b = a.split("."), c = y.$current.name.split("."), d = 0, e = b.length; e > d; d++) "*" === b[d] && (c[d] = "*");
                return "**" === b[0] && (c = c.slice(h(c, b[1])), c.unshift("**")), "**" === b[b.length - 1] && (c.splice(h(c, b[b.length - 2]) + 1, Number.MAX_VALUE), c.push("**")), b.length != c.length ? !1 : c.join("") === b.join("")
            }

            function t(a, b) {
                return N(a) && !L(b) ? C[a] : M(b) && N(a) ? (C[a] && !C.$delegates[a] && (C.$delegates[a] = C[a]), C[a] = b, this) : this
            }

            function u(a, b) {
                return O(a) ? b = a : b.name = a, q(b), this
            }

            function v(a, e, f, h, l, n, p, q, t) {
                function u(b, c, d, f) {
                    var g = a.$broadcast("$stateNotFound", b, c, d);
                    if (g.defaultPrevented) return p.update(), D;
                    if (!g.retry) return null;
                    if (f.$retry) return p.update(), E;
                    var h = y.transition = e.when(g.retry);
                    return h.then(function() {
                        return h !== y.transition ? A : (b.options.$retry = !0, y.transitionTo(b.to, b.toParams, b.options))
                    }, function() {
                        return D
                    }), p.update(), h
                }

                function v(a, c, d, g, i, j) {
                    function m() {
                        var c = [];
                        return Q(a.views, function(d, e) {
                            var g = d.resolve && d.resolve !== a.resolve ? d.resolve : {};
                            g.$template = [function() {
                                return f.load(e, {
                                    view: d,
                                    locals: i.globals,
                                    params: n,
                                    notify: j.notify
                                }) || ""
                            }], c.push(l.resolve(g, i.globals, i.resolve, a).then(function(c) {
                                if (M(d.controllerProvider) || P(d.controllerProvider)) {
                                    var f = b.extend({}, g, i.globals);
                                    c.$$controller = h.invoke(d.controllerProvider, null, f)
                                } else c.$$controller = d.controller;
                                c.$$state = a, c.$$controllerAs = d.controllerAs, i[e] = c
                            }))
                        }), e.all(c).then(function() {
                            return i.globals
                        })
                    }
                    var n = d ? c : k(a.params.$$keys(), c),
                        o = {
                            $stateParams: n
                        };
                    i.resolve = l.resolve(a.resolve, o, i.resolve, a);
                    var p = [i.resolve.then(function(a) {
                        i.globals = a
                    })];
                    return g && p.push(g), e.all(p).then(m).then(function(a) {
                        return i
                    })
                }
                var A = e.reject(new Error("transition superseded")),
                    C = e.reject(new Error("transition prevented")),
                    D = e.reject(new Error("transition aborted")),
                    E = e.reject(new Error("transition failed"));
                return x.locals = {
                    resolve: null,
                    globals: {
                        $stateParams: {}
                    }
                }, y = {
                    params: {},
                    current: x.self,
                    $current: x,
                    transition: null
                }, y.reload = function(a) {
                    return y.transitionTo(y.current, n, {
                        reload: a || !0,
                        inherit: !1,
                        notify: !0
                    })
                }, y.go = function(a, b, c) {
                    return y.transitionTo(a, b, R({
                        inherit: !0,
                        relative: y.$current
                    }, c))
                }, y.transitionTo = function(b, c, f) {
                    c = c || {}, f = R({
                        location: !0,
                        inherit: !1,
                        relative: null,
                        notify: !0,
                        reload: !1,
                        $retry: !1
                    }, f || {});
                    var g, j = y.$current,
                        l = y.params,
                        o = j.path,
                        q = m(b, f.relative),
                        r = c["#"];
                    if (!L(q)) {
                        var s = {
                                to: b,
                                toParams: c,
                                options: f
                            },
                            t = u(s, j.self, l, f);
                        if (t) return t;
                        if (b = s.to, c = s.toParams, f = s.options, q = m(b, f.relative), !L(q)) {
                            if (!f.relative) throw new Error("No such state '" + b + "'");
                            throw new Error("Could not resolve '" + b + "' from state '" + f.relative + "'")
                        }
                    }
                    if (q[B]) throw new Error("Cannot transition to abstract state '" + b + "'");
                    if (f.inherit && (c = i(n, c || {}, y.$current, q)), !q.params.$$validates(c)) return E;
                    c = q.params.$$values(c), b = q;
                    var z = b.path,
                        D = 0,
                        F = z[D],
                        G = x.locals,
                        H = [];
                    if (f.reload) {
                        if (N(f.reload) || O(f.reload)) {
                            if (O(f.reload) && !f.reload.name) throw new Error("Invalid reload state object");
                            var I = f.reload === !0 ? o[0] : m(f.reload);
                            if (f.reload && !I) throw new Error("No such reload state '" + (N(f.reload) ? f.reload : f.reload.name) + "'");
                            for (; F && F === o[D] && F !== I;) G = H[D] = F.locals, D++, F = z[D]
                        }
                    } else
                        for (; F && F === o[D] && F.ownParams.$$equals(c, l);) G = H[D] = F.locals, D++, F = z[D];
                    if (w(b, c, j, l, G, f)) return r && (c["#"] = r), y.params = c, S(y.params, n), S(k(b.params.$$keys(), n), b.locals.globals.$stateParams), f.location && b.navigable && b.navigable.url && (p.push(b.navigable.url, c, {
                        $$avoidResync: !0,
                        replace: "replace" === f.location
                    }), p.update(!0)), y.transition = null, e.when(y.current);
                    if (c = k(b.params.$$keys(), c || {}), r && (c["#"] = r), f.notify && a.$broadcast("$stateChangeStart", b.self, c, j.self, l, f).defaultPrevented) return a.$broadcast("$stateChangeCancel", b.self, c, j.self, l), null == y.transition && p.update(), C;
                    for (var J = e.when(G), K = D; K < z.length; K++, F = z[K]) G = H[K] = d(G), J = v(F, c, F === b, J, G, f);
                    var M = y.transition = J.then(function() {
                        var d, e, g;
                        if (y.transition !== M) return A;
                        for (d = o.length - 1; d >= D; d--) g = o[d], g.self.onExit && h.invoke(g.self.onExit, g.self, g.locals.globals), g.locals = null;
                        for (d = D; d < z.length; d++) e = z[d], e.locals = H[d], e.self.onEnter && h.invoke(e.self.onEnter, e.self, e.locals.globals);
                        return y.transition !== M ? A : (y.$current = b, y.current = b.self, y.params = c, S(y.params, n), y.transition = null, f.location && b.navigable && p.push(b.navigable.url, b.navigable.locals.globals.$stateParams, {
                            $$avoidResync: !0,
                            replace: "replace" === f.location
                        }), f.notify && a.$broadcast("$stateChangeSuccess", b.self, c, j.self, l), p.update(!0), y.current)
                    }, function(d) {
                        return y.transition !== M ? A : (y.transition = null, g = a.$broadcast("$stateChangeError", b.self, c, j.self, l, d), g.defaultPrevented || p.update(), e.reject(d))
                    });
                    return M
                }, y.is = function(a, b, d) {
                    d = R({
                        relative: y.$current
                    }, d || {});
                    var e = m(a, d.relative);
                    return L(e) ? y.$current !== e ? !1 : b ? j(e.params.$$values(b), n) : !0 : c
                }, y.includes = function(a, b, d) {
                    if (d = R({
                            relative: y.$current
                        }, d || {}), N(a) && r(a)) {
                        if (!s(a)) return !1;
                        a = y.$current.name
                    }
                    var e = m(a, d.relative);
                    return L(e) ? L(y.$current.includes[e.name]) ? b ? j(e.params.$$values(b), n, g(b)) : !0 : !1 : c
                }, y.href = function(a, b, d) {
                    d = R({
                        lossy: !0,
                        inherit: !0,
                        absolute: !1,
                        relative: y.$current
                    }, d || {});
                    var e = m(a, d.relative);
                    if (!L(e)) return null;
                    d.inherit && (b = i(n, b || {}, y.$current, e));
                    var f = e && d.lossy ? e.navigable : e;
                    return f && f.url !== c && null !== f.url ? p.href(f.url, k(e.params.$$keys().concat("#"), b || {}), {
                        absolute: d.absolute
                    }) : null
                }, y.get = function(a, b) {
                    if (0 === arguments.length) return o(g(z), function(a) {
                        return z[a].self
                    });
                    var c = m(a, b || y.$current);
                    return c && c.self ? c.self : null
                }, y
            }

            function w(a, b, c, d, e, f) {
                function g(a, b, c) {
                    function d(b) {
                        return "search" != a.params[b].location
                    }
                    var e = a.params.$$keys().filter(d),
                        f = l.apply({}, [a.params].concat(e)),
                        g = new U.ParamSet(f);
                    return g.$$equals(b, c)
                }
                return !f.reload && a === c && (e === c.locals || a.self.reloadOnSearch === !1 && g(c, d, b)) ? !0 : void 0
            }
            var x, y, z = {},
                A = {},
                B = "abstract",
                C = {
                    parent: function(a) {
                        if (L(a.parent) && a.parent) return m(a.parent);
                        var b = /^(.+)\.[^.]+$/.exec(a.name);
                        return b ? m(b[1]) : x
                    },
                    data: function(a) {
                        return a.parent && a.parent.data && (a.data = a.self.data = d(a.parent.data, a.data)), a.data
                    },
                    url: function(a) {
                        var b = a.url,
                            c = {
                                params: a.params || {}
                            };
                        if (N(b)) return "^" == b.charAt(0) ? e.compile(b.substring(1), c) : (a.parent.navigable || x).url.concat(b, c);
                        if (!b || e.isMatcher(b)) return b;
                        throw new Error("Invalid url '" + b + "' in state '" + a + "'")
                    },
                    navigable: function(a) {
                        return a.url ? a : a.parent ? a.parent.navigable : null
                    },
                    ownParams: function(a) {
                        var b = a.url && a.url.params || new U.ParamSet;
                        return Q(a.params || {}, function(a, c) {
                            b[c] || (b[c] = new U.Param(c, null, a, "config"))
                        }), b
                    },
                    params: function(a) {
                        var b = l(a.ownParams, a.ownParams.$$keys());
                        return a.parent && a.parent.params ? R(a.parent.params.$$new(), b) : new U.ParamSet
                    },
                    views: function(a) {
                        var b = {};
                        return Q(L(a.views) ? a.views : {
                            "": a
                        }, function(c, d) {
                            d.indexOf("@") < 0 && (d += "@" + a.parent.name), b[d] = c
                        }), b
                    },
                    path: function(a) {
                        return a.parent ? a.parent.path.concat(a) : []
                    },
                    includes: function(a) {
                        var b = a.parent ? R({}, a.parent.includes) : {};
                        return b[a.name] = !0, b
                    },
                    $delegates: {}
                };
            x = q({
                name: "",
                url: "^",
                views: null,
                "abstract": !0
            }), x.navigable = null, this.decorator = t, this.state = u, this.$get = v, v.$inject = ["$rootScope", "$q", "$view", "$injector", "$resolve", "$stateParams", "$urlRouter", "$location", "$urlMatcherFactory"]
        }

        function w() {
            function a(a, b) {
                return {
                    load: function(a, c) {
                        var d, e = {
                            template: null,
                            controller: null,
                            view: null,
                            locals: null,
                            notify: !0,
                            async: !0,
                            params: {}
                        };
                        return c = R(e, c), c.view && (d = b.fromConfig(c.view, c.params, c.locals)), d
                    }
                }
            }
            this.$get = a, a.$inject = ["$rootScope", "$templateFactory"]
        }

        function x() {
            var a = !1;
            this.useAnchorScroll = function() {
                a = !0
            }, this.$get = ["$anchorScroll", "$timeout", function(b, c) {
                return a ? b : function(a) {
                    return c(function() {
                        a[0].scrollIntoView()
                    }, 0, !1)
                }
            }]
        }

        function y(a, c, d, e) {
            function f() {
                return c.has ? function(a) {
                    return c.has(a) ? c.get(a) : null
                } : function(a) {
                    try {
                        return c.get(a)
                    } catch (b) {
                        return null
                    }
                }
            }

            function g(a, c) {
                function d(a) {
                    return 1 === V && W >= 4 ? !!j.enabled(a) : 1 === V && W >= 2 ? !!j.enabled() : !!i
                }
                var e = {
                    enter: function(a, b, c) {
                        b.after(a), c()
                    },
                    leave: function(a, b) {
                        a.remove(), b()
                    }
                };
                if (a.noanimation) return e;
                if (j) return {
                    enter: function(a, c, f) {
                        d(a) ? b.version.minor > 2 ? j.enter(a, null, c).then(f) : j.enter(a, null, c, f) : e.enter(a, c, f)
                    },
                    leave: function(a, c) {
                        d(a) ? b.version.minor > 2 ? j.leave(a).then(c) : j.leave(a, c) : e.leave(a, c)
                    }
                };
                if (i) {
                    var f = i && i(c, a);
                    return {
                        enter: function(a, b, c) {
                            f.enter(a, null, b), c()
                        },
                        leave: function(a, b) {
                            f.leave(a), b()
                        }
                    }
                }
                return e
            }
            var h = f(),
                i = h("$animator"),
                j = h("$animate"),
                k = {
                    restrict: "ECA",
                    terminal: !0,
                    priority: 400,
                    transclude: "element",
                    compile: function(c, f, h) {
                        return function(c, f, i) {
                            function j() {
                                function a() {
                                    b && b.remove(), c && c.$destroy()
                                }
                                var b = l,
                                    c = n;
                                c && (c._willBeDestroyed = !0), m ? (r.leave(m, function() {
                                    a(), l = null
                                }), l = m) : (a(), l = null), m = null, n = null
                            }

                            function k(g) {
                                var k, l = A(c, i, f, e),
                                    s = l && a.$current && a.$current.locals[l];
                                if ((g || s !== o) && !c._willBeDestroyed) {
                                    k = c.$new(), o = a.$current.locals[l], k.$emit("$viewContentLoading", l);
                                    var t = h(k, function(a) {
                                        r.enter(a, f, function() {
                                            n && n.$emit("$viewContentAnimationEnded"), (b.isDefined(q) && !q || c.$eval(q)) && d(a)
                                        }), j()
                                    });
                                    m = t, n = k, n.$emit("$viewContentLoaded", l), n.$eval(p)
                                }
                            }
                            var l, m, n, o, p = i.onload || "",
                                q = i.autoscroll,
                                r = g(i, c);
                            c.$on("$stateChangeSuccess", function() {
                                k(!1)
                            }), k(!0)
                        }
                    }
                };
            return k
        }

        function z(a, b, c, d) {
            return {
                restrict: "ECA",
                priority: -400,
                compile: function(e) {
                    var f = e.html();
                    return function(e, g, h) {
                        var i = c.$current,
                            j = A(e, h, g, d),
                            k = i && i.locals[j];
                        if (k) {
                            g.data("$uiView", {
                                name: j,
                                state: k.$$state
                            }), g.html(k.$template ? k.$template : f);
                            var l = a(g.contents());
                            if (k.$$controller) {
                                k.$scope = e, k.$element = g;
                                var m = b(k.$$controller, k);
                                k.$$controllerAs && (e[k.$$controllerAs] = m), g.data("$ngControllerController", m), g.children().data("$ngControllerController", m)
                            }
                            l(e)
                        }
                    }
                }
            }
        }

        function A(a, b, c, d) {
            var e = d(b.uiView || b.name || "")(a),
                f = c.inheritedData("$uiView");
            return e.indexOf("@") >= 0 ? e : e + "@" + (f ? f.state.name : "")
        }

        function B(a, b) {
            var c, d = a.match(/^\s*({[^}]*})\s*$/);
            if (d && (a = b + "(" + d[1] + ")"), c = a.replace(/\n/g, " ").match(/^([^(]+?)\s*(\((.*)\))?$/), !c || 4 !== c.length) throw new Error("Invalid state ref '" + a + "'");
            return {
                state: c[1],
                paramExpr: c[3] || null
            }
        }

        function C(a) {
            var b = a.parent().inheritedData("$uiView");
            return b && b.state && b.state.name ? b.state : void 0
        }

        function D(a) {
            var b = "[object SVGAnimatedString]" === Object.prototype.toString.call(a.prop("href")),
                c = "FORM" === a[0].nodeName;
            return {
                attr: c ? "action" : b ? "xlink:href" : "href",
                isAnchor: "A" === a.prop("tagName").toUpperCase(),
                clickable: !c
            }
        }

        function E(a, b, c, d, e) {
            return function(f) {
                var g = f.which || f.button,
                    h = e();
                if (!(g > 1 || f.ctrlKey || f.metaKey || f.shiftKey || a.attr("target"))) {
                    var i = c(function() {
                        b.go(h.state, h.params, h.options)
                    });
                    f.preventDefault();
                    var j = d.isAnchor && !h.href ? 1 : 0;
                    f.preventDefault = function() {
                        j-- <= 0 && c.cancel(i)
                    }
                }
            }
        }

        function F(a, b) {
            return {
                relative: C(a) || b.$current,
                inherit: !0
            }
        }

        function G(a, c) {
            return {
                restrict: "A",
                require: ["?^uiSrefActive", "?^uiSrefActiveEq"],
                link: function(d, e, f, g) {
                    var h = B(f.uiSref, a.current.name),
                        i = {
                            state: h.state,
                            href: null,
                            params: null
                        },
                        j = D(e),
                        k = g[1] || g[0];
                    i.options = R(F(e, a), f.uiSrefOpts ? d.$eval(f.uiSrefOpts) : {});
                    var l = function(c) {
                        c && (i.params = b.copy(c)), i.href = a.href(h.state, i.params, i.options), k && k.$$addStateInfo(h.state, i.params), null !== i.href && f.$set(j.attr, i.href)
                    };
                    h.paramExpr && (d.$watch(h.paramExpr, function(a) {
                        a !== i.params && l(a)
                    }, !0), i.params = b.copy(d.$eval(h.paramExpr))), l(), j.clickable && e.bind("click", E(e, a, c, j, function() {
                        return i
                    }))
                }
            }
        }

        function H(a, b) {
            return {
                restrict: "A",
                require: ["?^uiSrefActive", "?^uiSrefActiveEq"],
                link: function(c, d, e, f) {
                    function g(b) {
                        l.state = b[0], l.params = b[1], l.options = b[2], l.href = a.href(l.state, l.params, l.options), i && i.$$addStateInfo(l.state, l.params), l.href && e.$set(h.attr, l.href)
                    }
                    var h = D(d),
                        i = f[1] || f[0],
                        j = [e.uiState, e.uiStateParams || null, e.uiStateOpts || null],
                        k = "[" + j.map(function(a) {
                            return a || "null"
                        }).join(", ") + "]",
                        l = {
                            state: null,
                            params: null,
                            options: null,
                            href: null
                        };
                    c.$watch(k, g, !0), g(c.$eval(k)), h.clickable && d.bind("click", E(d, a, b, h, function() {
                        return l
                    }))
                }
            }
        }

        function I(a, b, c) {
            return {
                restrict: "A",
                controller: ["$scope", "$element", "$attrs", "$timeout", function(b, d, e, f) {
                    function g(b, c, e) {
                        var f = a.get(b, C(d)),
                            g = h(b, c);
                        p.push({
                            state: f || {
                                name: b
                            },
                            params: c,
                            hash: g
                        }), q[g] = e
                    }

                    function h(a, c) {
                        if (!N(a)) throw new Error("state should be a string");
                        return O(c) ? a + T(c) : (c = b.$eval(c), O(c) ? a + T(c) : a)
                    }

                    function i() {
                        for (var a = 0; a < p.length; a++) l(p[a].state, p[a].params) ? j(d, q[p[a].hash]) : k(d, q[p[a].hash]), m(p[a].state, p[a].params) ? j(d, n) : k(d, n)
                    }

                    function j(a, b) {
                        f(function() {
                            a.addClass(b)
                        })
                    }

                    function k(a, b) {
                        a.removeClass(b)
                    }

                    function l(b, c) {
                        return a.includes(b.name, c)
                    }

                    function m(b, c) {
                        return a.is(b.name, c)
                    }
                    var n, o, p = [],
                        q = {};
                    n = c(e.uiSrefActiveEq || "", !1)(b);
                    try {
                        o = b.$eval(e.uiSrefActive)
                    } catch (r) {}
                    o = o || c(e.uiSrefActive || "", !1)(b), O(o) && Q(o, function(c, d) {
                        if (N(c)) {
                            var e = B(c, a.current.name);
                            g(e.state, b.$eval(e.paramExpr), d)
                        }
                    }), this.$$addStateInfo = function(a, b) {
                        O(o) && p.length > 0 || (g(a, b, o), i())
                    }, b.$on("$stateChangeSuccess", i), i()
                }]
            }
        }

        function J(a) {
            var b = function(b, c) {
                return a.is(b, c)
            };
            return b.$stateful = !0, b
        }

        function K(a) {
            var b = function(b, c, d) {
                return a.includes(b, c, d)
            };
            return b.$stateful = !0, b
        }
        var L = b.isDefined,
            M = b.isFunction,
            N = b.isString,
            O = b.isObject,
            P = b.isArray,
            Q = b.forEach,
            R = b.extend,
            S = b.copy,
            T = b.toJson;
        b.module("ui.router.util", ["ng"]), b.module("ui.router.router", ["ui.router.util"]), b.module("ui.router.state", ["ui.router.router", "ui.router.util"]), b.module("ui.router", ["ui.router.state"]), b.module("ui.router.compat", ["ui.router"]), p.$inject = ["$q", "$injector"], b.module("ui.router.util").service("$resolve", p), q.$inject = ["$http", "$templateCache", "$injector"], b.module("ui.router.util").service("$templateFactory", q);
        var U;
        r.prototype.concat = function(a, b) {
            var c = {
                caseInsensitive: U.caseInsensitive(),
                strict: U.strictMode(),
                squash: U.defaultSquashPolicy()
            };
            return new r(this.sourcePath + a + this.sourceSearch, R(c, b), this)
        }, r.prototype.toString = function() {
            return this.source
        }, r.prototype.exec = function(a, b) {
            function c(a) {
                function b(a) {
                    return a.split("").reverse().join("")
                }

                function c(a) {
                    return a.replace(/\\-/g, "-")
                }
                var d = b(a).split(/-(?!\\)/),
                    e = o(d, b);
                return o(e, c).reverse()
            }
            var d = this.regexp.exec(a);
            if (!d) return null;
            b = b || {};
            var e, f, g, h = this.parameters(),
                i = h.length,
                j = this.segments.length - 1,
                k = {};
            if (j !== d.length - 1) throw new Error("Unbalanced capture group in route '" + this.source + "'");
            var l, m;
            for (e = 0; j > e; e++) {
                for (g = h[e], l = this.params[g], m = d[e + 1], f = 0; f < l.replace.length; f++) l.replace[f].from === m && (m = l.replace[f].to);
                m && l.array === !0 && (m = c(m)), L(m) && (m = l.type.decode(m)), k[g] = l.value(m)
            }
            for (; i > e; e++) {
                for (g = h[e], k[g] = this.params[g].value(b[g]), l = this.params[g], m = b[g], f = 0; f < l.replace.length; f++) l.replace[f].from === m && (m = l.replace[f].to);
                L(m) && (m = l.type.decode(m)), k[g] = l.value(m)
            }
            return k
        }, r.prototype.parameters = function(a) {
            return L(a) ? this.params[a] || null : this.$$paramNames
        }, r.prototype.validates = function(a) {
            return this.params.$$validates(a)
        }, r.prototype.format = function(a) {
            function b(a) {
                return encodeURIComponent(a).replace(/-/g, function(a) {
                    return "%5C%" + a.charCodeAt(0).toString(16).toUpperCase()
                })
            }
            a = a || {};
            var c = this.segments,
                d = this.parameters(),
                e = this.params;
            if (!this.validates(a)) return null;
            var f, g = !1,
                h = c.length - 1,
                i = d.length,
                j = c[0];
            for (f = 0; i > f; f++) {
                var k = h > f,
                    l = d[f],
                    m = e[l],
                    n = m.value(a[l]),
                    p = m.isOptional && m.type.equals(m.value(), n),
                    q = p ? m.squash : !1,
                    r = m.type.encode(n);
                if (k) {
                    var s = c[f + 1],
                        t = f + 1 === h;
                    if (q === !1) null != r && (j += P(r) ? o(r, b).join("-") : encodeURIComponent(r)), j += s;
                    else if (q === !0) {
                        var u = j.match(/\/$/) ? /\/?(.*)/ : /(.*)/;
                        j += s.match(u)[1]
                    } else N(q) && (j += q + s);
                    t && m.squash === !0 && "/" === j.slice(-1) && (j = j.slice(0, -1))
                } else {
                    if (null == r || p && q !== !1) continue;
                    if (P(r) || (r = [r]), 0 === r.length) continue;
                    r = o(r, encodeURIComponent).join("&" + l + "="), j += (g ? "&" : "?") + (l + "=" + r), g = !0
                }
            }
            return j
        }, s.prototype.is = function(a, b) {
            return !0
        }, s.prototype.encode = function(a, b) {
            return a
        }, s.prototype.decode = function(a, b) {
            return a
        }, s.prototype.equals = function(a, b) {
            return a == b
        }, s.prototype.$subPattern = function() {
            var a = this.pattern.toString();
            return a.substr(1, a.length - 2)
        }, s.prototype.pattern = /.*/, s.prototype.toString = function() {
            return "{Type:" + this.name + "}"
        }, s.prototype.$normalize = function(a) {
            return this.is(a) ? a : this.decode(a)
        }, s.prototype.$asArray = function(a, b) {
            function d(a, b) {
                function d(a, b) {
                    return function() {
                        return a[b].apply(a, arguments)
                    }
                }

                function e(a) {
                    return P(a) ? a : L(a) ? [a] : []
                }

                function f(a) {
                    switch (a.length) {
                        case 0:
                            return c;
                        case 1:
                            return "auto" === b ? a[0] : a;
                        default:
                            return a
                    }
                }

                function g(a) {
                    return !a
                }

                function h(a, b) {
                    return function(c) {
                        if (P(c) && 0 === c.length) return c;
                        c = e(c);
                        var d = o(c, a);
                        return b === !0 ? 0 === n(d, g).length : f(d)
                    }
                }

                function i(a) {
                    return function(b, c) {
                        var d = e(b),
                            f = e(c);
                        if (d.length !== f.length) return !1;
                        for (var g = 0; g < d.length; g++)
                            if (!a(d[g], f[g])) return !1;
                        return !0
                    }
                }
                this.encode = h(d(a, "encode")), this.decode = h(d(a, "decode")), this.is = h(d(a, "is"), !0), this.equals = i(d(a, "equals")), this.pattern = a.pattern, this.$normalize = h(d(a, "$normalize")), this.name = a.name, this.$arrayMode = b
            }
            if (!a) return this;
            if ("auto" === a && !b) throw new Error("'auto' array mode is for query parameters only");
            return new d(this, a)
        }, b.module("ui.router.util").provider("$urlMatcherFactory", t), b.module("ui.router.util").run(["$urlMatcherFactory", function(a) {}]), u.$inject = ["$locationProvider", "$urlMatcherFactoryProvider"], b.module("ui.router.router").provider("$urlRouter", u), v.$inject = ["$urlRouterProvider", "$urlMatcherFactoryProvider"], b.module("ui.router.state").factory("$stateParams", function() {
            return {}
        }).provider("$state", v), w.$inject = [], b.module("ui.router.state").provider("$view", w), b.module("ui.router.state").provider("$uiViewScroll", x);
        var V = b.version.major,
            W = b.version.minor;
        y.$inject = ["$state", "$injector", "$uiViewScroll", "$interpolate"], z.$inject = ["$compile", "$controller", "$state", "$interpolate"], b.module("ui.router.state").directive("uiView", y), b.module("ui.router.state").directive("uiView", z), G.$inject = ["$state", "$timeout"], H.$inject = ["$state", "$timeout"], I.$inject = ["$state", "$stateParams", "$interpolate"], b.module("ui.router.state").directive("uiSref", G).directive("uiSrefActive", I).directive("uiSrefActiveEq", I).directive("uiState", H), J.$inject = ["$state"], K.$inject = ["$state"], b.module("ui.router.state").filter("isState", J).filter("includedByState", K)
    }(window, window.angular), ! function() {
        "use strict";
        var a = {
                backspace: 8,
                tab: 9,
                enter: 13,
                escape: 27,
                space: 32,
                up: 38,
                down: 40,
                left: 37,
                right: 39,
                "delete": 46,
                comma: 188
            },
            b = 9007199254740991,
            c = ["text", "email", "url"],
            d = angular.module("ngTagsInput", []);
        d.directive("tagsInput", ["$timeout", "$document", "$window", "tagsInputConfig", "tiUtil", function(d, e, f, g, h) {
            function i(a, b, c, d) {
                var e, f, g, i = {};
                return e = function(b) {
                    return h.safeToString(b[a.displayProperty])
                }, f = function(b, c) {
                    b[a.displayProperty] = c
                }, g = function(b) {
                    var d = e(b);
                    return d && d.length >= a.minLength && d.length <= a.maxLength && a.allowedTagsPattern.test(d) && !h.findInObjectArray(i.items, b, a.keyProperty || a.displayProperty) && c({
                        $tag: b
                    })
                }, i.items = [], i.addText = function(a) {
                    var b = {};
                    return f(b, a), i.add(b)
                }, i.add = function(c) {
                    var d = e(c);
                    return a.replaceSpacesWithDashes && (d = h.replaceSpacesWithDashes(d)), f(c, d), g(c) ? (i.items.push(c), b.trigger("tag-added", {
                        $tag: c
                    })) : d && b.trigger("invalid-tag", {
                        $tag: c
                    }), c
                }, i.remove = function(a) {
                    var c = i.items[a];
                    return d({
                        $tag: c
                    }) ? (i.items.splice(a, 1), i.clearSelection(), b.trigger("tag-removed", {
                        $tag: c
                    }), c) : void 0
                }, i.select = function(a) {
                    0 > a ? a = i.items.length - 1 : a >= i.items.length && (a = 0), i.index = a, i.selected = i.items[a]
                }, i.selectPrior = function() {
                    i.select(--i.index)
                }, i.selectNext = function() {
                    i.select(++i.index)
                }, i.removeSelected = function() {
                    return i.remove(i.index)
                }, i.clearSelection = function() {
                    i.selected = null, i.index = -1
                }, i.clearSelection(), i
            }

            function j(a) {
                return -1 !== c.indexOf(a)
            }
            return {
                restrict: "E",
                require: "ngModel",
                scope: {
                    tags: "=ngModel",
                    onTagAdding: "&",
                    onTagAdded: "&",
                    onInvalidTag: "&",
                    onTagRemoving: "&",
                    onTagRemoved: "&"
                },
                replace: !1,
                transclude: !0,
                templateUrl: "ngTagsInput/tags-input.html",
                controller: ["$scope", "$attrs", "$element", function(a, c, d) {
                    a.events = h.simplePubSub(), g.load("tagsInput", a, c, {
                        template: [String, "ngTagsInput/tag-item.html"],
                        type: [String, "text", j],
                        placeholder: [String, "Add a tag"],
                        tabindex: [Number, null],
                        removeTagSymbol: [String, String.fromCharCode(215)],
                        replaceSpacesWithDashes: [Boolean, !0],
                        minLength: [Number, 3],
                        maxLength: [Number, b],
                        addOnEnter: [Boolean, !0],
                        addOnSpace: [Boolean, !1],
                        addOnComma: [Boolean, !0],
                        addOnBlur: [Boolean, !0],
                        addOnPaste: [Boolean, !1],
                        pasteSplitPattern: [RegExp, /,/],
                        allowedTagsPattern: [RegExp, /.+/],
                        enableEditingLastTag: [Boolean, !1],
                        minTags: [Number, 0],
                        maxTags: [Number, b],
                        displayProperty: [String, "text"],
                        keyProperty: [String, ""],
                        allowLeftoverText: [Boolean, !1],
                        addFromAutocompleteOnly: [Boolean, !1],
                        spellcheck: [Boolean, !0]
                    }), a.tagList = new i(a.options, a.events, h.handleUndefinedResult(a.onTagAdding, !0), h.handleUndefinedResult(a.onTagRemoving, !0)), this.registerAutocomplete = function() {
                        var b = d.find("input");
                        return {
                            addTag: function(b) {
                                return a.tagList.add(b)
                            },
                            focusInput: function() {
                                b[0].focus()
                            },
                            getTags: function() {
                                return a.tags
                            },
                            getCurrentTagText: function() {
                                return a.newTag.text
                            },
                            getOptions: function() {
                                return a.options
                            },
                            on: function(b, c) {
                                return a.events.on(b, c), this
                            }
                        }
                    }, this.registerTagItem = function() {
                        return {
                            getOptions: function() {
                                return a.options
                            },
                            removeTag: function(b) {
                                a.disabled || a.tagList.remove(b)
                            }
                        }
                    }
                }],
                link: function(b, c, g, i) {
                    var j, k = [a.enter, a.comma, a.space, a.backspace, a["delete"], a.left, a.right],
                        l = b.tagList,
                        m = b.events,
                        n = b.options,
                        o = c.find("input"),
                        p = ["minTags", "maxTags", "allowLeftoverText"];
                    j = function() {
                        i.$setValidity("maxTags", b.tags.length <= n.maxTags), i.$setValidity("minTags", b.tags.length >= n.minTags), i.$setValidity("leftoverText", b.hasFocus || n.allowLeftoverText ? !0 : !b.newTag.text)
                    }, i.$isEmpty = function(a) {
                        return !a || !a.length
                    }, b.newTag = {
                        text: "",
                        invalid: null,
                        setText: function(a) {
                            this.text = a, m.trigger("input-change", a)
                        }
                    }, b.track = function(a) {
                        return a[n.keyProperty || n.displayProperty]
                    }, b.$watch("tags", function(a) {
                        b.tags = h.makeObjectArray(a, n.displayProperty), l.items = b.tags
                    }), b.$watch("tags.length", function() {
                        j()
                    }), g.$observe("disabled", function(a) {
                        b.disabled = a
                    }), b.eventHandlers = {
                        input: {
                            change: function(a) {
                                m.trigger("input-change", a)
                            },
                            keydown: function(a) {
                                m.trigger("input-keydown", a)
                            },
                            focus: function() {
                                b.hasFocus || (b.hasFocus = !0, m.trigger("input-focus"))
                            },
                            blur: function() {
                                d(function() {
                                    var a = e.prop("activeElement"),
                                        d = a === o[0],
                                        f = c[0].contains(a);
                                    (d || !f) && (b.hasFocus = !1, m.trigger("input-blur"))
                                })
                            },
                            paste: function(a) {
                                a.getTextData = function() {
                                    var b = a.clipboardData || a.originalEvent && a.originalEvent.clipboardData;
                                    return b ? b.getData("text/plain") : f.clipboardData.getData("Text")
                                }, m.trigger("input-paste", a)
                            }
                        },
                        host: {
                            click: function() {
                                b.disabled || o[0].focus()
                            }
                        }
                    }, m.on("tag-added", b.onTagAdded).on("invalid-tag", b.onInvalidTag).on("tag-removed", b.onTagRemoved).on("tag-added", function() {
                        b.newTag.setText("")
                    }).on("tag-added tag-removed", function() {
                        i.$setViewValue(b.tags)
                    }).on("invalid-tag", function() {
                        b.newTag.invalid = !0
                    }).on("option-change", function(a) {
                        -1 !== p.indexOf(a.name) && j()
                    }).on("input-change", function() {
                        l.clearSelection(), b.newTag.invalid = null
                    }).on("input-focus", function() {
                        c.triggerHandler("focus"), i.$setValidity("leftoverText", !0)
                    }).on("input-blur", function() {
                        n.addOnBlur && !n.addFromAutocompleteOnly && l.addText(b.newTag.text), c.triggerHandler("blur"), j()
                    }).on("input-keydown", function(c) {
                        var d, e, f, g, h = c.keyCode,
                            i = c.shiftKey || c.altKey || c.ctrlKey || c.metaKey,
                            j = {};
                        if (!i && -1 !== k.indexOf(h)) {
                            if (j[a.enter] = n.addOnEnter, j[a.comma] = n.addOnComma, j[a.space] = n.addOnSpace, d = !n.addFromAutocompleteOnly && j[h], e = (h === a.backspace || h === a["delete"]) && l.selected, g = h === a.backspace && 0 === b.newTag.text.length && n.enableEditingLastTag, f = (h === a.backspace || h === a.left || h === a.right) && 0 === b.newTag.text.length && !n.enableEditingLastTag, d) l.addText(b.newTag.text);
                            else if (g) {
                                var m;
                                l.selectPrior(), m = l.removeSelected(), m && b.newTag.setText(m[n.displayProperty])
                            } else e ? l.removeSelected() : f && (h === a.left || h === a.backspace ? l.selectPrior() : h === a.right && l.selectNext());
                            (d || f || e || g) && c.preventDefault()
                        }
                    }).on("input-paste", function(a) {
                        if (n.addOnPaste) {
                            var b = a.getTextData(),
                                c = b.split(n.pasteSplitPattern);
                            c.length > 1 && (c.forEach(function(a) {
                                l.addText(a)
                            }), a.preventDefault())
                        }
                    })
                }
            }
        }]), d.directive("tiTagItem", ["tiUtil", function(a) {
            return {
                restrict: "E",
                require: "^tagsInput",
                template: '<ng-include src="$$template"></ng-include>',
                scope: {
                    data: "="
                },
                link: function(b, c, d, e) {
                    var f = e.registerTagItem(),
                        g = f.getOptions();
                    b.$$template = g.template, b.$$removeTagSymbol = g.removeTagSymbol, b.$getDisplayText = function() {
                        return a.safeToString(b.data[g.displayProperty])
                    }, b.$removeTag = function() {
                        f.removeTag(b.$index)
                    }, b.$watch("$parent.$index", function(a) {
                        b.$index = a
                    })
                }
            }
        }]), d.directive("autoComplete", ["$document", "$timeout", "$sce", "$q", "tagsInputConfig", "tiUtil", function(b, c, d, e, f, g) {
            function h(a, b, c) {
                var d, f, h, i = {};
                return h = function() {
                    return b.tagsInput.keyProperty || b.tagsInput.displayProperty
                }, d = function(a, c) {
                    return a.filter(function(a) {
                        return !g.findInObjectArray(c, a, h(), function(a, c) {
                            return b.tagsInput.replaceSpacesWithDashes && (a = g.replaceSpacesWithDashes(a), c = g.replaceSpacesWithDashes(c)), g.defaultComparer(a, c)
                        })
                    })
                }, i.reset = function() {
                    f = null, i.items = [], i.visible = !1, i.index = -1, i.selected = null, i.query = null
                }, i.show = function() {
                    b.selectFirstMatch ? i.select(0) : i.selected = null, i.visible = !0
                }, i.load = g.debounce(function(c, j) {
                    i.query = c;
                    var k = e.when(a({
                        $query: c
                    }));
                    f = k, k.then(function(a) {
                        k === f && (a = g.makeObjectArray(a.data || a, h()), a = d(a, j), i.items = a.slice(0, b.maxResultsToShow), i.items.length > 0 ? i.show() : i.reset())
                    })
                }, b.debounceDelay), i.selectNext = function() {
                    i.select(++i.index)
                }, i.selectPrior = function() {
                    i.select(--i.index)
                }, i.select = function(a) {
                    0 > a ? a = i.items.length - 1 : a >= i.items.length && (a = 0), i.index = a, i.selected = i.items[a], c.trigger("suggestion-selected", a)
                }, i.reset(), i
            }

            function i(a, b) {
                var c = a.find("li").eq(b),
                    d = c.parent(),
                    e = c.prop("offsetTop"),
                    f = c.prop("offsetHeight"),
                    g = d.prop("clientHeight"),
                    h = d.prop("scrollTop");
                h > e ? d.prop("scrollTop", e) : e + f > g + h && d.prop("scrollTop", e + f - g)
            }
            return {
                restrict: "E",
                require: "^tagsInput",
                scope: {
                    source: "&"
                },
                templateUrl: "ngTagsInput/auto-complete.html",
                controller: ["$scope", "$element", "$attrs", function(a, b, c) {
                    a.events = g.simplePubSub(), f.load("autoComplete", a, c, {
                        template: [String, "ngTagsInput/auto-complete-match.html"],
                        debounceDelay: [Number, 100],
                        minLength: [Number, 3],
                        highlightMatchedText: [Boolean, !0],
                        maxResultsToShow: [Number, 10],
                        loadOnDownArrow: [Boolean, !1],
                        loadOnEmpty: [Boolean, !1],
                        loadOnFocus: [Boolean, !1],
                        selectFirstMatch: [Boolean, !0],
                        displayProperty: [String, ""]
                    }), a.suggestionList = new h(a.source, a.options, a.events), this.registerAutocompleteMatch = function() {
                        return {
                            getOptions: function() {
                                return a.options
                            },
                            getQuery: function() {
                                return a.suggestionList.query
                            }
                        }
                    }
                }],
                link: function(b, c, d, e) {
                    var f, g = [a.enter, a.tab, a.escape, a.up, a.down],
                        h = b.suggestionList,
                        j = e.registerAutocomplete(),
                        k = b.options,
                        l = b.events;
                    k.tagsInput = j.getOptions(), f = function(a) {
                        return a && a.length >= k.minLength || !a && k.loadOnEmpty
                    }, b.addSuggestionByIndex = function(a) {
                        h.select(a), b.addSuggestion()
                    }, b.addSuggestion = function() {
                        var a = !1;
                        return h.selected && (j.addTag(angular.copy(h.selected)), h.reset(), j.focusInput(), a = !0), a
                    }, b.track = function(a) {
                        return a[k.tagsInput.keyProperty || k.tagsInput.displayProperty]
                    }, j.on("tag-added invalid-tag input-blur", function() {
                        h.reset()
                    }).on("input-change", function(a) {
                        f(a) ? h.load(a, j.getTags()) : h.reset()
                    }).on("input-focus", function() {
                        var a = j.getCurrentTagText();
                        k.loadOnFocus && f(a) && h.load(a, j.getTags())
                    }).on("input-keydown", function(c) {
                        var d = c.keyCode,
                            e = !1;
                        return -1 !== g.indexOf(d) ? (h.visible ? d === a.down ? (h.selectNext(), e = !0) : d === a.up ? (h.selectPrior(), e = !0) : d === a.escape ? (h.reset(), e = !0) : (d === a.enter || d === a.tab) && (e = b.addSuggestion()) : d === a.down && b.options.loadOnDownArrow && (h.load(j.getCurrentTagText(), j.getTags()), e = !0), e ? (c.preventDefault(), c.stopImmediatePropagation(), !1) : void 0) : void 0
                    }), l.on("suggestion-selected", function(a) {
                        i(c, a)
                    })
                }
            }
        }]), d.directive("tiAutocompleteMatch", ["$sce", "tiUtil", function(a, b) {
            return {
                restrict: "E",
                require: "^autoComplete",
                template: '<ng-include src="$$template"></ng-include>',
                scope: {
                    data: "="
                },
                link: function(c, d, e, f) {
                    var g = f.registerAutocompleteMatch(),
                        h = g.getOptions();
                    c.$$template = h.template, c.$index = c.$parent.$index, c.$highlight = function(c) {
                        return h.highlightMatchedText && (c = b.safeHighlight(c, g.getQuery())), a.trustAsHtml(c)
                    }, c.$getDisplayText = function() {
                        return b.safeToString(c.data[h.displayProperty || h.tagsInput.displayProperty])
                    }
                }
            }
        }]), d.directive("tiTranscludeAppend", function() {
            return function(a, b, c, d, e) {
                e(function(a) {
                    b.append(a)
                })
            }
        }), d.directive("tiAutosize", ["tagsInputConfig", function(a) {
            return {
                restrict: "A",
                require: "ngModel",
                link: function(b, c, d, e) {
                    var f, g, h = a.getTextAutosizeThreshold();
                    f = angular.element('<span class="input"></span>'), f.css("display", "none").css("visibility", "hidden").css("width", "auto").css("white-space", "pre"), c.parent().append(f), g = function(a) {
                        var b, e = a;
                        return angular.isString(e) && 0 === e.length && (e = d.placeholder), e && (f.text(e), f.css("display", ""), b = f.prop("offsetWidth"), f.css("display", "none")), c.css("width", b ? b + h + "px" : ""), a
                    }, e.$parsers.unshift(g), e.$formatters.unshift(g), d.$observe("placeholder", function(a) {
                        e.$modelValue || g(a)
                    })
                }
            }
        }]), d.directive("tiBindAttrs", function() {
            return function(a, b, c) {
                a.$watch(c.tiBindAttrs, function(a) {
                    angular.forEach(a, function(a, b) {
                        c.$set(b, a)
                    })
                }, !0)
            }
        }), d.provider("tagsInputConfig", function() {
            var a = {},
                b = {},
                c = 3;
            this.setDefaults = function(b, c) {
                return a[b] = c, this
            }, this.setActiveInterpolation = function(a, c) {
                return b[a] = c, this
            }, this.setTextAutosizeThreshold = function(a) {
                return c = a, this
            }, this.$get = ["$interpolate", function(d) {
                var e = {};
                return e[String] = function(a) {
                    return a
                }, e[Number] = function(a) {
                    return parseInt(a, 10)
                }, e[Boolean] = function(a) {
                    return "true" === a.toLowerCase()
                }, e[RegExp] = function(a) {
                    return new RegExp(a)
                }, {
                    load: function(c, f, g, h) {
                        var i = function() {
                            return !0
                        };
                        f.options = {}, angular.forEach(h, function(h, j) {
                            var k, l, m, n, o, p;
                            k = h[0], l = h[1], m = h[2] || i, n = e[k], o = function() {
                                var b = a[c] && a[c][j];
                                return angular.isDefined(b) ? b : l
                            }, p = function(a) {
                                f.options[j] = a && m(a) ? n(a) : o()
                            }, b[c] && b[c][j] ? g.$observe(j, function(a) {
                                p(a), f.events.trigger("option-change", {
                                    name: j,
                                    newValue: a
                                })
                            }) : p(g[j] && d(g[j])(f.$parent))
                        })
                    },
                    getTextAutosizeThreshold: function() {
                        return c
                    }
                }
            }]
        }), d.factory("tiUtil", ["$timeout", function(a) {
            var b = {};
            return b.debounce = function(b, c) {
                var d;
                return function() {
                    var e = arguments;
                    a.cancel(d), d = a(function() {
                        b.apply(null, e)
                    }, c)
                }
            }, b.makeObjectArray = function(a, b) {
                return a = a || [], a.length > 0 && !angular.isObject(a[0]) && a.forEach(function(c, d) {
                    a[d] = {}, a[d][b] = c
                }), a
            }, b.findInObjectArray = function(a, c, d, e) {
                var f = null;
                return e = e || b.defaultComparer, a.some(function(a) {
                    return e(a[d], c[d]) ? (f = a, !0) : void 0
                }), f
            }, b.defaultComparer = function(a, c) {
                return b.safeToString(a).toLowerCase() === b.safeToString(c).toLowerCase()
            }, b.safeHighlight = function(a, c) {
                function d(a) {
                    return a.replace(/([.?*+^$[\]\\(){}|-])/g, "\\$1")
                }
                if (!c) return a;
                a = b.encodeHTML(a), c = b.encodeHTML(c);
                var e = new RegExp("&[^;]+;|" + d(c), "gi");
                return a.replace(e, function(a) {
                    return a.toLowerCase() === c.toLowerCase() ? "<em>" + a + "</em>" : a
                })
            }, b.safeToString = function(a) {
                return angular.isUndefined(a) || null == a ? "" : a.toString().trim()
            }, b.encodeHTML = function(a) {
                return b.safeToString(a).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
            }, b.handleUndefinedResult = function(a, b) {
                return function() {
                    var c = a.apply(null, arguments);
                    return angular.isUndefined(c) ? b : c
                }
            }, b.replaceSpacesWithDashes = function(a) {
                return b.safeToString(a).replace(/\s/g, "-")
            }, b.simplePubSub = function() {
                var a = {};
                return {
                    on: function(b, c) {
                        return b.split(" ").forEach(function(b) {
                            a[b] || (a[b] = []), a[b].push(c)
                        }), this
                    },
                    trigger: function(c, d) {
                        var e = a[c] || [];
                        return e.every(function(a) {
                            return b.handleUndefinedResult(a, !0)(d)
                        }), this
                    }
                }
            }, b
        }]), d.run(["$templateCache", function(a) {
            a.put("ngTagsInput/tags-input.html", '<div class="host" tabindex="-1" ng-click="eventHandlers.host.click()" ti-transclude-append=""><div class="tags" ng-class="{focused: hasFocus}"><ul class="tag-list"><li class="tag-item" ng-repeat="tag in tagList.items track by track(tag)" ng-class="{ selected: tag == tagList.selected }"><ti-tag-item data="tag"></ti-tag-item></li></ul><input class="input" autocomplete="off" ng-model="newTag.text" ng-change="eventHandlers.input.change(newTag.text)" ng-keydown="eventHandlers.input.keydown($event)" ng-focus="eventHandlers.input.focus($event)" ng-blur="eventHandlers.input.blur($event)" ng-paste="eventHandlers.input.paste($event)" ng-trim="false" ng-class="{\'invalid-tag\': newTag.invalid}" ng-disabled="disabled" ti-bind-attrs="{type: options.type, placeholder: options.placeholder, tabindex: options.tabindex, spellcheck: options.spellcheck}" ti-autosize=""></div></div>'), a.put("ngTagsInput/tag-item.html", '<span ng-bind="$getDisplayText()"></span> <a class="remove-button" ng-click="$removeTag()" ng-bind="$$removeTagSymbol"></a>'), a.put("ngTagsInput/auto-complete.html", '<div class="autocomplete" ng-if="suggestionList.visible"><ul class="suggestion-list"><li class="suggestion-item" ng-repeat="item in suggestionList.items track by track(item)" ng-class="{selected: item == suggestionList.selected}" ng-click="addSuggestionByIndex($index)" ng-mouseenter="suggestionList.select($index)"><ti-autocomplete-match data="item"></ti-autocomplete-match></li></ul></div>'), a.put("ngTagsInput/auto-complete-match.html", '<span ng-bind-html="$highlight($getDisplayText())"></span>')
        }])
    }(), angular.module("toggle-switch", ["ng"]).directive("toggleSwitch", ["$compile", function(a) {
        return {
            restrict: "EA",
            replace: !0,
            require: "ngModel",
            scope: {
                isDisabled: "=",
                onLabel: "@",
                offLabel: "@",
                knobLabel: "@",
                html: "=",
                onChange: "&"
            },
            template: '<div class="ats-switch" ng-click="toggle()" ng-keypress="onKeyPress($event)" ng-class="{ \'disabled\': isDisabled }" role="switch" aria-checked="{{!!model}}"><div class="switch-animate" ng-class="{\'switch-off\': !model, \'switch-on\': model}"><span class="switch-left"></span><span class="knob"></span><span class="switch-right"></span></div></div>',
            compile: function(b, c) {
                return angular.isUndefined(c.onLabel) && (c.onLabel = "On"), angular.isUndefined(c.offLabel) && (c.offLabel = "Off"), angular.isUndefined(c.knobLabel) && (c.knobLabel = " "), angular.isUndefined(c.isDisabled) && (c.isDisabled = !1), angular.isUndefined(c.html) && (c.html = !1), angular.isUndefined(c.tabindex) && (c.tabindex = 0),
                    function(b, d, e, f) {
                        d.attr("tabindex", c.tabindex), b.toggle = function() {
                            b.isDisabled || (b.model = !b.model, f.$setViewValue(b.model)), b.onChange()
                        };
                        var g = 32;
                        b.onKeyPress = function(a) {
                            a.charCode != g || a.altKey || a.ctrlKey || a.metaKey || b.toggle()
                        }, f.$formatters.push(function(a) {
                            return a
                        }), f.$parsers.push(function(a) {
                            return a
                        }), f.$viewChangeListeners.push(function() {
                            b.$eval(c.ngChange)
                        }), f.$render = function() {
                            b.model = f.$viewValue
                        };
                        var h = function(c, d) {
                                c = angular.element(c);
                                var e = d === !0 ? "ng-bind-html" : "ng-bind";
                                c.removeAttr("ng-bind-html"), c.removeAttr("ng-bind"), angular.element(c).hasClass("switch-left") && c.attr(e, "onLabel"), c.hasClass("knob") && c.attr(e, "knobLabel"), c.hasClass("switch-right") && c.attr(e, "offLabel"), a(c)(b, function(a, b) {
                                    c.replaceWith(a)
                                })
                            },
                            i = function(a, b) {
                                angular.forEach(a[0].children[0].children, function(a, c) {
                                    h(a, b)
                                })
                            };
                        b.$watch("html", function(a) {
                            i(d, a)
                        })
                    }
            }
        }
    }]),
    function() {
        "use strict";
        var a = {
            TAB: 9,
            ENTER: 13,
            ESC: 27,
            SPACE: 32,
            LEFT: 37,
            UP: 38,
            RIGHT: 39,
            DOWN: 40,
            SHIFT: 16,
            CTRL: 17,
            ALT: 18,
            PAGE_UP: 33,
            PAGE_DOWN: 34,
            HOME: 36,
            END: 35,
            BACKSPACE: 8,
            DELETE: 46,
            COMMAND: 91,
            MAP: {
                91: "COMMAND",
                8: "BACKSPACE",
                9: "TAB",
                13: "ENTER",
                16: "SHIFT",
                17: "CTRL",
                18: "ALT",
                19: "PAUSEBREAK",
                20: "CAPSLOCK",
                27: "ESC",
                32: "SPACE",
                33: "PAGE_UP",
                34: "PAGE_DOWN",
                35: "END",
                36: "HOME",
                37: "LEFT",
                38: "UP",
                39: "RIGHT",
                40: "DOWN",
                43: "+",
                44: "PRINTSCREEN",
                45: "INSERT",
                46: "DELETE",
                48: "0",
                49: "1",
                50: "2",
                51: "3",
                52: "4",
                53: "5",
                54: "6",
                55: "7",
                56: "8",
                57: "9",
                59: ";",
                61: "=",
                65: "A",
                66: "B",
                67: "C",
                68: "D",
                69: "E",
                70: "F",
                71: "G",
                72: "H",
                73: "I",
                74: "J",
                75: "K",
                76: "L",
                77: "M",
                78: "N",
                79: "O",
                80: "P",
                81: "Q",
                82: "R",
                83: "S",
                84: "T",
                85: "U",
                86: "V",
                87: "W",
                88: "X",
                89: "Y",
                90: "Z",
                96: "0",
                97: "1",
                98: "2",
                99: "3",
                100: "4",
                101: "5",
                102: "6",
                103: "7",
                104: "8",
                105: "9",
                106: "*",
                107: "+",
                109: "-",
                110: ".",
                111: "/",
                112: "F1",
                113: "F2",
                114: "F3",
                115: "F4",
                116: "F5",
                117: "F6",
                118: "F7",
                119: "F8",
                120: "F9",
                121: "F10",
                122: "F11",
                123: "F12",
                144: "NUMLOCK",
                145: "SCROLLLOCK",
                186: ";",
                187: "=",
                188: ",",
                189: "-",
                190: ".",
                191: "/",
                192: "`",
                219: "[",
                220: "\\",
                221: "]",
                222: "'"
            },
            isControl: function(b) {
                var c = b.which;
                switch (c) {
                    case a.COMMAND:
                    case a.SHIFT:
                    case a.CTRL:
                    case a.ALT:
                        return !0
                }
                return b.metaKey ? !0 : !1
            },
            isFunctionKey: function(a) {
                return a = a.which ? a.which : a, a >= 112 && 123 >= a
            },
            isVerticalMovement: function(b) {
                return ~[a.UP, a.DOWN].indexOf(b)
            },
            isHorizontalMovement: function(b) {
                return ~[a.LEFT, a.RIGHT, a.BACKSPACE, a.DELETE].indexOf(b)
            }
        };
        void 0 === angular.element.prototype.querySelectorAll && (angular.element.prototype.querySelectorAll = function(a) {
            return angular.element(this[0].querySelectorAll(a))
        }), void 0 === angular.element.prototype.closest && (angular.element.prototype.closest = function(a) {
            for (var b = this[0], c = b.matches || b.webkitMatchesSelector || b.mozMatchesSelector || b.msMatchesSelector; b;) {
                if (c.bind(b)(a)) return b;
                b = b.parentElement
            }
            return !1
        });
        var b = 0,
            c = angular.module("ui.select", []).constant("uiSelectConfig", {
                theme: "bootstrap",
                searchEnabled: !0,
                sortable: !1,
                placeholder: "",
                refreshDelay: 1e3,
                closeOnSelect: !0,
                generateId: function() {
                    return b++
                },
                appendToBody: !1
            }).service("uiSelectMinErr", function() {
                var a = angular.$$minErr("ui.select");
                return function() {
                    var b = a.apply(this, arguments),
                        c = b.message.replace(new RegExp("\nhttp://errors.angularjs.org/.*"), "");
                    return new Error(c)
                }
            }).directive("uisTranscludeAppend", function() {
                return {
                    link: function(a, b, c, d, e) {
                        e(a, function(a) {
                            b.append(a)
                        })
                    }
                }
            }).filter("highlight", function() {
                function a(a) {
                    return a.replace(/([.?*+^$[\]\\(){}|-])/g, "\\$1")
                }
                return function(b, c) {
                    return c && b ? b.replace(new RegExp(a(c), "gi"), '<span class="ui-select-highlight">$&</span>') : b
                }
            }).factory("uisOffset", ["$document", "$window", function(a, b) {
                return function(c) {
                    var d = c[0].getBoundingClientRect();
                    return {
                        width: d.width || c.prop("offsetWidth"),
                        height: d.height || c.prop("offsetHeight"),
                        top: d.top + (b.pageYOffset || a[0].documentElement.scrollTop),
                        left: d.left + (b.pageXOffset || a[0].documentElement.scrollLeft)
                    }
                }
            }]);
        c.directive("uiSelectChoices", ["uiSelectConfig", "uisRepeatParser", "uiSelectMinErr", "$compile", function(a, b, c, d) {
            return {
                restrict: "EA",
                require: "^uiSelect",
                replace: !0,
                transclude: !0,
                templateUrl: function(b) {
                    var c = b.parent().attr("theme") || a.theme;
                    return c + "/choices.tpl.html"
                },
                compile: function(e, f) {
                    if (!f.repeat) throw c("repeat", "Expected 'repeat' expression.");
                    return function(e, f, g, h, i) {
                        var j = g.groupBy;
                        if (h.parseRepeatAttr(g.repeat, j), h.disableChoiceExpression = g.uiDisableChoice, h.onHighlightCallback = g.onHighlight, j) {
                            var k = f.querySelectorAll(".ui-select-choices-group");
                            if (1 !== k.length) throw c("rows", "Expected 1 .ui-select-choices-group but got '{0}'.", k.length);
                            k.attr("ng-repeat", b.getGroupNgRepeatExpression())
                        }
                        var l = f.querySelectorAll(".ui-select-choices-row");
                        if (1 !== l.length) throw c("rows", "Expected 1 .ui-select-choices-row but got '{0}'.", l.length);
                        l.attr("ng-repeat", b.getNgRepeatExpression(h.parserResult.itemName, "$select.items", h.parserResult.trackByExp, j)).attr("ng-if", "$select.open").attr("ng-mouseenter", "$select.setActiveItem(" + h.parserResult.itemName + ")").attr("ng-click", "$select.select(" + h.parserResult.itemName + ",false,$event)");
                        var m = f.querySelectorAll(".ui-select-choices-row-inner");
                        if (1 !== m.length) throw c("rows", "Expected 1 .ui-select-choices-row-inner but got '{0}'.", m.length);
                        m.attr("uis-transclude-append", ""), d(f, i)(e), e.$watch("$select.search", function(a) {
                            a && !h.open && h.multiple && h.activate(!1, !0), h.activeIndex = h.tagging.isActivated ? -1 : 0, h.refresh(g.refresh)
                        }), g.$observe("refreshDelay", function() {
                            var b = e.$eval(g.refreshDelay);
                            h.refreshDelay = void 0 !== b ? b : a.refreshDelay
                        })
                    }
                }
            }
        }]), c.controller("uiSelectCtrl", ["$scope", "$element", "$timeout", "$filter", "uisRepeatParser", "uiSelectMinErr", "uiSelectConfig", function(b, c, d, e, f, g, h) {
            function i() {
                (l.resetSearchInput || void 0 === l.resetSearchInput && h.resetSearchInput) && (l.search = m, l.selected && l.items.length && !l.multiple && (l.activeIndex = l.items.indexOf(l.selected)))
            }

            function j(b) {
                var c = !0;
                switch (b) {
                    case a.DOWN:
                        !l.open && l.multiple ? l.activate(!1, !0) : l.activeIndex < l.items.length - 1 && l.activeIndex++;
                        break;
                    case a.UP:
                        !l.open && l.multiple ? l.activate(!1, !0) : (l.activeIndex > 0 || 0 === l.search.length && l.tagging.isActivated && l.activeIndex > -1) && l.activeIndex--;
                        break;
                    case a.TAB:
                        (!l.multiple || l.open) && l.select(l.items[l.activeIndex], !0);
                        break;
                    case a.ENTER:
                        l.open && l.activeIndex >= 0 ? l.select(l.items[l.activeIndex]) : l.activate(!1, !0);
                        break;
                    case a.ESC:
                        l.close();
                        break;
                    default:
                        c = !1
                }
                return c
            }

            function k() {
                var a = c.querySelectorAll(".ui-select-choices-content"),
                    b = a.querySelectorAll(".ui-select-choices-row");
                if (b.length < 1) throw g("choices", "Expected multiple .ui-select-choices-row but got '{0}'.", b.length);
                if (!(l.activeIndex < 0)) {
                    var d = b[l.activeIndex],
                        e = d.offsetTop + d.clientHeight - a[0].scrollTop,
                        f = a[0].offsetHeight;
                    e > f ? a[0].scrollTop += e - f : e < d.clientHeight && (l.isGrouped && 0 === l.activeIndex ? a[0].scrollTop = 0 : a[0].scrollTop -= d.clientHeight - e)
                }
            }
            var l = this,
                m = "";
            if (l.placeholder = h.placeholder, l.searchEnabled = h.searchEnabled, l.sortable = h.sortable, l.refreshDelay = h.refreshDelay, l.removeSelected = !1, l.closeOnSelect = !0, l.search = m, l.activeIndex = 0, l.items = [], l.open = !1, l.focus = !1, l.disabled = !1, l.selected = void 0, l.focusser = void 0, l.resetSearchInput = !0, l.multiple = void 0, l.disableChoiceExpression = void 0, l.tagging = {
                    isActivated: !1,
                    fct: void 0
                }, l.taggingTokens = {
                    isActivated: !1,
                    tokens: void 0
                }, l.lockChoiceExpression = void 0, l.clickTriggeredSelect = !1, l.$filter = e, l.searchInput = c.querySelectorAll("input.ui-select-search"), 1 !== l.searchInput.length) throw g("searchInput", "Expected 1 input.ui-select-search but got '{0}'.", l.searchInput.length);
            l.isEmpty = function() {
                return angular.isUndefined(l.selected) || null === l.selected || "" === l.selected
            }, l.activate = function(a, c) {
                l.disabled || l.open || (c || i(), b.$broadcast("uis:activate"), l.open = !0, l.activeIndex = l.activeIndex >= l.items.length ? 0 : l.activeIndex, -1 === l.activeIndex && l.taggingLabel !== !1 && (l.activeIndex = 0), d(function() {
                    l.search = a || l.search, l.searchInput[0].focus()
                }))
            }, l.findGroupByName = function(a) {
                return l.groups && l.groups.filter(function(b) {
                    return b.name === a
                })[0]
            }, l.parseRepeatAttr = function(a, c) {
                function d(a) {
                    l.groups = [], angular.forEach(a, function(a) {
                        var d = b.$eval(c),
                            e = angular.isFunction(d) ? d(a) : a[d],
                            f = l.findGroupByName(e);
                        f ? f.items.push(a) : l.groups.push({
                            name: e,
                            items: [a]
                        })
                    }), l.items = [], l.groups.forEach(function(a) {
                        l.items = l.items.concat(a.items)
                    })
                }

                function e(a) {
                    l.items = a
                }
                l.setItemsFn = c ? d : e, l.parserResult = f.parse(a), l.isGrouped = !!c, l.itemProperty = l.parserResult.itemName, l.refreshItems = function(a) {
                    a = a || l.parserResult.source(b);
                    var c = l.selected;
                    if (angular.isArray(c) && !c.length || !l.removeSelected) l.setItemsFn(a);
                    else if (void 0 !== a) {
                        var d = a.filter(function(a) {
                            return c.indexOf(a) < 0
                        });
                        l.setItemsFn(d)
                    }
                }, b.$watchCollection(l.parserResult.source, function(a) {
                    if (void 0 === a || null === a) l.items = [];
                    else {
                        if (!angular.isArray(a)) throw g("items", "Expected an array but got '{0}'.", a);
                        l.refreshItems(a), l.ngModel.$modelValue = null
                    }
                })
            };
            var n;
            l.refresh = function(a) {
                void 0 !== a && (n && d.cancel(n), n = d(function() {
                    b.$eval(a)
                }, l.refreshDelay))
            }, l.setActiveItem = function(a) {
                l.activeIndex = l.items.indexOf(a)
            }, l.isActive = function(a) {
                if (!l.open) return !1;
                var b = l.items.indexOf(a[l.itemProperty]),
                    c = b === l.activeIndex;
                return !c || 0 > b && l.taggingLabel !== !1 || 0 > b && l.taggingLabel === !1 ? !1 : (c && !angular.isUndefined(l.onHighlightCallback) && a.$eval(l.onHighlightCallback), c)
            }, l.isDisabled = function(a) {
                if (l.open) {
                    var b, c = l.items.indexOf(a[l.itemProperty]),
                        d = !1;
                    return c >= 0 && !angular.isUndefined(l.disableChoiceExpression) && (b = l.items[c], d = !!a.$eval(l.disableChoiceExpression), b._uiSelectChoiceDisabled = d), d
                }
            }, l.select = function(a, c, e) {
                if (void 0 === a || !a._uiSelectChoiceDisabled) {
                    if (!l.items && !l.search) return;
                    if (!a || !a._uiSelectChoiceDisabled) {
                        if (l.tagging.isActivated) {
                            if (l.taggingLabel === !1)
                                if (l.activeIndex < 0) {
                                    if (a = void 0 !== l.tagging.fct ? l.tagging.fct(l.search) : l.search, !a || angular.equals(l.items[0], a)) return
                                } else a = l.items[l.activeIndex];
                            else if (0 === l.activeIndex) {
                                if (void 0 === a) return;
                                if (void 0 !== l.tagging.fct && "string" == typeof a) {
                                    if (a = l.tagging.fct(l.search), !a) return
                                } else "string" == typeof a && (a = a.replace(l.taggingLabel, "").trim())
                            }
                            if (l.selected && angular.isArray(l.selected) && l.selected.filter(function(b) {
                                    return angular.equals(b, a)
                                }).length > 0) return void l.close(c)
                        }
                        b.$broadcast("uis:select", a);
                        var f = {};
                        f[l.parserResult.itemName] = a, d(function() {
                            l.onSelectCallback(b, {
                                $item: a,
                                $model: l.parserResult.modelMapper(b, f)
                            })
                        }), l.closeOnSelect && l.close(c), e && "click" === e.type && (l.clickTriggeredSelect = !0)
                    }
                }
            }, l.close = function(a) {
                l.open && (l.ngModel && l.ngModel.$setTouched && l.ngModel.$setTouched(), i(), l.open = !1, b.$broadcast("uis:close", a))
            }, l.setFocus = function() {
                l.focus || l.focusInput[0].focus()
            }, l.clear = function(a) {
                l.select(void 0), a.stopPropagation(), l.focusser[0].focus()
            }, l.toggle = function(a) {
                l.open ? (l.close(), a.preventDefault(), a.stopPropagation()) : l.activate()
            }, l.isLocked = function(a, b) {
                var c, d = l.selected[b];
                return d && !angular.isUndefined(l.lockChoiceExpression) && (c = !!a.$eval(l.lockChoiceExpression), d._uiSelectChoiceLocked = c), c
            };
            var o = null;
            l.sizeSearchInput = function() {
                var a = l.searchInput[0],
                    c = l.searchInput.parent().parent()[0],
                    e = function() {
                        return c.clientWidth * !!a.offsetParent
                    },
                    f = function(b) {
                        if (0 === b) return !1;
                        var c = b - a.offsetLeft - 10;
                        return 50 > c && (c = b), l.searchInput.css("width", c + "px"), !0
                    };
                l.searchInput.css("width", "10px"), d(function() {
                    null !== o || f(e()) || (o = b.$watch(e, function(a) {
                        f(a) && (o(), o = null)
                    }))
                })
            }, l.searchInput.on("keydown", function(c) {
                var e = c.which;
                b.$apply(function() {
                    var b = !1;
                    if ((l.items.length > 0 || l.tagging.isActivated) && (j(e), l.taggingTokens.isActivated)) {
                        for (var f = 0; f < l.taggingTokens.tokens.length; f++) l.taggingTokens.tokens[f] === a.MAP[c.keyCode] && l.search.length > 0 && (b = !0);
                        b && d(function() {
                            l.searchInput.triggerHandler("tagged");
                            var b = l.search.replace(a.MAP[c.keyCode], "").trim();
                            l.tagging.fct && (b = l.tagging.fct(b)), b && l.select(b, !0)
                        })
                    }
                }), a.isVerticalMovement(e) && l.items.length > 0 && k()
            }), l.searchInput.on("paste", function(a) {
                var b = a.originalEvent.clipboardData.getData("text/plain");
                if (b && b.length > 0 && l.taggingTokens.isActivated && l.tagging.fct) {
                    var c = b.split(l.taggingTokens.tokens[0]);
                    c && c.length > 0 && (angular.forEach(c, function(a) {
                        var b = l.tagging.fct(a);
                        b && l.select(b, !0)
                    }), a.preventDefault(), a.stopPropagation())
                }
            }), l.searchInput.on("tagged", function() {
                d(function() {
                    i()
                })
            }), b.$on("$destroy", function() {
                l.searchInput.off("keyup keydown tagged blur paste")
            })
        }]), c.directive("uiSelect", ["$document", "uiSelectConfig", "uiSelectMinErr", "uisOffset", "$compile", "$parse", "$timeout", function(a, b, c, d, e, f, g) {
            return {
                restrict: "EA",
                templateUrl: function(a, c) {
                    var d = c.theme || b.theme;
                    return d + (angular.isDefined(c.multiple) ? "/select-multiple.tpl.html" : "/select.tpl.html")
                },
                replace: !0,
                transclude: !0,
                require: ["uiSelect", "^ngModel"],
                scope: !0,
                controller: "uiSelectCtrl",
                controllerAs: "$select",
                compile: function(e, h) {
                    return angular.isDefined(h.multiple) ? e.append("<ui-select-multiple/>").removeAttr("multiple") : e.append("<ui-select-single/>"),
                        function(e, h, i, j, k) {
                            function l(a) {
                                if (o.open) {
                                    var b = !1;
                                    if (b = window.jQuery ? window.jQuery.contains(h[0], a.target) : h[0].contains(a.target), !b && !o.clickTriggeredSelect) {
                                        var c = ["input", "button", "textarea"],
                                            d = angular.element(a.target).scope(),
                                            f = d && d.$select && d.$select !== o;
                                        f || (f = ~c.indexOf(a.target.tagName.toLowerCase())), o.close(f), e.$digest()
                                    }
                                    o.clickTriggeredSelect = !1
                                }
                            }

                            function m() {
                                var b = d(h);
                                r = angular.element('<div class="ui-select-placeholder"></div>'), r[0].style.width = b.width + "px", r[0].style.height = b.height + "px", h.after(r), s = h[0].style.width, a.find("body").append(h), h[0].style.position = "absolute", h[0].style.left = b.left + "px", h[0].style.top = b.top + "px", h[0].style.width = b.width + "px"
                            }

                            function n() {
                                null !== r && (r.replaceWith(h), r = null, h[0].style.position = "", h[0].style.left = "", h[0].style.top = "", h[0].style.width = s)
                            }
                            var o = j[0],
                                p = j[1];
                            o.generatedId = b.generateId(), o.baseTitle = i.title || "Select box", o.focusserTitle = o.baseTitle + " focus", o.focusserId = "focusser-" + o.generatedId, o.closeOnSelect = function() {
                                return angular.isDefined(i.closeOnSelect) ? f(i.closeOnSelect)() : b.closeOnSelect
                            }(), o.onSelectCallback = f(i.onSelect), o.onRemoveCallback = f(i.onRemove), o.ngModel = p, o.choiceGrouped = function(a) {
                                return o.isGrouped && a && a.name
                            }, i.tabindex && i.$observe("tabindex", function(a) {
                                o.focusInput.attr("tabindex", a), h.removeAttr("tabindex")
                            }), e.$watch("searchEnabled", function() {
                                var a = e.$eval(i.searchEnabled);
                                o.searchEnabled = void 0 !== a ? a : b.searchEnabled
                            }), e.$watch("sortable", function() {
                                var a = e.$eval(i.sortable);
                                o.sortable = void 0 !== a ? a : b.sortable
                            }), i.$observe("disabled", function() {
                                o.disabled = void 0 !== i.disabled ? i.disabled : !1
                            }), i.$observe("resetSearchInput", function() {
                                var a = e.$eval(i.resetSearchInput);
                                o.resetSearchInput = void 0 !== a ? a : !0
                            }), i.$observe("tagging", function() {
                                if (void 0 !== i.tagging) {
                                    var a = e.$eval(i.tagging);
                                    o.tagging = {
                                        isActivated: !0,
                                        fct: a !== !0 ? a : void 0
                                    }
                                } else o.tagging = {
                                    isActivated: !1,
                                    fct: void 0
                                }
                            }), i.$observe("taggingLabel", function() {
                                void 0 !== i.tagging && ("false" === i.taggingLabel ? o.taggingLabel = !1 : o.taggingLabel = void 0 !== i.taggingLabel ? i.taggingLabel : "(new)")
                            }), i.$observe("taggingTokens", function() {
                                if (void 0 !== i.tagging) {
                                    var a = void 0 !== i.taggingTokens ? i.taggingTokens.split("|") : [",", "ENTER"];
                                    o.taggingTokens = {
                                        isActivated: !0,
                                        tokens: a
                                    }
                                }
                            }), angular.isDefined(i.autofocus) && g(function() {
                                o.setFocus()
                            }), angular.isDefined(i.focusOn) && e.$on(i.focusOn, function() {
                                g(function() {
                                    o.setFocus()
                                })
                            }), a.on("click", l), e.$on("$destroy", function() {
                                a.off("click", l)
                            }), k(e, function(a) {
                                var b = angular.element("<div>").append(a),
                                    d = b.querySelectorAll(".ui-select-match");
                                if (d.removeAttr("ui-select-match"), d.removeAttr("data-ui-select-match"), 1 !== d.length) throw c("transcluded", "Expected 1 .ui-select-match but got '{0}'.", d.length);
                                h.querySelectorAll(".ui-select-match").replaceWith(d);
                                var e = b.querySelectorAll(".ui-select-choices");
                                if (e.removeAttr("ui-select-choices"), e.removeAttr("data-ui-select-choices"), 1 !== e.length) throw c("transcluded", "Expected 1 .ui-select-choices but got '{0}'.", e.length);
                                h.querySelectorAll(".ui-select-choices").replaceWith(e)
                            });
                            var q = e.$eval(i.appendToBody);
                            (void 0 !== q ? q : b.appendToBody) && (e.$watch("$select.open", function(a) {
                                a ? m() : n()
                            }), e.$on("$destroy", function() {
                                n()
                            }));
                            var r = null,
                                s = ""
                        }
                }
            }
        }]), c.directive("uiSelectMatch", ["uiSelectConfig", function(a) {
            return {
                restrict: "EA",
                require: "^uiSelect",
                replace: !0,
                transclude: !0,
                templateUrl: function(b) {
                    var c = b.parent().attr("theme") || a.theme,
                        d = b.parent().attr("multiple");
                    return c + (d ? "/match-multiple.tpl.html" : "/match.tpl.html")
                },
                link: function(b, c, d, e) {
                    function f(a) {
                        e.allowClear = angular.isDefined(a) ? "" === a ? !0 : "true" === a.toLowerCase() : !1
                    }
                    e.lockChoiceExpression = d.uiLockChoice, d.$observe("placeholder", function(b) {
                        e.placeholder = void 0 !== b ? b : a.placeholder
                    }), d.$observe("allowClear", f), f(d.allowClear), e.multiple && e.sizeSearchInput()
                }
            }
        }]), c.directive("uiSelectMultiple", ["uiSelectMinErr", "$timeout", function(b, c) {
            return {
                restrict: "EA",
                require: ["^uiSelect", "^ngModel"],
                controller: ["$scope", "$timeout", function(a, b) {
                    var c, d = this,
                        e = a.$select;
                    a.$evalAsync(function() {
                        c = a.ngModel
                    }), d.activeMatchIndex = -1, d.updateModel = function() {
                        c.$setViewValue(Date.now()), d.refreshComponent()
                    }, d.refreshComponent = function() {
                        e.refreshItems(), e.sizeSearchInput()
                    }, d.removeChoice = function(c) {
                        var f = e.selected[c];
                        if (!f._uiSelectChoiceLocked) {
                            var g = {};
                            g[e.parserResult.itemName] = f, e.selected.splice(c, 1), d.activeMatchIndex = -1, e.sizeSearchInput(), b(function() {
                                e.onRemoveCallback(a, {
                                    $item: f,
                                    $model: e.parserResult.modelMapper(a, g)
                                })
                            }), d.updateModel()
                        }
                    }, d.getPlaceholder = function() {
                        return e.selected.length ? void 0 : e.placeholder
                    }
                }],
                controllerAs: "$selectMultiple",
                link: function(d, e, f, g) {
                    function h(a) {
                        return angular.isNumber(a.selectionStart) ? a.selectionStart : a.value.length
                    }

                    function i(b) {
                        function c() {
                            switch (b) {
                                case a.LEFT:
                                    return ~n.activeMatchIndex ? k : g;
                                case a.RIGHT:
                                    return ~n.activeMatchIndex && i !== g ? j : (l.activate(), !1);
                                case a.BACKSPACE:
                                    return ~n.activeMatchIndex ? (n.removeChoice(i), k) : g;
                                case a.DELETE:
                                    return ~n.activeMatchIndex ? (n.removeChoice(n.activeMatchIndex), i) : !1
                            }
                        }
                        var d = h(l.searchInput[0]),
                            e = l.selected.length,
                            f = 0,
                            g = e - 1,
                            i = n.activeMatchIndex,
                            j = n.activeMatchIndex + 1,
                            k = n.activeMatchIndex - 1,
                            m = i;
                        return d > 0 || l.search.length && b == a.RIGHT ? !1 : (l.close(), m = c(), l.selected.length && m !== !1 ? n.activeMatchIndex = Math.min(g, Math.max(f, m)) : n.activeMatchIndex = -1, !0)
                    }

                    function j(a) {
                        if (void 0 === a || void 0 === l.search) return !1;
                        var b = a.filter(function(a) {
                            return void 0 === l.search.toUpperCase() || void 0 === a ? !1 : a.toUpperCase() === l.search.toUpperCase()
                        }).length > 0;
                        return b
                    }

                    function k(a, b) {
                        var c = -1;
                        if (angular.isArray(a))
                            for (var d = angular.copy(a), e = 0; e < d.length; e++)
                                if (void 0 === l.tagging.fct) d[e] + " " + l.taggingLabel === b && (c = e);
                                else {
                                    var f = d[e];
                                    f.isTag = !0, angular.equals(f, b) && (c = e)
                                }
                        return c
                    }
                    var l = g[0],
                        m = d.ngModel = g[1],
                        n = d.$selectMultiple;
                    l.multiple = !0, l.removeSelected = !0, l.focusInput = l.searchInput, m.$parsers.unshift(function() {
                        for (var a, b = {}, c = [], e = l.selected.length - 1; e >= 0; e--) b = {}, b[l.parserResult.itemName] = l.selected[e], a = l.parserResult.modelMapper(d, b), c.unshift(a);
                        return c
                    }), m.$formatters.unshift(function(a) {
                        var b, c = l.parserResult.source(d, {
                                $select: {
                                    search: ""
                                }
                            }),
                            e = {};
                        if (!c) return a;
                        var f = [],
                            g = function(a, c) {
                                if (a && a.length) {
                                    for (var g = a.length - 1; g >= 0; g--) {
                                        if (e[l.parserResult.itemName] = a[g], b = l.parserResult.modelMapper(d, e), l.parserResult.trackByExp) {
                                            var h = /\.(.+)/.exec(l.parserResult.trackByExp);
                                            if (h.length > 0 && b[h[1]] == c[h[1]]) return f.unshift(a[g]), !0
                                        }
                                        if (angular.equals(b, c)) return f.unshift(a[g]), !0
                                    }
                                    return !1
                                }
                            };
                        if (!a) return f;
                        for (var h = a.length - 1; h >= 0; h--) g(l.selected, a[h]) || g(c, a[h]) || f.unshift(a[h]);
                        return f
                    }), d.$watchCollection(function() {
                        return m.$modelValue
                    }, function(a, b) {
                        b != a && (m.$modelValue = null, n.refreshComponent())
                    }), m.$render = function() {
                        if (!angular.isArray(m.$viewValue)) {
                            if (!angular.isUndefined(m.$viewValue) && null !== m.$viewValue) throw b("multiarr", "Expected model value to be array but got '{0}'", m.$viewValue);
                            l.selected = []
                        }
                        l.selected = m.$viewValue, d.$evalAsync()
                    }, d.$on("uis:select", function(a, b) {
                        l.selected.push(b), n.updateModel()
                    }), d.$on("uis:activate", function() {
                        n.activeMatchIndex = -1
                    }), d.$watch("$select.disabled", function(a, b) {
                        b && !a && l.sizeSearchInput()
                    }), l.searchInput.on("keydown", function(b) {
                        var c = b.which;
                        d.$apply(function() {
                            var d = !1;
                            a.isHorizontalMovement(c) && (d = i(c)), d && c != a.TAB && (b.preventDefault(), b.stopPropagation())
                        })
                    }), l.searchInput.on("keyup", function(b) {
                        if (a.isVerticalMovement(b.which) || d.$evalAsync(function() {
                                l.activeIndex = l.taggingLabel === !1 ? -1 : 0
                            }), l.tagging.isActivated && l.search.length > 0) {
                            if (b.which === a.TAB || a.isControl(b) || a.isFunctionKey(b) || b.which === a.ESC || a.isVerticalMovement(b.which)) return;
                            if (l.activeIndex = l.taggingLabel === !1 ? -1 : 0, l.taggingLabel === !1) return;
                            var c, e, f, g, h = angular.copy(l.items),
                                i = angular.copy(l.items),
                                m = !1,
                                n = -1;
                            if (void 0 !== l.tagging.fct) {
                                if (f = l.$filter("filter")(h, {
                                        isTag: !0
                                    }), f.length > 0 && (g = f[0]), h.length > 0 && g && (m = !0, h = h.slice(1, h.length), i = i.slice(1, i.length)), c = l.tagging.fct(l.search), c.isTag = !0, i.filter(function(a) {
                                        return angular.equals(a, l.tagging.fct(l.search))
                                    }).length > 0) return;
                                c.isTag = !0
                            } else {
                                if (f = l.$filter("filter")(h, function(a) {
                                        return a.match(l.taggingLabel)
                                    }), f.length > 0 && (g = f[0]), e = h[0], void 0 !== e && h.length > 0 && g && (m = !0, h = h.slice(1, h.length), i = i.slice(1, i.length)), c = l.search + " " + l.taggingLabel, k(l.selected, l.search) > -1) return;
                                if (j(i.concat(l.selected))) return void(m && (h = i, d.$evalAsync(function() {
                                    l.activeIndex = 0, l.items = h
                                })));
                                if (j(i)) return void(m && (l.items = i.slice(1, i.length)))
                            }
                            m && (n = k(l.selected, c)), n > -1 ? h = h.slice(n + 1, h.length - 1) : (h = [], h.push(c), h = h.concat(i)), d.$evalAsync(function() {
                                l.activeIndex = 0, l.items = h
                            })
                        }
                    }), l.searchInput.on("blur", function() {
                        c(function() {
                            n.activeMatchIndex = -1
                        })
                    })
                }
            }
        }]), c.directive("uiSelectSingle", ["$timeout", "$compile", function(b, c) {
            return {
                restrict: "EA",
                require: ["^uiSelect", "^ngModel"],
                link: function(d, e, f, g) {
                    var h = g[0],
                        i = g[1];
                    i.$parsers.unshift(function(a) {
                        var b, c = {};
                        return c[h.parserResult.itemName] = a, b = h.parserResult.modelMapper(d, c)
                    }), i.$formatters.unshift(function(a) {
                        var b, c = h.parserResult.source(d, {
                                $select: {
                                    search: ""
                                }
                            }),
                            e = {};
                        if (c) {
                            var f = function(c) {
                                return e[h.parserResult.itemName] = c, b = h.parserResult.modelMapper(d, e), b == a
                            };
                            if (h.selected && f(h.selected)) return h.selected;
                            for (var g = c.length - 1; g >= 0; g--)
                                if (f(c[g])) return c[g]
                        }
                        return a
                    }), d.$watch("$select.selected", function(a) {
                        i.$viewValue !== a && i.$setViewValue(a)
                    }), i.$render = function() {
                        h.selected = i.$viewValue
                    }, d.$on("uis:select", function(a, b) {
                        h.selected = b
                    }), d.$on("uis:close", function(a, c) {
                        b(function() {
                            h.focusser.prop("disabled", !1), c || h.focusser[0].focus()
                        }, 0, !1)
                    }), d.$on("uis:activate", function() {
                        j.prop("disabled", !0)
                    });
                    var j = angular.element("<input ng-disabled='$select.disabled' class='ui-select-focusser ui-select-offscreen' type='text' id='{{ $select.focusserId }}' aria-label='{{ $select.focusserTitle }}' aria-haspopup='true' role='button' />");
                    c(j)(d), h.focusser = j, h.focusInput = j, e.parent().append(j), j.bind("focus", function() {
                        d.$evalAsync(function() {
                            h.focus = !0
                        })
                    }), j.bind("blur", function() {
                        d.$evalAsync(function() {
                            h.focus = !1
                        })
                    }), j.bind("keydown", function(b) {
                        return b.which === a.BACKSPACE ? (b.preventDefault(), b.stopPropagation(), h.select(void 0), void d.$apply()) : void(b.which === a.TAB || a.isControl(b) || a.isFunctionKey(b) || b.which === a.ESC || ((b.which == a.DOWN || b.which == a.UP || b.which == a.ENTER || b.which == a.SPACE) && (b.preventDefault(), b.stopPropagation(), h.activate()), d.$digest()))
                    }), j.bind("keyup input", function(b) {
                        b.which === a.TAB || a.isControl(b) || a.isFunctionKey(b) || b.which === a.ESC || b.which == a.ENTER || b.which === a.BACKSPACE || (h.activate(j.val()), j.val(""), d.$digest())
                    })
                }
            }
        }]), c.directive("uiSelectSort", ["$timeout", "uiSelectConfig", "uiSelectMinErr", function(a, b, c) {
            return {
                require: "^uiSelect",
                link: function(b, d, e, f) {
                    if (null === b[e.uiSelectSort]) throw c("sort", "Expected a list to sort");
                    var g = angular.extend({
                            axis: "horizontal"
                        }, b.$eval(e.uiSelectSortOptions)),
                        h = g.axis,
                        i = "dragging",
                        j = "dropping",
                        k = "dropping-before",
                        l = "dropping-after";
                    b.$watch(function() {
                        return f.sortable
                    }, function(a) {
                        a ? d.attr("draggable", !0) : d.removeAttr("draggable")
                    }), d.on("dragstart", function(a) {
                        d.addClass(i), (a.dataTransfer || a.originalEvent.dataTransfer).setData("text/plain", b.$index)
                    }), d.on("dragend", function() {
                        d.removeClass(i)
                    });
                    var m, n = function(a, b) {
                            this.splice(b, 0, this.splice(a, 1)[0])
                        },
                        o = function(a) {
                            a.preventDefault();
                            var b = "vertical" === h ? a.offsetY || a.layerY || (a.originalEvent ? a.originalEvent.offsetY : 0) : a.offsetX || a.layerX || (a.originalEvent ? a.originalEvent.offsetX : 0);
                            b < this["vertical" === h ? "offsetHeight" : "offsetWidth"] / 2 ? (d.removeClass(l), d.addClass(k)) : (d.removeClass(k), d.addClass(l))
                        },
                        p = function(b) {
                            b.preventDefault();
                            var c = parseInt((b.dataTransfer || b.originalEvent.dataTransfer).getData("text/plain"), 10);
                            a.cancel(m), m = a(function() {
                                q(c)
                            }, 20)
                        },
                        q = function(a) {
                            var c = b.$eval(e.uiSelectSort),
                                f = c[a],
                                g = null;
                            g = d.hasClass(k) ? a < b.$index ? b.$index - 1 : b.$index : a < b.$index ? b.$index : b.$index + 1, n.apply(c, [a, g]), b.$apply(function() {
                                b.$emit("uiSelectSort:change", {
                                    array: c,
                                    item: f,
                                    from: a,
                                    to: g
                                })
                            }), d.removeClass(j), d.removeClass(k), d.removeClass(l), d.off("drop", p)
                        };
                    d.on("dragenter", function() {
                        d.hasClass(i) || (d.addClass(j), d.on("dragover", o), d.on("drop", p))
                    }), d.on("dragleave", function(a) {
                        a.target == d && (d.removeClass(j), d.removeClass(k), d.removeClass(l), d.off("dragover", o), d.off("drop", p))
                    })
                }
            }
        }]), c.service("uisRepeatParser", ["uiSelectMinErr", "$parse", function(a, b) {
            var c = this;
            c.parse = function(c) {
                var d = c.match(/^\s*(?:([\s\S]+?)\s+as\s+)?([\S]+?)\s+in\s+([\s\S]+?)(?:\s+track\s+by\s+([\s\S]+?))?\s*$/);
                if (!d) throw a("iexp", "Expected expression in form of '_item_ in _collection_[ track by _id_]' but got '{0}'.", c);
                return {
                    itemName: d[2],
                    source: b(d[3]),
                    trackByExp: d[4],
                    modelMapper: b(d[1] || d[2])
                }
            }, c.getGroupNgRepeatExpression = function() {
                return "$group in $select.groups"
            }, c.getNgRepeatExpression = function(a, b, c, d) {
                var e = a + " in " + (d ? "$group.items" : b);
                return c && (e += " track by " + c), e
            }
        }])
    }(), angular.module("ui.select").run(["$templateCache", function(a) {
        a.put("bootstrap/choices.tpl.html", '<ul class="ui-select-choices ui-select-choices-content dropdown-menu" role="listbox" ng-show="$select.items.length > 0"><li class="ui-select-choices-group" id="ui-select-choices-{{ $select.generatedId }}"><div class="divider" ng-show="$select.isGrouped && $index > 0"></div><div ng-show="$select.isGrouped" class="ui-select-choices-group-label dropdown-header" ng-bind="$group.name"></div><div id="ui-select-choices-row-{{ $select.generatedId }}-{{$index}}" class="ui-select-choices-row" ng-class="{active: $select.isActive(this), disabled: $select.isDisabled(this)}" role="option"><a href="javascript:void(0)" class="ui-select-choices-row-inner"></a></div></li></ul>'), a.put("bootstrap/match-multiple.tpl.html", '<span class="ui-select-match"><span ng-repeat="$item in $select.selected"><span class="ui-select-match-item btn btn-default btn-xs" tabindex="-1" type="button" ng-disabled="$select.disabled" ng-click="$selectMultiple.activeMatchIndex = $index;" ng-class="{\'btn-primary\':$selectMultiple.activeMatchIndex === $index, \'select-locked\':$select.isLocked(this, $index)}" ui-select-sort="$select.selected"><span class="close ui-select-match-close" ng-hide="$select.disabled" ng-click="$selectMultiple.removeChoice($index)">&nbsp;&times;</span> <span uis-transclude-append=""></span></span></span></span>'), a.put("bootstrap/match.tpl.html", '<div class="ui-select-match" ng-hide="$select.open" ng-disabled="$select.disabled" ng-class="{\'btn-default-focus\':$select.focus}"><span tabindex="-1" class="btn btn-default form-control ui-select-toggle" aria-label="{{ $select.baseTitle }} activate" ng-disabled="$select.disabled" ng-click="$select.activate()" style="outline: 0;"><span ng-show="$select.isEmpty()" class="ui-select-placeholder text-muted">{{$select.placeholder}}</span> <span ng-hide="$select.isEmpty()" class="ui-select-match-text pull-left" ng-class="{\'ui-select-allow-clear\': $select.allowClear && !$select.isEmpty()}" ng-transclude=""></span> <i class="caret pull-right" ng-click="$select.toggle($event)"></i> <a ng-show="$select.allowClear && !$select.isEmpty()" aria-label="{{ $select.baseTitle }} clear" style="margin-right: 10px" ng-click="$select.clear($event)" class="btn btn-xs btn-link pull-right"><i class="glyphicon glyphicon-remove" aria-hidden="true"></i></a></span></div>'), a.put("bootstrap/select-multiple.tpl.html", '<div class="ui-select-container ui-select-multiple ui-select-bootstrap dropdown form-control" ng-class="{open: $select.open}"><div><div class="ui-select-match"></div><input type="text" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" class="ui-select-search input-xs" placeholder="{{$selectMultiple.getPlaceholder()}}" ng-disabled="$select.disabled" ng-hide="$select.disabled" ng-click="$select.activate()" ng-model="$select.search" role="combobox" aria-label="{{ $select.baseTitle }}" ondrop="return false;"></div><div class="ui-select-choices"></div></div>'), a.put("bootstrap/select.tpl.html", '<div class="ui-select-container ui-select-bootstrap dropdown" ng-class="{open: $select.open}"><div class="ui-select-match"></div><input type="text" autocomplete="off" tabindex="-1" aria-expanded="true" aria-label="{{ $select.baseTitle }}" aria-owns="ui-select-choices-{{ $select.generatedId }}" aria-activedescendant="ui-select-choices-row-{{ $select.generatedId }}-{{ $select.activeIndex }}" class="form-control ui-select-search" placeholder="{{$select.placeholder}}" ng-model="$select.search" ng-show="$select.searchEnabled && $select.open"><div class="ui-select-choices"></div></div>'), a.put("select2/choices.tpl.html", '<ul class="ui-select-choices ui-select-choices-content select2-results"><li class="ui-select-choices-group" ng-class="{\'select2-result-with-children\': $select.choiceGrouped($group) }"><div ng-show="$select.choiceGrouped($group)" class="ui-select-choices-group-label select2-result-label" ng-bind="$group.name"></div><ul role="listbox" id="ui-select-choices-{{ $select.generatedId }}" ng-class="{\'select2-result-sub\': $select.choiceGrouped($group), \'select2-result-single\': !$select.choiceGrouped($group) }"><li role="option" id="ui-select-choices-row-{{ $select.generatedId }}-{{$index}}" class="ui-select-choices-row" ng-class="{\'select2-highlighted\': $select.isActive(this), \'select2-disabled\': $select.isDisabled(this)}"><div class="select2-result-label ui-select-choices-row-inner"></div></li></ul></li></ul>'), a.put("select2/match-multiple.tpl.html", '<span class="ui-select-match"><li class="ui-select-match-item select2-search-choice" ng-repeat="$item in $select.selected" ng-class="{\'select2-search-choice-focus\':$selectMultiple.activeMatchIndex === $index, \'select2-locked\':$select.isLocked(this, $index)}" ui-select-sort="$select.selected"><span uis-transclude-append=""></span> <a href="javascript:;" class="ui-select-match-close select2-search-choice-close" ng-click="$selectMultiple.removeChoice($index)" tabindex="-1"></a></li></span>'), a.put("select2/match.tpl.html", '<a class="select2-choice ui-select-match" ng-class="{\'select2-default\': $select.isEmpty()}" ng-click="$select.toggle($event)" aria-label="{{ $select.baseTitle }} select"><span ng-show="$select.isEmpty()" class="select2-chosen">{{$select.placeholder}}</span> <span ng-hide="$select.isEmpty()" class="select2-chosen" ng-transclude=""></span> <abbr ng-if="$select.allowClear && !$select.isEmpty()" class="select2-search-choice-close" ng-click="$select.clear($event)"></abbr> <span class="select2-arrow ui-select-toggle"><b></b></span></a>'), a.put("select2/select-multiple.tpl.html", '<div class="ui-select-container ui-select-multiple select2 select2-container select2-container-multi" ng-class="{\'select2-container-active select2-dropdown-open open\': $select.open, \'select2-container-disabled\': $select.disabled}"><ul class="select2-choices"><span class="ui-select-match"></span><li class="select2-search-field"><input type="text" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" role="combobox" aria-expanded="true" aria-owns="ui-select-choices-{{ $select.generatedId }}" aria-label="{{ $select.baseTitle }}" aria-activedescendant="ui-select-choices-row-{{ $select.generatedId }}-{{ $select.activeIndex }}" class="select2-input ui-select-search" placeholder="{{$selectMultiple.getPlaceholder()}}" ng-disabled="$select.disabled" ng-hide="$select.disabled" ng-model="$select.search" ng-click="$select.activate()" style="width: 34px;" ondrop="return false;"></li></ul><div class="select2-drop select2-with-searchbox select2-drop-active" ng-class="{\'select2-display-none\': !$select.open}"><div class="ui-select-choices"></div></div></div>'), a.put("select2/select.tpl.html", '<div class="ui-select-container select2 select2-container" ng-class="{\'select2-container-active select2-dropdown-open open\': $select.open, \'select2-container-disabled\': $select.disabled, \'select2-container-active\': $select.focus, \'select2-allowclear\': $select.allowClear && !$select.isEmpty()}"><div class="ui-select-match"></div><div class="select2-drop select2-with-searchbox select2-drop-active" ng-class="{\'select2-display-none\': !$select.open}"><div class="select2-search" ng-show="$select.searchEnabled"><input type="text" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" role="combobox" aria-expanded="true" aria-owns="ui-select-choices-{{ $select.generatedId }}" aria-label="{{ $select.baseTitle }}" aria-activedescendant="ui-select-choices-row-{{ $select.generatedId }}-{{ $select.activeIndex }}" class="ui-select-search select2-input" ng-model="$select.search"></div><div class="ui-select-choices"></div></div></div>'), a.put("selectize/choices.tpl.html", '<div ng-show="$select.open" class="ui-select-choices selectize-dropdown single"><div class="ui-select-choices-content selectize-dropdown-content"><div class="ui-select-choices-group optgroup" role="listbox"><div ng-show="$select.isGrouped" class="ui-select-choices-group-label optgroup-header" ng-bind="$group.name"></div><div role="option" class="ui-select-choices-row" ng-class="{active: $select.isActive(this), disabled: $select.isDisabled(this)}"><div class="option ui-select-choices-row-inner" data-selectable=""></div></div></div></div></div>'), a.put("selectize/match.tpl.html", '<div ng-hide="($select.open || $select.isEmpty())" class="ui-select-match" ng-transclude=""></div>'), a.put("selectize/select.tpl.html", '<div class="ui-select-container selectize-control single" ng-class="{\'open\': $select.open}"><div class="selectize-input" ng-class="{\'focus\': $select.open, \'disabled\': $select.disabled, \'selectize-focus\' : $select.focus}" ng-click="$select.activate()"><div class="ui-select-match"></div><input type="text" autocomplete="off" tabindex="-1" class="ui-select-search ui-select-toggle" ng-click="$select.toggle($event)" placeholder="{{$select.placeholder}}" ng-model="$select.search" ng-hide="!$select.searchEnabled || ($select.selected && !$select.open)" ng-disabled="$select.disabled" aria-label="{{ $select.baseTitle }}"></div><div class="ui-select-choices"></div></div>')
    }]), angular.module("angular-growl", []), angular.module("angular-growl").directive("growl", [function() {
        "use strict";
        return {
            restrict: "A",
            templateUrl: "templates/growl/growl.html",
            replace: !1,
            scope: {
                reference: "@",
                inline: "=",
                limitMessages: "="
            },
            controller: ["$scope", "$interval", "growl", "growlMessages", function(a, b, c, d) {
                a.referenceId = a.reference || 0, d.initDirective(a.referenceId, a.limitMessages), a.growlMessages = d, a.inlineMessage = angular.isDefined(a.inline) ? a.inline : c.inlineMessages(), a.$watch("limitMessages", function(b) {
                    var c = d.directives[a.referenceId];
                    angular.isUndefined(b) || angular.isUndefined(c) || (c.limitMessages = b)
                }), a.stopTimeoutClose = function(a) {
                    a.clickToClose || (angular.forEach(a.promises, function(a) {
                        b.cancel(a)
                    }), a.close ? d.deleteMessage(a) : a.close = !0)
                }, a.alertClasses = function(a) {
                    return {
                        "alert-success": "success" === a.severity,
                        "alert-error": "error" === a.severity,
                        "alert-danger": "error" === a.severity,
                        "alert-info": "info" === a.severity,
                        "alert-warning": "warning" === a.severity,
                        icon: a.disableIcons === !1,
                        "alert-dismissable": !a.disableCloseButton
                    }
                }, a.showCountDown = function(a) {
                    return !a.disableCountDown && a.ttl > 0
                }, a.wrapperClasses = function() {
                    var b = {};
                    return b["growl-fixed"] = !a.inlineMessage, b[c.position()] = !0, b
                }, a.computeTitle = function(a) {
                    var b = {
                        success: "Success",
                        error: "Error",
                        info: "Information",
                        warn: "Warning"
                    };
                    return b[a.severity]
                }
            }]
        }
    }]), angular.module("angular-growl").run(["$templateCache", function(a) {
        "use strict";
        void 0 === a.get("templates/growl/growl.html") && a.put("templates/growl/growl.html", '<div class="growl-container" ng-class="wrapperClasses()"><div class="growl-item alert" ng-repeat="message in growlMessages.directives[referenceId].messages" ng-class="alertClasses(message)" ng-click="stopTimeoutClose(message)"><button type="button" class="close" data-dismiss="alert" aria-hidden="true" ng-click="growlMessages.deleteMessage(message)" ng-show="!message.disableCloseButton">&times;</button><button type="button" class="close" aria-hidden="true" ng-show="showCountDown(message)">{{message.countdown}}</button><h4 class="growl-title" ng-show="message.title" ng-bind="message.title"></h4><div class="growl-message" ng-bind-html="message.text"></div></div></div>')
    }]), angular.module("angular-growl").provider("growl", function() {
        "use strict";
        var a = {
                success: null,
                error: null,
                warning: null,
                info: null
            },
            b = "messages",
            c = "text",
            d = "title",
            e = "severity",
            f = "ttl",
            g = !0,
            h = "variables",
            i = 0,
            j = !1,
            k = "top-right",
            l = !1,
            m = !1,
            n = !1,
            o = !1,
            p = !0;
        this.globalTimeToLive = function(b) {
            if ("object" == typeof b)
                for (var c in b) b.hasOwnProperty(c) && (a[c] = b[c]);
            else
                for (var d in a) a.hasOwnProperty(d) && (a[d] = b);
            return this
        }, this.globalTranslateMessages = function(a) {
            return p = a, this
        }, this.globalDisableCloseButton = function(a) {
            return l = a, this
        }, this.globalDisableIcons = function(a) {
            return m = a, this
        }, this.globalReversedOrder = function(a) {
            return n = a, this
        }, this.globalDisableCountDown = function(a) {
            return o = a, this
        }, this.messageVariableKey = function(a) {
            return h = a, this
        }, this.globalInlineMessages = function(a) {
            return j = a, this
        }, this.globalPosition = function(a) {
            return k = a, this
        }, this.messagesKey = function(a) {
            return b = a, this
        }, this.messageTextKey = function(a) {
            return c = a, this
        }, this.messageTitleKey = function(a) {
            return d = a, this
        }, this.messageSeverityKey = function(a) {
            return e = a, this
        }, this.messageTTLKey = function(a) {
            return f = a, this
        }, this.onlyUniqueMessages = function(a) {
            return g = a, this
        }, this.serverMessagesInterceptor = ["$q", "growl", function(a, c) {
            function d(a) {
                void 0 !== a && a.data && a.data[b] && a.data[b].length > 0 && c.addServerMessages(a.data[b])
            }
            return {
                response: function(a) {
                    return d(a), a
                },
                responseError: function(b) {
                    return d(b), a.reject(b)
                }
            }
        }], this.$get = ["$rootScope", "$interpolate", "$sce", "$filter", "$interval", "growlMessages", function(b, q, r, s, t, u) {
            function v(a) {
                if (H && a.translateMessage) a.text = H(a.text, a.variables) || a.text, a.title = H(a.title) || a.title;
                else {
                    var c = q(a.text);
                    a.text = c(a.variables)
                }
                var d = u.addMessage(a);
                return b.$broadcast("growlMessage", a), t(function() {}, 0, 1), d
            }

            function w(b, c, d) {
                var e, f = c || {};
                return e = {
                    text: b,
                    title: f.title,
                    severity: d,
                    ttl: f.ttl || a[d],
                    variables: f.variables || {},
                    disableCloseButton: void 0 === f.disableCloseButton ? l : f.disableCloseButton,
                    disableIcons: void 0 === f.disableIcons ? m : f.disableIcons,
                    disableCountDown: void 0 === f.disableCountDown ? o : f.disableCountDown,
                    position: f.position || k,
                    referenceId: f.referenceId || i,
                    translateMessage: void 0 === f.translateMessage ? p : f.translateMessage,
                    destroy: function() {
                        u.deleteMessage(e)
                    },
                    setText: function(a) {
                        e.text = r.trustAsHtml(String(a))
                    },
                    onclose: f.onclose,
                    onopen: f.onopen
                }, v(e)
            }

            function x(a, b) {
                return w(a, b, "warning")
            }

            function y(a, b) {
                return w(a, b, "error")
            }

            function z(a, b) {
                return w(a, b, "info")
            }

            function A(a, b) {
                return w(a, b, "success")
            }

            function B(a, b, c) {
                return c = (c || "error").toLowerCase(), w(a, b, c)
            }

            function C(a) {
                if (a && a.length) {
                    var b, g, i, j;
                    for (j = a.length, b = 0; j > b; b++)
                        if (g = a[b], g[c]) {
                            i = (g[e] || "error").toLowerCase();
                            var k = {};
                            k.variables = g[h] || {}, k.title = g[d], g[f] && (k.ttl = g[f]), w(g[c], k, i)
                        }
                }
            }

            function D() {
                return g
            }

            function E() {
                return n
            }

            function F() {
                return j
            }

            function G() {
                return k
            }
            var H;
            u.onlyUnique = g, u.reverseOrder = n;
            try {
                H = s("translate")
            } catch (I) {}
            return {
                warning: x,
                error: y,
                info: z,
                success: A,
                general: B,
                addServerMessages: C,
                onlyUnique: D,
                reverseOrder: E,
                inlineMessages: F,
                position: G
            }
        }]
    }), angular.module("angular-growl").service("growlMessages", ["$sce", "$interval", function(a, b) {
        "use strict";

        function c(a) {
            var b;
            return b = f[a] ? f[a] : f[a] = {
                messages: []
            }
        }

        function d(a) {
            var b = a || 0;
            return e.directives[b] || f[b]
        }
        var e = this;
        this.directives = {};
        var f = {};
        this.initDirective = function(a, b) {
            return f[a] ? (this.directives[a] = f[a], this.directives[a].limitMessages = b) : this.directives[a] = {
                messages: [],
                limitMessages: b
            }, this.directives[a]
        }, this.getAllMessages = function(a) {
            a = a || 0;
            var b;
            return b = d(a) ? d(a).messages : []
        }, this.destroyAllMessages = function(a) {
            for (var b = this.getAllMessages(a), c = b.length - 1; c >= 0; c--) b[c].destroy();
            var e = d(a);
            e && (e.messages = [])
        }, this.addMessage = function(d) {
            var e, f, g, h;
            if (e = this.directives[d.referenceId] ? this.directives[d.referenceId] : c(d.referenceId), f = e.messages, !this.onlyUnique || (angular.forEach(f, function(b) {
                    h = a.getTrustedHtml(b.text), d.text === h && d.severity === b.severity && d.title === b.title && (g = !0)
                }), !g)) {
                if (d.text = a.trustAsHtml(String(d.text)), d.ttl && -1 !== d.ttl && (d.countdown = d.ttl / 1e3, d.promises = [], d.close = !1, d.countdownFunction = function() {
                        d.countdown > 1 ? (d.countdown--, d.promises.push(b(d.countdownFunction, 1e3, 1, 1))) : d.countdown--
                    }), angular.isDefined(e.limitMessages)) {
                    var i = f.length - (e.limitMessages - 1);
                    i > 0 && f.splice(e.limitMessages - 1, i)
                }
                if (this.reverseOrder ? f.unshift(d) : f.push(d), "function" == typeof d.onopen && d.onopen(), d.ttl && -1 !== d.ttl) {
                    var j = this;
                    d.promises.push(b(angular.bind(this, function() {
                        j.deleteMessage(d)
                    }), d.ttl, 1, 1)), d.promises.push(b(d.countdownFunction, 1e3, 1, 1))
                }
                return d
            }
        }, this.deleteMessage = function(a) {
            var b = this.getAllMessages(a.referenceId),
                c = -1;
            for (var d in b) b.hasOwnProperty(d) && (c = b[d] === a ? d : c);
            c > -1 && (b[c].close = !0, b.splice(c, 1)), "function" == typeof a.onclose && a.onclose()
        }
    }]), ! function(a, b) {
        "use strict";

        function c(a) {
            return /^-?\d+\.?\d*$/.test(a.replace(/["']/g, ""))
        }
        var d = b.isDefined,
            e = b.isUndefined,
            f = b.isNumber,
            g = b.isObject,
            h = b.isArray,
            i = b.extend,
            j = b.toJson,
            k = b.fromJson,
            l = b.module("LocalStorageModule", []);
        l.provider("localStorageService", function() {
            this.prefix = "ls", this.storageType = "localStorage", this.cookie = {
                expiry: 30,
                path: "/"
            }, this.notify = {
                setItem: !0,
                removeItem: !1
            }, this.setPrefix = function(a) {
                return this.prefix = a, this
            }, this.setStorageType = function(a) {
                return this.storageType = a, this
            }, this.setStorageCookie = function(a, b) {
                return this.cookie = {
                    expiry: a,
                    path: b
                }, this
            }, this.setStorageCookieDomain = function(a) {
                return this.cookie.domain = a, this
            }, this.setNotify = function(a, b) {
                return this.notify = {
                    setItem: a,
                    removeItem: b
                }, this
            }, this.$get = ["$rootScope", "$window", "$document", "$parse", function(a, b, l, m) {
                var n, o = this,
                    p = o.prefix,
                    q = o.cookie,
                    r = o.notify,
                    s = o.storageType;
                l ? l[0] && (l = l[0]) : l = document, "." !== p.substr(-1) && (p = p ? p + "." : "");
                var t = function(a) {
                        return p + a
                    },
                    u = function() {
                        try {
                            var c = s in b && null !== b[s],
                                d = t("__" + Math.round(1e7 * Math.random()));
                            return c && (n = b[s], n.setItem(d, ""), n.removeItem(d)), c
                        } catch (e) {
                            return s = "cookie", a.$broadcast("LocalStorageModule.notification.error", e.message), !1
                        }
                    }(),
                    v = function(b, c) {
                        if (e(c) ? c = null : (g(c) || h(c) || f(+c || c)) && (c = j(c)), !u || "cookie" === o.storageType) return u || a.$broadcast("LocalStorageModule.notification.warning", "LOCAL_STORAGE_NOT_SUPPORTED"), r.setItem && a.$broadcast("LocalStorageModule.notification.setitem", {
                            key: b,
                            newvalue: c,
                            storageType: "cookie"
                        }), B(b, c);
                        try {
                            (g(c) || h(c)) && (c = j(c)), n && n.setItem(t(b), c), r.setItem && a.$broadcast("LocalStorageModule.notification.setitem", {
                                key: b,
                                newvalue: c,
                                storageType: o.storageType
                            })
                        } catch (d) {
                            return a.$broadcast("LocalStorageModule.notification.error", d.message), B(b, c)
                        }
                        return !0
                    },
                    w = function(b) {
                        if (!u || "cookie" === o.storageType) return u || a.$broadcast("LocalStorageModule.notification.warning", "LOCAL_STORAGE_NOT_SUPPORTED"), C(b);
                        var d = n ? n.getItem(t(b)) : null;
                        return d && "null" !== d ? "{" === d.charAt(0) || "[" === d.charAt(0) || c(d) ? k(d) : d : null
                    },
                    x = function(b) {
                        if (!u || "cookie" === o.storageType) return u || a.$broadcast("LocalStorageModule.notification.warning", "LOCAL_STORAGE_NOT_SUPPORTED"), r.removeItem && a.$broadcast("LocalStorageModule.notification.removeitem", {
                            key: b,
                            storageType: "cookie"
                        }), D(b);
                        try {
                            n.removeItem(t(b)), r.removeItem && a.$broadcast("LocalStorageModule.notification.removeitem", {
                                key: b,
                                storageType: o.storageType
                            })
                        } catch (c) {
                            return a.$broadcast("LocalStorageModule.notification.error", c.message), D(b)
                        }
                        return !0
                    },
                    y = function() {
                        if (!u) return a.$broadcast("LocalStorageModule.notification.warning", "LOCAL_STORAGE_NOT_SUPPORTED"), !1;
                        var b = p.length,
                            c = [];
                        for (var d in n)
                            if (d.substr(0, b) === p) try {
                                c.push(d.substr(b))
                            } catch (e) {
                                return a.$broadcast("LocalStorageModule.notification.error", e.Description), []
                            }
                        return c
                    },
                    z = function(b) {
                        b = b || "";
                        var c = p.slice(0, -1),
                            d = new RegExp(c + "." + b);
                        if (!u || "cookie" === o.storageType) return u || a.$broadcast("LocalStorageModule.notification.warning", "LOCAL_STORAGE_NOT_SUPPORTED"), E();
                        var e = p.length;
                        for (var f in n)
                            if (d.test(f)) try {
                                x(f.substr(e))
                            } catch (g) {
                                return a.$broadcast("LocalStorageModule.notification.error", g.message), E()
                            }
                        return !0
                    },
                    A = function() {
                        try {
                            return b.navigator.cookieEnabled || "cookie" in l && (l.cookie.length > 0 || (l.cookie = "test").indexOf.call(l.cookie, "test") > -1)
                        } catch (c) {
                            return a.$broadcast("LocalStorageModule.notification.error", c.message), !1
                        }
                    }(),
                    B = function(b, c) {
                        if (e(c)) return !1;
                        if ((h(c) || g(c)) && (c = j(c)), !A) return a.$broadcast("LocalStorageModule.notification.error", "COOKIES_NOT_SUPPORTED"), !1;
                        try {
                            var d = "",
                                f = new Date,
                                i = "";
                            if (null === c ? (f.setTime(f.getTime() + -864e5), d = "; expires=" + f.toGMTString(), c = "") : 0 !== q.expiry && (f.setTime(f.getTime() + 24 * q.expiry * 60 * 60 * 1e3), d = "; expires=" + f.toGMTString()), b) {
                                var k = "; path=" + q.path;
                                q.domain && (i = "; domain=" + q.domain), l.cookie = t(b) + "=" + encodeURIComponent(c) + d + k + i
                            }
                        } catch (m) {
                            return a.$broadcast("LocalStorageModule.notification.error", m.message), !1
                        }
                        return !0
                    },
                    C = function(b) {
                        if (!A) return a.$broadcast("LocalStorageModule.notification.error", "COOKIES_NOT_SUPPORTED"), !1;
                        for (var c = l.cookie && l.cookie.split(";") || [], d = 0; d < c.length; d++) {
                            for (var e = c[d];
                                " " === e.charAt(0);) e = e.substring(1, e.length);
                            if (0 === e.indexOf(t(b) + "=")) {
                                var f = decodeURIComponent(e.substring(p.length + b.length + 1, e.length));
                                try {
                                    var g = JSON.parse(f);
                                    return k(g)
                                } catch (h) {
                                    return f
                                }
                            }
                        }
                        return null
                    },
                    D = function(a) {
                        B(a, null)
                    },
                    E = function() {
                        for (var a = null, b = p.length, c = l.cookie.split(";"), d = 0; d < c.length; d++) {
                            for (a = c[d];
                                " " === a.charAt(0);) a = a.substring(1, a.length);
                            var e = a.substring(b, a.indexOf("="));
                            D(e)
                        }
                    },
                    F = function() {
                        return s
                    },
                    G = function(a, b, c, e) {
                        e = e || b;
                        var f = w(e);
                        return null === f && d(c) ? f = c : g(f) && g(c) && (f = i(c, f)), m(b).assign(a, f), a.$watch(b, function(a) {
                            v(e, a)
                        }, g(a[b]))
                    },
                    H = function() {
                        for (var a = 0, c = b[s], d = 0; d < c.length; d++) 0 === c.key(d).indexOf(p) && a++;
                        return a
                    };
                return {
                    isSupported: u,
                    getStorageType: F,
                    set: v,
                    add: v,
                    get: w,
                    keys: y,
                    remove: x,
                    clearAll: z,
                    bind: G,
                    deriveKey: t,
                    length: H,
                    cookie: {
                        isSupported: A,
                        set: B,
                        add: B,
                        get: C,
                        remove: D,
                        clearAll: E
                    }
                }
            }]
        })
    }(window, window.angular),
    function(a) {
        var b = function(a, c, d) {
                if (!h(c) || j(c) || k(c)) return c;
                var e, f = 0,
                    g = 0;
                if (i(c))
                    for (e = [], g = c.length; g > f; f++) e.push(b(a, c[f], d));
                else {
                    e = {};
                    for (var l in c) c.hasOwnProperty(l) && (e[a(l, d)] = b(a, c[l], d))
                }
                return e
            },
            c = function(a, b) {
                return void 0 === b && (b = "_"), a.replace(/([a-z])([A-Z0-9])/g, "$1" + b + "$2")
            },
            d = function(a) {
                return a = a.replace(/[\-_\s]+(.)?/g, function(a, b) {
                    return b ? b.toUpperCase() : ""
                }), a.replace(/^([A-Z])/, function(a, b) {
                    return b ? b.toLowerCase() : ""
                })
            },
            e = function(a) {
                return d(a).replace(/^([a-z])/, function(a, b) {
                    return b ? b.toUpperCase() : ""
                })
            },
            f = function(a, b) {
                return c(a, b).toLowerCase()
            },
            g = Object.prototype.toString,
            h = function(a) {
                return a === Object(a)
            },
            i = function(a) {
                return "[object Array]" == g.call(a)
            },
            j = function(a) {
                return "[object Date]" == g.call(a)
            },
            k = function(a) {
                return "[object RegExp]" == g.call(a)
            },
            l = {
                camelize: d,
                decamelize: f,
                pascalize: e,
                depascalize: f,
                camelizeKeys: function(a) {
                    return b(d, a)
                },
                decamelizeKeys: function(a, c) {
                    return b(f, a, c)
                },
                pascalizeKeys: function(a) {
                    return b(e, a)
                },
                depascalizeKeys: this.decamelizeKeys
            };
        "undefined" != typeof module && module.exports ? module.exports = l : a.humps = l
    }(this), ! function() {
        "use strict";
        angular.module("ui.tree", []).constant("treeConfig", {
            treeClass: "angular-ui-tree",
            emptyTreeClass: "angular-ui-tree-empty",
            hiddenClass: "angular-ui-tree-hidden",
            nodesClass: "angular-ui-tree-nodes",
            nodeClass: "angular-ui-tree-node",
            handleClass: "angular-ui-tree-handle",
            placeHolderClass: "angular-ui-tree-placeholder",
            dragClass: "angular-ui-tree-drag",
            dragThreshold: 3,
            levelThreshold: 30
        })
    }(),
    function() {
        "use strict";
        angular.module("ui.tree").factory("$uiTreeHelper", ["$document", "$window", function(a, b) {
            return {
                nodesData: {},
                setNodeAttribute: function(a, b, c) {
                    var d = this.nodesData[a.$modelValue.$$hashKey];
                    d || (d = {}, this.nodesData[a.$modelValue.$$hashKey] = d), d[b] = c
                },
                getNodeAttribute: function(a, b) {
                    var c = this.nodesData[a.$modelValue.$$hashKey];
                    return c ? c[b] : null
                },
                nodrag: function(a) {
                    return "undefined" != typeof a.attr("data-nodrag")
                },
                eventObj: function(a) {
                    var b = a;
                    return void 0 !== a.targetTouches ? b = a.targetTouches.item(0) : void 0 !== a.originalEvent && void 0 !== a.originalEvent.targetTouches && (b = a.originalEvent.targetTouches.item(0)), b
                },
                dragInfo: function(a) {
                    return {
                        source: a,
                        sourceInfo: {
                            nodeScope: a,
                            index: a.index(),
                            nodesScope: a.$parentNodesScope
                        },
                        index: a.index(),
                        siblings: a.siblings().slice(0),
                        parent: a.$parentNodesScope,
                        moveTo: function(a, b, c) {
                            this.parent = a, this.siblings = b.slice(0);
                            var d = this.siblings.indexOf(this.source);
                            d > -1 && (this.siblings.splice(d, 1), this.source.index() < c && c--), this.siblings.splice(c, 0, this.source), this.index = c
                        },
                        parentNode: function() {
                            return this.parent.$nodeScope
                        },
                        prev: function() {
                            return this.index > 0 ? this.siblings[this.index - 1] : null
                        },
                        next: function() {
                            return this.index < this.siblings.length - 1 ? this.siblings[this.index + 1] : null
                        },
                        isDirty: function() {
                            return this.source.$parentNodesScope != this.parent || this.source.index() != this.index
                        },
                        eventArgs: function(a, b) {
                            return {
                                source: this.sourceInfo,
                                dest: {
                                    index: this.index,
                                    nodesScope: this.parent
                                },
                                elements: a,
                                pos: b
                            }
                        },
                        apply: function() {
                            var a = this.source.$modelValue;
                            this.source.remove(), this.parent.insertNode(this.index, a)
                        }
                    }
                },
                height: function(a) {
                    return a.prop("scrollHeight")
                },
                width: function(a) {
                    return a.prop("scrollWidth")
                },
                offset: function(c) {
                    var d = c[0].getBoundingClientRect();
                    return {
                        width: c.prop("offsetWidth"),
                        height: c.prop("offsetHeight"),
                        top: d.top + (b.pageYOffset || a[0].body.scrollTop || a[0].documentElement.scrollTop),
                        left: d.left + (b.pageXOffset || a[0].body.scrollLeft || a[0].documentElement.scrollLeft)
                    }
                },
                positionStarted: function(a, b) {
                    var c = {};
                    return c.offsetX = a.pageX - this.offset(b).left, c.offsetY = a.pageY - this.offset(b).top, c.startX = c.lastX = a.pageX, c.startY = c.lastY = a.pageY, c.nowX = c.nowY = c.distX = c.distY = c.dirAx = 0, c.dirX = c.dirY = c.lastDirX = c.lastDirY = c.distAxX = c.distAxY = 0, c
                },
                positionMoved: function(a, b, c) {
                    b.lastX = b.nowX, b.lastY = b.nowY, b.nowX = a.pageX, b.nowY = a.pageY, b.distX = b.nowX - b.lastX, b.distY = b.nowY - b.lastY, b.lastDirX = b.dirX, b.lastDirY = b.dirY, b.dirX = 0 === b.distX ? 0 : b.distX > 0 ? 1 : -1, b.dirY = 0 === b.distY ? 0 : b.distY > 0 ? 1 : -1;
                    var d = Math.abs(b.distX) > Math.abs(b.distY) ? 1 : 0;
                    return c ? (b.dirAx = d, void(b.moving = !0)) : (b.dirAx !== d ? (b.distAxX = 0, b.distAxY = 0) : (b.distAxX += Math.abs(b.distX), 0 !== b.dirX && b.dirX !== b.lastDirX && (b.distAxX = 0), b.distAxY += Math.abs(b.distY), 0 !== b.dirY && b.dirY !== b.lastDirY && (b.distAxY = 0)), void(b.dirAx = d))
                }
            }
        }])
    }(),
    function() {
        "use strict";
        angular.module("ui.tree").controller("TreeController", ["$scope", "$element", "$attrs", "treeConfig", function(a, b) {
            this.scope = a, a.$element = b, a.$nodesScope = null, a.$type = "uiTree", a.$emptyElm = null, a.$callbacks = null, a.dragEnabled = !0, a.emptyPlaceHolderEnabled = !0, a.maxDepth = 0, a.dragDelay = 0, a.isEmpty = function() {
                return a.$nodesScope && a.$nodesScope.$modelValue && 0 === a.$nodesScope.$modelValue.length
            }, a.place = function(b) {
                a.$nodesScope.$element.append(b), a.$emptyElm.remove()
            }, a.resetEmptyElement = function() {
                0 === a.$nodesScope.$modelValue.length && a.emptyPlaceHolderEnabled ? b.append(a.$emptyElm) : a.$emptyElm.remove()
            };
            var c = function(a, b) {
                for (var d = a.childNodes(), e = 0; e < d.length; e++) {
                    b ? d[e].collapse() : d[e].expand();
                    var f = d[e].$childNodesScope;
                    f && c(f, b)
                }
            };
            a.collapseAll = function() {
                c(a.$nodesScope, !0)
            }, a.expandAll = function() {
                c(a.$nodesScope, !1)
            }
        }])
    }(),
    function() {
        "use strict";
        angular.module("ui.tree").controller("TreeNodesController", ["$scope", "$element", "treeConfig", function(a, b) {
            this.scope = a, a.$element = b, a.$modelValue = null, a.$nodeScope = null, a.$treeScope = null, a.$type = "uiTreeNodes", a.$nodesMap = {}, a.nodrop = !1, a.maxDepth = 0, a.initSubNode = function(b) {
                a.$nodesMap[b.$modelValue.$$hashKey] = b
            }, a.destroySubNode = function(b) {
                a.$nodesMap[b.$modelValue.$$hashKey] = null
            }, a.accept = function(b, c) {
                return a.$treeScope.$callbacks.accept(b, a, c)
            }, a.beforeDrag = function(b) {
                return a.$treeScope.$callbacks.beforeDrag(b)
            }, a.isParent = function(b) {
                return b.$parentNodesScope == a
            }, a.hasChild = function() {
                return a.$modelValue.length > 0
            }, a.safeApply = function(a) {
                var b = this.$root.$$phase;
                "$apply" == b || "$digest" == b ? a && "function" == typeof a && a() : this.$apply(a)
            }, a.removeNode = function(b) {
                var c = a.$modelValue.indexOf(b.$modelValue);
                return c > -1 ? (a.safeApply(function() {
                    a.$modelValue.splice(c, 1)[0]
                }), b) : null
            }, a.insertNode = function(b, c) {
                a.safeApply(function() {
                    a.$modelValue.splice(b, 0, c)
                })
            }, a.childNodes = function() {
                var b = [];
                if (a.$modelValue)
                    for (var c = 0; c < a.$modelValue.length; c++) b.push(a.$nodesMap[a.$modelValue[c].$$hashKey]);
                return b
            }, a.depth = function() {
                return a.$nodeScope ? a.$nodeScope.depth() : 0
            }, a.outOfDepth = function(b) {
                var c = a.maxDepth || a.$treeScope.maxDepth;
                return c > 0 ? a.depth() + b.maxSubDepth() + 1 > c : !1
            }
        }])
    }(),
    function() {
        "use strict";
        angular.module("ui.tree").controller("TreeNodeController", ["$scope", "$element", "$attrs", "treeConfig", function(a, b) {
            this.scope = a, a.$element = b, a.$modelValue = null, a.$parentNodeScope = null, a.$childNodesScope = null, a.$parentNodesScope = null, a.$treeScope = null, a.$handleScope = null, a.$type = "uiTreeNode", a.$$apply = !1, a.collapsed = !1, a.init = function(c) {
                var d = c[0];
                a.$treeScope = c[1] ? c[1].scope : null, a.$parentNodeScope = d.scope.$nodeScope, a.$modelValue = d.scope.$modelValue[a.$index], a.$parentNodesScope = d.scope, d.scope.initSubNode(a), b.on("$destroy", function() {
                    d.scope.destroySubNode(a)
                })
            }, a.index = function() {
                return a.$parentNodesScope.$modelValue.indexOf(a.$modelValue)
            }, a.dragEnabled = function() {
                return !(a.$treeScope && !a.$treeScope.dragEnabled)
            }, a.isSibling = function(b) {
                return a.$parentNodesScope == b.$parentNodesScope
            }, a.isChild = function(b) {
                var c = a.childNodes();
                return c && c.indexOf(b) > -1
            }, a.prev = function() {
                var b = a.index();
                return b > 0 ? a.siblings()[b - 1] : null
            }, a.siblings = function() {
                return a.$parentNodesScope.childNodes()
            }, a.childNodesCount = function() {
                return a.childNodes() ? a.childNodes().length : 0
            }, a.hasChild = function() {
                return a.childNodesCount() > 0
            }, a.childNodes = function() {
                return a.$childNodesScope && a.$childNodesScope.$modelValue ? a.$childNodesScope.childNodes() : null
            }, a.accept = function(b, c) {
                return a.$childNodesScope && a.$childNodesScope.$modelValue && a.$childNodesScope.accept(b, c)
            }, a.removeNode = function() {
                var b = a.remove();
                return a.$callbacks.removed(b), b
            }, a.remove = function() {
                return a.$parentNodesScope.removeNode(a)
            }, a.toggle = function() {
                a.collapsed = !a.collapsed
            }, a.collapse = function() {
                a.collapsed = !0
            }, a.expand = function() {
                a.collapsed = !1
            }, a.depth = function() {
                var b = a.$parentNodeScope;
                return b ? b.depth() + 1 : 1
            };
            var c = 0,
                d = function(a) {
                    for (var b = 0, e = a.childNodes(), f = 0; f < e.length; f++) {
                        var g = e[f].$childNodesScope;
                        g && (b = 1, d(g))
                    }
                    c += b
                };
            a.maxSubDepth = function() {
                return c = 0, a.$childNodesScope && d(a.$childNodesScope), c
            }
        }])
    }(),
    function() {
        "use strict";
        angular.module("ui.tree").controller("TreeHandleController", ["$scope", "$element", "$attrs", "treeConfig", function(a, b) {
            this.scope = a, a.$element = b, a.$nodeScope = null, a.$type = "uiTreeHandle"
        }])
    }(),
    function() {
        "use strict";
        angular.module("ui.tree").directive("uiTree", ["treeConfig", "$window", function(a, b) {
            return {
                restrict: "A",
                scope: !0,
                controller: "TreeController",
                link: function(c, d, e) {
                    var f = {
                            accept: null,
                            beforeDrag: null
                        },
                        g = {};
                    angular.extend(g, a), g.treeClass && d.addClass(g.treeClass), c.$emptyElm = angular.element(b.document.createElement("div")), g.emptyTreeClass && c.$emptyElm.addClass(g.emptyTreeClass), c.$watch("$nodesScope.$modelValue.length", function() {
                        c.$nodesScope.$modelValue && c.resetEmptyElement()
                    }, !0), c.$watch(e.dragEnabled, function(a) {
                        "boolean" == typeof a && (c.dragEnabled = a)
                    }), c.$watch(e.emptyPlaceHolderEnabled, function(a) {
                        "boolean" == typeof a && (c.emptyPlaceHolderEnabled = a)
                    }), c.$watch(e.maxDepth, function(a) {
                        "number" == typeof a && (c.maxDepth = a)
                    }), c.$watch(e.dragDelay, function(a) {
                        "number" == typeof a && (c.dragDelay = a)
                    }), f.accept = function(a, b) {
                        return b.nodrop || b.outOfDepth(a) ? !1 : !0
                    }, f.beforeDrag = function() {
                        return !0
                    }, f.removed = function() {}, f.dropped = function() {}, f.dragStart = function() {}, f.dragMove = function() {}, f.dragStop = function() {}, f.beforeDrop = function() {}, c.$watch(e.uiTree, function(a) {
                        angular.forEach(a, function(a, b) {
                            f[b] && "function" == typeof a && (f[b] = a)
                        }), c.$callbacks = f
                    }, !0)
                }
            }
        }])
    }(),
    function() {
        "use strict";
        angular.module("ui.tree").directive("uiTreeNodes", ["treeConfig", "$window", function(a) {
            return {
                require: ["ngModel", "?^uiTreeNode", "^uiTree"],
                restrict: "A",
                scope: !0,
                controller: "TreeNodesController",
                link: function(b, c, d, e) {
                    var f = {};
                    angular.extend(f, a), f.nodesClass && c.addClass(f.nodesClass);
                    var g = e[0],
                        h = e[1],
                        i = e[2];
                    h ? (h.scope.$childNodesScope = b, b.$nodeScope = h.scope) : i.scope.$nodesScope = b, b.$treeScope = i.scope, g && (g.$render = function() {
                        g.$modelValue && angular.isArray(g.$modelValue) || (b.$modelValue = []), b.$modelValue = g.$modelValue
                    }), b.$watch(d.maxDepth, function(a) {
                        "number" == typeof a && (b.maxDepth = a)
                    }), d.$observe("nodrop", function(a) {
                        b.nodrop = "undefined" != typeof a
                    }), d.$observe("horizontal", function(a) {
                        b.horizontal = "undefined" != typeof a
                    })
                }
            }
        }])
    }(),
    function() {
        "use strict";
        angular.module("ui.tree").directive("uiTreeNode", ["treeConfig", "$uiTreeHelper", "$window", "$document", "$timeout", function(a, b, c, d, e) {
            return {
                require: ["^uiTreeNodes", "^uiTree"],
                restrict: "A",
                controller: "TreeNodeController",
                link: function(f, g, h, i) {
                    var j = {};
                    angular.extend(j, a), j.nodeClass && g.addClass(j.nodeClass), f.init(i), f.collapsed = !!b.getNodeAttribute(f, "collapsed"), f.$watch(h.collapsed, function(a) {
                        "boolean" == typeof a && (f.collapsed = a)
                    }), f.$watch("collapsed", function(a) {
                        b.setNodeAttribute(f, "collapsed", a), h.$set("collapsed", a)
                    });
                    var k, l, m, n, o, p, q, r, s, t = "ontouchstart" in window,
                        u = null,
                        v = !0,
                        w = !1,
                        x = null,
                        y = document.body,
                        z = document.documentElement,
                        A = function(a) {
                            if ((t || 2 != a.button && 3 != a.which) && !(a.uiTreeDragging || a.originalEvent && a.originalEvent.uiTreeDragging)) {
                                var e = angular.element(a.target),
                                    h = e.scope();
                                if (h && h.$type && !("uiTreeNode" != h.$type && "uiTreeHandle" != h.$type || "uiTreeNode" == h.$type && h.$handleScope)) {
                                    var i = e.prop("tagName").toLowerCase();
                                    if ("input" != i && "textarea" != i && "button" != i && "select" != i) {
                                        for (; e && e[0] && e[0] != g;) {
                                            if (b.nodrag(e)) return;
                                            e = e.parent()
                                        }
                                        if (f.beforeDrag(f)) {
                                            a.uiTreeDragging = !0, a.originalEvent && (a.originalEvent.uiTreeDragging = !0), a.preventDefault();
                                            var u = b.eventObj(a);
                                            k = !0, l = b.dragInfo(f);
                                            var v = f.$element.prop("tagName");
                                            if ("tr" === v.toLowerCase()) {
                                                n = angular.element(c.document.createElement(v));
                                                var w = angular.element(c.document.createElement("td")).addClass(j.placeHolderClass);
                                                n.append(w)
                                            } else n = angular.element(c.document.createElement(v)).addClass(j.placeHolderClass);
                                            o = angular.element(c.document.createElement(v)), j.hiddenClass && o.addClass(j.hiddenClass), m = b.positionStarted(u, f.$element), n.css("height", b.height(f.$element) + "px"), n.css("width", b.width(f.$element) + "px"), p = angular.element(c.document.createElement(f.$parentNodesScope.$element.prop("tagName"))).addClass(f.$parentNodesScope.$element.attr("class")).addClass(j.dragClass), p.css("width", b.width(f.$element) + "px"), p.css("z-index", 9999);
                                            var x = (f.$element[0].querySelector(".angular-ui-tree-handle") || f.$element[0]).currentStyle;
                                            x && (document.body.setAttribute("ui-tree-cursor", d.find("body").css("cursor") || ""), d.find("body").css({
                                                cursor: x.cursor + "!important"
                                            })), f.$element.after(n), f.$element.after(o), p.append(f.$element), d.find("body").append(p), p.css({
                                                left: u.pageX - m.offsetX + "px",
                                                top: u.pageY - m.offsetY + "px"
                                            }), q = {
                                                placeholder: n,
                                                dragging: p
                                            }, angular.element(d).bind("touchend", F), angular.element(d).bind("touchcancel", F), angular.element(d).bind("touchmove", E), angular.element(d).bind("mouseup", F), angular.element(d).bind("mousemove", E), angular.element(d).bind("mouseleave", G), r = Math.max(y.scrollHeight, y.offsetHeight, z.clientHeight, z.scrollHeight, z.offsetHeight), s = Math.max(y.scrollWidth, y.offsetWidth, z.clientWidth, z.scrollWidth, z.offsetWidth)
                                        }
                                    }
                                }
                            }
                        },
                        B = function(a) {
                            if (!w) return void(v || (w = !0, f.$apply(function() {
                                f.$callbacks.dragStart(l.eventArgs(q, m))
                            })));
                            var d, e, g, h = b.eventObj(a);
                            if (p) {
                                a.preventDefault(), c.getSelection ? c.getSelection().removeAllRanges() : c.document.selection && c.document.selection.empty(), e = h.pageX - m.offsetX, g = h.pageY - m.offsetY, 0 > e && (e = 0), 0 > g && (g = 0), g + 10 > r && (g = r - 10), e + 10 > s && (e = s - 10), p.css({
                                    left: e + "px",
                                    top: g + "px"
                                });
                                var i = window.pageYOffset || c.document.documentElement.scrollTop,
                                    o = i + (window.innerHeight || c.document.clientHeight || c.document.clientHeight);
                                if (o < h.pageY && r >= o && window.scrollBy(0, 10), i > h.pageY && window.scrollBy(0, -10), b.positionMoved(a, m, k), k) return void(k = !1);
                                if (m.dirAx && m.distAxX >= j.levelThreshold && (m.distAxX = 0, m.distX > 0 && (d = l.prev(), d && !d.collapsed && d.accept(f, d.childNodesCount()) && (d.$childNodesScope.$element.append(n), l.moveTo(d.$childNodesScope, d.childNodes(), d.childNodesCount()))), m.distX < 0)) {
                                    var t = l.next();
                                    if (!t) {
                                        var x = l.parentNode();
                                        x && x.$parentNodesScope.accept(f, x.index() + 1) && (x.$element.after(n), l.moveTo(x.$parentNodesScope, x.siblings(), x.index() + 1))
                                    }
                                }
                                var y, z = (b.offset(p).left - b.offset(n).left >= j.threshold, h.pageX - c.document.body.scrollLeft),
                                    A = h.pageY - (window.pageYOffset || c.document.documentElement.scrollTop);
                                angular.isFunction(p.hide) ? p.hide() : (y = p[0].style.display, p[0].style.display = "none"), c.document.elementFromPoint(z, A);
                                var B = angular.element(c.document.elementFromPoint(z, A));
                                if (angular.isFunction(p.show) ? p.show() : p[0].style.display = y, !m.dirAx) {
                                    var C, D;
                                    D = B.scope();
                                    var E = !1;
                                    if (!D) return;
                                    if ("uiTree" == D.$type && D.dragEnabled && (E = D.isEmpty()), "uiTreeHandle" == D.$type && (D = D.$nodeScope), "uiTreeNode" != D.$type && !E) return;
                                    if (u && n.parent()[0] != u.$element[0] && (u.resetEmptyElement(), u = null), E) u = D, D.$nodesScope.accept(f, 0) && (D.place(n), l.moveTo(D.$nodesScope, D.$nodesScope.childNodes(), 0));
                                    else if (D.dragEnabled()) {
                                        B = D.$element;
                                        var F = b.offset(B);
                                        C = D.horizontal ? h.pageX < F.left + b.width(B) / 2 : h.pageY < F.top + b.height(B) / 2, D.$parentNodesScope.accept(f, D.index()) ? C ? (B[0].parentNode.insertBefore(n[0], B[0]), l.moveTo(D.$parentNodesScope, D.siblings(), D.index())) : (B.after(n), l.moveTo(D.$parentNodesScope, D.siblings(), D.index() + 1)) : !C && D.accept(f, D.childNodesCount()) && (D.$childNodesScope.$element.append(n), l.moveTo(D.$childNodesScope, D.childNodes(), D.childNodesCount()))
                                    }
                                }
                                f.$apply(function() {
                                    f.$callbacks.dragMove(l.eventArgs(q, m))
                                })
                            }
                        },
                        C = function(a) {
                            a.preventDefault(), p && (f.$treeScope.$apply(function() {
                                f.$callbacks.beforeDrop(l.eventArgs(q, m))
                            }), o.replaceWith(f.$element), n.remove(), p.remove(), p = null, f.$$apply ? (l.apply(), f.$treeScope.$apply(function() {
                                f.$callbacks.dropped(l.eventArgs(q, m))
                            })) : H(), f.$treeScope.$apply(function() {
                                f.$callbacks.dragStop(l.eventArgs(q, m))
                            }), f.$$apply = !1, l = null);
                            var b = document.body.getAttribute("ui-tree-cursor");
                            null !== b && (d.find("body").css({
                                cursor: b
                            }), document.body.removeAttribute("ui-tree-cursor")), angular.element(d).unbind("touchend", F), angular.element(d).unbind("touchcancel", F), angular.element(d).unbind("touchmove", E), angular.element(d).unbind("mouseup", F), angular.element(d).unbind("mousemove", E), angular.element(c.document.body).unbind("mouseleave", G)
                        },
                        D = function(a) {
                            f.dragEnabled() && A(a)
                        },
                        E = function(a) {
                            B(a)
                        },
                        F = function(a) {
                            f.$$apply = !0, C(a)
                        },
                        G = function(a) {
                            C(a)
                        },
                        H = function() {
                            g.bind("touchstart mousedown", function(a) {
                                v = !0, w = !1, D(a), x = e(function() {
                                    v = !1
                                }, f.dragDelay)
                            }), g.bind("touchend touchcancel mouseup", function() {
                                e.cancel(x)
                            })
                        };
                    H(), angular.element(c.document.body).bind("keydown", function(a) {
                        27 == a.keyCode && (f.$$apply = !1, C(a))
                    })
                }
            }
        }])
    }(),
    function() {
        "use strict";
        angular.module("ui.tree").directive("uiTreeHandle", ["treeConfig", "$window", function(a) {
            return {
                require: "^uiTreeNode",
                restrict: "A",
                scope: !0,
                controller: "TreeHandleController",
                link: function(b, c, d, e) {
                    var f = {};
                    angular.extend(f, a), f.handleClass && c.addClass(f.handleClass), b != e.scope && (b.$nodeScope = e.scope, e.scope.$handleScope = b)
                }
            }
        }])
    }(),
    function(a, b) {
        "object" == typeof exports ? module.exports = b() : "function" == typeof define && define.amd ? define(b) : a.Spinner = b()
    }(this, function() {
        "use strict";

        function a(a, b) {
            var c, d = document.createElement(a || "div");
            for (c in b) d[c] = b[c];
            return d
        }

        function b(a) {
            for (var b = 1, c = arguments.length; c > b; b++) a.appendChild(arguments[b]);
            return a
        }

        function c(a, b, c, d) {
            var e = ["opacity", b, ~~(100 * a), c, d].join("-"),
                f = .01 + c / d * 100,
                g = Math.max(1 - (1 - a) / b * (100 - f), a),
                h = j.substring(0, j.indexOf("Animation")).toLowerCase(),
                i = h && "-" + h + "-" || "";
            return l[e] || (m.insertRule("@" + i + "keyframes " + e + "{0%{opacity:" + g + "}" + f + "%{opacity:" + a + "}" + (f + .01) + "%{opacity:1}" + (f + b) % 100 + "%{opacity:" + a + "}100%{opacity:" + g + "}}", m.cssRules.length), l[e] = 1), e
        }

        function d(a, b) {
            var c, d, e = a.style;
            for (b = b.charAt(0).toUpperCase() + b.slice(1), d = 0; d < k.length; d++)
                if (c = k[d] + b, void 0 !== e[c]) return c;
            return void 0 !== e[b] ? b : void 0
        }

        function e(a, b) {
            for (var c in b) a.style[d(a, c) || c] = b[c];
            return a
        }

        function f(a) {
            for (var b = 1; b < arguments.length; b++) {
                var c = arguments[b];
                for (var d in c) void 0 === a[d] && (a[d] = c[d])
            }
            return a
        }

        function g(a, b) {
            return "string" == typeof a ? a : a[b % a.length]
        }

        function h(a) {
            this.opts = f(a || {}, h.defaults, n)
        }

        function i() {
            function c(b, c) {
                return a("<" + b + ' xmlns="urn:schemas-microsoft.com:vml" class="spin-vml">', c)
            }
            m.addRule(".spin-vml", "behavior:url(#default#VML)"), h.prototype.lines = function(a, d) {
                function f() {
                    return e(c("group", {
                        coordsize: k + " " + k,
                        coordorigin: -j + " " + -j
                    }), {
                        width: k,
                        height: k
                    })
                }

                function h(a, h, i) {
                    b(m, b(e(f(), {
                        rotation: 360 / d.lines * a + "deg",
                        left: ~~h
                    }), b(e(c("roundrect", {
                        arcsize: d.corners
                    }), {
                        width: j,
                        height: d.width,
                        left: d.radius,
                        top: -d.width >> 1,
                        filter: i
                    }), c("fill", {
                        color: g(d.color, a),
                        opacity: d.opacity
                    }), c("stroke", {
                        opacity: 0
                    }))))
                }
                var i, j = d.length + d.width,
                    k = 2 * j,
                    l = 2 * -(d.width + d.length) + "px",
                    m = e(f(), {
                        position: "absolute",
                        top: l,
                        left: l
                    });
                if (d.shadow)
                    for (i = 1; i <= d.lines; i++) h(i, -2, "progid:DXImageTransform.Microsoft.Blur(pixelradius=2,makeshadow=1,shadowopacity=.3)");
                for (i = 1; i <= d.lines; i++) h(i);
                return b(a, m)
            }, h.prototype.opacity = function(a, b, c, d) {
                var e = a.firstChild;
                d = d.shadow && d.lines || 0, e && b + d < e.childNodes.length && (e = e.childNodes[b + d], e = e && e.firstChild, e = e && e.firstChild, e && (e.opacity = c))
            }
        }
        var j, k = ["webkit", "Moz", "ms", "O"],
            l = {},
            m = function() {
                var c = a("style", {
                    type: "text/css"
                });
                return b(document.getElementsByTagName("head")[0], c), c.sheet || c.styleSheet
            }(),
            n = {
                lines: 12,
                length: 7,
                width: 5,
                radius: 10,
                rotate: 0,
                corners: 1,
                color: "#000",
                direction: 1,
                speed: 1,
                trail: 100,
                opacity: .25,
                fps: 20,
                zIndex: 2e9,
                className: "spinner",
                top: "50%",
                left: "50%",
                position: "absolute"
            };
        h.defaults = {}, f(h.prototype, {
            spin: function(b) {
                this.stop();
                var c = this,
                    d = c.opts,
                    f = c.el = e(a(0, {
                        className: d.className
                    }), {
                        position: d.position,
                        width: 0,
                        zIndex: d.zIndex
                    });
                d.radius + d.length + d.width;
                if (e(f, {
                        left: d.left,
                        top: d.top
                    }), b && b.insertBefore(f, b.firstChild || null), f.setAttribute("role", "progressbar"), c.lines(f, c.opts), !j) {
                    var g, h = 0,
                        i = (d.lines - 1) * (1 - d.direction) / 2,
                        k = d.fps,
                        l = k / d.speed,
                        m = (1 - d.opacity) / (l * d.trail / 100),
                        n = l / d.lines;
                    ! function o() {
                        h++;
                        for (var a = 0; a < d.lines; a++) g = Math.max(1 - (h + (d.lines - a) * n) % l * m, d.opacity), c.opacity(f, a * d.direction + i, g, d);
                        c.timeout = c.el && setTimeout(o, ~~(1e3 / k))
                    }()
                }
                return c
            },
            stop: function() {
                var a = this.el;
                return a && (clearTimeout(this.timeout), a.parentNode && a.parentNode.removeChild(a), this.el = void 0), this
            },
            lines: function(d, f) {
                function h(b, c) {
                    return e(a(), {
                        position: "absolute",
                        width: f.length + f.width + "px",
                        height: f.width + "px",
                        background: b,
                        boxShadow: c,
                        transformOrigin: "left",
                        transform: "rotate(" + ~~(360 / f.lines * k + f.rotate) + "deg) translate(" + f.radius + "px,0)",
                        borderRadius: (f.corners * f.width >> 1) + "px"
                    })
                }
                for (var i, k = 0, l = (f.lines - 1) * (1 - f.direction) / 2; k < f.lines; k++) i = e(a(), {
                    position: "absolute",
                    top: 1 + ~(f.width / 2) + "px",
                    transform: f.hwaccel ? "translate3d(0,0,0)" : "",
                    opacity: f.opacity,
                    animation: j && c(f.opacity, f.trail, l + k * f.direction, f.lines) + " " + 1 / f.speed + "s linear infinite"
                }), f.shadow && b(i, e(h("#000", "0 0 4px #000"), {
                    top: "2px"
                })), b(d, b(i, h(g(f.color, k), "0 0 1px rgba(0,0,0,.1)")));
                return d
            },
            opacity: function(a, b, c) {
                b < a.childNodes.length && (a.childNodes[b].style.opacity = c)
            }
        });
        var o = e(a("group"), {
            behavior: "url(#default#VML)"
        });
        return !d(o, "transform") && o.adj ? i() : j = d(o, "animation"), h
    }),
    function(a, b) {
        "object" == typeof exports ? module.exports = b(require("spin.js")) : "function" == typeof define && define.amd ? define(["spin"], b) : a.Ladda = b(a.Spinner)
    }(this, function(a) {
        "use strict";

        function b(a) {
            if ("undefined" == typeof a) return void console.warn("Ladda button target must be defined.");
            a.querySelector(".ladda-label") || (a.innerHTML = '<span class="ladda-label">' + a.innerHTML + "</span>");
            var b, c = a.querySelector(".ladda-spinner");
            c || (c = document.createElement("span"), c.className = "ladda-spinner"), a.appendChild(c);
            var d, e = {
                start: function() {
                    return b || (b = g(a)), a.setAttribute("disabled", ""), a.setAttribute("data-loading", ""), clearTimeout(d), b.spin(c), this.setProgress(0), this
                },
                startAfter: function(a) {
                    return clearTimeout(d), d = setTimeout(function() {
                        e.start()
                    }, a), this
                },
                stop: function() {
                    return a.removeAttribute("disabled"), a.removeAttribute("data-loading"), clearTimeout(d), b && (d = setTimeout(function() {
                        b.stop()
                    }, 1e3)), this
                },
                toggle: function() {
                    return this.isLoading() ? this.stop() : this.start(), this
                },
                setProgress: function(b) {
                    b = Math.max(Math.min(b, 1), 0);
                    var c = a.querySelector(".ladda-progress");
                    0 === b && c && c.parentNode ? c.parentNode.removeChild(c) : (c || (c = document.createElement("div"), c.className = "ladda-progress", a.appendChild(c)), c.style.width = (b || 0) * a.offsetWidth + "px")
                },
                enable: function() {
                    return this.stop(), this
                },
                disable: function() {
                    return this.stop(), a.setAttribute("disabled", ""), this
                },
                isLoading: function() {
                    return a.hasAttribute("data-loading")
                },
                remove: function() {
                    clearTimeout(d), a.removeAttribute("disabled", ""), a.removeAttribute("data-loading", ""), b && (b.stop(), b = null);
                    for (var c = 0, f = i.length; f > c; c++)
                        if (e === i[c]) {
                            i.splice(c, 1);
                            break
                        }
                }
            };
            return i.push(e), e
        }

        function c(a, b) {
            for (; a.parentNode && a.tagName !== b;) a = a.parentNode;
            return b === a.tagName ? a : void 0
        }

        function d(a) {
            for (var b = ["input", "textarea", "select"], c = [], d = 0; d < b.length; d++)
                for (var e = a.getElementsByTagName(b[d]), f = 0; f < e.length; f++) e[f].hasAttribute("required") && c.push(e[f]);
            return c
        }

        function e(a, e) {
            e = e || {};
            var f = [];
            "string" == typeof a ? f = h(document.querySelectorAll(a)) : "object" == typeof a && "string" == typeof a.nodeName && (f = [a]);
            for (var g = 0, i = f.length; i > g; g++) ! function() {
                var a = f[g];
                if ("function" == typeof a.addEventListener) {
                    var h = b(a),
                        i = -1;
                    a.addEventListener("click", function(b) {
                        var f = !0,
                            g = c(a, "FORM");
                        if ("undefined" != typeof g)
                            for (var j = d(g), k = 0; k < j.length; k++) "" === j[k].value.replace(/^\s+|\s+$/g, "") && (f = !1), "checkbox" !== j[k].type && "radio" !== j[k].type || j[k].checked || (f = !1), "email" === j[k].type && (f = /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/.test(j[k].value));
                        f && (h.startAfter(1), "number" == typeof e.timeout && (clearTimeout(i), i = setTimeout(h.stop, e.timeout)), "function" == typeof e.callback && e.callback.apply(null, [h]))
                    }, !1)
                }
            }()
        }

        function f() {
            for (var a = 0, b = i.length; b > a; a++) i[a].stop()
        }

        function g(b) {
            var c, d = b.offsetHeight;
            0 === d && (d = parseFloat(window.getComputedStyle(b).height)), d > 32 && (d *= .8), b.hasAttribute("data-spinner-size") && (d = parseInt(b.getAttribute("data-spinner-size"), 10)), b.hasAttribute("data-spinner-color") && (c = b.getAttribute("data-spinner-color"));
            var e = 12,
                f = .2 * d,
                g = .6 * f,
                h = 7 > f ? 2 : 3;
            return new a({
                color: c || "#fff",
                lines: e,
                radius: f,
                length: g,
                width: h,
                zIndex: "auto",
                top: "auto",
                left: "auto",
                className: ""
            })
        }

        function h(a) {
            for (var b = [], c = 0; c < a.length; c++) b.push(a[c]);
            return b
        }
        var i = [];
        return {
            bind: e,
            create: b,
            stopAll: f
        }
    }), ! function() {
        "use strict";
        angular.module("angular-ladda", []).provider("ladda", function() {
            var a = {
                style: "zoom-in"
            };
            return {
                setOption: function(b) {
                    angular.extend(a, b)
                },
                $get: function() {
                    return a
                }
            }
        }).directive("ladda", ["$compile", "$timeout", "ladda", function(a, b, c) {
            return {
                restrict: "A",
                replace: !1,
                terminal: !0,
                priority: 501,
                link: function(d, e, f) {
                    e.addClass("ladda-button"), angular.isUndefined(e.attr("data-style")) && e.attr("data-style", c.style || "zoom-in");
                    var g = Ladda.create(e[0]);
                    b(function() {
                        e.removeAttr("ladda"), e.removeAttr("data-ladda"), a(e, null, 501)(d), d.$watch(f.ladda, function(a) {
                            a || angular.isNumber(a) ? (g.isLoading() || g.start(), angular.isNumber(a) && g.setProgress(a)) : (g.stop(), f.ngDisabled && e.attr("disabled", d.$eval(f.ngDisabled)))
                        })
                    }, 0)
                }
            }
        }])
    }(), angular.module("unsavedChanges", ["lazyModel"]).provider("unsavedWarningsConfig", function() {
        var a = this,
            b = !1,
            c = !0,
            d = ["$locationChangeStart", "$stateChangeStart"],
            e = "You will lose unsaved changes if you leave this page",
            f = "You will lose unsaved changes if you reload this page";
        Object.defineProperty(a, "navigateMessage", {
            get: function() {
                return e
            },
            set: function(a) {
                e = a
            }
        }), Object.defineProperty(a, "reloadMessage", {
            get: function() {
                return f
            },
            set: function(a) {
                f = a
            }
        }), Object.defineProperty(a, "useTranslateService", {
            get: function() {
                return c
            },
            set: function(a) {
                c = !!a
            }
        }), Object.defineProperty(a, "routeEvent", {
            get: function() {
                return d
            },
            set: function(a) {
                "string" == typeof a && (a = [a]), d = a
            }
        }), Object.defineProperty(a, "logEnabled", {
            get: function() {
                return b
            },
            set: function(a) {
                b = !!a
            }
        }), this.$get = ["$injector", function(a) {
            function g(b) {
                return a.has("$translate") && c ? a.get("$translate")(b) : !1
            }
            var h = {
                log: function() {
                    if (console.log && b && arguments.length) {
                        var a = [].slice.call(arguments);
                        "object" == typeof console.log ? log.apply.call(console.log, console, a) : console.log.apply(console, a)
                    }
                }
            };
            return Object.defineProperty(h, "useTranslateService", {
                get: function() {
                    return c
                }
            }), Object.defineProperty(h, "reloadMessage", {
                get: function() {
                    return g(f) || f
                }
            }), Object.defineProperty(h, "navigateMessage", {
                get: function() {
                    return g(e) || e
                }
            }), Object.defineProperty(h, "routeEvent", {
                get: function() {
                    return d
                }
            }), Object.defineProperty(h, "logEnabled", {
                get: function() {
                    return b
                }
            }), h
        }]
    }).service("unsavedWarningSharedService", ["$rootScope", "unsavedWarningsConfig", "$injector", function(a, b, c) {
        function d() {
            return i = !0, angular.forEach(h, function(a, c) {
                b.log("Form : " + a.$name + " dirty : " + a.$dirty), a.$dirty && (i = !1)
            }), i
        }

        function e() {
            b.log("No more forms, tearing down"), angular.forEach(j, function(a) {
                a()
            }), window.onbeforeunload = null
        }

        function f() {
            b.log("Setting up"), window.onbeforeunload = g.confirmExit;
            var c = b.routeEvent;
            angular.forEach(c, function(c) {
                var e = a.$on(c, function(a, e, f) {
                    b.log("user is moving with " + c), d() ? b.log("all forms are clean") : (b.log("a form is dirty"), confirm(k.navigate) ? b.log("user doesn't care about loosing stuff") : (b.log("user wants to cancel leaving"), a.preventDefault()))
                });
                j.push(e)
            })
        }
        var g = this,
            h = [],
            i = !0,
            j = [angular.noop];
        this.allForms = function() {
            return h
        };
        var k = {
            navigate: b.navigateMessage,
            reload: b.reloadMessage
        };
        this.init = function(a) {
            0 === h.length && f(), b.log("Registering form", a), h.push(a)
        }, this.removeForm = function(a) {
            var c = h.indexOf(a); - 1 !== c && (h.splice(c, 1), b.log("Removing form from watch list", a), 0 === h.length && e())
        }, this.confirmExit = function() {
            return d() ? void e() : k.reload
        }
    }]).directive("unsavedWarningClear", ["unsavedWarningSharedService", function(a) {
        return {
            scope: !0,
            require: "^form",
            priority: 3e3,
            link: function(a, b, c, d) {
                b.bind("click", function(a) {
                    d.$setPristine()
                })
            }
        }
    }]).directive("unsavedWarningForm", ["unsavedWarningSharedService", function(a) {
        return {
            require: "form",
            link: function(b, c, d, e) {
                a.init(e), c.bind("submit", function(a) {
                    e.$valid && e.$setPristine()
                }), b.$on("$destroy", function() {
                    a.removeForm(e)
                })
            }
        }
    }]), angular.module("lazyModel", []).directive("lazyModel", ["$parse", "$compile", function(a, b) {
        return {
            restrict: "A",
            priority: 500,
            terminal: !0,
            require: "^form",
            scope: !0,
            compile: function(c, d) {
                var e = a(d.lazyModel),
                    f = e.assign;
                return c.attr("ng-model", "buffer"), c.removeAttr("lazy-model"), {
                    pre: function(a, c) {
                        a.buffer = e(a.$parent), b(c)(a)
                    },
                    post: function(a, b, c, d) {
                        for (var g = b.parent();
                            "FORM" !== g[0].tagName;) g = g.parent();
                        g.bind("submit", function() {
                            d.$valid && a.$apply(function() {
                                f(a.$parent, a.buffer)
                            })
                        }), g.bind("reset", function(b) {
                            b.preventDefault(), a.$apply(function() {
                                a.buffer = e(a.$parent)
                            })
                        })
                    }
                }
            }
        }
    }]), angular.module("checklist-model", []).directive("checklistModel", ["$parse", "$compile", function(a, b) {
        function c(a, b) {
            if (angular.isArray(a))
                for (var c = a.length; c--;)
                    if (angular.equals(a[c], b)) return !0;
            return !1
        }

        function d(a, b) {
            return a = angular.isArray(a) ? a : [], c(a, b) || a.push(b), a
        }

        function e(a, b) {
            if (angular.isArray(a))
                for (var c = a.length; c--;)
                    if (angular.equals(a[c], b)) {
                        a.splice(c, 1);
                        break
                    }
            return a
        }

        function f(f, g, h) {
            function i(a, b) {
                f.checked = c(a, m)
            }
            b(g)(f);
            var j = a(h.checklistModel),
                k = j.assign,
                l = a(h.checklistChange),
                m = a(h.checklistValue)(f.$parent);
            f.$watch("checked", function(a, b) {
                if (a !== b) {
                    var c = j(f.$parent);
                    a === !0 ? k(f.$parent, d(c, m)) : k(f.$parent, e(c, m)), l && l(f)
                }
            }), angular.isFunction(f.$parent.$watchCollection) ? f.$parent.$watchCollection(h.checklistModel, i) : f.$parent.$watch(h.checklistModel, i, !0)
        }
        return {
            restrict: "A",
            priority: 1e3,
            terminal: !0,
            scope: !0,
            compile: function(a, b) {
                if ("INPUT" !== a[0].tagName || "checkbox" !== b.type) throw 'checklist-model should be applied to `input[type="checkbox"]`.';
                if (!b.checklistValue) throw "You should provide `checklist-value`.";
                return a.removeAttr("checklist-model"), a.attr("ng-model", "checked"), f
            }
        }
    }]);