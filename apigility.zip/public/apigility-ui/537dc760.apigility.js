"function" != typeof String.prototype.endsWith && (String.prototype.endsWith = function(a) {
        return this.length >= a.length && this.substr(this.length - a.length) == a
    }),
    function() {
        "use strict";
        angular.module("apigility", ["apigility.core", "apigility.service", "apigility.modal", "apigility.api-module", "apigility.rest", "apigility.rpc", "apigility.content-negotiation", "apigility.authentication", "apigility.database", "apigility.documentation", "apigility.package", "apigility.about", "ngSanitize", "ui.bootstrap", "ui.router", "ui.tree", "ui.select", "angular-ladda", "unsavedChanges", "ngTagsInput", "checklist-model", "toggle-switch", "angular-growl"])
    }(),
    function() {
        "use strict";

        function a(a, b, c, d, e, f, g) {
            a.value("agApiPath", angular.element("body").data("ag-api-path") || angular.element("body").data("api-base-path") || "/api"), b.state({
                name: "ag",
                url: "/",
                controller: "Application",
                views: {
                    "header@": {
                        templateUrl: "apigility-ui/header/header.html",
                        controller: "Header",
                        controllerAs: "vm",
                        parent: this
                    },
                    "sidebar@": {
                        templateUrl: "apigility-ui/sidebar/sidebar.html",
                        controller: "Sidebar",
                        controllerAs: "vm",
                        parent: this
                    },
                    "content@": {
                        templateUrl: "apigility-ui/dashboard/dashboard.html",
                        controller: "Dashboard",
                        controllerAs: "vm",
                        parent: this
                    }
                }
            }), c.otherwise("/"), e.setPrefix("apigility"), f.theme = "bootstrap", g.globalReversedOrder(!0), g.globalTimeToLive(5e3), g.globalDisableCountDown(!0), g.onlyUniqueMessages(!1)
        }
        angular.module("apigility").config(a).directive("autofocus", ["$timeout", function(a) {
            return {
                restrict: "A",
                link: function(b, c) {
                    a(function() {
                        c[0].focus()
                    })
                }
            }
        }]), a.$inject = ["$provide", "$stateProvider", "$urlRouterProvider", "$httpProvider", "localStorageServiceProvider", "uiSelectConfig", "growlProvider"]
    }(),
    function() {
        "use strict";
        angular.module("apigility.core", ["ui.bootstrap", "ui.router", "ngTagsInput", "LocalStorageModule", "templates-main"])
    }(),
    function() {
        "use strict";

        function a() {
            function a(a) {
                for (var b in c.tabs) c.tabs[b].active = b === a
            }

            function b() {
                a("content-negotiation")
            }
            var c = this;
            c.select = a, c.tabs = {
                "content-negotiation": {
                    title: "Content Negotiation",
                    active: !1
                },
                authentication: {
                    title: "Authentication",
                    active: !1
                },
                documentation: {
                    title: "Documentation",
                    active: !1
                },
                backend: {
                    title: "Generate Backend",
                    active: !1
                }
            }, b()
        }
        angular.module("apigility.core").controller("Nav", a)
    }(),
    function() {
        "use strict";

        function a(a) {
            var b = this;
            b.setSelected = a.setSelected, b.isCollapsed = !0
        }
        angular.module("apigility").controller("Header", a), a.$inject = ["SidebarService"]
    }(),
    function() {
        "use strict";

        function a(a, b, c, d, e) {
            function f(a, b) {
                g.services = [], b.forEach(function(b) {
                    b.rest.forEach(function(a) {
                        g.services.push(a)
                    }), a.getRestList(b.name, b.selected_version, function(a) {
                        b.rest = a
                    }), b.rpc.forEach(function(a) {
                        g.services.push(a)
                    }), a.getRpcList(b.name, b.selected_version, function(a) {
                        b.rpc = a
                    })
                })
            }
            var g = this;
            g.apis = e.getApis(), g.getSelected = e.getSelected, g.setSelected = e.setSelected, g.search = "", 0 === g.apis.length && (g.loading = !0, a.getApiList(function(b, c) {
                g.loading = !1, b || (e.setApis(c), g.apis = c, f(a, c))
            })), g.searchApi = function(a) {
                if (!a) return g.apis = e.getApis(), void(g.search = "");
                var b = [];
                g.apis.forEach(function(c) {
                    var d = [];
                    c.rest.forEach(function(b) {
                        b.toUpperCase() == a.toUpperCase() && d.push(b)
                    });
                    var e = [];
                    if (c.rpc.forEach(function(b) {
                            b.toUpperCase() == a.toUpperCase() && e.push(b)
                        }), d.length > 0 || e.length > 0) {
                        var f = angular.copy(c);
                        f.rest = d, f.rpc = e, b.push(f)
                    }
                }), g.apis = b
            }, g.toggle = function(a) {
                a.toggle()
            }, g.newApiModal = function() {
                var a = b.open({
                    templateUrl: "apigility-ui/modal/new-api.html",
                    controller: "NewApi",
                    controllerAs: "vm"
                });
                a.result.then(function(a) {
                    e.addApi(a), g.setSelected("api" + a.name), d.go("ag.apimodule", {
                        api: a.name,
                        ver: 1
                    })
                })
            }, g.newServiceModal = function() {
                var a = b.open({
                    templateUrl: "apigility-ui/modal/new-service.html",
                    controller: "NewService",
                    controllerAs: "vm"
                });
                a.result.then(function(a) {
                    a.hasOwnProperty("rest") ? (e.setSelectedVersion(a.api, a.ver), d.go("ag.rest", {
                        api: a.api,
                        ver: a.ver,
                        rest: a.rest
                    }), g.setSelected("api" + a.api + "rest" + a.rest)) : a.hasOwnProperty("rpc") ? (e.setSelectedVersion(a.api, a.ver), d.go("ag.rpc", {
                        api: a.api,
                        ver: a.ver,
                        rpc: a.rpc
                    }), g.setSelected("api" + a.api + "rpc" + a.rpc)) : a.hasOwnProperty("rests") && (e.setSelectedVersion(a.api, a.ver), d.go("ag.apimodule", {
                        api: a.api,
                        ver: a.ver
                    }))
                })
            }, g.changeVersion = function(a, b) {
                e.setSelectedVersion(a, b), d.go("ag.apimodule", {
                    api: a,
                    ver: b
                })
            }
        }
        angular.module("apigility").controller("Sidebar", a), a.$inject = ["api", "$modal", "$rootScope", "$state", "SidebarService"]
    }(),
    function() {
        "use strict";

        function a(a) {}
        angular.module("apigility").controller("Dashboard", a), a.$inject = ["$rootScope"]
    }(),
    function() {
        "use strict";
        angular.module("apigility.modal", ["ui.router"]).filter("emptyObject", function() {
            return function(a) {
                return angular.equals({}, a)
            }
        })
    }(),
    function() {
        "use strict";

        function a(a, b, c, d, e) {
            function f(b, c) {
                return g.loading = !1, b ? void(g.alert = c) : void a.close({
                    api: h,
                    ver: i
                })
            }
            var g = this,
                h = b.api,
                i = b.ver;
            g.service_name = d.service_name, g.description = "", g.loading = !1, g.cancel = a.dismiss, g.ok = function() {
                if (!g.description) return void(g.alert = "The option name cannot be empty");
                g.loading = !0;
                var a;
                "object" != typeof d._embedded || "object" != typeof d._embedded.documentation ? a = {
                    description: g.description
                } : (a = angular.copy(d._embedded.documentation), a.description = g.description), "rest" === e ? c.saveRestDoc(h, i, d.controller_service_name, a, f) : "rpc" === e && c.saveRpcDoc(h, i, d.controller_service_name, a, f)
            }
        }
        angular.module("apigility.modal").controller("AddServiceDescription", a), a.$inject = ["$modalInstance", "$stateParams", "api", "service", "type"]
    }(),
    function() {
        "use strict";

        function a(a, b, c) {
            var d = this;
            d.cancel = a.dismiss, d.apiname = "", d.loading = !1, d.ok = function() {
                return d.apiname ? (d.loading = !0, void b.newApi(d.apiname, function(b, e) {
                    return b ? (d.alert = e, void(d.loading = !1)) : void c(function() {
                        d.loading = !1, a.close(e)
                    }, 3e3)
                })) : void(d.alert = "The API name cannot be empty")
            }
        }
        angular.module("apigility.modal").controller("NewApi", a), a.$inject = ["$modalInstance", "api", "$timeout"]
    }(),
    function() {
        "use strict";

        function a(a, b, c, d) {
            var e = this;
            e.cancel = a.dismiss, e.apis = b.getApis(), e.tabs = {}, e.apiname = e.apis[0], e.hasDoctrine = !1;
            for (var f = 0; f < e.apis.length; f++)
                if ("api" + e.apis[f].name === b.getSelected()) {
                    e.apiname = e.apis[f];
                    break
                }
            e.toggle = function(a) {
                a.toggle()
            }, c.getDatabase(function(a, b) {
                e.db = b
            }), c.getDoctrineAdapters(function(a, b) {
                a && 204 == b || (e.hasDoctrine = !0, e.doctrine = b)
            }), e.discoverDb = function() {
                e.discovering = !0, c.autodiscover(e.apiname.name, b.getSelectedVersion(e.apiname.name), !1, encodeURIComponent(e.adapter.adapter_name), function(a, b) {
                    e.dbServices = [], e.discovering = !1, e.tables = b
                })
            }, e.discoverDoctrine = function() {
                e.discovering = !0, c.autodiscover(e.apiname.name, b.getSelectedVersion(e.apiname.name), !0, e.doctrineAdapter.adapter_name, function(a, b) {
                    e.doctrineEntities = [], e.discovering = !1, e.entities = b
                })
            }, e.ok = function() {
                e.loading = !0;
                var f = 1;
                if (e.apis.forEach(function(a) {
                        a.name === e.apiname.name && (f = Math.max.apply(Math, a.versions))
                    }), e.tabs.rest) {
                    if (!e.restname) return e.alert = "The service name cannot be empty", void(e.loading = !1);
                    if (!/^[a-zA-Z][a-zA-Z0-9_]*(\\\[a-zA-Z][a-zA-Z0-9_]*)*$/.test(e.restname)) return e.alert = "Invalid service name. A valid name starts with a letter followed by any number of letters, numbers, or underscores.", void(e.loading = !1);
                    c.newRest(e.apiname.name, e.restname, function(b, c) {
                        b ? (e.alert = c, e.loading = !1) : (e.controller = c.controller_service_name, d(function() {
                            e.loading = !1, a.close({
                                api: e.apiname.name,
                                rest: e.controller.replace(/\\/g, "-"),
                                ver: f
                            })
                        }, 2e3))
                    })
                } else if (e.tabs.rpc) {
                    if (!e.rpcname) return e.alert = "The service name cannot be empty", void(e.loading = !1);
                    if (!e.route) return e.alert = "The route to match cannot be empty", void(e.loading = !1);
                    if (!/^[a-zA-Z][a-zA-Z0-9_]*(\\\[a-zA-Z][a-zA-Z0-9_]*)*$/.test(e.rpcname)) return e.alert = "Invalid service name. A valid name starts with a letter followed by any number of letters, numbers, or underscores.", void(e.loading = !1);
                    c.newRpc(e.apiname.name, e.rpcname, e.route, function(b, c) {
                        b ? (e.alert = c, e.loading = !1) : (e.controller = c.controller_service_name.replace(/\\/g, "-"), d(function() {
                            e.loading = !1, a.close({
                                api: e.apiname.name,
                                rpc: e.controller,
                                ver: f
                            })
                        }, 2e3))
                    })
                } else if (e.tabs.db) {
                    if (!e.adapter) return e.alert = "The DB adapter name cannot be empty", void(e.loading = !1);
                    if (e.hasOwnProperty("rest") && e.rest.hasOwnProperty("table_name") && (e.dbServices = [{
                            table_name: e.rest.table_name,
                            columns: []
                        }]), 0 == e.dbServices.length) return e.alert = "Please choose at least one table", void(e.loading = !1);
                    var g = [];
                    e.dbServices.forEach(function(a) {
                        c.newDbConnected(e.apiname.name, e.adapter.adapter_name, a.table_name, function(d, f) {
                            if (d) e.alert = f, e.loading = !1;
                            else {
                                e.controller = f.controller_service_name.replace(/\\/g, "-");
                                var h = [];
                                a.columns.forEach(function(a) {
                                    void 0 != a.filters && void 0 != a.validators && h.push({
                                        name: a.name,
                                        required: a.required,
                                        filters: a.filters,
                                        validators: a.validators
                                    })
                                }), c.saveRestField(e.apiname.name, b.getSelectedVersion(e.apiname.name), e.controller, h, function(a, b) {}), g.push(a.table_name), e.tables.splice(a, 1)
                            }
                        })
                    }), d(function() {
                        e.loading = !1, a.close({
                            api: e.apiname.name,
                            rests: g,
                            ver: f,
                            controller: e.controller
                        })
                    }, 2e3)
                } else if (e.tabs.doctrine) {
                    if (!e.doctrineAdapter) return e.alert = "The DB adapter name cannot be empty", void(e.loading = !1);
                    if (0 == e.doctrineEntities.length) return e.alert = "Please choose at least one entity", void(e.loading = !1);
                    var g = [];
                    e.doctrineEntities.forEach(function(a) {
                        c.newDoctrine(e.apiname.name, e.doctrineAdapter.adapter_name, a, function(d, f) {
                            d ? (e.alert = f, e.loading = !1) : (e.controller = f.controller_service_name.replace(/\\/g, "-"), c.saveRestField(e.apiname.name, b.getSelectedVersion(e.apiname.name), e.controller, a.fields, function(a, b) {}), g.push(a.service_name), e.entities.splice(a, 1))
                        })
                    }), d(function() {
                        e.loading = !1, a.close({
                            api: e.apiname.name,
                            rests: g,
                            ver: f,
                            controller: e.controller
                        })
                    }, 2e3)
                }
            }
        }
        angular.module("apigility.modal").controller("NewService", a), a.$inject = ["$modalInstance", "SidebarService", "api", "$timeout"]
    }(),
    function() {
        "use strict";

        function a(a, b, c) {
            var d = this;
            d.apiName = b.api, d.newVersion = parseInt(b.ver) + 1, d.cancel = a.dismiss, d.ok = function() {
                d.loading = !0, c.newVersion(d.apiName, function(b, c) {
                    return d.loading = !1, b ? void(d.alert = c) : void a.close(c)
                })
            }
        }
        angular.module("apigility.modal").controller("NewVersion", a), a.$inject = ["$modalInstance", "$stateParams", "api"]
    }(),
    function() {
        "use strict";

        function a(a, b, c, d) {
            var e = this;
            e.apiName = b.api, e.cancel = a.dismiss, e.recursive = !1, e.ok = function() {
                e.loading = !0, c.deleteApi(e.apiName, e.recursive, function(b, c) {
                    return b ? (e.alert = "Error during the delete of the API", void(e.loading = !1)) : void d(function() {
                        e.loading = !1, a.close(e.apiName)
                    }, 2e3)
                })
            }
        }
        angular.module("apigility.modal").controller("DeleteApi", a), a.$inject = ["$modalInstance", "$stateParams", "api", "$timeout"]
    }(),
    function() {
        "use strict";

        function a(a, b, c, d, e) {
            var f = this;
            f.apiName = b.api, f.version = b.ver, f.restName = b.rest, f.cancel = a.dismiss, f.ok = function() {
                f.loading = !0, c.deleteRest(f.apiName, f.version, f.restName, e, f.recursive, function(b, c) {
                    return b ? (f.alert = "Error during the delete of the service", void(f.loading = !1)) : void d(function() {
                        f.loading = !1, a.close({
                            api: f.apiName,
                            version: f.version,
                            service: f.restName
                        })
                    }, 2e3)
                })
            }
        }
        angular.module("apigility.modal").controller("DeleteRest", a), a.$inject = ["$modalInstance", "$stateParams", "api", "$timeout", "isDoctrine"]
    }(),
    function() {
        "use strict";

        function a(a, b, c, d, e) {
            var f = this;
            f.apiName = b.api, f.version = b.ver, f.field = {}, f.field.required = !0, f.field.validators = [], f.field.filters = [], f.cancel = a.dismiss, f.ok = function() {
                if (!f.field.name) return void(f.alert = "The Field name cannot be empty");
                f.loading = !0;
                var g = angular.copy(d);
                g.push(f.field);
                for (var h = 0; h < g.length; h++) g[h].type || delete g[h].type;
                "rest" === e ? c.saveRestField(f.apiName, f.version, b.rest, g, function(b, c) {
                    return f.loading = !1, b ? void(f.alert = c) : void a.close(c)
                }) : "rpc" === e && c.saveRpcField(f.apiName, f.version, b.rpc, g, function(b, c) {
                    return f.loading = !1, b ? void(f.alert = c) : void a.close(c)
                })
            }
        }
        angular.module("apigility.modal").controller("NewField", a), a.$inject = ["$modalInstance", "$stateParams", "api", "fields", "type"]
    }(),
    function() {
        "use strict";

        function a(a, b, c, d, e, f) {
            var g = this;
            g.apiName = b.api, g.version = b.ver, g.cancel = a.dismiss, g.field = d, g.ok = function() {
                for (var d = angular.copy(e), h = 0; h < d.length; h++)
                    if (d[h].name === g.field.name) {
                        d.splice(h, 1);
                        break
                    }
                "rest" === f ? c.saveRestField(g.apiName, g.version, b.rest, d, function(b, c) {
                    return g.loading = !1, b ? void(g.alert = c) : void a.close(c)
                }) : "rpc" === f && c.saveRpcField(g.apiName, g.version, b.rpc, d, function(b, c) {
                    return g.loading = !1, b ? void(g.alert = c) : void a.close(c)
                })
            }
        }
        angular.module("apigility.modal").controller("DeleteField", a), a.$inject = ["$modalInstance", "$stateParams", "api", "field", "fields", "type"]
    }(),
    function() {
        "use strict";

        function a(a, b, c, d, e, f) {
            var g = this;
            g.apiName = b.api, g.version = b.ver, g.field = d, g.cancel = a.dismiss, g.ok = function() {
                g.loading = !0;
                for (var d = angular.copy(e), h = 0; h < d.length; h++) d[h].type || delete d[h].type;
                "rest" === f ? c.saveRestField(g.apiName, g.version, b.rest, d, function(b, c) {
                    return g.loading = !1, b ? void(g.alert = c) : void a.close(c)
                }) : "rpc" === f && c.saveRpcField(g.apiName, g.version, b.rpc, d, function(b, c) {
                    return g.loading = !1, b ? void(g.alert = c) : void a.close(c)
                })
            }
        }
        angular.module("apigility.modal").controller("EditField", a), a.$inject = ["$modalInstance", "$stateParams", "api", "field", "fields", "type"]
    }(),
    function() {
        "use strict";

        function a(a, b, c, d, e, f) {
            function g(a, b, c) {
                for (var d = 0; d < a.length; d++)
                    if (a[d].name == b.name) {
                        a[d].validators.push(c);
                        break
                    }
            }
            var h = this;
            h.apiName = b.api, h.version = b.ver, h.field = d, h.validators = {}, h.validatorNames = [], h.optionNames = [], h.cancel = a.dismiss, h.validator = {
                name: "",
                options: {}
            };
            var i = [];
            d.validators.forEach(function(a) {
                i.push(a.name)
            }), e.getValidators(function(a) {
                h.validators = a;
                for (var b in a) i.indexOf(b) > -1 ? delete h.validators[b] : h.validatorNames.push(b)
            }), h.selectValidator = function(a, b) {
                h.options = h.validators[a], h.optionNames = [];
                for (var c in h.options) h.optionNames.push(c)
            }, h.selectOption = function(a, b) {
                h.option.value = "bool" == h.options[a] ? h.option.value = !1 : ""
            }, h.addOption = function() {
                h.validator.options.hasOwnProperty(h.option.name) || (h.validator.options[h.option.name] = h.option.value)
            }, h.deleteOption = function(a) {
                h.validator.options.hasOwnProperty(a) && delete h.validator.options[a]
            }, h.ok = function() {
                h.loading = !0;
                var i = angular.copy(c);
                g(i, d, h.validator), "rest" === f ? e.saveRestField(h.apiName, h.version, b.rest, i, function(b, c) {
                    return h.loading = !1, b ? void(h.alert = c) : void a.close(c)
                }) : "rpc" === f && e.saveRpcField(h.apiName, h.version, b.rpc, i, function(b, c) {
                    return h.loading = !1, b ? void(h.alert = c) : void a.close(c)
                })
            }
        }
        angular.module("apigility.modal").controller("AddValidator", a), a.$inject = ["$modalInstance", "$stateParams", "fields", "field", "api", "type"]
    }(),
    function() {
        "use strict";

        function a(a, b, c, d, e, f, g, h, i) {
            function j(a, b, c) {
                for (var d = 0; d < a.length; d++)
                    if (a[d].name === b.name) {
                        for (var e = 0; e < a[d].validators.length; e++)
                            if (a[d].validators[e].name === c.name) {
                                a[d].validators[e] = c;
                                break
                            }
                        break
                    }
            }
            var k = this;
            k.apiName = c.api, k.version = c.ver, k.restName = c.rest, k.field = d, k.options = {}, k.optionNames = [], k.disabled = !i.isLastVersion(k.version, k.apiName), k.cancel = a.dismiss, k.validator = angular.copy(e), 0 === k.validator.options.length && (k.validator.options = {}), f.getValidators(function(a) {
                k.validators = a, k.options = a[k.validator.name], k.optionNames = [];
                for (var b in k.options) k.optionNames.push(b)
            }), k.addOption = function() {
                k.validator.options.hasOwnProperty(k.option.name) || (k.validator.options[k.option.name] = k.option.value)
            }, k.deleteOption = function(a) {
                k.validator.options.hasOwnProperty(a) && delete k.validator.options[a]
            }, k.deleteValidatorModal = function() {
                var c = b.open({
                    templateUrl: "apigility-ui/modal/delete-validator.html",
                    controller: "DeleteValidator",
                    controllerAs: "vm",
                    resolve: {
                        validator: function() {
                            return e
                        },
                        field: function() {
                            return d
                        },
                        fields: function() {
                            return g
                        },
                        type: function() {
                            return h
                        }
                    }
                });
                c.result.then(function(b) {
                    a.close(b)
                })
            }, k.ok = function() {
                k.loading = !0;
                var b = angular.copy(g);
                j(b, d, k.validator), "rest" === h ? f.saveRestField(k.apiName, k.version, c.rest, b, function(b, c) {
                    return k.loading = !1, b ? void(k.alert = c) : void a.close(c)
                }) : "rpc" === h && f.saveRpcField(k.apiName, k.version, c.rpc, b, function(b, c) {
                    return k.loading = !1, b ? void(k.alert = c) : void a.close(c)
                })
            }
        }
        angular.module("apigility.modal").controller("EditValidator", a), a.$inject = ["$modalInstance", "$modal", "$stateParams", "field", "validator", "api", "fields", "type", "SidebarService"]
    }(),
    function() {
        "use strict";

        function a(a, b, c, d, e, f, g) {
            function h(a, b, c) {
                for (var d = 0; d < a.length; d++)
                    if (a[d].name === b.name) {
                        for (var e = 0; e < a[d].validators.length; e++)
                            if (a[d].validators[e].name === c.name) {
                                a[d].validators.splice(e, 1);
                                break
                            }
                        break
                    }
            }
            var i = this;
            i.apiName = b.api, i.version = b.ver, i.validator = c, i.cancel = a.dismiss, i.ok = function() {
                i.loading = !0;
                var j = angular.copy(f);
                h(j, d, c), "rest" === g ? e.saveRestField(i.apiName, i.version, b.rest, j, function(b, c) {
                    return i.loading = !1, b ? void(i.alert = c) : void a.close(c)
                }) : "rpc" === g && e.saveRpcField(i.apiName, i.version, b.rpc, j, function(b, c) {
                    return i.loading = !1, b ? void(i.alert = c) : void a.close(c)
                })
            }
        }
        angular.module("apigility.modal").controller("DeleteValidator", a), a.$inject = ["$modalInstance", "$stateParams", "validator", "field", "api", "fields", "type"]
    }(),
    function() {
        "use strict";

        function a(a, b, c, d, e, f) {
            function g(a, b, c) {
                for (var d = 0; d < a.length; d++)
                    if (a[d].name == b.name) {
                        a[d].filters.push(c);
                        break
                    }
            }
            var h = this;
            h.apiName = b.api, h.version = b.ver, h.field = d, h.cancel = a.dismiss, h.filter = {
                name: "",
                options: {}
            }, h.filters = {}, h.filterNames = [], h.optionNames = [];
            var i = [];
            d.filters.forEach(function(a) {
                i.push(a.name)
            }), e.getFilters(function(a) {
                h.filters = a, h.filterNames = [];
                for (var b in a) i.indexOf(b) > -1 ? delete h.filters[b] : h.filterNames.push(b)
            }), h.selectFilter = function(a, b) {
                h.options = h.filters[a], h.optionNames = [];
                for (var c in h.options) h.optionNames.push(c)
            }, h.selectOption = function(a, b) {
                h.option.value = ""
            }, h.addOption = function() {
                h.filter.options.hasOwnProperty(h.option.name) || (h.filter.options[h.option.name] = h.option.value)
            }, h.deleteOption = function(a) {
                h.filter.options.hasOwnProperty(a) && delete h.filter.options[a]
            }, h.ok = function() {
                var i = angular.copy(c);
                g(i, d, h.filter), "rest" === f ? e.saveRestField(h.apiName, h.version, b.rest, i, function(b, c) {
                    return h.loading = !1, b ? void(h.alert = c) : void a.close(c)
                }) : "rpc" === f && e.saveRpcField(h.apiName, h.version, b.rpc, i, function(b, c) {
                    return h.loading = !1, b ? void(h.alert = c) : void a.close(c)
                })
            }
        }
        angular.module("apigility.modal").controller("AddFilter", a), a.$inject = ["$modalInstance", "$stateParams", "fields", "field", "api", "type"]
    }(),
    function() {
        "use strict";

        function a(a, b, c, d, e, f, g, h, i) {
            function j(a, b, c) {
                for (var d = 0; d < a.length; d++)
                    if (a[d].name === b.name) {
                        for (var e = 0; e < a[d].filters.length; e++)
                            if (a[d].filters[e].name === c.name) {
                                a[d].filters[e] = c;
                                break
                            }
                        break
                    }
            }
            var k = this;
            k.apiName = c.api, k.version = c.ver, k.field = e, k.options = {}, k.optionNames = [], k.disabled = !i.isLastVersion(k.version, k.apiName), k.cancel = a.dismiss, k.filter = angular.copy(f), 0 === k.filter.options.length && (k.filter.options = {}), g.getFilters(function(a) {
                k.filters = a, k.options = a[k.filter.name], k.optionNames = [];
                for (var b in k.options) k.optionNames.push(b)
            }), k.addOption = function() {
                k.filter.options.hasOwnProperty(k.option.name) || (k.filter.options[k.option.name] = k.option.value)
            }, k.deleteOption = function(a) {
                k.filter.options.hasOwnProperty(a) && delete k.filter.options[a]
            }, k.deleteFilterModal = function() {
                var c = b.open({
                    templateUrl: "apigility-ui/modal/delete-filter.html",
                    controller: "DeleteFilter",
                    controllerAs: "vm",
                    resolve: {
                        filter: function() {
                            return f
                        },
                        field: function() {
                            return e
                        },
                        fields: function() {
                            return d
                        },
                        type: function() {
                            return h
                        }
                    }
                });
                c.result.then(function(b) {
                    a.close(b)
                })
            }, k.ok = function() {
                var b = angular.copy(d);
                j(b, e, k.filter), "rest" === h ? g.saveRestField(k.apiName, k.version, c.rest, b, function(b, c) {
                    return k.loading = !1, b ? void(k.alert = c) : void a.close(c)
                }) : "rpc" === h && g.saveRpcField(k.apiName, k.version, c.rpc, b, function(b, c) {
                    return k.loading = !1, b ? void(k.alert = c) : void a.close(c)
                })
            }
        }
        angular.module("apigility.modal").controller("EditFilter", a), a.$inject = ["$modalInstance", "$modal", "$stateParams", "fields", "field", "filter", "api", "type", "SidebarService"]
    }(),
    function() {
        "use strict";

        function a(a, b, c, d, e, f, g) {
            function h(a, b, c) {
                for (var d = 0; d < a.length; d++)
                    if (a[d].name === b.name) {
                        for (var e = 0; e < a[d].filters.length; e++)
                            if (a[d].filters[e].name === c.name) {
                                a[d].filters.splice(e, 1);
                                break
                            }
                        break
                    }
            }
            var i = this;
            i.apiName = b.api, i.version = b.ver, i.filter = c, i.cancel = a.dismiss, i.ok = function() {
                i.loading = !0;
                var j = angular.copy(f);
                h(j, d, c), "rest" === g ? e.saveRestField(i.apiName, i.version, b.rest, j, function(b, c) {
                    return i.loading = !1, b ? void(i.alert = c) : void a.close(c)
                }) : "rpc" === g && e.saveRpcField(i.apiName, i.version, b.rpc, j, function(b, c) {
                    return i.loading = !1, b ? void(i.alert = c) : void a.close(c)
                })
            }
        }
        angular.module("apigility.modal").controller("DeleteFilter", a), a.$inject = ["$modalInstance", "$stateParams", "filter", "field", "api", "fields", "type"]
    }(),
    function() {
        "use strict";

        function a(a, b) {
            var c = this;
            c.cancel = a.dismiss, c.selectorname = "", c.loading = !1, c.ok = function() {
                return c.selectorname ? (c.loading = !0, void b.newSelector(c.selectorname, function(b, d) {
                    return c.loading = !1, b ? void(c.alert = d) : void a.close(d)
                })) : void(c.alert = "The Selector name cannot be empty")
            }
        }
        angular.module("apigility.modal").controller("NewSelector", a), a.$inject = ["$modalInstance", "api"]
    }(),
    function() {
        "use strict";

        function a(a, b, c, d) {
            var e = this;
            e.cancel = a.dismiss, e.selector = d, e.ok = function() {
                c.deleteSelector(d.content_name, function(b, c) {
                    return e.loading = !1, b ? void(e.alert = c) : void a.close(d.content_name)
                })
            }
        }
        angular.module("apigility.modal").controller("DeleteSelector", a), a.$inject = ["$modalInstance", "$stateParams", "api", "selector"]
    }(),
    function() {
        "use strict";

        function a(a, b, c, d) {
            var e = this;
            e.apiName = b.api, e.version = b.ver, e.rpcName = b.rpc, e.cancel = a.dismiss, e.ok = function() {
                e.loading = !0, c.deleteRpc(e.apiName, e.version, e.rpcName, e.recursive, function(b, c) {
                    return b ? (e.alert = "Error during the delete of the service", void(e.loading = !1)) : void d(function() {
                        e.loading = !1, a.close({
                            api: e.apiName,
                            version: e.version,
                            service: e.rpcName
                        })
                    }, 2e3)
                })
            }
        }
        angular.module("apigility.modal").controller("DeleteRpc", a), a.$inject = ["$modalInstance", "$stateParams", "api", "$timeout"]
    }(),
    function() {
        "use strict";

        function a(a, b, c, d) {
            var e = this;
            e.cancel = a.dismiss, e.ok = function() {
                if (!e.classname) return void(e.alert = "The View Model class name cannot be empty");
                if (0 == e.mediatypes.length) return void(e.alert = "The Mediatypes cannot be empty");
                for (var b in d.selectors)
                    if (b === e.classname) return void(e.alert = "The View Model class already exists!");
                e.loading = !0;
                var f = angular.copy(d);
                0 == f.selectors.length && (f.selectors = {}), f.selectors[e.classname] = e.mediatypes.map(c.mapTagInput), c.saveSelector(f, function(b, c) {
                    return e.loading = !1, b ? void(e.alert = c) : void a.close(c)
                })
            }
        }
        angular.module("apigility.modal").controller("NewViewModel", a), a.$inject = ["$modalInstance", "$stateParams", "api", "selector"]
    }(),
    function() {
        "use strict";

        function a(a, b, c, d, e, f) {
            var g = this;
            g.classname = f, g.mediatypes = e.selectors[f], g.cancel = a.dismiss, g.ok = function() {
                if (0 == g.mediatypes.length) return void(g.alert = "The Mediatypes cannot be empty");
                g.loading = !0;
                var b = angular.copy(e);
                b.selectors[f] = g.mediatypes.map(d.mapTagInput), d.saveSelector(b, function(b, c) {
                    return g.loading = !1, b ? void(g.alert = c) : void a.close(c)
                })
            }, g.deleteViewModelModal = function() {
                var c = b.open({
                    templateUrl: "apigility-ui/modal/delete-viewmodel.html",
                    controller: "DeleteViewModel",
                    controllerAs: "vm",
                    resolve: {
                        selector: function() {
                            return e
                        },
                        classname: function() {
                            return f
                        }
                    }
                });
                c.result.then(function(b) {
                    a.close(b)
                })
            }
        }
        angular.module("apigility.modal").controller("EditViewModel", a), a.$inject = ["$modalInstance", "$modal", "$stateParams", "api", "selector", "classname"]
    }(),
    function() {
        "use strict";

        function a(a, b, c, d, e) {
            var f = this;
            f.classname = e, f.cancel = a.dismiss, f.ok = function() {
                f.loading = !0;
                var b = angular.copy(d);
                delete b.selectors[e], 0 === Object.keys(b.selectors).length ? c.newSelector(d.content_name, function(b, c) {
                    return f.loading = !1, b ? void(f.alert = c) : void a.close(c)
                }) : c.saveSelector(b, function(b, c) {
                    return f.loading = !1, b ? void(f.alert = c) : void a.close(c)
                })
            }
        }
        angular.module("apigility.modal").controller("DeleteViewModel", a), a.$inject = ["$modalInstance", "$stateParams", "api", "selector", "classname"]
    }(),
    function() {
        "use strict";

        function a(a, b, c, d) {
            var e = this;
            e.cancel = a.dismiss, e.driver_types = d, e.db = {}, e.db.driver = d[0], e.loading = !1, e.ok = function() {
                return e.db.adapter_name ? e.db.database ? (e.loading = !0, void b.addDatabase(e.db, function(b, c) {
                    return e.loading = !1, b ? void(e.alert = c) : void a.close(c)
                })) : void(e.alert = "The Database name cannot be empty") : void(e.alert = "The Adapter name cannot be empty")
            }
        }
        angular.module("apigility.modal").controller("NewDb", a), a.$inject = ["$modalInstance", "api", "$timeout", "driver_types"]
    }(),
    function() {
        "use strict";

        function a(a, b, c, d) {
            var e = this;
            e.db = d, e.cancel = a.dismiss, e.ok = function() {
                e.loading = !0, c.deleteDatabase(e.db.adapter_name, function(b, c) {
                    return e.loading = !1, b ? void(e.alert = "Error during the delete of the Database adapter") : void a.close(e.db.adapter_name)
                })
            }
        }
        angular.module("apigility.modal").controller("DeleteDb", a), a.$inject = ["$modalInstance", "$stateParams", "api", "db"]
    }(),
    function() {
        "use strict";

        function a(a, b, c, d, e) {
            var f = this;
            f.cancel = a.dismiss, f.driver_types = d, f.db = e, f.loading = !1, f.ok = function() {
                return f.db.database ? (f.loading = !0, void b.saveDatabase(f.db, function(b, c) {
                    return f.loading = !1, b ? void(f.alert = c) : void a.close(c)
                })) : void(f.alert = "The Database name cannot be empty")
            }
        }
        angular.module("apigility.modal").controller("EditDb", a), a.$inject = ["$modalInstance", "api", "$timeout", "driver_types", "db"]
    }(),
    function() {
        "use strict";

        function a(a, b, c, d) {
            var e = this;
            e.db = d, e.cancel = a.dismiss, e.ok = function() {
                if (!e.option) return void(e.alert = "The option name cannot be empty");
                if (!e.value) return void(e.alert = "The option value cannot be empty");
                if (d.hasOwnProperty("driver_options")) {
                    if (d.driver_options.hasOwnProperty(e.option)) return void(e.alert = "The option already exists")
                } else d.driver_options = {};
                e.loading = !0;
                var b = angular.copy(d);
                b.driver_options[e.option] = e.value, c.saveDatabase(b, function(b, c) {
                    return e.loading = !1, b ? void(e.alert = c) : void a.close(c)
                })
            }
        }
        angular.module("apigility.modal").controller("AddDbOption", a), a.$inject = ["$modalInstance", "$stateParams", "api", "db"]
    }(),
    function() {
        "use strict";

        function a(a, b, c, d, e, f) {
            var g = this;
            g.db = e, g.option = f, g.value = e.driver_options[f], g.cancel = a.dismiss, g.deleteDbOptionModal = function(c, d) {
                var e = b.open({
                    templateUrl: "apigility-ui/modal/delete-dboption.html",
                    controller: "DeleteDbOption",
                    controllerAs: "vm",
                    resolve: {
                        db: function() {
                            return c
                        },
                        option: function() {
                            return d
                        }
                    }
                });
                e.result.then(function(b) {
                    a.close(b)
                })
            }, g.ok = function() {
                if (!g.value) return void(g.alert = "The option value cannot be empty");
                g.loading = !0;
                var b = angular.copy(e);
                b.driver_options[g.option] = g.value, d.saveDatabase(b, function(b, c) {
                    return g.loading = !1, b ? void(g.alert = c) : void a.close(c)
                })
            }
        }
        angular.module("apigility.modal").controller("EditDbOption", a), a.$inject = ["$modalInstance", "$modal", "$stateParams", "api", "db", "option"]
    }(),
    function() {
        "use strict";

        function a(a, b, c, d, e) {
            var f = this;
            f.option = e, f.db = d, f.cancel = a.dismiss, f.ok = function() {
                f.loading = !0;
                var b = angular.copy(d);
                delete b.driver_options[e], 0 === Object.keys(b.driver_options).length && delete b.driver_options, c.saveDatabase(b, function(b, c) {
                    return f.loading = !1, b ? void(f.alert = c) : void a.close(c)
                })
            }
        }
        angular.module("apigility.modal").controller("DeleteDbOption", a), a.$inject = ["$modalInstance", "$stateParams", "api", "db", "option"]
    }(),
    function() {
        "use strict";

        function a(a, b, c) {
            var d = this;
            d.adapter = b, d.driver_types = c, d.ok = a.dismiss
        }
        angular.module("apigility.modal").controller("ViewDoctrineParams", a), a.$inject = ["$modalInstance", "doctrine_adapter", "driver_types"]
    }(),
    function() {
        "use strict";

        function a(a, b, c, d) {
            var e = this;
            e.apiName = b.api, e.version = b.ver, e.cancel = a.dismiss, e.fields = d, e.ok = function() {
                return "" == e.strategy || void 0 == e.strategy ? void(e.alert = "Please choose a field and provide a declared strategy service") : (e.loading = !0, void c.strategyExists(encodeURIComponent(e.strategy), function(b, c) {
                    return b ? (e.loading = !1, void(e.alert = c.data.detail)) : void a.close({
                        field: e.field,
                        strategy: e.strategy
                    })
                }))
            }
        }
        angular.module("apigility.modal").controller("NewDoctrineStrategy", a), a.$inject = ["$modalInstance", "$stateParams", "api", "fields"]
    }(),
    function() {
        "use strict";

        function a(a, b, c, d) {
            var e = this;
            e.cancel = a.dismiss, e.auth_types = d, e.auth = {
                basic: {},
                digest: {},
                oauth2: {
                    pdo: {},
                    mongo: {}
                }
            }, e.auth.type = d[0], e.loading = !1, e.ok = function() {
                return e.auth.name ? "none" === e.auth.name.toLowerCase() ? void(e.alert = 'The Adapter name cannot be "' + e.auth.name + '"') : e.auth.name.endsWith("-basic") || e.auth.name.endsWith("-digest") ? void(e.alert = "The Adapter name cannot have -basic or -digest as suffix") : (e.loading = !0, void b.addAuthenticationAdapter(e.auth, function(b, c) {
                    return e.loading = !1, b ? void(e.alert = c) : void a.close(c)
                })) : void(e.alert = "The Adapter name cannot be empty")
            }
        }
        angular.module("apigility.modal").controller("NewAuth", a), a.$inject = ["$modalInstance", "api", "$timeout", "auth_types"]
    }(),
    function() {
        "use strict";

        function a(a, b, c, d, e) {
            var f = this;
            switch (f.cancel = a.dismiss, f.auth_types = d, f.auth = {
                name: e.name
            }, e.type) {
                case "basic":
                    f.auth.type = "HTTP Basic", f.auth.basic = e;
                    break;
                case "digest":
                    f.auth.type = "HTTP Digest", f.auth.digest = e;
                    break;
                case "oauth2":
                    switch (e.oauth2_type) {
                        case "pdo":
                            f.auth.type = "OAuth2 PDO", f.auth.pdo = e;
                            break;
                        case "mongo":
                            f.auth.type = "OAuth2 Mongo", f.auth.mongo = e
                    }
            }
            f.loading = !1, f.ok = function() {
                f.loading = !0, b.saveAuthenticationAdapter(f.auth, function(b, c) {
                    return f.loading = !1, b ? void(f.alert = c) : void a.close(c)
                })
            }
        }
        angular.module("apigility.modal").controller("EditAuth", a), a.$inject = ["$modalInstance", "api", "$timeout", "auth_types", "auth"]
    }(),
    function() {
        "use strict";

        function a(a, b, c, d) {
            var e = this;
            e.auth = d, e.cancel = a.dismiss, e.ok = function() {
                e.loading = !0, c.deleteAuthenticationAdapter(e.auth.name, function(b, c) {
                    return e.loading = !1, b ? void(e.alert = "Error during the delete of the Authentication adapter") : void a.close(e.auth.name)
                })
            }
        }
        angular.module("apigility.modal").controller("DeleteAuth", a), a.$inject = ["$modalInstance", "$stateParams", "api", "auth"]
    }(),
    function() {
        "use strict";

        function a(a, b, c, d) {
            var e = this;
            e.auth = d, e.cancel = a.dismiss, e.ok = function() {
                if (!e.option) return void(e.alert = "The option name cannot be empty");
                if (!e.value) return void(e.alert = "The option value cannot be empty");
                if (d.hasOwnProperty("oauth2_options") && null !== d.oauth2_options) {
                    if (d.oauth2_options.hasOwnProperty(e.option)) return void(e.alert = "The option already exists")
                } else d.oauth2_options = {};
                e.loading = !0;
                var b = angular.copy(d);
                b.oauth2_options[e.option] = e.value, c.saveOptionsAuthenticationAdapter(b, function(b, c) {
                    return e.loading = !1, b ? void(e.alert = c) : void a.close(c)
                })
            }
        }
        angular.module("apigility.modal").controller("AddAuthOption", a), a.$inject = ["$modalInstance", "$stateParams", "api", "auth"]
    }(),
    function() {
        "use strict";

        function a(a, b, c, d, e, f) {
            var g = this;
            g.auth = e, g.option = f, g.value = e.oauth2_options[f], g.cancel = a.dismiss, g.deleteAuthOptionModal = function(c, d) {
                var e = b.open({
                    templateUrl: "apigility-ui/modal/delete-authoption.html",
                    controller: "DeleteAuthOption",
                    controllerAs: "vm",
                    resolve: {
                        auth: function() {
                            return c
                        },
                        option: function() {
                            return d
                        }
                    }
                });
                e.result.then(function(b) {
                    a.close(b)
                })
            }, g.ok = function() {
                if (!g.value) return void(g.alert = "The option value cannot be empty");
                g.loading = !0;
                var b = angular.copy(e);
                b.oauth2_options[g.option] = g.value, d.saveOptionsAuthenticationAdapter(b, function(b, c) {
                    return g.loading = !1, b ? void(g.alert = c) : void a.close(c)
                })
            }
        }
        angular.module("apigility.modal").controller("EditAuthOption", a), a.$inject = ["$modalInstance", "$modal", "$stateParams", "api", "auth", "option"]
    }(),
    function() {
        "use strict";

        function a(a, b, c, d, e) {
            var f = this;
            f.option = e, f.auth = d, f.cancel = a.dismiss, f.ok = function() {
                f.loading = !0;
                var b = angular.copy(d);
                delete b.oauth2_options[e], 0 === Object.keys(b.oauth2_options).length && (b.oauth2_options = null), c.saveOptionsAuthenticationAdapter(b, function(b, c) {
                    return f.loading = !1, b ? void(f.alert = c) : void a.close(c)
                })
            }
        }
        angular.module("apigility.modal").controller("DeleteAuthOption", a), a.$inject = ["$modalInstance", "$stateParams", "api", "auth", "option"]
    }(),
    function() {
        "use strict";
        angular.module("apigility.api-module", ["ui.router"])
    }(),
    function() {
        "use strict";

        function a(a) {
            a.state("ag.apimodule", b)
        }
        angular.module("apigility.api-module").config(a);
        var b = {
            url: "/module/:api/:ver",
            views: {
                "content@": {
                    templateUrl: "apigility-ui/api-module/api-module.html",
                    controller: "ApiModule",
                    controllerAs: "vm"
                }
            }
        };
        a.$inject = ["$stateProvider"]
    }(),
    function() {
        "use strict";

        function a(a, b, c, d, e) {
            var f = this;
            f.apiName = d.api, f.version = d.ver, f.loading = !1, f.setSelected = e.setSelected, f.getSelected = e.getSelected, f.disabled = !e.isLastVersion(f.version, f.apiName), a.getRestList(f.apiName, f.version, function(a) {
                f.rest = a
            }), a.getRpcList(f.apiName, f.version, function(a) {
                f.rpc = a
            }), a.getAuthenticationTypes(function(a) {
                f.auth_types = a
            }), a.getModuleAuthentication(f.apiName, f.version, function(a) {
                a === !1 ? f.auth_type = "None" : f.auth_type = a
            });
            for (var g = e.getApis(), h = 0; h < g.length; h++)
                if (g[h].name === f.apiName) {
                    f.module = g[h];
                    break
                }
            f.newVersionModal = function() {
                var a = b.open({
                    templateUrl: "apigility-ui/modal/new-version.html",
                    controller: "NewVersion",
                    controllerAs: "vm"
                });
                a.result.then(function(a) {
                    a.hasOwnProperty("version") && (e.addVersion(f.apiName, a.version), e.setSelectedVersion(f.apiName, a.version), c.go("ag.apimodule", {
                        api: f.apiName,
                        ver: a.version
                    }))
                })
            }, f.deleteApiModal = function() {
                var a = b.open({
                    templateUrl: "apigility-ui/modal/delete-api.html",
                    controller: "DeleteApi",
                    controllerAs: "vm"
                });
                a.result.then(function(a) {
                    e.removeApi(a), c.go("ag", null, {
                        reload: !0
                    })
                })
            }, f.newServiceModal = function() {
                var a = b.open({
                    templateUrl: "apigility-ui/modal/new-service.html",
                    controller: "NewService",
                    controllerAs: "vm",
                    resolve: {
                        apiname: function() {
                            return f.apiName
                        },
                        version: function() {
                            return f.version
                        }
                    }
                });
                a.result.then(function(a) {
                    a.hasOwnProperty("rest") ? (e.setSelectedVersion(a.api, a.ver), c.go("ag.rest", {
                        api: a.api,
                        ver: a.ver,
                        rest: a.rest
                    }), f.setSelected("api" + a.api + "rest" + a.rest)) : a.hasOwnProperty("rpc") ? (e.setSelectedVersion(a.api, a.ver), c.go("ag.rpc", {
                        api: a.api,
                        ver: a.ver,
                        rpc: a.rpc
                    }), f.setSelected("api" + a.api + "rpc" + a.rpc)) : a.hasOwnProperty("rests") && (e.setSelectedVersion(a.api, a.ver), c.go("ag.apimodule", {
                        api: a.api,
                        ver: a.ver
                    }))
                })
            }, f.addServiceDescriptionModal = function(a, d) {
                var e = b.open({
                    templateUrl: "apigility-ui/modal/add-service-description.html",
                    controller: "AddServiceDescription",
                    controllerAs: "vm",
                    resolve: {
                        service: function() {
                            return a
                        },
                        type: function() {
                            return d
                        }
                    }
                });
                e.result.then(function(a) {
                    c.reload()
                })
            }, f.setDefaultVersion = function() {
                f.loading = !0, a.setDefaultVersion(f.apiName, f.module.default_version, function(a, b) {
                    return f.loading = !1, a ? void(f.alert = b) : void 0
                })
            }, f.saveAuthentication = function(b) {
                f.loading = !0, "none" === b.toLowerCase() ? a.deleteModuleAuthentication(f.apiName, f.version, function(a, b) {
                    return f.loading = !1, a ? void(f.alert = b) : void 0
                }) : a.saveModuleAuthentication(f.apiName, f.version, b, function(a, b) {
                    return f.loading = !1, a ? void(f.alert = b) : void 0
                })
            }
        }
        angular.module("apigility").controller("ApiModule", a), a.$inject = ["api", "$modal", "$state", "$stateParams", "SidebarService"]
    }(),
    function() {
        "use strict";
        angular.module("apigility.rest", ["ui.router"])
    }(),
    function() {
        "use strict";

        function a(a) {
            a.state("ag.rest", b)
        }
        angular.module("apigility.rest").config(a);
        var b = {
            url: "/module/:api/:ver/rest/:rest",
            views: {
                "content@": {
                    templateUrl: "apigility-ui/rest/rest.html",
                    controller: "Rest",
                    controllerAs: "vm"
                }
            }
        };
        a.$inject = ["$stateProvider"]
    }(),
    function() {
        "use strict";

        function a(a, b, c, d, e, f, g, h, i) {
            function j() {
                l.selectorNames = [], l.adapterNames = [], l.tags = {
                    accept_whitelist: [],
                    content_type_whitelist: [],
                    collection_query_whitelist: []
                }, a.getHydrators(function(a) {
                    l.hydrators = a
                }), a.getDatabase(function(a, b) {
                    for (var c in b.db_adapter) l.adapterNames.push(b.db_adapter[c].adapter_name)
                }), a.getDoctrineAdapters(function(a, b) {
                    l.doctrine = b.doctrine_adapter
                }), a.getRest(l.apiName, l.version, l.restName, function(b) {
                    l.rest = b, l.serviceName = l.rest.service_name, l.isDoctrine = angular.isDefined(b.object_manager), l.rest.accept_whitelist.forEach(function(a) {
                        l.tags.accept_whitelist.push({
                            text: a
                        })
                    }), l.rest.content_type_whitelist.forEach(function(a) {
                        l.tags.content_type_whitelist.push({
                            text: a
                        })
                    }), l.rest.collection_query_whitelist.forEach(function(a) {
                        l.tags.collection_query_whitelist.push({
                            text: a
                        })
                    }), l.isDoctrine && (0 === l.rest.strategies.length && (l.rest.strategies = {}), a.getRestDoctrineMetadata(b.object_manager, b.entity_class, function(a, b) {
                        return a ? void console.log(b) : void(l.doctrineMetadata = b)
                    })), l.rest.source_code = [{
                        name: "Collection Class",
                        classname: l.rest.collection_class
                    }, {
                        name: "Entity Class",
                        classname: l.rest.entity_class
                    }], l.rest.resource_class && l.rest.source_code.push({
                        name: "Resource Class",
                        classname: l.rest.resource_class
                    }, {
                        name: "Resource Factory",
                        classname: l.rest.resource_class + "Factory"
                    }), l.getSourceCode(l.rest.source_code[0].classname), l.source = l.rest.source_code[0], a.getContentNegotiation(function(a) {
                        l.content_negotiation = a;
                        for (var b in a) l.selectorNames.push(a[b].content_name)
                    })
                })
            }

            function k() {
                a.getAuthorizationRest(l.apiName, l.version, l.restName, function(a, b) {
                    return a ? void console.log("Error getting the authorization data") : void(l.auth = b)
                })
            }
            var l = this;
            l.apiName = c.api, l.version = c.ver, l.restName = c.rest, l.httpMethods = ["GET", "POST", "PUT", "PATCH", "DELETE"], l.disabled = !e.isLastVersion(l.version, l.apiName), l.selectHydrator = function(a, b) {}, j(), k(), l.saveGeneral = function() {
                l.loading = !0, l.adapter && (l.rest.adapter_name = l.adapter.adapter_name), l.rest.collection_query_whitelist = l.tags.collection_query_whitelist.map(a.mapTagInput), l.rest.hydrator_name.name && (l.rest.hydrator_name = l.rest.hydrator_name.name), a.updateGeneralRest(l.apiName, l.version, l.restName, l.rest, l.isDoctrine, function(a, b) {
                    return l.loading = !1, a ? void(l.alert = b) : void 0
                })
            }, l.resetGeneral = function() {
                j()
            }, l.newDoctrineStrategyModal = function() {
                var a = b.open({
                    templateUrl: "apigility-ui/modal/new-doctrinestrategy.html",
                    controller: "NewDoctrineStrategy",
                    controllerAs: "vm",
                    resolve: {
                        fields: function() {
                            var a = [];
                            return angular.forEach(l.doctrineMetadata.fieldNames, function(b) {
                                a[b] = b
                            }), a
                        }
                    }
                });
                a.result.then(function(a) {
                    l.rest.strategies[a.field] = a.strategy
                })
            }, l.removeStrategy = function(a) {
                delete l.rest.strategies[a]
            }, l.hasProperties = function(a) {
                for (var b in a)
                    if (a.hasOwnProperty(b)) return !0;
                return !1
            }, l.saveContentNegotiation = function() {
                l.loading = !0, l.rest.accept_whitelist = l.tags.accept_whitelist.map(a.mapTagInput), l.rest.content_type_whitelist = l.tags.content_type_whitelist.map(a.mapTagInput), a.updateContentNegotiationRest(l.apiName, l.version, l.restName, l.rest, function(a, b) {
                    return l.loading = !1, a ? void(l.alert = b) : void 0
                })
            }, l.resetContentNegotiation = function() {
                j()
            }, l.saveAuthorization = function() {
                l.loading = !0, a.saveAuthorizationRest(l.apiName, l.version, l.restName, l.auth, function(a, b) {
                    return l.loading = !1, a ? void(l.alert = b) : void 0
                })
            }, l.resetAuthorization = function() {
                k()
            }, l.saveDocumentation = function() {
                a.saveRestDoc(l.apiName, l.version, l.restName, l.rest.documentation, function(a, b) {
                    return l.loading = !1, a ? void(l.alert = b) : void 0
                })
            }, l.resetDocumentation = function() {
                j()
            }, l.deleteRestModal = function() {
                var a = b.open({
                    templateUrl: "apigility-ui/modal/delete-rest.html",
                    controller: "DeleteRest",
                    controllerAs: "vm",
                    resolve: {
                        isDoctrine: function() {
                            return void 0 !== l.rest.object_manager
                        }
                    }
                });
                a.result.then(function(a) {
                    e.removeRestService(a.api, a.service), f.go("ag.apimodule", {
                        api: a.api,
                        ver: a.version
                    }, {
                        reload: !0
                    })
                })
            }, l.newFieldModal = function() {
                var a = b.open({
                    templateUrl: "apigility-ui/modal/new-field.html",
                    controller: "NewField",
                    controllerAs: "vm",
                    resolve: {
                        fields: function() {
                            return l.rest.fields
                        },
                        type: function() {
                            return "rest"
                        }
                    }
                });
                a.result.then(function(a) {
                    l.rest.fields = a
                })
            }, l.editFieldModal = function(a) {
                var c = b.open({
                    templateUrl: "apigility-ui/modal/edit-field.html",
                    controller: "EditField",
                    controllerAs: "vm",
                    resolve: {
                        field: function() {
                            return a
                        },
                        fields: function() {
                            return l.rest.fields
                        },
                        type: function() {
                            return "rest"
                        }
                    }
                });
                c.result.then(function(a) {
                    l.rest.fields = a
                })
            }, l.deleteFieldModal = function(a) {
                var c = b.open({
                    templateUrl: "apigility-ui/modal/delete-field.html",
                    controller: "DeleteField",
                    controllerAs: "vm",
                    resolve: {
                        field: function() {
                            return a
                        },
                        fields: function() {
                            return l.rest.fields
                        },
                        type: function() {
                            return "rest"
                        }
                    }
                });
                c.result.then(function(a) {
                    l.rest.fields = a
                })
            }, l.addValidatorModal = function(a) {
                var c = b.open({
                    templateUrl: "apigility-ui/modal/add-validator.html",
                    controller: "AddValidator",
                    controllerAs: "vm",
                    resolve: {
                        field: function() {
                            return a
                        },
                        fields: function() {
                            return l.rest.fields
                        },
                        type: function() {
                            return "rest"
                        }
                    }
                });
                c.result.then(function(a) {
                    l.rest.fields = a
                })
            }, l.editValidatorModal = function(a, c) {
                var d = b.open({
                    templateUrl: "apigility-ui/modal/edit-validator.html",
                    controller: "EditValidator",
                    controllerAs: "vm",
                    resolve: {
                        field: function() {
                            return a
                        },
                        validator: function() {
                            return c
                        },
                        fields: function() {
                            return l.rest.fields
                        },
                        type: function() {
                            return "rest"
                        }
                    }
                });
                d.result.then(function(a) {
                    l.rest.fields = a
                })
            }, l.addFilterModal = function(a) {
                var c = b.open({
                    templateUrl: "apigility-ui/modal/add-filter.html",
                    controller: "AddFilter",
                    controllerAs: "vm",
                    resolve: {
                        field: function() {
                            return a
                        },
                        fields: function() {
                            return l.rest.fields
                        },
                        type: function() {
                            return "rest"
                        }
                    }
                });
                c.result.then(function(a) {
                    l.rest.fields = a
                })
            }, l.editFilterModal = function(a, c) {
                var d = b.open({
                    templateUrl: "apigility-ui/modal/edit-filter.html",
                    controller: "EditFilter",
                    controllerAs: "vm",
                    resolve: {
                        field: function() {
                            return a
                        },
                        filter: function() {
                            return c
                        },
                        fields: function() {
                            return l.rest.fields
                        },
                        type: function() {
                            return "rest"
                        }
                    }
                });
                d.result.then(function(a) {
                    l.rest.fields = a
                })
            }, l.getSourceCode = function(b) {
                a.getSourceCode(l.apiName, b, function(a, b) {
                    l.sourcecode = h.trustAsHtml(b.source), l.file = b.file
                })
            }, l.generateFromConfiguration = function(a, b, c) {
                return i.fromConfiguration(a, b, c, l.rest.fields, l.tags.accept_whitelist, l.rest.route_match, l.rest.collection_name)
            }
        }
        angular.module("apigility.rest").controller("Rest", a), a.$inject = ["api", "$modal", "$stateParams", "$rootScope", "SidebarService", "$state", "$scope", "$sce", "documentation"]
    }(),
    function() {
        "use strict";
        angular.module("apigility.rpc", ["ui.router"])
    }(),
    function() {
        "use strict";

        function a(a) {
            a.state("ag.rpc", b)
        }
        angular.module("apigility.rpc").config(a);
        var b = {
            url: "/module/:api/:ver/rpc/:rpc",
            views: {
                "content@": {
                    templateUrl: "apigility-ui/rpc/rpc.html",
                    controller: "Rpc",
                    controllerAs: "vm"
                }
            }
        };
        a.$inject = ["$stateProvider"]
    }(),
    function() {
        "use strict";

        function a(a, b, c, d, e, f, g, h, i) {
            function j() {
                l.tags = {
                    accept_whitelist: [],
                    content_type_whitelist: []
                }, a.getRpc(l.apiName, l.version, l.rpcName, function(b, c) {
                    return b ? void(l.alert = "The RPC service doesn't exist. Try to choose a different version!") : (l.rpc = c, l.serviceName = l.rpc.service_name, l.rpc.accept_whitelist.forEach(function(a) {
                        l.tags.accept_whitelist.push({
                            text: a
                        })
                    }), l.rpc.content_type_whitelist.forEach(function(a) {
                        l.tags.content_type_whitelist.push({
                            text: a
                        })
                    }), l.rpc.source_code = [{
                        name: "Controller Class",
                        classname: l.rpc.controller_class
                    }, {
                        name: "Controller Factory",
                        classname: l.rpc.controller_class + "Factory"
                    }], l.getSourceCode(l.rpc.source_code[0].classname), l.source = l.rpc.source_code[0], void a.getContentNegotiation(function(a) {
                        l.content_negotiation = a;
                        for (var b in a) l.selectorNames.push(a[b].content_name)
                    }))
                })
            }

            function k() {
                a.getAuthorizationRpc(l.apiName, l.version, l.rpcName, function(a, b) {
                    return a ? void console.log("Error getting the authorization data") : void(l.auth = b)
                })
            }
            var l = this;
            l.apiName = c.api, l.version = c.ver, l.rpcName = c.rpc, l.httpMethods = ["GET", "POST", "PUT", "PATCH", "DELETE"], l.disabled = !e.isLastVersion(l.version, l.apiName), l.selectorNames = [], j(), k(), l.saveGeneral = function() {
                l.loading = !0, l.rpc.accept_whitelist = l.tags.accept_whitelist.map(a.mapTagInput), l.rpc.content_type_whitelist = l.tags.content_type_whitelist.map(a.mapTagInput), a.updateGeneralRpc(l.apiName, l.version, l.rpcName, l.rpc, function(a, b) {
                    return l.loading = !1, a ? void(l.alert = b) : void 0
                })
            }, l.resetGeneral = function() {
                j()
            }, l.saveAuthorization = function() {
                l.loading = !0, a.saveAuthorizationRpc(l.apiName, l.version, l.rpcName, l.auth, function(a, b) {
                    return l.loading = !1, a ? void(l.alert = b) : void 0
                })
            }, l.resetAuthorization = function() {
                k()
            }, l.saveDocumentation = function() {
                l.loading = !0, a.saveRpcDoc(l.apiName, l.version, l.rpcName, l.rpc.documentation, function(a, b) {
                    return l.loading = !1, a ? (error = !0, void(l.alert = b)) : void 0
                })
            }, l.resetDocumentation = function() {
                j()
            }, l.deleteRpcModal = function() {
                var a = b.open({
                    templateUrl: "apigility-ui/modal/delete-rpc.html",
                    controller: "DeleteRpc",
                    controllerAs: "vm"
                });
                a.result.then(function(a) {
                    e.removeRpcService(a.api, a.service), f.go("ag.apimodule", {
                        api: a.api,
                        ver: a.version
                    }, {
                        reload: !0
                    })
                })
            }, l.newFieldModal = function() {
                var a = b.open({
                    templateUrl: "apigility-ui/modal/new-field.html",
                    controller: "NewField",
                    controllerAs: "vm",
                    resolve: {
                        fields: function() {
                            return l.rpc.fields
                        },
                        type: function() {
                            return "rpc"
                        }
                    }
                });
                a.result.then(function(a) {
                    l.rpc.fields = a
                })
            }, l.editFieldModal = function(a) {
                var c = b.open({
                    templateUrl: "apigility-ui/modal/edit-field.html",
                    controller: "EditField",
                    controllerAs: "vm",
                    resolve: {
                        field: function() {
                            return a
                        },
                        fields: function() {
                            return l.rpc.fields
                        },
                        type: function() {
                            return "rpc"
                        }
                    }
                });
                c.result.then(function(a) {
                    l.rpc.fields = a
                })
            }, l.deleteFieldModal = function(a) {
                var c = b.open({
                    templateUrl: "apigility-ui/modal/delete-field.html",
                    controller: "DeleteField",
                    controllerAs: "vm",
                    resolve: {
                        field: function() {
                            return a
                        },
                        fields: function() {
                            return l.rpc.fields
                        },
                        type: function() {
                            return "rpc"
                        }
                    }
                });
                c.result.then(function(a) {
                    l.rpc.fields = a
                })
            }, l.addValidatorModal = function(a) {
                var c = b.open({
                    templateUrl: "apigility-ui/modal/add-validator.html",
                    controller: "AddValidator",
                    controllerAs: "vm",
                    resolve: {
                        field: function() {
                            return a
                        },
                        fields: function() {
                            return l.rpc.fields
                        },
                        type: function() {
                            return "rpc"
                        }
                    }
                });
                c.result.then(function(a) {
                    l.rpc.fields = a
                })
            }, l.editValidatorModal = function(a, c) {
                var d = b.open({
                    templateUrl: "apigility-ui/modal/edit-validator.html",
                    controller: "EditValidator",
                    controllerAs: "vm",
                    resolve: {
                        field: function() {
                            return a
                        },
                        validator: function() {
                            return c
                        },
                        fields: function() {
                            return l.rpc.fields
                        },
                        type: function() {
                            return "rpc"
                        }
                    }
                });
                d.result.then(function(a) {
                    l.rpc.fields = a
                })
            }, l.addFilterModal = function(a) {
                var c = b.open({
                    templateUrl: "apigility-ui/modal/add-filter.html",
                    controller: "AddFilter",
                    controllerAs: "vm",
                    resolve: {
                        field: function() {
                            return a
                        },
                        fields: function() {
                            return l.rpc.fields
                        },
                        type: function() {
                            return "rpc"
                        }
                    }
                });
                c.result.then(function(a) {
                    l.rpc.fields = a
                })
            }, l.editFilterModal = function(a, c) {
                var d = b.open({
                    templateUrl: "apigility-ui/modal/edit-filter.html",
                    controller: "EditFilter",
                    controllerAs: "vm",
                    resolve: {
                        field: function() {
                            return a
                        },
                        filter: function() {
                            return c
                        },
                        fields: function() {
                            return l.rpc.fields
                        },
                        type: function() {
                            return "rpc"
                        }
                    }
                });
                d.result.then(function(a) {
                    l.rpc.fields = a
                })
            }, l.getSourceCode = function(b) {
                a.getSourceCode(l.apiName, b, function(a, b) {
                    l.sourcecode = h.trustAsHtml(b.source), l.file = b.file
                })
            }, l.generateFromConfiguration = function(a, b) {
                return i.fromConfiguration(a, b, null, l.rpc.fields, l.tags.accept_whitelist, l.rpc.route_match, null)
            }
        }
        angular.module("apigility.rpc").controller("Rpc", a), a.$inject = ["api", "$modal", "$stateParams", "$rootScope", "SidebarService", "$state", "$scope", "$sce", "documentation"]
    }(),
    function() {
        "use strict";
        angular.module("apigility.content-negotiation", ["ui.router"])
    }(),
    function() {
        "use strict";

        function a(a) {
            a.state("ag.content", b)
        }
        angular.module("apigility.content-negotiation").config(a);
        var b = {
            url: "/content",
            views: {
                "content@": {
                    templateUrl: "apigility-ui/content-negotiation/content-negotiation.html",
                    controller: "ContentNegotiation",
                    controllerAs: "vm"
                }
            }
        };
        a.$inject = ["$stateProvider"]
    }(),
    function() {
        "use strict";

        function a(a, b, c, d) {
            function e(a) {
                for (var b = 0; b < f.content_negotiation.length; b++)
                    if (f.content_negotiation[b].content_name === a.content_name) {
                        f.content_negotiation[b] = a;
                        break
                    }
            }
            var f = this;
            a.getContentNegotiation(function(a) {
                f.content_negotiation = a
            }), f.newSelectorModal = function() {
                var a = b.open({
                    templateUrl: "apigility-ui/modal/new-selector.html",
                    controller: "NewSelector",
                    controllerAs: "vm"
                });
                a.result.then(function(a) {
                    f.content_negotiation.push(a)
                })
            }, f.deleteSelectorModal = function(a) {
                var c = b.open({
                    templateUrl: "apigility-ui/modal/delete-selector.html",
                    controller: "DeleteSelector",
                    controllerAs: "vm",
                    resolve: {
                        selector: function() {
                            return a
                        }
                    }
                });
                c.result.then(function(a) {
                    for (var b = 0; b < f.content_negotiation.length; b++)
                        if (f.content_negotiation[b].content_name === a) {
                            f.content_negotiation.splice(b, 1);
                            break
                        }
                })
            }, f.addViewModel = function(a) {
                var c = b.open({
                    templateUrl: "apigility-ui/modal/new-viewmodel.html",
                    controller: "NewViewModel",
                    controllerAs: "vm",
                    resolve: {
                        selector: function() {
                            return a
                        }
                    }
                });
                c.result.then(function(a) {
                    e(a)
                })
            }, f.editViewModel = function(a, c) {
                var d = b.open({
                    templateUrl: "apigility-ui/modal/edit-viewmodel.html",
                    controller: "EditViewModel",
                    controllerAs: "vm",
                    resolve: {
                        selector: function() {
                            return a
                        },
                        classname: function() {
                            return c
                        }
                    }
                });
                d.result.then(function(a) {
                    e(a)
                })
            }
        }
        angular.module("apigility.content-negotiation").controller("ContentNegotiation", a), a.$inject = ["api", "$modal", "$state", "$stateParams"]
    }(),
    function() {
        "use strict";
        angular.module("apigility.authentication", ["ui.router"])
    }(),
    function() {
        "use strict";

        function a(a) {
            a.state("ag.authentication", b)
        }
        angular.module("apigility.authentication").config(a);
        var b = {
            url: "/auth",
            views: {
                "content@": {
                    templateUrl: "apigility-ui/authentication/authentication.html",
                    controller: "Authentication",
                    controllerAs: "vm"
                }
            }
        };
        a.$inject = ["$stateProvider"]
    }(),
    function() {
        "use strict";

        function a(a, b, c, d) {
            function e(a) {
                for (var b = 0; b < f.adapters.length; b++)
                    if (f.adapters[b].name === a.name) {
                        f.adapters[b] = a;
                        break
                    }
            }
            var f = this;
            f.auth_types = ["HTTP Basic", "HTTP Digest", "OAuth2 PDO", "OAuth2 Mongo"], a.getAuthenticationAdapters(function(a, b) {
                f.adapters = b
            }), f.newAuthModal = function() {
                var a = b.open({
                    templateUrl: "apigility-ui/modal/new-auth.html",
                    controller: "NewAuth",
                    controllerAs: "vm",
                    resolve: {
                        auth_types: function() {
                            return f.auth_types
                        }
                    }
                });
                a.result.then(function(a) {
                    f.adapters.push(a)
                })
            }, f.deleteAuthModal = function(a) {
                var c = b.open({
                    templateUrl: "apigility-ui/modal/delete-auth.html",
                    controller: "DeleteAuth",
                    controllerAs: "vm",
                    resolve: {
                        auth: function() {
                            return a
                        }
                    }
                });
                c.result.then(function(a) {
                    for (var b = 0; b < f.adapters.length; b++)
                        if (f.adapters[b].name === a) {
                            f.adapters.splice(b, 1);
                            break
                        }
                })
            }, f.editAuthModal = function(a) {
                var c = b.open({
                    templateUrl: "apigility-ui/modal/edit-auth.html",
                    controller: "EditAuth",
                    controllerAs: "vm",
                    resolve: {
                        auth: function() {
                            return a
                        },
                        auth_types: function() {
                            return f.auth_types
                        }
                    }
                });
                c.result.then(function(a) {})
            }, f.addAuthOptionModal = function(a) {
                var c = b.open({
                    templateUrl: "apigility-ui/modal/add-authoption.html",
                    controller: "AddAuthOption",
                    controllerAs: "vm",
                    resolve: {
                        auth: function() {
                            return a
                        }
                    }
                });
                c.result.then(function(a) {
                    e(a)
                })
            }, f.editAuthOptionModal = function(a, c) {
                var d = b.open({
                    templateUrl: "apigility-ui/modal/edit-authoption.html",
                    controller: "EditAuthOption",
                    controllerAs: "vm",
                    resolve: {
                        auth: function() {
                            return a
                        },
                        option: function() {
                            return c
                        }
                    }
                });
                d.result.then(function(a) {
                    e(a)
                })
            }
        }
        angular.module("apigility.authentication").controller("Authentication", a), a.$inject = ["api", "$modal", "$state", "$stateParams"]
    }(),
    function() {
        "use strict";
        angular.module("apigility.database", ["ui.router"])
    }(),
    function() {
        "use strict";

        function a(a) {
            a.state("ag.database", b)
        }
        angular.module("apigility.database").config(a);
        var b = {
            url: "/db",
            views: {
                "content@": {
                    templateUrl: "apigility-ui/database/database.html",
                    controller: "Database",
                    controllerAs: "vm"
                }
            }
        };
        a.$inject = ["$stateProvider"]
    }(),
    function() {
        "use strict";

        function a(a, b, c, d) {
            function e(a) {
                for (var b = 0; b < f.db_adapter.length; b++)
                    if (f.db_adapter[b].adapter_name === a.adapter_name) {
                        f.db_adapter[b] = a;
                        break
                    }
            }
            var f = this;
            f.driver_types = ["IbmDb2", "Mysqli", "Oci8", "PDO_Mysql", "PDO_Oci", "PDO_Pgsql", "PDO_Sqlite", "Pgsql", "Sqlsrv"], f.doctrine_driver_types = ["Doctrine\\DBAL\\Driver\\DrizzlePDOMySql\\DrizzlePDOMySql", "Doctrine\\DBAL\\Driver\\DB2Driver", "Doctrine\\DBAL\\Driver\\Mysqli\\Driver", "Doctrine\\DBAL\\Driver\\OCI8\\Driver", "Doctrine\\DBAL\\Driver\\PDOIbm\\Driver", "Doctrine\\DBAL\\Driver\\PDOMySql\\Driver", "Doctrine\\DBAL\\Driver\\PDOOracle\\Driver", "Doctrine\\DBAL\\Driver\\PDOPgSql\\Driver", "Doctrine\\DBAL\\Driver\\PDOSqlite\\Driver", "Doctrine\\DBAL\\Driver\\PDOSqlsrv\\Driver", "Doctrine\\DBAL\\Driver\\SQLAnywhere\\Driver", "Doctrine\\DBAL\\Driver\\SQLSrv\\Driver"], a.getDatabase(function(a, b) {
                f.db_adapter = b.db_adapter
            }), a.getDoctrineAdapters(function(a, b) {
                f.doctrine_adapter = b.doctrine_adapter
            }), f.newDbModal = function() {
                var a = b.open({
                    templateUrl: "apigility-ui/modal/new-db.html",
                    controller: "NewDb",
                    controllerAs: "vm",
                    resolve: {
                        driver_types: function() {
                            return f.driver_types
                        }
                    }
                });
                a.result.then(function(a) {
                    f.db_adapter.push(a)
                })
            }, f.deleteDbModal = function(a) {
                var c = b.open({
                    templateUrl: "apigility-ui/modal/delete-db.html",
                    controller: "DeleteDb",
                    controllerAs: "vm",
                    resolve: {
                        db: function() {
                            return a
                        }
                    }
                });
                c.result.then(function(a) {
                    for (var b = 0; b < f.db_adapter.length; b++)
                        if (f.db_adapter[b].adapter_name === a) {
                            f.db_adapter.splice(b, 1);
                            break
                        }
                })
            }, f.editDbModal = function(a) {
                var c = b.open({
                    templateUrl: "apigility-ui/modal/edit-db.html",
                    controller: "EditDb",
                    controllerAs: "vm",
                    resolve: {
                        db: function() {
                            return a
                        },
                        driver_types: function() {
                            return f.driver_types
                        }
                    }
                });
                c.result.then(function(a) {
                    e(a)
                })
            }, f.addDbOptionModal = function(a) {
                var c = b.open({
                    templateUrl: "apigility-ui/modal/add-dboption.html",
                    controller: "AddDbOption",
                    controllerAs: "vm",
                    resolve: {
                        db: function() {
                            return a
                        }
                    }
                });
                c.result.then(function(a) {
                    e(a)
                })
            }, f.editDbOptionModal = function(a, c) {
                var d = b.open({
                    templateUrl: "apigility-ui/modal/edit-dboption.html",
                    controller: "EditDbOption",
                    controllerAs: "vm",
                    resolve: {
                        db: function() {
                            return a
                        },
                        option: function() {
                            return c
                        }
                    }
                });
                d.result.then(function(a) {
                    e(a)
                })
            }, f.viewDoctrineParamsModal = function(a) {
                b.open({
                    templateUrl: "apigility-ui/modal/view-doctrineparams.html",
                    controller: "ViewDoctrineParams",
                    controllerAs: "vm",
                    resolve: {
                        doctrine_adapter: function() {
                            return a
                        },
                        driver_types: function() {
                            return f.doctrine_driver_types
                        }
                    }
                })
            }
        }
        angular.module("apigility.database").controller("Database", a), a.$inject = ["api", "$modal", "$state", "$stateParams"]
    }(),
    function() {
        "use strict";
        angular.module("apigility.documentation", ["ui.router"])
    }(),
    function() {
        "use strict";

        function a(a) {
            a.state("ag.documentation", b)
        }
        angular.module("apigility.documentation").config(a);
        var b = {
            url: "/doc/:api/:ver",
            views: {
                "content@": {
                    templateUrl: "apigility-ui/documentation/documentation.html",
                    controller: "Documentation",
                    controllerAs: "vm"
                }
            }
        };
        a.$inject = ["$stateProvider"]
    }(),
    function() {
        "use strict";

        function a(a, b, c, d) {
            var e = this;
            e.apiName = d.api, e.version = d.ver, e.apiName ? a.getApiDocument(e.apiName, e.version, function(a, b) {
                b.services.forEach(function(a) {
                    a.route_collection = a.route.replace(/\[.*?\]/g, "")
                }), e.doc = b
            }) : a.getApiDocumentList(function(a, b) {
                e.doc = b
            })
        }
        angular.module("apigility.documentation").controller("Documentation", a), a.$inject = ["api", "$modal", "$state", "$stateParams"]
    }(),
    function() {
        "use strict";
        angular.module("apigility.package", ["ui.router"])
    }(),
    function() {
        "use strict";

        function a(a) {
            a.state("ag.package", b)
        }
        angular.module("apigility.package").config(a);
        var b = {
            url: "/package",
            views: {
                "content@": {
                    templateUrl: "apigility-ui/package/package.html",
                    controller: "Package",
                    controllerAs: "vm"
                }
            }
        };
        a.$inject = ["$stateProvider"]
    }(),
    function() {
        "use strict";

        function a(a, b, c, d, e, f, g) {
            var h = this;
            h.formats = ["ZIP", "TAR", "TGZ", "ZPK"], h.apis = f.getApis(), 0 == h.apis.length && (h.alert = "In order to create a package file, ready for deployment, you need to create a new API first."), h["package"] = g.get("package"), h["package"] || (h["package"] = {}, h["package"].format = "ZIP", h["package"].modules = angular.copy(h.modules), h["package"].composer = !0), h.buildPackage = function() {
                if (h.alert = "", 0 === h["package"].modules.length) return void(h.alert = "You need to select at least one API to build the package");
                h.loading = !0;
                var c = (new Date).getTime();
                b.buildPackage(h["package"], h.apis, function(b, d) {
                    if (h.loading = !1, b) return void(h.alert = d);
                    if (d.token && d.format) {
                        var e = (new Date).getTime();
                        h["package"].composer && (h["package"].time = (e - c) / 1e3), g.set("package", h["package"]), window.location = a + "/package?token=" + d.token + "&format=" + d.format
                    }
                })
            }
        }
        angular.module("apigility.package").controller("Package", a), a.$inject = ["agApiPath", "api", "$modal", "$state", "$stateParams", "SidebarService", "localStorageService"]
    }(),
    function() {
        "use strict";
        angular.module("apigility.about", ["ui.router"])
    }(),
    function() {
        "use strict";

        function a(a) {
            a.state("ag.about", b)
        }
        angular.module("apigility.about").config(a);
        var b = {
            url: "/about",
            views: {
                "content@": {
                    templateUrl: "apigility-ui/about/about.html",
                    controller: "About",
                    controllerAs: "vm"
                }
            }
        };
        a.$inject = ["$stateProvider"]
    }(),
    function() {
        "use strict";

        function a(a, b, c) {
            function d() {
                b.getApigilityVersion(function(a) {
                    e.version = a.version
                })
            }
            var e = this;
            e.version = "@dev", d()
        }
        angular.module("apigility.about").controller("About", a), a.$inject = ["$stateParams", "api", "$timeout"]
    }(),
    function() {
        "use strict";
        angular.module("apigility.service", [])
    }(),
    function() {
        "use strict";

        function a(a, b, c, d, e) {
            function f(a) {
                var b, c, d, e, f, g;
                switch (a.type) {
                    case "HTTP Basic":
                        b = ["name", "type", "realm", "htpasswd"], c = a.basic, d = [a.name, "basic", c.realm, c.htpasswd];
                        break;
                    case "HTTP Digest":
                        b = ["name", "type", "realm", "digest_domains", "nonce_timeout", "htdigest"], e = a.digest, d = [a.name, "digest", e.realm, e.digest_domains, e.nonce_timeout, e.htdigest];
                        break;
                    case "OAuth2 PDO":
                        b = ["name", "type", "oauth2_type", "oauth2_route", "oauth2_dsn", "oauth2_username", "oauth2_password", "oauth2_options"], f = a.pdo, d = [a.name, "oauth2", "pdo", f.oauth2_route, f.oauth2_dsn, f.oauth2_username, f.oauth2_password, f.oauth2_options];
                        break;
                    case "OAuth2 Mongo":
                        b = ["name", "type", "oauth2_type", "oauth2_route", "oauth2_dsn", "oauth2_database", "oauth2_locator_name", "oauth2_options"], g = a.mongo, d = [a.name, "oauth2", "mongo", g.oauth2_route, g.oauth2_dsn, g.oauth2_database, g.oauth2_locator_name, g.oauth2_options]
                }
                return {
                    data: d,
                    allowed: b
                }
            }

            function g(a, b) {
                var c = {
                    key: [],
                    value: []
                };
                return b.forEach(function(b) {
                    a.hasOwnProperty(b) && (c.key.push(b), c.value.push(a[b]))
                }), c
            }
            this.http = c, this.q = d;
            var h = ["GET", "POST", "PUT", "PATCH", "DELETE"];
            this.getApigilityVersion = function(c) {
                a.get(b + "/apigility-version").then(function(a) {
                    return c("string" != typeof a.version ? {
                        version: "@dev"
                    } : a)
                })["catch"](function(a) {
                    return c({
                        version: "@dev"
                    })
                })
            }, this.getApiList = function(c) {
                a.get(b + "/dashboard", "_embedded").then(function(a) {
                    return a.module.forEach(function(a) {
                        a.selected_version = Math.max.apply(Math, a.versions), a.hasOwnProperty("_links") && delete a._links
                    }), c(!1, a.module)
                })["catch"](function(a) {
                    return e.error("Unable to fetch dashboard!", {
                        ttl: -1
                    }), c(!0, null)
                })
            }, this.getApi = function(c, d) {
                var f = this.normalizeModuleName(c);
                a.get(b + "/module/" + f).then(function(a) {
                    return d(!1, a)
                })["catch"](function(a) {
                    return e.error("Unable to fetch API details!", {
                        ttl: -1
                    }), d(!0, a.detail)
                })
            }, this.newApi = function(c, d) {
                var f = ["name"];
                a.create(b + "/module", [c], f).then(function(a) {
                    return e.success("API created"), d(!1, a)
                })["catch"](function(a) {
                    switch (a.status) {
                        case 500:
                            return d(!0, "I cannot create the API module, please check if already exists");
                        case 409:
                            if (a.data.detail) return d(!0, a.data.detail)
                    }
                    return d(!0, "I cannot create the API module, please enter a valid name (alpha characters)")
                })
            }, this.deleteApi = function(c, d, f) {
                var g = this.normalizeModuleName(c);
                a.remove(b + "/module/" + g + "?recursive=" + (d ? 1 : 0)).then(function(a) {
                    return e.success("API removed"), f(!1, a)
                })["catch"](function(a) {
                    return e.error("Unable to delete API", {
                        ttl: -1
                    }), f(!0)
                })
            }, this.strategyExists = function(c, d) {
                a.get(b + "/strategy/" + c).then(function(a) {
                    return d(!1, a.success)
                })["catch"](function(a) {
                    return d(!0, a)
                })
            }, this.newRest = function(c, d, f) {
                var g = ["service_name"],
                    h = this.normalizeModuleName(c);
                a.create(b + "/module/" + h + "/rest", [d], g).then(function(a) {
                    return e.success("Service created"), f(!1, a)
                })["catch"](function(a) {
                    switch (e.error("Unable to create service", {
                        ttl: -1
                    }), a.status) {
                        case 409:
                            return f(!0, "The service already exists; please choose a different name")
                    }
                    return f(!0, "Unable to create service (Code: " + a.status + "): " + a.data.detail)
                })
            }, this.updateGeneralRest = function(c, d, f, h, i, j) {
                var k = ["collection_class", "collection_http_methods", "collection_name", "collection_query_whitelist", "entity_class", "entity_http_methods", "entity_identifier_name", "hydrator_name", "page_size", "page_size_param", "resource_class", "route_identifier_name", "route_match", "service_name", "table_name", "adapter_name"];
                i && k.push("strategies", "by_value");
                var l = g(h, k),
                    m = i ? "/doctrine/" : "/rest/",
                    n = this.normalizeModuleName(c);
                a.update(b + "/module/" + n + m + f, l.value, l.key).then(function(a) {
                    return e.success("Service updated"), j(!1, a)
                })["catch"](function(a) {
                    return a.data.detail ? e.error(a.data.detail, {
                        ttl: -1
                    }) : e.error("Error updating service", {
                        ttl: -1
                    }), j(!0, "Error during the update of the REST service")
                })
            }, this.updateContentNegotiationRest = function(c, d, f, h, i) {
                var j = ["service_name", "selector", "accept_whitelist", "content_type_whitelist"],
                    k = this.normalizeModuleName(c),
                    l = g(h, j);
                a.update(b + "/module/" + k + "/rest/" + f, l.value, l.key).then(function(a) {
                    return e.success("Content negotiation updated"), i(!1, a)
                })["catch"](function(a) {
                    return e.error("Unable to update content negotiation", {
                        ttl: -1
                    }), i(!0, "Error during the update of the REST service")
                })
            }, this.deleteRest = function(c, d, f, g, h, i) {
                var j = g ? "doctrine" : "rest",
                    k = this.normalizeModuleName(c);
                a.remove(b + "/module/" + k + "/" + j + "/" + f + "?recursive=" + (h ? 1 : 0)).then(function(a) {
                    return e.success("Service deleted"), i(!1, a)
                })["catch"](function(a) {
                    return e.error("Unable to delete service", {
                        ttl: -1
                    }), i(!0)
                })
            }, this.getAuthorizationRest = function(c, d, f, g) {
                var h = this.normalizeModuleName(c),
                    i = f.replace(/-/g, "\\");
                a.get(b + "/module/" + h + "/authorization").then(function(a) {
                    var b, c = {};
                    c.collection = [], c.entity = [];
                    var d = a[i + "::__collection__"];
                    for (b in d) d[b] && c.collection.push(b);
                    var e = a[i + "::__entity__"];
                    for (b in e) e[b] && c.entity.push(b);
                    return g(!1, c)
                })["catch"](function(a) {
                    return e.error("Unable to fetch API authorization details", {
                        ttl: -1
                    }), g(!0, a.detail)
                })
            }, this.saveAuthorizationRest = function(c, d, f, g, i) {
                var j = {},
                    k = {},
                    l = this.normalizeModuleName(c),
                    m = f.replace(/-/g, "\\");
                h.forEach(function(a) {
                    j[a] = g.collection.indexOf(a) > -1, k[a] = g.entity.indexOf(a) > -1
                });
                var n = {};
                n[m + "::__collection__"] = j, n[m + "::__entity__"] = k, a.save(b + "/module/" + l + "/authorization", n).then(function(a) {
                    return e.success("Authorization saved"), i(!1, a)
                })["catch"](function(a) {
                    return e.error("Unable to save authorization", {
                        ttl: -1
                    }), i(!0)
                })
            }, this.getRestList = function(c, d, f) {
                var g = this.normalizeModuleName(c);
                a.get(b + "/module/" + g + "/rest?version=" + d, "_embedded").then(function(a) {
                    return a.rest.forEach(function(a) {
                        a.hasOwnProperty("_links") && delete a._links
                    }), f(a.rest)
                })["catch"](function(a) {
                    return e.error("Unable to fetch REST services", {
                        ttl: -1
                    }), console.log("Failed to get the list of REST services", a), !1
                })
            }, this.getRpcList = function(c, d, f) {
                var g = this.normalizeModuleName(c);
                a.get(b + "/module/" + g + "/rpc?version=" + d, "_embedded").then(function(a) {
                    return a.rpc.forEach(function(a) {
                        a.hasOwnProperty("_links") && delete a._links
                    }), f(a.rpc)
                })["catch"](function(a) {
                    return e.error("Unable to fetch RPC services", {
                        ttl: -1
                    }), console.log("Failed to get the list of RPC services", a), !1
                })
            }, this.getRest = function(c, d, f, g) {
                var h = this.normalizeModuleName(c);
                a.get(b + "/module/" + h + "/rest/" + f).then(function(a) {
                    var b = angular.copy(a);
                    b.fields = [];
                    var c = 0;
                    if (a.hasOwnProperty("_embedded")) {
                        if (a._embedded.hasOwnProperty("input_filters"))
                            for (; !angular.isUndefined(a._embedded.input_filters[0][c]);) b.fields[c] = a._embedded.input_filters[0][c], c++;
                        a._embedded.hasOwnProperty("documentation") && (delete a._embedded.documentation._links, b.documentation = a._embedded.documentation)
                    }
                    return delete b._links, delete b._embedded, g(b)
                })["catch"](function(a) {
                    return e.error("Unable to fetch service", {
                        ttl: -1
                    }), console.log("Failed to get the REST service", a), !1
                })
            }, this.getRestDoctrineMetadata = function(c, d, f) {
                a.get(b + "/doctrine/" + c + "/metadata/" + encodeURIComponent(d)).then(function(a) {
                    return f(!1, a)
                })["catch"](function(a) {
                    return e.error("Unable to fetch Doctrine metadata", {
                        ttl: -1
                    }), f(!0, "I cannot retrieve entity metadata")
                })
            }, this.getHydrators = function(c) {
                a.get(b + "/hydrators", "hydrators").then(function(a) {
                    return c(a)
                })["catch"](function(a) {
                    return e.error("Unable to fetch hydrators", {
                        ttl: -1
                    }), console.log("Failed to get the list of Hydrators", a), !1
                })
            }, this.getContentNegotiation = function(c) {
                a.get(b + "/content-negotiation", "_embedded").then(function(a) {
                    return a.selectors.forEach(function(a) {
                        delete a._links
                    }), c(a.selectors)
                })["catch"](function(a) {
                    return e.error("Unable to fetch content-negotiation details", {
                        ttl: -1
                    }), console.log("Failed to get the list of Content Negotiation", a), !1
                })
            }, this.newSelector = function(c, d) {
                var f = ["content_name"];
                a.create(b + "/content-negotiation", [c], f).then(function(a) {
                    return e.success("Selector created"), delete a._links, d(!1, a)
                })["catch"](function(a) {
                    return e.error("Unable to create content-negotiation selector", {
                        ttl: -1
                    }), d(!0, "I cannot create the Selector, please enter a valid name (alpha characters)");
                })
            }, this.deleteSelector = function(c, d) {
                a.remove(b + "/content-negotiation/" + c).then(function(a) {
                    return e.success("Content-negotiation selector deleted"), d(!1, a)
                })["catch"](function(a) {
                    return e.error("Unable to delete content-negotiation selector", {
                        ttl: -1
                    }), d(!0)
                })
            }, this.saveSelector = function(c, d) {
                var f = ["selectors"],
                    g = angular.copy(c);
                delete g.content_name, a.update(b + "/content-negotiation/" + c.content_name, [g], f).then(function(a) {
                    return e.success("Selector updated"), delete a._links, d(!1, a)
                })["catch"](function(a) {
                    switch (a.status) {
                        case 422:
                            if (a.data.hasOwnProperty("validation_messages") && a.data.validation_messages.hasOwnProperty("selectors") && a.data.validation_messages.selectors.hasOwnProperty("classNotFound")) return e.error("Unable to update selector due to validation errors", {
                                ttl: -1
                            }), d(!0, a.data.validation_messages.selectors.classNotFound)
                    }
                    return e.error("Error updating selector", {
                        ttl: -1
                    }), d(!0, "Error during the API communication")
                })
            }, this.getValidators = function(c) {
                a.get(b + "/validators", "validators").then(function(a) {
                    return c(a)
                })["catch"](function(a) {
                    return e.error("Unable to fetch validator list", {
                        ttl: -1
                    }), console.log("Failed to get the list of Validators", a), !1
                })
            }, this.getFilters = function(c) {
                a.get(b + "/filters", "filters").then(function(a) {
                    return c(a)
                })["catch"](function(a) {
                    return e.error("Unable to fetch filter list", {
                        ttl: -1
                    }), console.log("Failed to get the list of Filters", a), !1
                })
            }, this.saveRestField = function(c, d, f, g, h) {
                angular.forEach(g, function(a, b) {
                    a.hasOwnProperty("error_message") && !a.error_message && delete a.error_message
                });
                var i = this.normalizeModuleName(c);
                a.save(b + "/module/" + i + "/rest/" + f + "/input-filter", g).then(function(a) {
                    return e.success("Saved field"), delete a._links, delete a.input_filter_name, a = Object.keys(a).map(function(b) {
                        return a[b]
                    }), h(!1, a)
                })["catch"](function(a) {
                    return e.error("Error saving field", {
                        ttl: -1
                    }), h(!0, "Error during the API communication")
                })
            }, this.getAuthorizationRpc = function(c, d, f, g) {
                var h = this.normalizeModuleName(c),
                    i = f.replace(/-/g, "\\"),
                    j = f.replace(/-Controller$/, "").split("-").pop();
                a.get(b + "/module/" + h + "/authorization").then(function(a) {
                    var b = [],
                        c = a[i + "::" + j];
                    for (var d in c) c[d] && b.push(d);
                    return g(!1, b)
                })["catch"](function(a) {
                    return e.error("Unable to fetch authorization details", {
                        ttl: -1
                    }), g(!0, a.detail)
                })
            }, this.saveAuthorizationRpc = function(c, d, f, g, i) {
                var j = {},
                    k = this.normalizeModuleName(c),
                    l = f.replace(/-/g, "\\"),
                    m = f.replace(/-Controller$/, "").split("-").pop();
                h.forEach(function(a) {
                    j[a] = g.indexOf(a) > -1
                });
                var n = {};
                n[l + "::" + m] = j, a.save(b + "/module/" + k + "/authorization", n).then(function(a) {
                    return e.success("Authorization updated"), i(!1, a)
                })["catch"](function(a) {
                    return e.error("Error saving authorization details", {
                        ttl: -1
                    }), i(!0)
                })
            }, this.saveRpcField = function(c, d, f, g, h) {
                angular.forEach(g, function(a, b) {
                    a.hasOwnProperty("error_message") && !a.error_message && delete a.error_message
                });
                var i = this.normalizeModuleName(c);
                a.save(b + "/module/" + i + "/rpc/" + f + "/input-filter", g).then(function(a) {
                    return e.success("Field saved"), delete a._links, delete a.input_filter_name, a = Object.keys(a).map(function(b) {
                        return a[b]
                    }), h(!1, a)
                })["catch"](function(a) {
                    return e.error("Error saving field", {
                        ttl: -1
                    }), h(!0, "Error during the API communication")
                })
            }, this.saveRestDoc = function(c, d, f, g, h) {
                var i = this.normalizeModuleName(c);
                a.save(b + "/module/" + i + "/rest/" + f + "/doc", g).then(function(a) {
                    return e.success("Documentation saved"), delete a._links, h(!1, a)
                })["catch"](function(a) {
                    return e.error("Error saving documentation", {
                        ttl: -1
                    }), h(!0, "Error during the API communication")
                })
            }, this.saveRpcDoc = function(c, d, f, g, h) {
                var i = this.normalizeModuleName(c);
                a.save(b + "/module/" + i + "/rpc/" + f + "/doc", g).then(function(a) {
                    return e.success("Documentation saved"), delete a._links, h(!1, a)
                })["catch"](function(a) {
                    return e.error("Error saving documentation", {
                        ttl: -1
                    }), h(!0, "Error during the API communication")
                })
            }, this.newRpc = function(c, d, f, g) {
                var h = ["service_name", "route_match"],
                    i = this.normalizeModuleName(c);
                a.create(b + "/module/" + i + "/rpc", [d, f], h).then(function(a) {
                    return e.success("Service created"), g(!1, a)
                })["catch"](function(a) {
                    switch (e.error("Error creating service", {
                        ttl: -1
                    }), a.status) {
                        case 409:
                            return g(!0, "The service already exists; please choose a different name")
                    }
                    return g(!0, "Error creating service (Code: " + a.status + "): " + a.data.detail)
                })
            }, this.getRpc = function(c, d, f, g) {
                var h = this.normalizeModuleName(c);
                a.get(b + "/module/" + h + "/rpc/" + f).then(function(a) {
                    var b = angular.copy(a);
                    b.fields = [];
                    var c = 0;
                    if (a._embedded) {
                        if (a._embedded.input_filters)
                            for (; !angular.isUndefined(a._embedded.input_filters[0][c]);) b.fields[c] = a._embedded.input_filters[0][c], c++;
                        a._embedded.documentation && (delete a._embedded.documentation._links, b.documentation = a._embedded.documentation)
                    }
                    return delete b._links, delete b._embedded, g(!1, b)
                })["catch"](function(a) {
                    return e.error("Unable to fetch service", {
                        ttl: -1
                    }), g(!0, "Error getting the RPC service")
                })
            }, this.updateGeneralRpc = function(c, d, f, h, i) {
                var j = this.normalizeModuleName(c),
                    k = ["accept_whitelist", "content_type_whitelist", "controller_class", "http_methods", "route_match", "selector", "service_name"],
                    l = g(h, k);
                a.update(b + "/module/" + j + "/rpc/" + f, l.value, l.key).then(function(a) {
                    return e.success("Service updated"), i(!1, a)
                })["catch"](function(a) {
                    return a.data.detail ? e.error(a.data.detail, {
                        ttl: -1
                    }) : e.error("Error updating service", {
                        ttl: -1
                    }), i(!0, "Error during the update of the RPC service")
                })
            }, this.deleteRpc = function(c, d, f, g, h) {
                var i = this.normalizeModuleName(c);
                a.remove(b + "/module/" + i + "/rpc/" + f + "?recursive=" + (g ? 1 : 0)).then(function(a) {
                    return e.success("Service deleted"), h(!1, a)
                })["catch"](function(a) {
                    return e.error("Error deleting service", {
                        ttl: -1
                    }), h(!0)
                })
            }, this.getAuthentication = function(c) {
                a.get(b + "/authentication").then(function(a) {
                    return a.hasOwnProperty("_links") && delete a._links, c(!1, a)
                })["catch"](function(a) {
                    return e.error("Unable to fetch authentication details", {
                        ttl: -1
                    }), c(!0, null)
                })
            }, this.addBasicAuthentication = function(c, d) {
                var f = ["accept_schemes", "htpasswd", "realm"];
                c.hasOwnProperty("accept_schemes") || (c.accept_schemes = []), c.accept_schemes.push("basic"), a.create(b + "/authentication/http-basic", [c.accept_schemes, c.htpasswd, c.realm], f).then(function(a) {
                    return e.success("HTTP Basic authentication adapter created"), a.hasOwnProperty("_links") && delete a._links, d(!1, a)
                })["catch"](function(a) {
                    return e.error("Error creating HTTP Basic authentication adapter", {
                        ttl: -1
                    }), d(!0, null)
                })
            }, this.saveBasicAuthentication = function(c, d) {
                var f = ["htpasswd", "realm"];
                a.update(b + "/authentication/http-basic", [c.htpasswd, c.realm], f).then(function(a) {
                    return e.success("Authentication updated"), a.hasOwnProperty("_links") && delete a._links, d(!1, a)
                })["catch"](function(a) {
                    switch (a.status) {
                        case 422:
                            return e.error("Unable to update authentication due to validation errors", {
                                ttl: -1
                            }), d(!0, a.validation_messages.htpasswd[0])
                    }
                    return e.error("Unable to update authentication", {
                        ttl: -1
                    }), d(!0, "Error saving the basic authentication")
                })
            }, this.getApiDocumentList = function(c) {
                a.get(b + "/../documentation").then(function(a) {
                    return c(!1, a)
                })["catch"](function(a) {
                    return e.error("Unable to fetch documentation", {
                        ttl: -1
                    }), c(!0, null)
                })
            }, this.getApiDocument = function(c, d, f) {
                var g = this.normalizeModuleName(c);
                a.get(b + "/../documentation/" + g + "-v" + d).then(function(a) {
                    return f(!1, a)
                })["catch"](function(a) {
                    return e.error("Unable to fetch documentation", {
                        ttl: -1
                    }), f(!0, null)
                })
            }, this.getDatabase = function(c) {
                a.get(b + "/db-adapter", "_embedded").then(function(a) {
                    return a.db_adapter.forEach(function(a) {
                        delete a._links
                    }), c(!0, a)
                })["catch"](function(a) {
                    return e.error("Unable to fetch database adapters", {
                        ttl: -1
                    }), c(!0, null)
                })
            }, this.addDatabase = function(c, d) {
                var f = ["adapter_name", "charset", "database", "driver", "hostname", "username", "password", "port", "dsn", "driver_options"],
                    h = g(c, f);
                a.create(b + "/db-adapter", h.value, h.key).then(function(a) {
                    return e.success("Database adapter created"), a.hasOwnProperty("_links") && delete a._links, d(!1, a)
                })["catch"](function(a) {
                    return e.error("Error creating database adapter", {
                        ttl: -1
                    }), d(!0, null)
                })
            }, this.saveDatabase = function(c, d) {
                var f = ["charset", "database", "driver", "hostname", "username", "password", "port", "dsn", "driver_options"],
                    h = g(c, f);
                a.update(b + "/db-adapter/" + c.adapter_name, h.value, h.key).then(function(a) {
                    return e.success("Database adapter updated"), a.hasOwnProperty("_links") && delete a._links, d(!1, a)
                })["catch"](function(a) {
                    return e.error("Error updating database adapter", {
                        ttl: -1
                    }), d(!0, null)
                })
            }, this.deleteDatabase = function(c, d) {
                a.remove(b + "/db-adapter/" + c).then(function(a) {
                    return e.success("Database adapter removed"), d(!1, a)
                })["catch"](function(a) {
                    return e.error("Error removing database adapter", {
                        ttl: -1
                    }), d(!0)
                })
            }, this.autodiscover = function(c, d, f, g, h) {
                var i = f ? "doctrine/" : "",
                    j = this.normalizeModuleName(c);
                a.get(b + "/module/" + j + "/" + d + "/autodiscovery/" + i + g).then(function(a) {
                    return h(!0, a)
                })["catch"](function(a) {
                    return a.data.detail ? e.error(a.data.detail, {
                        ttl: -1
                    }) : f ? e.error("Error getting Doctrine service(s)", {
                        ttl: -1
                    }) : e.error("Error getting db service(s)", {
                        ttl: -1
                    }), h(!0, null)
                })
            }, this.newDbConnected = function(c, d, f, g) {
                var h = ["adapter_name", "table_name"],
                    i = this.normalizeModuleName(c);
                a.create(b + "/module/" + i + "/rest", [d, f], h).then(function(a) {
                    return e.success("DB-Connected service(s) created"), g(!1, a)
                })["catch"](function(a) {
                    switch (e.error("Error creating DB-Connected service(s)", {
                        ttl: -1
                    }), a.status) {
                        case 500:
                            return g(!0, "I cannot create the DB-Connected service, please check if already exists")
                    }
                    return g(!0, "I cannot create the DB-Connected service, please check your database server")
                })
            }, this.getDoctrineAdapters = function(a) {
                var f, g = {
                        method: "GET",
                        url: b + "/doctrine-adapter",
                        headers: {
                            Accept: "application/json"
                        },
                        cache: !1
                    },
                    h = d.defer(),
                    i = c(g),
                    j = "_embedded";
                i.then(function(b) {
                    if (204 == b.status) return a(!0, b.status);
                    var c = b.data;
                    return h.resolve(c[j]), c.hasOwnProperty(j) ? (f = c[j], f.doctrine_adapter.forEach(function(a) {
                        delete a._links
                    }), a(!1, f)) : void 0
                })["catch"](function(a) {
                    e.error("Unable to fetch Doctrine adapters", {
                        ttl: -1
                    }), h.reject(a)
                })
            }, this.newDoctrine = function(c, d, f, g) {
                var h = ["object_manager", "entity_class", "service_name"],
                    i = this.normalizeModuleName(c);
                a.create(b + "/module/" + i + "/doctrine/" + f.service_name, [d, f.entity_class, f.service_name], h).then(function(a) {
                    return e.success("Doctrine-connected service created"), g(!1, a)
                })["catch"](function(a) {
                    switch (e.error("Error creating Doctrine-connected service", {
                        ttl: -1
                    }), a.status) {
                        case 500:
                            return g(!0, "I cannot create the Doctrine-Connected service, please check if already exists")
                    }
                    return g(!0, "I cannot create the Doctrine-Connected service, please check your database server")
                })
            }, this.newVersion = function(c, d) {
                var f = ["module"];
                a.update(b + "/versioning", [c], f).then(function(a) {
                    return e.success("New API version created"), d(!1, a)
                })["catch"](function(a) {
                    return e.error("Error creating new API version", {
                        ttl: -1
                    }), d(!0, null)
                })
            }, this.setDefaultVersion = function(c, d, f) {
                var g = ["module", "version"];
                a.update(b + "/default-version", [c, d], g).then(function(a) {
                    return e.success("API default version updated"), f(!1, a)
                })["catch"](function(a) {
                    return e.error("Error updating default API version", {
                        ttl: -1
                    }), f(!0, null)
                })
            }, this.getSourceCode = function(c, d, f) {
                var g = this.normalizeModuleName(c);
                a.get(b + "/source?module=" + g + "&class=" + d).then(function(a) {
                    return f(!1, a)
                })["catch"](function(a) {
                    return e.error("Error fetching source code", {
                        ttl: -1
                    }), f(!0, null)
                })
            }, this.buildPackage = function(c, d, f) {
                var g = ["format", "apis", "composer", "config", "zpk_xml", "zpk_assets", "zpk_version"],
                    h = {};
                d.forEach(function(a) {
                    h[a.name] = c.modules.indexOf(a.name) >= 0
                });
                var i = [c.format, h, c.composer, c.config];
                "zpk" === c.format && i.push.apply(i, [c.zpk.xml, c.zpk.assets, c.zpk.version]), a.create(b + "/package", i, g).then(function(a) {
                    return a ? (e.success("Package creation initiated"), f(!1, a)) : (e.error("Error occurred when building package", {
                        ttl: -1
                    }), f(!0, "Error occurred building the package"))
                })["catch"](function(a) {
                    return e.error("Error occurred when building package", {
                        ttl: -1
                    }), f(!0, "Error occurred building the package")
                })
            }, this.getAuthenticationAdapters = function(c) {
                a.get(b + "/authentication", "_embedded", 2).then(function(a) {
                    return a.items.forEach(function(a) {
                        delete a._links
                    }), c(!0, a.items)
                })["catch"](function(a) {
                    return e.error("Error fetching authentication adapters", {
                        ttl: -1
                    }), c(!0, null)
                })
            }, this.addAuthenticationAdapter = function(c, d) {
                for (var g = f(c), h = 0; h < g.data.length; h++) angular.isUndefined(g.data[h]) && (g.data.splice(h, 1), g.allowed.splice(h, 1));
                a.create(b + "/authentication", g.data, g.allowed, null, 2).then(function(a) {
                    return e.success("Authentication adapter created"), a.hasOwnProperty("_links") && delete a._links, d(!1, a)
                })["catch"](function(a) {
                    return e.error("Error creating authentication adapter", {
                        ttl: -1
                    }), a.hasOwnProperty("data") && a.data.hasOwnProperty("detail") ? d(!0, a.data.detail) : d(!0, "Error on authentication adapter save")
                })
            }, this.saveAuthenticationAdapter = function(c, d) {
                for (var g = f(c), h = {}, i = 0; i < g.data.length; i++) angular.isUndefined(g.data[i]) || (h[g.allowed[i]] = g.data[i]);
                a.save(b + "/authentication/" + c.name, h, 2).then(function(a) {
                    return e.success("Authentication adapter updated"), delete a._links, d(!1, a)
                })["catch"](function(a) {
                    return e.error("Error updating authentication adapter", {
                        ttl: -1
                    }), d(!0, "Error during the authentication adapter API save")
                })
            }, this.saveOptionsAuthenticationAdapter = function(c, d) {
                a.save(b + "/authentication/" + c.name, c, 2).then(function(a) {
                    return e.success("Authentication adapter options updated"), delete a._links, d(!1, a)
                })["catch"](function(a) {
                    return e.error("Error updating authentication adapter options", {
                        ttl: -1
                    }), d(!0, "Error during the authentication adapter API save")
                })
            }, this.deleteAuthenticationAdapter = function(c, d) {
                a.remove(b + "/authentication/" + c, 2).then(function(a) {
                    return e.success("Authentication adapter removed"), d(!1, a)
                })["catch"](function(a) {
                    return e.error("Error removing authentication adapter", {
                        ttl: -1
                    }), d(!0)
                })
            }, this.getAuthenticationTypes = function(c) {
                a.get(b + "/auth-type", "auth-types", 2).then(function(a) {
                    for (var b, d, e = [], f = 0; f < a.length; f++) a[f].endsWith("-basic") ? (b = a[f].slice(0, -6), d = b + " (basic)") : a[f].endsWith("-digest") ? (b = a[f].slice(0, -7), d = b + " (digest)") : (b = a[f], d = b + " (oauth2)"), e[f] = {
                        key: d,
                        value: b
                    };
                    return c(e)
                })["catch"](function(a) {
                    return e.error("Error fetching authentication types", {
                        ttl: -1
                    }), console.log("Failed to get the list of authentication types", a), !1
                })
            }, this.getModuleAuthentication = function(c, d, f) {
                var g = this.normalizeModuleName(c);
                a.get(b + "/module/" + g + "/authentication?version=" + d, "authentication", 2).then(function(a) {
                    return f(a)
                })["catch"](function(a) {
                    return e.error("Unable to fetch API authentication details", {
                        ttl: -1
                    }), console.log("Failed to get the list of authentication types", a), !1
                })
            }, this.saveModuleAuthentication = function(c, d, f, g) {
                var h = {
                        authentication: f
                    },
                    i = this.normalizeModuleName(c);
                a.save(b + "/module/" + i + "/authentication?version=" + d, h, 2).then(function(a) {
                    return e.success("API authentication adapter updated"), g(!1, a)
                })["catch"](function(a) {
                    return e.error("Error updating API authentication adapter", {
                        ttl: -1
                    }), g(!0)
                })
            }, this.deleteModuleAuthentication = function(c, d, f) {
                var g = this.normalizeModuleName(c);
                a.remove(b + "/module/" + g + "/authentication?version=" + d, 2).then(function(a) {
                    return e.success("API authentication adapter removed"), f(!1, a)
                })["catch"](function(a) {
                    return e.error("Error removing API authentication adapter", {
                        ttl: -1
                    }), f(!0)
                })
            }, this.normalizeModuleName = function(a) {
                return encodeURIComponent(a)
            }, this.mapTagInput = function(a) {
                return a.text
            }
        }
        angular.module("apigility.service").service("api", a), a.$inject = ["xhr", "agApiPath", "$http", "$q", "growl"]
    }(),
    function() {
        "use strict";

        function a() {
            function a(a) {
                if (console.log("In hasHalMediaType with mediatypes", a), !Array.isArray(a)) return console.log("Did not receive an array; returning false"), !1;
                for (var b, c = 0; c < a.length; c += 1) {
                    if (b = a[c], console.log("Examining mediatype", b), "object" == typeof b) {
                        if (console.log("Is an object"), !b.hasOwnProperty("text")) {
                            console.log("Does not have text property; moving on");
                            continue
                        }
                        console.log("Casting type to text property"), b = b.text
                    }
                    if ("string" == typeof b) {
                        if (console.log("Examining mediatype", b), "application/hal+json" === b) return console.log("Found HAL!"), !0
                    } else console.log("Type is still not a string", b)
                }
                return console.log("Did not find HAL!"), !1
            }

            function b(a) {
                return new Array(4 * a).join(" ")
            }

            function c(a, c, d, e, f) {
                return "collection" == f && (c = c.replace(/\[[a-zA-Z0-9_\/:\-]+\]$/, "")), e && (c += e), b(d) + '"' + a + '": {\n' + b(d + 1) + '"href": "' + c + '"\n' + b(d) + "}"
            }

            function d(a, c) {
                return b(c) + '"_links": {\n' + a.join(",\n") + "\n" + b(c) + "}\n"
            }

            function e(a, e, f) {
                var g = [c("self", e, 5)],
                    h = b(1) + '"_embedded": {\n' + b(2) + '"' + a + '": [\n' + b(3) + "{\n";
                return h += d(g, 4), h += f.join(",\n") + "\n" + b(3) + "}\n" + b(2) + "]\n" + b(1) + "}"
            }
            this.fromConfiguration = function(f, g, h, i, j, k, l) {
                var m = "",
                    n = [],
                    o = !1,
                    p = [];
                if ("response" == g && j && (o = a(j)), i.forEach(function(a) {
                        n.push(b(1) + '"' + a.name + '": "' + (a.description || "") + '"')
                    }), !o || "collection" == h && "POST" != f)
                    if (o && "collection" == h) {
                        var q = l ? l : "items";
                        n.forEach(function(a, c) {
                            n[c] = b(3) + a
                        }), p.push(c("self", k, 2, !1, "collection")), p.push(c("first", k, 2, "?page={page}", "collection")), p.push(c("prev", k, 2, "?page={page}", "collection")), p.push(c("next", k, 2, "?page={page}", "collection")), p.push(c("last", k, 2, "?page={page}", "collection")), m = "{\n" + d(p, 1) + e(q, k, n) + "\n}"
                    } else m = "{\n" + n.join(",\n") + "\n}";
                else p.push(c("self", k, 2)), m = "{\n" + d(p, 1) + n.join(",\n") + "\n}";
                return m
            }
        }
        angular.module("apigility.service").service("documentation", a), a.$inject = []
    }(),
    function() {
        "use strict";

        function a(a) {
            var b = [],
                c = "",
                d = function(a, c) {
                    for (var d = 0; d < b.length; d++)
                        if (b[d].name === a) return void b[d].versions.push(c)
                },
                e = function(c, d) {
                    b.forEach(function(b) {
                        b.name === c && (a.getRestList(c, d, function(a) {
                            b.rest = [], a.forEach(function(a) {
                                b.rest.push(a)
                            })
                        }), a.getRpcList(c, d, function(a) {
                            b.rpc = [], a.forEach(function(a) {
                                b.rpc.push(a)
                            })
                        }))
                    })
                },
                f = function(a) {
                    for (var c = 0; c < b.length; c++)
                        if (b[c].name === a) return b[c].selected_version
                },
                g = function(a, c) {
                    for (var d = 0; d < b.length; d++)
                        if (b[d].name === c) return a == Math.max.apply(Math, b[d].versions);
                    return !1
                },
                h = function(a) {
                    b = a
                },
                i = function(a) {
                    a.hasOwnProperty("selected_version") || (a.selected_version = Math.max.apply(Math, a.versions)), b.push(a)
                },
                j = function(a) {
                    for (var c = 0; c < b.length; c++)
                        if (b[c].name === a) return void b.splice(c, 1)
                },
                k = function() {
                    return b
                },
                l = function(a, c) {
                    b.forEach(function(b) {
                        return b.name == a ? void b.rest.push(c) : void 0
                    })
                },
                m = function(a, c) {
                    var d, e, f = [];
                    b.forEach(function(b) {
                        return b.name !== a ? void f.push(b) : (e = !1, b.rest.forEach(function(a, b) {
                            a.controller_service_name === c && (e = b)
                        }), !1 === e ? void f.push(b) : (d = angular.copy(b), d.rest.splice(e, 1), void f.push(d)))
                    }), b = f
                },
                n = function(a, c) {
                    var d, e, f = [];
                    b.forEach(function(b) {
                        return b.name !== a ? void f.push(b) : (e = !1, b.rpc.forEach(function(a, b) {
                            a.controller_service_name === c && (e = b)
                        }), !1 === e ? void f.push(b) : (d = angular.copy(b), d.rpc.splice(e, 1), void f.push(d)))
                    }), b = f
                },
                o = function(a, c) {
                    b.forEach(function(b) {
                        return b.name == a ? void b.rpc.push(c) : void 0
                    })
                },
                p = function() {
                    return c
                },
                q = function(a) {
                    c = a
                };
            return {
                addVersion: d,
                setSelectedVersion: e,
                getSelectedVersion: f,
                isLastVersion: g,
                setApis: h,
                addApi: i,
                getApis: k,
                removeApi: j,
                addRestService: l,
                removeRestService: m,
                addRpcService: o,
                removeRpcService: n,
                getSelected: p,
                setSelected: q
            }
        }
        angular.module("apigility.service").service("SidebarService", a), a.$inject = ["api"]
    }(),
    function() {
        "use strict";

        function a(a, g) {
            this.http = a, this.q = g, this.get = b, this.create = c, this.update = d, this.remove = f, this.save = e
        }

        function b(a, b, c) {
            var d = g(this.http, this.q, "GET", a, {
                key: b
            }, c);
            return d
        }

        function c(a, b, c, d, e) {
            return g(this.http, this.q, "POST", a, {
                data: h(c, b),
                key: d
            }, e)
        }

        function d(a, b, c, d, e) {
            return g(this.http, this.q, "PATCH", a, {
                data: h(c, b),
                key: d
            }, e)
        }

        function e(a, b, c) {
            return g(this.http, this.q, "PUT", a, {
                data: b
            }, c)
        }

        function f(a, b) {
            return g(this.http, this.q, "DELETE", a, null, b)
        }

        function g(a, b, c, d, e, f) {
            var g;
            g = f ? {
                Accept: "application/vnd.apigility.v2+json"
            } : {
                Accept: "application/json"
            }, ("POST" === c || "PATCH" === c || "PUT" === c) && (g["Content-Type"] = "application/json");
            var h = {
                method: c,
                url: d,
                headers: g,
                cache: !1
            };
            if ("POST" === c || "PATCH" === c || "PUT" === c) {
                if (!e || !e.data) throw new Error("Missing data for " + c + " operation");
                h.data = e.data
            }
            var i, j = b.defer(),
                k = a(h);
            return e && e.hasOwnProperty("key") && e.key && (i = e.key), k.then(function(a) {
                var b = a.data;
                return i && b.hasOwnProperty(i) ? void j.resolve(b[i]) : i && b.hasOwnProperty("_embedded") && b._embedded.hasOwnProperty(i) ? void j.resolve(b._embedded[i]) : void j.resolve(b)
            }), k["catch"](function(a) {
                j.reject(a)
            }), j.promise
        }

        function h(a, b) {
            if (1 === b.length && "object" == typeof b[0]) return b[0];
            for (var c = {}, d = 0; d < a.length && !angular.isUndefined(b[d]); d += 1) {
                if (b[d] instanceof Array)
                    for (var e = 0; e < b[d].length; e++) b[d][e].hasOwnProperty("text") && (b[d][e] = b[d][e].text);
                c[a[d]] = b[d]
            }
            return c
        }
        angular.module("apigility.service").service("xhr", a), a.$inject = ["$http", "$q"]
    }(), angular.module("templates-main", ["apigility-ui/about/about.html", "apigility-ui/api-module/api-module.html", "apigility-ui/authentication/authentication.html", "apigility-ui/content-negotiation/content-negotiation.html", "apigility-ui/dashboard/dashboard.html", "apigility-ui/database/database.html", "apigility-ui/documentation/documentation-api.html", "apigility-ui/documentation/documentation-list.html", "apigility-ui/documentation/documentation-service.html", "apigility-ui/documentation/documentation.html", "apigility-ui/header/header.html", "apigility-ui/modal/add-authoption.html", "apigility-ui/modal/add-dboption.html", "apigility-ui/modal/add-filter.html", "apigility-ui/modal/add-service-description.html", "apigility-ui/modal/add-validator.html", "apigility-ui/modal/delete-api.html", "apigility-ui/modal/delete-auth.html", "apigility-ui/modal/delete-authoption.html", "apigility-ui/modal/delete-db.html", "apigility-ui/modal/delete-dboption.html", "apigility-ui/modal/delete-field.html", "apigility-ui/modal/delete-filter.html", "apigility-ui/modal/delete-rest.html", "apigility-ui/modal/delete-rpc.html", "apigility-ui/modal/delete-selector.html", "apigility-ui/modal/delete-validator.html", "apigility-ui/modal/delete-viewmodel.html", "apigility-ui/modal/edit-auth.html", "apigility-ui/modal/edit-authoption.html", "apigility-ui/modal/edit-db.html", "apigility-ui/modal/edit-dboption.html", "apigility-ui/modal/edit-field.html", "apigility-ui/modal/edit-filter.html", "apigility-ui/modal/edit-validator.html", "apigility-ui/modal/edit-viewmodel.html", "apigility-ui/modal/new-api.html", "apigility-ui/modal/new-auth.html", "apigility-ui/modal/new-db.html", "apigility-ui/modal/new-doctrinestrategy.html", "apigility-ui/modal/new-field.html", "apigility-ui/modal/new-selector.html", "apigility-ui/modal/new-service.html", "apigility-ui/modal/new-version.html", "apigility-ui/modal/new-viewmodel.html", "apigility-ui/modal/view-doctrineparams.html", "apigility-ui/package/package.html", "apigility-ui/rest/rest.html", "apigility-ui/rpc/rpc.html", "apigility-ui/sidebar/sidebar.html"]), angular.module("apigility-ui/about/about.html", []).run(["$templateCache", function(a) {
        a.put("apigility-ui/about/about.html", '<div class="panel panel-default">\n  <div class="panel-heading">\n    <h3 class="panel-title">Apigility  {{vm.version}}</h3>\n  </div>\n  <div class="panel-body">\n    <div class="hero pull-right">\n      <img src="apigility-ui/img/ag-hero.png">\n    </div>\n\n    <p>\n      <strong>Apigility</strong> is the open source API builder for PHP,\n      designed to simplify creating and maintaining useful, easy to consume, and\n      well structured APIs. Regardless of your experience in API building, with\n      <strong>Apigility</strong> you can build APIs that enable mobile apps,\n      developer communities, and any other consumer controlled access to your\n      applications.\n    </p>\n\n    <p>\n      <strong>Key features:</strong> RESTful or RPC services; JSON\n      (specifically, <a href="http://tools.ietf.org/html/draft-kelly-json-hal-08" target="_blank">HAL</a>);\n      <a href="https://tools.ietf.org/html/rfc7807" target="_blank">Problem Details for HTTP APIs</a>;\n      Versioning; Normalisation and Validation; Authentication (HTTP Basic/Digest,\n      <a href="http://oauth.net/2/" target="_blank">OAuth2</a>); Documentation\n      (HTML, <a href="http://swagger.io/" target="_blank">Swagger</a>, and <a\n        href="https://apiblueprint.org/" target="_blank">API Blueprint</a>).\n    </p>\n\n    <p>\n      <strong>Apigility</strong> is made using\n      <a href="http://framework.zend.com" target="_blank">Zend Framework</a>,\n      <a href="https://angularjs.org/" target="_blank">AngularJS</a> and\n      <a href="http://getbootstrap.com/" target="_blank">Bootstrap</a>.\n    </p>\n\n    <p>\n      If you want to contribute, you can <a href="https://github.com/zfcampus"\n        target="_blank">fork any of the relevant repositories under the zfcampus\n        organization on GitHub</a>.\n    </p>\n\n    <p>\n      The official web site of the project is <a href="https://apigility.org" target="_blank">apigility.org</a>.\n    </p>\n  </div>\n</div>\n')
    }]), angular.module("apigility-ui/api-module/api-module.html", []).run(["$templateCache", function(a) {
        a.put("apigility-ui/api-module/api-module.html", '<div class="panel panel-default">\n  <div class="panel-heading">\n    <h3 class="panel-title">\n      <span class="pull-right"><button class="btn btn-danger" ng-click="vm.deleteApiModal()" ng-hide="vm.disabled"><span class="glyphicon glyphicon-trash"></span> Delete API</button></span>\n      API: {{vm.apiName}} (v{{vm.version}})\n    </h3>\n  </div>\n  <div class="panel-body">\n    <div class="alert alert-danger" role="alert" ng-hide="!vm.alert">\n      <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> {{vm.alert}}\n    </div>\n    <div class="col-sm-12">\n      <div class="col-sm-6">\n        <h3>Authentication</h3>\n        <br />\n        <form class="form-inline" role="form" unsaved-warning-form>\n          <div class="form-group">\n            <label class="control-label">Set authentication type</label>\n            <select class="form-control" ng-model="vm.auth_type" ng-disabled="vm.disabled">\n              <option value="None">None</option>\n              <option ng-repeat="type in vm.auth_types" value="{{type.value}}">{{type.key}}</option>\n            </select>\n          </div>\n          <div class="form-group">\n            <button type="submit" class="btn btn-success btn-sm" ng-hide="vm.disabled" ng-click="vm.saveAuthentication(vm.auth_type)">Save</span></button>\n          </div>\n        </form>\n      </div>\n      <div class="col-sm-6">\n        <h3>Version <button class="btn btn-sm btn-primary" ng-click="vm.newVersionModal()" ng-hide="vm.disabled">New version</button></h3>\n        <br />\n        <form class="form-inline" role="form" unsaved-warning-form>\n          <div class="form-group">\n            <label class="control-label">Set default version</label>\n            <select class="form-control" ng-model="vm.module.default_version" ng-options="ver for ver in vm.module.versions" ng-disabled="vm.disabled"></select>\n          </div>\n          <div class="form-group">\n            <button type="submit" class="btn btn-success btn-sm" ng-click="vm.setDefaultVersion()" ladda="vm.loading" ng-hide="vm.disabled">Save</span></button>\n          </div>\n        </form>\n      </div>\n      <br clear="left"><br />\n      <h3>REST</h3>\n      <table class="table table-bordered col-sm-12">\n        <thead>\n          <tr>\n            <th class="col-sm-2">Service name</th>\n            <th class="col-sm-4">URL</th>\n            <th class="col-sm-6">Description</th>\n          </tr>\n        </thead>\n        <tr ng-repeat="rest in vm.rest track by $index">\n          <td><a ui-sref="ag.rest({api: vm.apiName, ver: vm.version, rest: rest.controller_service_name})" ng-click="vm.setSelected(\'api\'+vm.apiName+\'rest\'+rest.service_name)">{{rest.service_name}}</a></td>\n          <td>{{rest.route_match}}</td>\n          <td>\n            <a ng-click="vm.addServiceDescriptionModal(rest, \'rest\')" ng-if="!rest._embedded.documentation.description" ng-hide="vm.disabled">Add a description for this service</a>\n            <span ng-if="rest._embedded.documentation.description">{{rest._embedded.documentation.description}}</span>\n          </td>\n        </tr>\n        <tr ng-if="!vm.rest || vm.rest.length == 0">\n          <td colspan="3">\n            No REST services<span ng-hide="vm.disabled">, <a ng-click="vm.newServiceModal()">create a new one</a></span>\n          </td>\n        </tr>\n      </table>\n    </div>\n    <div class="col-sm-12">\n      <h3>RPC</h3>\n      <table class="table table-bordered col-sm-12">\n        <thead>\n          <tr>\n            <th class="col-sm-2">Service name</th>\n            <th class="col-sm-4">URL</th>\n            <th class="col-sm-6">Description</th>\n          </tr>\n        </thead>\n        <tr ng-repeat="rpc in vm.rpc track by $index">\n          <td><a ui-sref="ag.rpc({api: vm.apiName, ver: vm.version, rpc: rpc.controller_service_name})" ng-click="vm.setSelected(\'api\'+vm.apiName+\'rpc\'+rpc.service_name)">{{rpc.service_name}}</a></td>\n          <td>{{rpc.route_match}}</td>\n          <td>\n            <a ng-click="vm.addServiceDescriptionModal(rpc, \'rpc\')" ng-if="!rpc._embedded.documentation.description" ng-hide="vm.disabled">Add a description for this service</a>\n            <span ng-if="rpc._embedded.documentation.description">{{rpc._embedded.documentation.description}}</span>\n          </td>\n        </tr>\n        <tr ng-if="!vm.rpc || vm.rpc.length == 0">\n          <td colspan="3">\n            No RPC services<span ng-hide="vm.disabled">, <a ng-click="vm.newServiceModal()">create a new one</a></span>\n          </td>\n        </tr>\n      </table>\n    </div>\n  </div>\n</div>\n')
    }]), angular.module("apigility-ui/authentication/authentication.html", []).run(["$templateCache", function(a) {
        a.put("apigility-ui/authentication/authentication.html", '<div class="panel panel-default">\n  <div class="panel-heading">\n    <h3 class="panel-title">Authentication</h3>\n  </div>\n  <div class="panel-body">\n    <div class="col-sm-12">\n      <h3>Adapters <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" ng-click="vm.newAuthModal()">New adapter</button></h3>\n      <table class="table table-bordered col-sm-12">\n        <thead>\n          <tr>\n            <th class="col-sm-3">Name</th>\n            <th class="col-sm-2">Type</th>\n            <th class="col-sm-4">Options</th>\n            <th class="col-sm-3">Actions</th>\n          </tr>\n        </thead>\n        <tr ng-repeat="item in vm.adapters">\n          <td>{{item.name}}</td>\n          <td>{{item.type}} <span ng-show="item.type == \'oauth2\'" ng-if="item.oauth2_type">({{item.oauth2_type}})</span></td>\n          <td>\n            <button ng-show="item.type == \'oauth2\' && item.oauth2_type != \'custom\'" type="button" class="btn btn-primary btn-xs" ng-click="vm.addAuthOptionModal(item)"><span class="glyphicon glyphicon-plus"></span></button>\n            <span ng-repeat="(option, value) in item.oauth2_options"><a ng-click="vm.editAuthOptionModal(item, option)">{{option}} = {{value}}</a>, </span>\n            <span ng-if="item.oauth2_type == \'custom\' && item.oauth2_route">Route: {{item.oauth2_route}}</span>\n            <span ng-if="item.type == \'custom\' && item.route">Route: {{item.route}}</span>\n          </td>\n          <td>\n            <span ng-if="item.type != \'custom\' && item.oauth2_type != \'custom\'">\n              <button type="button" ng-click="vm.editAuthModal(item)" class="btn btn-success btn-xs"><i class="glyphicon glyphicon-pencil"></i> edit</button> <button type="button" ng-click="vm.deleteAuthModal(item)" class="btn btn-danger btn-xs"><i class="glyphicon glyphicon-trash"></i> delete</button>\n            </span>\n            <span ng-if="item.type == \'custom\' || item.oauth2_type == \'custom\'">\n              No actions for custom adapter\n            </span>\n          </td>\n        </tr>\n      </table>\n    </div>\n  </div>\n</div>\n')
    }]), angular.module("apigility-ui/content-negotiation/content-negotiation.html", []).run(["$templateCache", function(a) {
        a.put("apigility-ui/content-negotiation/content-negotiation.html", '<div class="panel panel-default">\n  <div class="panel-heading">\n    <h3 class="panel-title">Content Negotiation</h3>\n  </div>\n  <div class="panel-body">\n    <div class="col-sm-12">\n      <h3>Selectors <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" ng-click="vm.newSelectorModal()">New selector</button></h3>\n      <table class="table table-bordered col-sm-12">\n        <thead>\n          <tr>\n            <th class="col-sm-3">Name</th>\n            <th class="col-sm-6">View model</th>\n            <th class="col-sm-3">Action</th>\n          </tr>\n        </thead>\n        <tr ng-repeat="item in vm.content_negotiation">\n          <td>{{item.content_name}}</td>\n          <td>\n            <button type="button" class="btn btn-primary btn-xs" ng-click="vm.addViewModel(item)"><span class="glyphicon glyphicon-plus"></span></button>\n            <span ng-repeat="(viewmodel, mediatype) in item.selectors"><a ng-click="vm.editViewModel(item, viewmodel)">{{viewmodel}}</a>, </span>\n            <span ng-if="vm.selectors.length == 0">No view models</span>\n          </td>\n          <td>\n            <button type="button" ng-click="vm.deleteSelectorModal(item)" class="btn btn-danger btn-xs"><i class="glyphicon glyphicon-trash"></i> delete</button>\n          </td>\n        </tr>\n      </table>\n    </div>\n  </div>\n</div>\n');
    }]), angular.module("apigility-ui/dashboard/dashboard.html", []).run(["$templateCache", function(a) {
        a.put("apigility-ui/dashboard/dashboard.html", '<div class="row dashboard">\n  <div class="col-xs-12">\n    <div class="hero pull-right">\n      <img src="apigility-ui/img/ag-hero.png">\n    </div>\n\n    <div>\n      <h1>Welcome to Apigility!</h1>\n\n      <p class="lead">\n        <strong>Apigility</strong> is an API Builder, designed to simplify\n        creating and maintaining useful, easy to consume, and well-structured\n        APIs.<br />\n      </p>\n\n      <p class="lead">\n        If this is the first time using <strong>Apigility</strong> we suggest\n        you read the <a href="https://apigility.org/documentation/intro/getting-started"\n          target="_blank">introduction</a> or watch the <a\n          href="https://apigility.org/video" target="_blank">getting started video</a>.\n      </p>\n  </div>\n  </div>\n</div>\n')
    }]), angular.module("apigility-ui/database/database.html", []).run(["$templateCache", function(a) {
        a.put("apigility-ui/database/database.html", '<div class="panel panel-default">\n  <div class="panel-heading">\n    <h3 class="panel-title">Database</h3>\n  </div>\n  <div class="panel-body">\n    <div class="col-sm-12">\n      <h3>Database adapters <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" ng-click="vm.newDbModal()">New DB Adapter</button></h3>\n      <table class="table table-bordered col-sm-12">\n        <thead>\n          <tr>\n            <th class="col-sm-2">Name</th>\n            <th class="col-sm-2">Driver</th>\n            <th class="col-sm-2">Database</th>\n            <th class="col-sm-4">Driver options</th>\n            <th class="col-sm-2">Actions</th>\n          </tr>\n        </thead>\n        <tr ng-repeat="item in vm.db_adapter">\n          <td>{{item.adapter_name}}</td>\n          <td>{{item.driver}}</td>\n          <td>{{item.database}}</td>\n          <td>\n            <button type="button" class="btn btn-primary btn-xs" ng-click="vm.addDbOptionModal(item)"><span class="glyphicon glyphicon-plus"></span></button>\n            <span ng-repeat="(option, value) in item.driver_options"><a ng-click="vm.editDbOptionModal(item, option)">{{option}} = {{value}}</a>, </span>\n          </td>\n          <td>\n            <button type="button" ng-click="vm.editDbModal(item)" class="btn btn-success btn-xs"><i class="glyphicon glyphicon-pencil"></i> edit</button> <button type="button" ng-click="vm.deleteDbModal(item)" class="btn btn-danger btn-xs"><i class="glyphicon glyphicon-trash"></i> delete</button>\n          </td>\n        </tr>\n      </table>\n    </div>\n    <div class="row" ng-if="vm.doctrine_adapter">\n      <div class="col-sm-12">\n        <h3>Doctrine adapters</h3>\n        <table class="table table-bordered col-sm-12">\n          <thead>\n            <tr>\n              <th class="col-sm-2">Adapter name</th>\n              <th class="col-sm-2">Configuration</th>\n              <th class="col-sm-2">Event Manager</th>\n              <th class="col-sm-4">Driver class</th>\n              <th class="col-sm-2">Params</th>\n            </tr>\n          </thead>\n          <tbody>\n            <tr ng-repeat="item in vm.doctrine_adapter">\n              <td>{{item.adapter_name}}</td>\n              <td>{{item.configuration}}</td>\n              <td>{{item.eventmanager}}</td>\n              <td>{{item.driverClass}}</td>\n              <td><button type="button" ng-click="vm.viewDoctrineParamsModal(item)" class="btn btn-primary btn-xs"><i class="glyphicon glyphicon-search"></i> view params</button></td>\n            </tr>\n          </tbody>\n        </table>\n      </div>\n    </div>\n  </div>\n</div>\n')
    }]), angular.module("apigility-ui/documentation/documentation-api.html", []).run(["$templateCache", function(a) {
        a.put("apigility-ui/documentation/documentation-api.html", '<div class="panel panel-default">\n  <div class="panel-body">\n    <accordion close-others="oneAtATime">\n      <accordion-group ng-repeat="service in vm.doc.services" heading="{{service.name}}">\n        <accordion>\n          <p>{{service.description}}</p>\n          <accordion-group ng-repeat="(http, collection) in service.operations">\n            <ng-include src="\'apigility-ui/documentation/documentation-service.html\'"></ng-include>\n          </accordion-group>\n          <accordion-group ng-repeat="(http, collection) in service.entity_operations">\n            <ng-include src="\'apigility-ui/documentation/documentation-service.html\'"></ng-include>\n          </accordion-group>\n        </accordion>\n      </accordion-gruop>\n    </accordion>\n  </div>\n</div>\n')
    }]), angular.module("apigility-ui/documentation/documentation-list.html", []).run(["$templateCache", function(a) {
        a.put("apigility-ui/documentation/documentation-list.html", '<table class="table table-bordered">\n  <thead>\n    <tr>\n      <th class="col-md-4">API name</th>\n      <th class="col-md-8">Versions</th>\n    </tr>\n  </thead>\n  <tr ng-repeat="api in vm.doc">\n    <td>{{api.name}}</td>\n    <td>\n      <span ng-repeat="ver in api.versions"><a ui-sref="ag.documentation({api: api.name, ver: ver})">Ver. {{ver}}</a>, </span>\n    </td>\n  </tr>\n</table>\n')
    }]), angular.module("apigility-ui/documentation/documentation-service.html", []).run(["$templateCache", function(a) {
        a.put("apigility-ui/documentation/documentation-service.html", '<accordion-heading>\n              <span style="width:70px" class="badge">{{http}}</span> {{service.route_collection}}\n              <span class="pull-right" ng-if="collection.requires_authorization"><span class="glyphicon glyphicon-lock"></span> requires authentication</span>\n            </accordion-heading>\n            <p>{{collection.description}}</p>\n            <h4 ng-if="service.fields">Fields</h4>\n            <table class="table table-striped table-bordered" ng-if="service.fields">\n              <thead>\n                <tr>\n                  <th>Field</th>\n                  <th>Description</th>\n                  <th class="table-center">Required</th>\n                </tr>\n              </thead>\n              <tbody>\n                <tr ng-repeat="(field, data) in service.fields.input_filter">\n                  <td>{{field}}</td>\n                  <td>{{data.description}}</td>\n                  <td class="table-center">&nbsp;<span ng-show="data.required" class="glyphicon glyphicon-ok"></span>&nbsp;</td>\n                </tr>\n              </tbody>\n            </table>\n            <div class="panel-info">\n              <div class="panel-heading"><h4 class="panel-title">Request</h4></div>\n              <div class="panel-body">\n                <h4>Headers</h4>\n                <table class="table table-striped table-bordered">\n                  <thead>\n                    <tr>\n                      <th>Header</th>\n                      <th>Value</th>\n                    </tr>\n                  </thead>\n                  <tbody>\n                    <tr>\n                      <td>Accept</td>\n                      <td class="list-group">\n                        <div class="list-group-item" ng-repeat="type in service.request_accept_types">{{type}}</div>\n                      </td>\n                    </tr>\n                    <tr ng-if="collection.requires_authorization">\n                      <td>Authentication</td>\n                      <td style="color:gray">HTTP Basic, HTTP Digest, or OAuth2 Bearer token (check API provider for details)</td>\n                    </tr>\n                  </tbody>\n                </table>\n                <h4 ng-if="http !== \'GET\' && http !== \'DELETE\'">Body</h4>\n                <pre ng-if="http !== \'GET\' && http !== \'DELETE\'" class="pre-scrollable">{{collection.request}}</pre>\n              </div>\n            </div>\n            <div class="panel-info">\n              <div class="panel-heading"><h4 class="panel-title">Response</h4></div>\n              <div class="panel-body">\n                <h4>Status Codes</h4>\n                <ul class="list-group">\n                  <li class="list-group-item" ng-repeat="status in collection.response_status_codes"><strong>{{status.code}}:</strong> {{status.message}}</li>\n                </ul>\n                <h4>Headers</h4>\n                <table class="table table-striped table-bordered">\n                  <thead>\n                    <tr>\n                      <th>Header</th>\n                      <th>Value</th>\n                    </tr>\n                  </thead>\n                  <tbody>\n                    <tr>\n                      <td>Content-Type</td>\n                      <td class="list-group">\n                        <div class="list-group-item" ng-repeat="type in service.response_content_types">{{type}}</div>\n                      </td>\n                    </tr>\n                    <tr>\n                      <td>Allow</td>\n                      <td style="color:gray">Comma-separated list of all HTTP methods allowed</td>\n                    </tr>\n                  </tbody>\n                </table>\n                <h4 ng-if="http !== \'DELETE\'">Body</h4>\n                <pre ng-if="http !== \'DELETE\'" class="pre-scrollable">{{collection.response}}</pre>\n              </div>\n            </div>\n')
    }]), angular.module("apigility-ui/documentation/documentation.html", []).run(["$templateCache", function(a) {
        a.put("apigility-ui/documentation/documentation.html", '<div class="panel panel-default">\n  <div class="panel-heading">\n    <h3 class="panel-title">Documentation <span ng-if="vm.apiName"> of <strong>{{vm.apiName}}</strong> (v{{vm.version}})</span></h3>\n  </div>\n  <div class="panel-body">\n    <ng-include src="\'apigility-ui/documentation/documentation-list.html\'" ng-if="!vm.apiName"></ng-include>\n    <ng-include src="\'apigility-ui/documentation/documentation-api.html\'" ng-if="vm.apiName"></ng-include>\n  </div>\n</div>\n')
    }]), angular.module("apigility-ui/header/header.html", []).run(["$templateCache", function(a) {
        a.put("apigility-ui/header/header.html", '<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">\n  <div class="navbar-header">\n    <button type="button" class="btn btn-info header-toggle"\n      data-toggle="navbar">\n      <span class="sr-only">Toggle navigation</span>\n      <span class="glyphicon glyphicon-menu-hamburger"></span>\n    </button>\n\n    <a class="logo" ui-sref="ag"\n      ng-click="vm.setSelected(\'\')"><img id="logo"\n      src="apigility-ui/img/logo.png" alt="Apigility"></a>\n\n    <button type="button" class="btn btn-info sidebar-toggle"\n      data-toggle="sidebar">\n      <span class="sr-only">Toggle sidebar</span>\n      <span class="glyphicon glyphicon-chevron-left"></span>\n    </button>\n  </div>\n\n  <ul class="nav nav-pills">\n    <li role="presentation" ng-class="{active: (\'ag.content\' | includedByState)}"><a ui-sref="ag.content" ng-click="vm.setSelected(\'\')">Content Negotiation</a></li>\n    <li role="presentation" ng-class="{active: (\'ag.authentication\' | includedByState)}"><a ui-sref="ag.authentication" ng-click="vm.setSelected(\'\')">Authentication</a></li>\n    <li role="presentation" ng-class="{active: (\'ag.database\' | includedByState)}"><a ui-sref="ag.database" ng-click="vm.setSelected(\'\')">Database</a></li>\n    <li role="presentation" ng-class="{active: (\'ag.documentation\' | includedByState)}"><a ui-sref="ag.documentation({api : null, ver : null})" ng-click="vm.setSelected(\'\')">Documentation</a></li>\n    <li role="presentation" ng-class="{active: (\'ag.package\' | includedByState)}"><a ui-sref="ag.package" ng-click="vm.setSelected(\'\')">Package</a></li>\n    <li role="presentation" ng-class="{active: (\'ag.about\' | includedByState)}"><a ui-sref="ag.about" ng-click="vm.setSelected(\'\')">About</a></li>\n  </ul>\n</nav>\n')
    }]), angular.module("apigility-ui/modal/add-authoption.html", []).run(["$templateCache", function(a) {
        a.put("apigility-ui/modal/add-authoption.html", '<div class="modal-header">\n  <h4 class="modal-title">Add OAuth2 option for <strong>{{vm.auth.name}}</strong></h4>\n</div>\n<div class="modal-body">\n  <div class="alert alert-danger" role="alert" ng-hide="!vm.alert">\n    <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> {{vm.alert}}\n  </div>\n  <label class="control-label">Option</label>\n  <input type="text" class="form-control" ng-model="vm.option" placeholder="Insert the option name" autofocus>\n  <label class="control-label">Value</label>\n  <input type="text" class="form-control" ng-model="vm.value" placeholder="Insert the option value">\n</div>\n<div class="modal-footer">\n  <button type="button" class="btn btn-default" ng-click="vm.cancel()">Close</button>\n  <button type="button" class="btn btn-success btn-sm" ng-click="vm.ok()" ladda="vm.loading">Save</span></button>\n</div>\n')
    }]), angular.module("apigility-ui/modal/add-dboption.html", []).run(["$templateCache", function(a) {
        a.put("apigility-ui/modal/add-dboption.html", '<div class="modal-header">\n  <h4 class="modal-title">Add driver option for <strong>{{vm.db.adapter_name}}</strong></h4>\n</div>\n<div class="modal-body">\n  <div class="alert alert-danger" role="alert" ng-hide="!vm.alert">\n    <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> {{vm.alert}}\n  </div>\n  <label class="control-label">Option</label>\n  <input type="text" class="form-control" ng-model="vm.option" placeholder="Insert the option name" autofocus>\n  <label class="control-label">Value</label>\n  <input type="text" class="form-control" ng-model="vm.value" placeholder="Insert the option value">\n</div>\n<div class="modal-footer">\n  <button type="button" class="btn btn-default" ng-click="vm.cancel()">Close</button>\n  <button type="button" class="btn btn-success btn-sm" ng-click="vm.ok()" ladda="vm.loading">Save</span></button>\n</div>\n')
    }]), angular.module("apigility-ui/modal/add-filter.html", []).run(["$templateCache", function(a) {
        a.put("apigility-ui/modal/add-filter.html", '<div class="modal-header">\n  <h4 class="modal-title">Add filter for field {{vm.field.name}}</h4>\n</div>\n<div class="modal-body">\n  <div class="alert alert-danger" role="alert" ng-hide="!vm.alert">\n    <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> {{vm.alert}}\n  </div>\n  <label class="control-label">Filter</label>\n  <ui-select\n    ng-model="vm.filter.name"\n    on-select="vm.selectFilter($item, $model)">\n    <ui-select-match placeholder="Select Filter...">{{$select.selected}}</ui-select-match>\n    <ui-select-choices\n      repeat="filter in vm.filterNames | filter: $select.search">\n      <div ng-bind-html="filter | highlight: $select.search"></div>\n    </ui-select-choices>\n  </ui-select>\n  <br />\n  <div class="form-group">\n    <label for="rest_validator_option" class="col-sm-2 control-label">Option</label>\n    <div class="col-sm-8">\n      <ui-select\n        ng-model="vm.option.name"\n        on-select="vm.selectOption($item, $model)">\n        <ui-select-match placeholder="Select an option...">{{$select.selected}}</ui-select-match>\n        <ui-select-choices repeat="option in vm.optionNames | filter: $select.search">\n          <div ng-bind-html="option | highlight: $select.search"></div>\n        </ui-select-choices>\n      </ui-select>\n    </div>\n    <div class="col-sm-2">\n      <button type="button" class="btn btn-success btn-sm" ng-click="vm.addOption()">Add option</span></button>\n    </div>\n  </div>\n  <br />\n  <div class="form-group">\n    <label class="control-label col-sm-2">Value</label>\n    <div class="col-sm-8">\n      <toggle-switch type="checkbox"\n        class="switch-info switch-small"\n        ng-model="vm.option.value"\n        ng-show="vm.filter.name && vm.filters[vm.filter.name][vm.option.name] == \'bool\'"></toggle-switch>\n\n      <input type="text" class="form-control"\n        ng-model="vm.option.value"\n        ng-hide="vm.filter.name && vm.filters[vm.filter.name][vm.option.name] == \'bool\'"\n        placeholder="Insert the option value ({{vm.filters[vm.filter.name][vm.option.name]}})">\n    </div>\n  </div>\n  <br /><br />\n  <table class="table table-bordered col-md-12">\n    <thead>\n      <tr>\n        <th class="col-md-5">Option</th>\n        <th class="col-md-5">Value</th>\n        <th class="col-md-2">Action</th>\n      </tr>\n    </thead>\n    <tr ng-repeat="(option, value) in vm.filter.options">\n      <td>{{option}}</td>\n      <td>{{value}}</td>\n      <td><button type="button" ng-click="vm.deleteOption(option)" class="btn btn-danger btn-xs"><i class="glyphicon glyphicon-trash"></i> delete</button></td>\n    </tr>\n    <tr ng-show="vm.filter.options | emptyObject">\n      <td colspan="3">\n        No options have been defined</a>\n      </td>\n    </tr>\n  </table>\n  <br clear="left" />\n</div>\n<div class="modal-footer">\n  <button type="button" class="btn btn-default" ng-click="vm.cancel()">Close</button>\n  <button type="button" class="btn btn-success btn-sm" ng-click="vm.ok()" ladda="vm.loading">Save</span></button>\n</div>\n')
    }]), angular.module("apigility-ui/modal/add-service-description.html", []).run(["$templateCache", function(a) {
        a.put("apigility-ui/modal/add-service-description.html", '<div class="modal-header">\n  <h4 class="modal-title">Add service description for <strong>{{vm.service_name}}</strong></h4>\n</div>\n\n<div class="modal-body">\n  <label class="control-label">Description</label>\n  <input class="form-control" type="text" ng-model="vm.description" placeholder="Insert the service description" autofocus />\n</div>\n\n<div class="modal-footer">\n  <div class="alert alert-danger" role="alert" ng-hide="!vm.alert">\n    <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> {{vm.alert}}\n  </div>\n\n  <button class="btn btn-default" type="button" ng-click="vm.cancel()">Close</button>\n  <button class="btn btn-success" type="button" ng-click="vm.ok()" ladda="vm.loading">Save</button>\n</div>\n')
    }]), angular.module("apigility-ui/modal/add-validator.html", []).run(["$templateCache", function(a) {
        a.put("apigility-ui/modal/add-validator.html", '<div class="modal-header">\n  <h4 class="modal-title">Add validator for field <strong>{{vm.field.name}}</strong></h4>\n</div>\n<div class="modal-body">\n  <div class="alert alert-danger" role="alert" ng-hide="!vm.alert">\n    <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> {{vm.alert}}\n  </div>\n  <label class="control-label">Validator</label>\n  <ui-select\n    ng-model="vm.validator.name"\n    on-select="vm.selectValidator($item, $model)">\n    <ui-select-match placeholder="Select Validator...">{{$select.selected}}</ui-select-match>\n    <ui-select-choices\n      repeat="validator in vm.validatorNames | filter: $select.search">\n      <div ng-bind-html="validator | highlight: $select.search"></div>\n    </ui-select-choices>\n  </ui-select>\n  <br />\n  <div class="form-group">\n    <label for="rest_validator_option" class="col-sm-2 control-label">Option</label>\n    <div class="col-sm-8">\n      <ui-select\n        ng-model="vm.option.name"\n        on-select="vm.selectOption($item, $model)">\n        <ui-select-match placeholder="Select an option...">{{$select.selected}}</ui-select-match>\n        <ui-select-choices repeat="option in vm.optionNames | filter: $select.search">\n          <div ng-bind-html="option | highlight: $select.search"></div>\n        </ui-select-choices>\n      </ui-select>\n    </div>\n    <div class="col-sm-2">\n      <button type="button" class="btn btn-success btn-sm" ng-click="vm.addOption()">Add option</span></button>\n    </div>\n  </div>\n  <br />\n  <div class="form-group">\n    <label class="control-label col-sm-2">Value</label>\n    <div class="col-sm-8">\n      <toggle-switch type="checkbox"\n        class="switch-info switch-small"\n        ng-model="vm.option.value"\n        ng-show="vm.validator.name && vm.validators[vm.validator.name][vm.option.name] == \'bool\'"></toggle-switch>\n\n      <input type="text" class="form-control"\n        ng-model="vm.option.value"\n        ng-hide="vm.validator.name && vm.validators[vm.validator.name][vm.option.name] == \'bool\'"\n        placeholder="Insert the option value ({{vm.validators[vm.validator.name][vm.option.name]}})">\n    </div>\n  </div>\n  <br /><br />\n  <table class="table table-bordered col-md-12">\n    <thead>\n      <tr>\n        <th class="col-md-5">Option</th>\n        <th class="col-md-5">Value</th>\n        <th class="col-md-2">Action</th>\n      </tr>\n    </thead>\n    <tr ng-repeat="(option, value) in vm.validator.options">\n      <td>{{option}}</td>\n      <td>{{value}}</td>\n      <td><button type="button" ng-click="vm.deleteOption(option)" class="btn btn-danger btn-xs"><i class="glyphicon glyphicon-trash"></i> delete</button></td>\n    </tr>\n    <tr ng-show="vm.validator.options | emptyObject">\n      <td colspan="3">\n        No options have been defined</a>\n      </td>\n    </tr>\n  </table>\n  <br clear="left" />\n</div>\n<div class="modal-footer">\n  <button type="button" class="btn btn-default" ng-click="vm.cancel()">Close</button>\n  <button type="button" class="btn btn-success btn-sm" ng-click="vm.ok()" ladda="vm.loading">Save</span></button>\n</div>\n')
    }]), angular.module("apigility-ui/modal/delete-api.html", []).run(["$templateCache", function(a) {
        a.put("apigility-ui/modal/delete-api.html", '<div class="modal-header">\n  <h4 class="modal-title" id="myModalDeleteService"><span class="glyphicon glyphicon-trash"></span> Delete API</h4>\n</div>\n<div class="modal-body">\n  <div class="alert alert-danger" role="alert" ng-hide="!vm.alert">\n    <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> {{vm.alert}}\n  </div>\n  <p class="modal_msg">Are you sure to delete the <strong>{{vm.apiName}}</strong> API?</p>\n  <p>By default, deleting the API only removes the API module from the application configuration.\n  You can re-enable it by re-adding the module to your application configuration at a later date.</p>\n\n  <p><input type="checkbox" ng-model="vm.recursive" ng-disabled="vm.loading"> Delete all files associated with this API?</p>\n</div>\n<div class="modal-footer">\n  <button type="button" class="btn btn-default" ng-click="vm.cancel()" ng-disabled="vm.loading">No</button>\n  <button type="button" class="btn btn-primary btn-sm" ng-click="vm.ok()" ladda="vm.loading">Yes</span></button>\n</div>\n')
    }]), angular.module("apigility-ui/modal/delete-auth.html", []).run(["$templateCache", function(a) {
        a.put("apigility-ui/modal/delete-auth.html", '<div class="modal-header">\n  <h4 class="modal-title" id="myModalDeleteAuth"><span class="glyphicon glyphicon-trash"></span> Delete authentication adapter</h4>\n</div>\n<div class="modal-body">\n  <p class="modal_msg">Are you sure to delete the authentication adapter <strong>{{vm.auth.name}}</strong>?</p>\n</div>\n<div class="modal-footer">\n  <button type="button" class="btn btn-default" ng-click="vm.cancel()">No</button>\n  <button type="button" class="btn btn-primary btn-sm" ng-click="vm.ok()" ladda="vm.loading">Yes</span></button>\n</div>\n')
    }]), angular.module("apigility-ui/modal/delete-authoption.html", []).run(["$templateCache", function(a) {
        a.put("apigility-ui/modal/delete-authoption.html", '<div class="modal-header">\n  <h4 class="modal-title"><span class="glyphicon glyphicon-trash"></span> Delete OAuth2 option</h4>\n</div>\n<div class="modal-body">\n  <p class="modal_msg">Are you sure to delete the OAuth2 option <strong>{{vm.option}}</strong>?</p>\n</div>\n<div class="modal-footer">\n  <button type="button" class="btn btn-default" ng-click="vm.cancel()">No</button>\n  <button type="button" class="btn btn-primary btn-sm" ng-click="vm.ok()" ladda="vm.loading">Yes</span></button>\n</div>\n')
    }]), angular.module("apigility-ui/modal/delete-db.html", []).run(["$templateCache", function(a) {
        a.put("apigility-ui/modal/delete-db.html", '<div class="modal-header">\n  <h4 class="modal-title" id="myModalDeleteService"><span class="glyphicon glyphicon-trash"></span> Delete database adapter</h4>\n</div>\n<div class="modal-body">\n  <p class="modal_msg">Are you sure to delete the database adapter <strong>{{vm.db.adapter_name}}</strong>?</p>\n</div>\n<div class="modal-footer">\n  <button type="button" class="btn btn-default" ng-click="vm.cancel()">No</button>\n  <button type="button" class="btn btn-primary btn-sm" ng-click="vm.ok()" ladda="vm.loading">Yes</span></button>\n</div>\n')
    }]), angular.module("apigility-ui/modal/delete-dboption.html", []).run(["$templateCache", function(a) {
        a.put("apigility-ui/modal/delete-dboption.html", '<div class="modal-header">\n  <h4 class="modal-title"><span class="glyphicon glyphicon-trash"></span> Delete driver option</h4>\n</div>\n<div class="modal-body">\n  <p class="modal_msg">Are you sure to delete the driver option <strong>{{vm.option}}</strong>?</p>\n</div>\n<div class="modal-footer">\n  <button type="button" class="btn btn-default" ng-click="vm.cancel()">No</button>\n  <button type="button" class="btn btn-primary btn-sm" ng-click="vm.ok()" ladda="vm.loading">Yes</span></button>\n</div>\n')
    }]), angular.module("apigility-ui/modal/delete-field.html", []).run(["$templateCache", function(a) {
        a.put("apigility-ui/modal/delete-field.html", '<div class="modal-header">\n  <h4 class="modal-title" id="myModalDeleteService"><span class="glyphicon glyphicon-trash"></span> Delete field</h4>\n</div>\n<div class="modal-body">\n  <div class="alert alert-danger" role="alert" ng-hide="!vm.alert">\n    <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> {{vm.alert}}\n  </div>\n  <p class="modal_msg">Are you sure to delete the field <strong>{{vm.field.name}}</strong>?</p>\n</div>\n<div class="modal-footer">\n  <button type="button" class="btn btn-default" ng-click="vm.cancel()">No</button>\n  <button type="button" class="btn btn-primary btn-sm" ng-click="vm.ok()" ladda="vm.loading">Yes</span></button>\n</div>\n')
    }]), angular.module("apigility-ui/modal/delete-filter.html", []).run(["$templateCache", function(a) {
        a.put("apigility-ui/modal/delete-filter.html", '<div class="modal-header">\n  <h4 class="modal-title"><span class="glyphicon glyphicon-trash"></span> Delete filter</h4>\n</div>\n<div class="modal-body">\n  <p class="modal_msg">Are you sure to delete the filter <strong>{{vm.filter.name}}</strong>?</p>\n</div>\n<div class="modal-footer">\n  <button type="button" class="btn btn-default" ng-click="vm.cancel()">No</button>\n  <button type="button" class="btn btn-primary btn-sm" ng-click="vm.ok()" ladda="vm.loading">Yes</span></button>\n</div>\n')
    }]), angular.module("apigility-ui/modal/delete-rest.html", []).run(["$templateCache", function(a) {
        a.put("apigility-ui/modal/delete-rest.html", '<div class="modal-header">\n  <h4 class="modal-title" id="myModalDeleteService"><span class="glyphicon glyphicon-trash"></span> Delete REST</h4>\n</div>\n<div class="modal-body">\n  <p class="modal_msg">Are you sure to delete the REST service <strong>{{vm.restName}}</strong>?</p>\n  <p><input type="checkbox" ng-model="vm.recursive" ng-disabled="vm.loading"> Delete all files and directories for this service</p>\n</div>\n<div class="modal-footer">\n  <button type="button" class="btn btn-default" ng-click="vm.cancel()">No</button>\n  <button type="button" class="btn btn-primary btn-sm" ng-click="vm.ok()" ladda="vm.loading">Yes</span></button>\n</div>\n')
    }]), angular.module("apigility-ui/modal/delete-rpc.html", []).run(["$templateCache", function(a) {
        a.put("apigility-ui/modal/delete-rpc.html", '<div class="modal-header">\n  <h4 class="modal-title" id="myModalDeleteService"><span class="glyphicon glyphicon-trash"></span> Delete RPC</h4>\n</div>\n<div class="modal-body">\n  <p class="modal_msg">Are you sure to delete the RPC service <strong>{{vm.rpcName}}</strong>?</p>\n  <p><input type="checkbox" ng-model="vm.recursive" ng-disabled="vm.loading"> Delete all files and directories for this service</p>\n</div>\n<div class="modal-footer">\n  <button type="button" class="btn btn-default" ng-click="vm.cancel()">No</button>\n  <button type="button" class="btn btn-primary btn-sm" ng-click="vm.ok()" ladda="vm.loading">Yes</span></button>\n</div>\n')
    }]), angular.module("apigility-ui/modal/delete-selector.html", []).run(["$templateCache", function(a) {
        a.put("apigility-ui/modal/delete-selector.html", '<div class="modal-header">\n  <h4 class="modal-title"><span class="glyphicon glyphicon-trash"></span> Delete selector</h4>\n</div>\n<div class="modal-body">\n  <div class="alert alert-danger" role="alert" ng-hide="!vm.alert">\n    <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> {{vm.alert}}\n  </div>\n  <p class="modal_msg">Are you sure to delete the selector <strong>{{vm.selector.content_name}}</strong>?</p>\n</div>\n<div class="modal-footer">\n  <button type="button" class="btn btn-default" ng-click="vm.cancel()">No</button>\n  <button type="button" class="btn btn-primary btn-sm" ng-click="vm.ok()" ladda="vm.loading">Yes</span></button>\n</div>\n')
    }]), angular.module("apigility-ui/modal/delete-validator.html", []).run(["$templateCache", function(a) {
        a.put("apigility-ui/modal/delete-validator.html", '<div class="modal-header">\n  <h4 class="modal-title"><span class="glyphicon glyphicon-trash"></span> Delete validator</h4>\n</div>\n<div class="modal-body">\n  <p class="modal_msg">Are you sure to delete the validator <strong>{{vm.validator.name}}</strong>?</p>\n</div>\n<div class="modal-footer">\n  <button type="button" class="btn btn-default" ng-click="vm.cancel()">No</button>\n  <button type="button" class="btn btn-primary btn-sm" ng-click="vm.ok()" ladda="vm.loading">Yes</span></button>\n</div>\n')
    }]), angular.module("apigility-ui/modal/delete-viewmodel.html", []).run(["$templateCache", function(a) {
        a.put("apigility-ui/modal/delete-viewmodel.html", '<div class="modal-header">\n  <h4 class="modal-title"><span class="glyphicon glyphicon-trash"></span> Delete view model</h4>\n</div>\n<div class="modal-body">\n  <p class="modal_msg">Are you sure to delete the view model <strong>{{vm.classname}}</strong>?</p>\n</div>\n<div class="modal-footer">\n  <button type="button" class="btn btn-default" ng-click="vm.cancel()">No</button>\n  <button type="button" class="btn btn-primary btn-sm" ng-click="vm.ok()" ladda="vm.loading">Yes</span></button>\n</div>\n')
    }]), angular.module("apigility-ui/modal/edit-auth.html", []).run(["$templateCache", function(a) {
        a.put("apigility-ui/modal/edit-auth.html", '<div class="modal-header">\n  <h4 class="modal-title">Edit Authentication Adapter</h4>\n</div>\n<div class="modal-body">\n  <div class="alert alert-danger" role="alert" ng-hide="!vm.alert">\n    <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> {{vm.alert}}\n  </div>\n  <div class="row">\n    <div class="col-sm-6">\n      <label class="control-label">Adapter Name</label>\n      <input type="text" class="form-control" ng-model="vm.auth.name" readonly><br />\n    </div>\n    <div class="col-sm-6">\n      <label class="control-label">Type</label>\n      <input type="text" class="form-control" ng-model="vm.auth.type" readonly>\n    </div>\n  </div>\n  <!-- HTTP Basic -->\n  <div ng-show="vm.auth.type == \'HTTP Basic\'">\n    <div class="row">\n      <div class="col-sm-12">\n        <label class="control-label">Realm</label>\n        <input type="text" class="form-control" ng-model="vm.auth.basic.realm" placeholder="api">\n        <span class="help-block">HTTP authentication realm</span>\n      </div>\n    </div>\n    <div class="row">\n      <div class="col-sm-12">\n        <label class="control-label">htpasswd file</label>\n        <input type="text" class="form-control" ng-model="vm.auth.basic.htpasswd" placeholder="Insert the htpasswd file path">\n        <span class="help-block"><span class="glyphicon glyphicon-info-sign" aria-hidden="true"></span> If you don\'t know how to create a <i>htpasswd</i> file, read this <a href="https://apigility.org/documentation/auth/authentication-http-basic" target="_blank">guide</a></span>\n      </div>\n    </div>\n  </div>\n  <!-- HTTP Digest -->\n  <div ng-show="vm.auth.type == \'HTTP Digest\'">\n    <div class="row">\n      <div class="col-sm-12">\n        <label class="control-label">Realm</label>\n        <input type="text" class="form-control" ng-model="vm.auth.digest.realm" placeholder="api">\n        <span class="help-block">HTTP authentication realm</span>\n      </div>\n    </div>\n    <div class="row">\n      <div class="col-sm-12">\n        <label class="control-label">Digest domains</label>\n        <input type="text" class="form-control" ng-model="vm.auth.digest.digest_domains" placeholder="Add a path">\n        <span class="help-block">Space-separated list of URI paths for which authentication will be applied</span>\n      </div>\n    </div>\n    <div class="row">\n      <div class="col-sm-12">\n        <label class="control-label">Nonce timeout</label>\n        <input type="text" class="form-control" ng-model="vm.auth.digest.nonce_timeout" placeholder="3600">\n        <span class="help-block">Expiration in seconds for inactive authentication</span>\n      </div>\n    </div>\n    <div class="row">\n      <div class="col-sm-12">\n        <label class="control-label">htdigest file</label>\n        <input type="text" class="form-control" ng-model="vm.auth.digest.htdigest" placeholder="Insert the htdigest file path">\n        <span class="help-block"><span class="glyphicon glyphicon-info-sign" aria-hidden="true"></span> If you don\'t know how to create a <i>htdigest</i> file, read this <a href="https://apigility.org/documentation/auth/authentication-http-digest" target="_blank">guide</a></span>\n      </div>\n    </div>\n  </div>\n  <!-- OAuth2 PDO -->\n  <div ng-show="vm.auth.type == \'OAuth2 PDO\'">\n    <div class="row">\n      <div class="col-sm-12">\n        <label class="control-label">DSN</label>\n        <input type="text" class="form-control" ng-model="vm.auth.pdo.oauth2_dsn" placeholder="sqlite::memory:">\n        <span class="help-block">The PDO database source name (DSN).</span>\n      </div>\n    </div>\n    <div class="row">\n      <div class="col-sm-12">\n        <label class="control-label">Username</label>\n        <input type="text" class="form-control" ng-model="vm.auth.pdo.oauth2_username" placeholder="(optional) username">\n        <span class="help-block">Username for OAuth2 database credentials (required if not using SQLite)</span>\n      </div>\n    </div>\n    <div class="row">\n      <div class="col-sm-12">\n        <label class="control-label">Password</label>\n        <input type="password" class="form-control" ng-model="vm.auth.pdo.oauth2_password" placeholder="(optional) password">\n        <span class="help-block">Password for the username listed (required if not using SQLite)</span>\n      </div>\n    </div>\n    <div class="row">\n      <div class="col-sm-12">\n        <label class="control-label">OAuth2 route</label>\n        <input type="text" class="form-control" ng-model="vm.auth.pdo.oauth2_route" placeholder="/oauth">\n        <span class="help-block">Base URI to use as the OAuth2 server endpoint</span>\n      </div>\n    </div>\n  </div>\n  <!-- OAuth2 Mongo -->\n  <div ng-show="vm.auth.type == \'OAuth2 Mongo\'">\n    <div class="row">\n      <div class="col-sm-12">\n        <label class="control-label">DSN</label>\n        <input type="text" class="form-control" ng-model="vm.auth.mongo.oauth2_dsn" placeholder="Insert the Mongo database source name (DSN)">\n        <span class="help-block">The MongoClient server connection string; if not provided, "mongodb://localhost:27017" will be used. "mongodb://" may be omitted from the string.</span>\n      </div>\n    </div>\n    <div class="row">\n      <div class="col-sm-12">\n        <label class="control-label">Locator name</label>\n        <input type="text" class="form-control" ng-model="vm.auth.mongo.oauth2_locator_name" placeholder="(optional) Insert the locator name">\n      </div>\n    </div>\n    <div class="row">\n      <div class="col-sm-12">\n        <label class="control-label">Database</label>\n        <input type="test" class="form-control" ng-model="vm.auth.mongo.oauth2_database" placeholder="The Mongo database name">\n      </div>\n    </div>\n    <div class="row">\n      <div class="col-sm-12">\n        <label class="control-label">OAuth2 route</label>\n        <input type="text" class="form-control" ng-model="vm.auth.oauth2.mongo.route" placeholder="/oauth">\n        <span class="help-block">Base URI to use as the OAuth2 server endpoint</span>\n      </div>\n    </div>\n  </div>\n</div>\n<div class="modal-footer">\n  <button type="button" class="btn btn-default" ng-click="vm.cancel()">Close</button>\n  <button type="button" class="btn btn-success btn-sm" ng-click="vm.ok()" ladda="vm.loading">Save</span></button>\n</div>\n');
    }]), angular.module("apigility-ui/modal/edit-authoption.html", []).run(["$templateCache", function(a) {
        a.put("apigility-ui/modal/edit-authoption.html", '<div class="modal-header">\n  <h4 class="modal-title">Edit OAuth2 option for <strong>{{vm.auth.name}}</strong> <button type="button" class="btn btn-danger btn-sm pull-right" ng-click="vm.deleteAuthOptionModal(vm.auth, vm.option)"><span class="glyphicon glyphicon-trash"></span> Delete option</button></h4>\n</div>\n<div class="modal-body">\n  <div class="alert alert-danger" role="alert" ng-hide="!vm.alert">\n    <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> {{vm.alert}}\n  </div>\n  <label class="control-label">Option</label>\n  <input type="text" class="form-control" ng-model="vm.option" placeholder="Insert the option name" readonly>\n  <label class="control-label">Value</label>\n  <input type="text" class="form-control" ng-model="vm.value" placeholder="Insert the option value">\n</div>\n<div class="modal-footer">\n  <button type="button" class="btn btn-default" ng-click="vm.cancel()">Close</button>\n  <button type="button" class="btn btn-success btn-sm" ng-click="vm.ok()" ladda="vm.loading">Save</span></button>\n</div>\n')
    }]), angular.module("apigility-ui/modal/edit-db.html", []).run(["$templateCache", function(a) {
        a.put("apigility-ui/modal/edit-db.html", '<div class="modal-header">\n  <h4 class="modal-title">Edit Database Adapter</h4>\n</div>\n<div class="modal-body">\n  <div class="alert alert-danger" role="alert" ng-hide="!vm.alert">\n    <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> {{vm.alert}}\n  </div>\n  <label class="control-label">Adapter Name</label>\n  <input type="text" class="form-control" ng-model="vm.db.adapter_name" readonly><br />\n  <div class="row">\n    <div class="col-sm-6">\n      <label class="control-label">Driver Type</label>\n      <select class="form-control" ng-model="vm.db.driver" ng-options="option as option for option in vm.driver_types"></select>\n    </div>\n    <div class="col-sm-6">\n      <label class="control-label">Database</label>\n      <input type="text" class="form-control" ng-model="vm.db.database" placeholder="Insert the database name"><br />\n    </div>\n  </div>\n  <label class="control-label">DSN</label>\n  <input type="text" class="form-control" ng-model="vm.db.dsn" placeholder="(Optional) DSN for database"><br />\n  <div class="row">\n    <div class="col-sm-6">\n      <label class="control-label">Username</label>\n      <input type="text" class="form-control" ng-model="vm.db.username" placeholder="(Optional) Username"><br />\n    </div>\n    <div class="col-sm-6">\n      <label class="control-label">Password</label>\n      <input type="password" class="form-control" ng-model="vm.db.password" placeholder="(Optional) Password"><br />\n    </div>\n  </div>\n  <label class="control-label">Hostname</label>\n  <input type="text" class="form-control" ng-model="vm.db.hostname" placeholder="(Optional) Hostname"><br />\n  <div class="row">\n    <div class="col-sm-6">\n      <label class="control-label">Port</label>\n      <input type="text" class="form-control" ng-model="vm.db.port" placeholder="(Optional) Port"><br />\n    </div>\n    <div class="col-sm-6">\n      <label class="control-label">Charset</label>\n      <input type="text" class="form-control" ng-model="vm.db.charset" placeholder="(Optional) Charset"><br />\n    </div>\n  </div>\n</div>\n<div class="modal-footer">\n  <button type="button" class="btn btn-default" ng-click="vm.cancel()">Close</button>\n  <button type="button" class="btn btn-success btn-sm" ng-click="vm.ok()" ladda="vm.loading">Save</button>\n</div>\n')
    }]), angular.module("apigility-ui/modal/edit-dboption.html", []).run(["$templateCache", function(a) {
        a.put("apigility-ui/modal/edit-dboption.html", '<div class="modal-header">\n  <h4 class="modal-title">Edit driver option for <strong>{{vm.db.adapter_name}}</strong> <button type="button" class="btn btn-danger btn-sm pull-right" ng-click="vm.deleteDbOptionModal(vm.db, vm.option)"><span class="glyphicon glyphicon-trash"></span> Delete option</button></h4>\n</div>\n<div class="modal-body">\n  <div class="alert alert-danger" role="alert" ng-hide="!vm.alert">\n    <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> {{vm.alert}}\n  </div>\n  <label class="control-label">Option</label>\n  <input type="text" class="form-control" ng-model="vm.option" placeholder="Insert the option name" readonly>\n  <label class="control-label">Value</label>\n  <input type="text" class="form-control" ng-model="vm.value" placeholder="Insert the option value">\n</div>\n<div class="modal-footer">\n  <button type="button" class="btn btn-default" ng-click="vm.cancel()">Close</button>\n  <button type="button" class="btn btn-success btn-sm" ng-click="vm.ok()" ladda="vm.loading">Save</span></button>\n</div>\n')
    }]), angular.module("apigility-ui/modal/edit-field.html", []).run(["$templateCache", function(a) {
        a.put("apigility-ui/modal/edit-field.html", '<div class="modal-header">\n  <h4 class="modal-title">Edit Field</h4>\n</div>\n<div class="modal-body">\n  <div class="alert alert-danger" role="alert" ng-hide="!vm.alert">\n    <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> {{vm.alert}}\n  </div>\n  <label class="control-label">Name</label>\n  <input type="text" class="form-control" ng-model="vm.field.name" placeholder="Insert the Field name" readonly><br />\n  <label class="control-label">Description</label>\n  <textarea class="form-control" ng-model="vm.field.description" rows="3" placeholder="Insert the description"></textarea><br />\n  <label class="control-label">Field Type</label>\n  <input type="text" class="form-control" ng-model="vm.field.field_type" rows="3" placeholder="Insert the field type"><br />\n  <label class="col-sm-4 control-label">File upload?</label>\n  <input type="checkbox" ng-model="vm.field.type" ng-true-value="Zend\\InputFilter\\FileInput" class="col-sm-2 control-label">\n  <label class="col-sm-4 control-label">Required</label>\n  <input type="checkbox" ng-model="vm.field.required" value="Yes" class="col-sm-2 control-label"><br />\n  <label class="col-sm-4 control-label">Allow Empty</label>\n  <input type="checkbox" ng-model="vm.field.allow_empty" value="Yes" class="col-sm-2 control-label">\n  <label class="col-sm-4 control-label">Continue if Empty</label>\n  <input type="checkbox" ng-model="vm.field.continue_if_empty" value="Yes" class="col-sm-2 control-label"><br /><br />\n  <label class="control-label">Validation Failure Message</label>\n  <textarea class="form-control" ng-model="vm.field.error_message" rows="3" placeholder="Insert the failure message"></textarea>\n</div>\n<div class="modal-footer">\n  <button type="button" class="btn btn-default" ng-click="vm.cancel()">Close</button>\n  <button type="button" class="btn btn-success btn-sm" ng-click="vm.ok()" ladda="vm.loading">Save</span></button>\n</div>\n')
    }]), angular.module("apigility-ui/modal/edit-filter.html", []).run(["$templateCache", function(a) {
        a.put("apigility-ui/modal/edit-filter.html", '<div class="modal-header">\n  <h4 class="modal-title">Filter for <strong>{{vm.field.name}}</strong> field <button type="button" class="btn btn-danger btn-sm pull-right" ng-click="vm.deleteFilterModal()" ng-hide="vm.disabled"><span class="glyphicon glyphicon-trash"></span> Delete filter</button></h4>\n</div>\n<div class="modal-body">\n  <div class="alert alert-danger" role="alert" ng-hide="!vm.alert">\n    <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> {{vm.alert}}\n  </div>\n  <label class="control-label">Filter</label>\n  <input type="text" class="form-control" ng-model="vm.filter.name" readonly>\n  <br />\n  <div class="form-group">\n    <label class="col-sm-2 control-label">Option</label>\n    <div class="col-sm-8">\n      <ui-select\n        ng-model="vm.option.name"\n        ng-disabled="vm.disabled"\n        on-select="vm.selectOption($item, $model)">\n        <ui-select-match placeholder="Select an option...">{{$select.selected}}</ui-select-match>\n        <ui-select-choices repeat="option in vm.optionNames | filter: $select.search">\n          <div ng-bind-html="option | highlight: $select.search"></div>\n        </ui-select-choices>\n      </ui-select>\n    </div>\n    <div class="col-sm-2">\n      <button type="button" class="btn btn-success btn-sm" ng-click="vm.addOption()" ng-hide="vm.disabled">Add option</span></button>\n    </div>\n  </div>\n  <br />\n  <div class="form-group">\n    <label class="control-label col-sm-2">Value</label>\n    <div class="col-sm-8">\n      <toggle-switch type="checkbox"\n        class="switch-info switch-small"\n        ng-model="vm.option.value"\n        ng-disabled="vm.disabled"\n        ng-show="vm.filter.name && vm.filters[vm.filter.name][vm.option.name] == \'bool\'"></toggle-switch>\n\n      <input type="text" class="form-control"\n        ng-model="vm.option.value"\n        ng-hide="vm.filter.name && vm.filters[vm.filter.name][vm.option.name] == \'bool\'"\n        ng-disabled="vm.disabled"\n        placeholder="Insert the option value ({{vm.filters[vm.filter.name][vm.option.name]}})">\n    </div>\n  </div>\n  <br /><br />\n  <table class="table table-bordered col-md-12">\n    <thead>\n      <tr>\n        <th class="col-md-5">Option</th>\n        <th class="col-md-5">Value</th>\n        <th class="col-md-2">Action</th>\n      </tr>\n    </thead>\n    <tr ng-repeat="(option, value) in vm.filter.options">\n      <td>{{option}}</td>\n      <td>{{value}}</td>\n      <td><button type="button" ng-click="vm.deleteOption(option)" class="btn btn-danger btn-xs" ng-hide="vm.disabled"><i class="glyphicon glyphicon-trash"></i> delete</button></td>\n    </tr>\n    <tr ng-show="vm.filter.options | emptyObject">\n      <td colspan="3">\n        No options have been defined</a>\n      </td>\n    </tr>\n  </table>\n  <br clear="left" />\n</div>\n<div class="modal-footer">\n  <button type="button" class="btn btn-default" ng-click="vm.cancel()">Close</button>\n  <button type="button" class="btn btn-success btn-sm" ng-click="vm.ok()" ladda="vm.loading" ng-hide="vm.disabled">Save</span></button>\n</div>\n')
    }]), angular.module("apigility-ui/modal/edit-validator.html", []).run(["$templateCache", function(a) {
        a.put("apigility-ui/modal/edit-validator.html", '<div class="modal-header">\n  <h4 class="modal-title">Validator for <strong>{{vm.field.name}}</strong> field <button type="button" class="btn btn-danger btn-sm pull-right" ng-click="vm.deleteValidatorModal()" ng-hide="vm.disabled"><span class="glyphicon glyphicon-trash"></span> Delete validator</button></h4>\n</div>\n<div class="modal-body">\n  <div class="alert alert-danger" role="alert" ng-hide="!vm.alert">\n    <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> {{vm.alert}}\n  </div>\n  <label class="control-label">Validator</label>\n  <input type="text" class="form-control" ng-model="vm.validator.name" readonly>\n  <br />\n  <div class="form-group">\n    <label for="rest_validator_option" class="col-sm-2 control-label">Option</label>\n    <div class="col-sm-8">\n      <ui-select\n        ng-model="vm.option.name"\n        ng-disabled="vm.disabled"\n        on-select="vm.selectOption($item, $model)">\n        <ui-select-match placeholder="Select an option...">{{$select.selected}}</ui-select-match>\n        <ui-select-choices repeat="option in vm.optionNames | filter: $select.search">\n          <div ng-bind-html="option | highlight: $select.search"></div>\n        </ui-select-choices>\n      </ui-select>\n    </div>\n    <div class="col-sm-2">\n      <button type="button" class="btn btn-success btn-sm" ng-click="vm.addOption()" ng-hide="vm.disabled">Add option</span></button>\n    </div>\n  </div>\n  <br />\n  <div class="form-group" ng-disabled="vm.disabled">\n    <label class="control-label col-sm-2">Value</label>\n    <div class="col-sm-8">\n      <toggle-switch type="checkbox"\n        ng-model="vm.option.value"\n        ng-disabled="vm.disabled"\n        ng-show="vm.validator.name && vm.validators[vm.validator.name][vm.option.name] == \'bool\'"></toggle-switch>\n\n      <input type="text" class="form-control"\n        ng-model="vm.option.value"\n        ng-hide="vm.validator.name && vm.validators[vm.validator.name][vm.option.name] == \'bool\'"\n        ng-disabled="vm.disabled"\n        placeholder="Insert the option value ({{vm.validators[vm.validator.name][vm.option.name]}})">\n    </div>\n  </div>\n  <br /><br />\n  <table class="table table-bordered col-md-12">\n    <thead>\n      <tr>\n        <th class="col-md-5">Option</th>\n        <th class="col-md-5">Value</th>\n        <th class="col-md-2">Action</th>\n      </tr>\n    </thead>\n    <tr ng-repeat="(option, value) in vm.validator.options">\n      <td>{{option}}</td>\n      <td>{{value}}</td>\n      <td><button type="button" ng-click="vm.deleteOption(option)" class="btn btn-danger btn-xs" ng-hide="vm.disabled"><i class="glyphicon glyphicon-trash"></i> delete</button></td>\n    </tr>\n    <tr ng-show="vm.validator.options | emptyObject">\n      <td colspan="3">\n        No options have been defined</a>\n      </td>\n    </tr>\n  </table>\n  <br clear="left" />\n</div>\n<div class="modal-footer">\n  <button type="button" class="btn btn-default" ng-click="vm.cancel()">Close</button>\n  <button type="button" class="btn btn-success btn-sm" ng-click="vm.ok()" ladda="vm.loading" ng-hide="vm.disabled">Save</span></button>\n</div>\n')
    }]), angular.module("apigility-ui/modal/edit-viewmodel.html", []).run(["$templateCache", function(a) {
        a.put("apigility-ui/modal/edit-viewmodel.html", '<div class="modal-header">\n  <h4 class="modal-title">Edit View Model <button type="button" class="btn btn-danger btn-sm pull-right" ng-click="vm.deleteViewModelModal()"><span class="glyphicon glyphicon-trash"></span> Delete view model</button></h4>\n</div>\n<div class="modal-body">\n  <div class="alert alert-danger" role="alert" ng-hide="!vm.alert">\n    <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> {{vm.alert}}\n  </div>\n  <label class="control-label">Name</label>\n  <input type="text" class="form-control" ng-model="vm.classname" readonly><br />\n  <label class="control-label">Mediatypes</label>\n  <tags-input\n    ng-model="vm.mediatypes"\n    ng-readonly=""\n    placeholder="Add a media type"\n    add-on-space="true"\n    add-on-enter="true"\n    add-on-blur="true"\n    allowed-tags-pattern="^[a-zA-Z-]+/[a-zA-Z0-9*_+.-]+$"></tags-input>\n</div>\n<div class="modal-footer">\n  <button type="button" class="btn btn-default" ng-click="vm.cancel()">Close</button>\n  <button type="button" class="btn btn-success btn-sm" ng-click="vm.ok()" ladda="vm.loading">Save</span></button>\n</div>\n')
    }]), angular.module("apigility-ui/modal/new-api.html", []).run(["$templateCache", function(a) {
        a.put("apigility-ui/modal/new-api.html", '<div class="modal-header">\n  <h4 class="modal-title">Create new API</h4>\n</div>\n<div class="modal-body">\n  <div class="alert alert-danger" role="alert" ng-hide="!vm.alert">\n    <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> {{vm.alert}}\n  </div>\n  <input type="text" class="form-control" ng-model="vm.apiname" placeholder="Insert the API name" ng-disabled="vm.loading" autofocus>\n</div>\n<div class="modal-footer">\n  <button type="button" class="btn btn-default" ng-click="vm.cancel()" ng-disabled="vm.loading">Close</button>\n  <button type="button" class="btn btn-primary" ng-click="vm.ok()" ladda="vm.loading">Create</span></button>\n</div>\n')
    }]), angular.module("apigility-ui/modal/new-auth.html", []).run(["$templateCache", function(a) {
        a.put("apigility-ui/modal/new-auth.html", '<div class="modal-header">\n  <h4 class="modal-title">New Authentication Adapter</h4>\n</div>\n<div class="modal-body">\n  <div class="alert alert-danger" role="alert" ng-hide="!vm.alert">\n    <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> {{vm.alert}}\n  </div>\n  <div class="row">\n    <div class="col-sm-6">\n      <label class="control-label">Adapter Name</label>\n      <input type="text" class="form-control" ng-model="vm.auth.name" placeholder="Insert the adapter name"><br />\n    </div>\n    <div class="col-sm-6">\n      <label class="control-label">Type</label>\n      <select class="form-control" ng-model="vm.auth.type" ng-options="option as option for option in vm.auth_types"></select>\n    </div>\n  </div>\n  <!-- HTTP Basic -->\n  <div ng-show="vm.auth.type == \'HTTP Basic\'">\n    <div class="row">\n      <div class="col-sm-12">\n        <label class="control-label">Realm</label>\n        <input type="text" class="form-control" ng-model="vm.auth.basic.realm" placeholder="api">\n        <span class="help-block">HTTP authentication realm</span>\n      </div>\n    </div>\n    <div class="row">\n      <div class="col-sm-12">\n        <label class="control-label">htpasswd file</label>\n        <input type="text" class="form-control" ng-model="vm.auth.basic.htpasswd" placeholder="Insert the htpasswd file path">\n        <span class="help-block"><span class="glyphicon glyphicon-info-sign" aria-hidden="true"></span> If you don\'t know how to create a <i>htpasswd</i> file, read this <a href="https://apigility.org/documentation/auth/authentication-http-basic" target="_blank">guide</a></span>\n      </div>\n    </div>\n  </div>\n  <!-- HTTP Digest -->\n  <div ng-show="vm.auth.type == \'HTTP Digest\'">\n    <div class="row">\n      <div class="col-sm-12">\n        <label class="control-label">Realm</label>\n        <input type="text" class="form-control" ng-model="vm.auth.digest.realm" placeholder="api">\n        <span class="help-block">HTTP authentication realm</span>\n      </div>\n    </div>\n    <div class="row">\n      <div class="col-sm-12">\n        <label class="control-label">Digest domains</label>\n        <input type="text" class="form-control" ng-model="vm.auth.digest.digest_domains" placeholder="Add a path">\n        <span class="help-block">Space-separated list of URI paths for which authentication will be applied</span>\n      </div>\n    </div>\n    <div class="row">\n      <div class="col-sm-12">\n        <label class="control-label">Nonce timeout</label>\n        <input type="text" class="form-control" ng-model="vm.auth.digest.nonce_timeout" placeholder="3600">\n        <span class="help-block">Expiration in seconds for inactive authentication</span>\n      </div>\n    </div>\n    <div class="row">\n      <div class="col-sm-12">\n        <label class="control-label">htdigest file</label>\n        <input type="text" class="form-control" ng-model="vm.auth.digest.htdigest" placeholder="Insert the htdigest file path">\n        <span class="help-block"><span class="glyphicon glyphicon-info-sign" aria-hidden="true"></span> If you don\'t know how to create a <i>htdigest</i> file, read this <a href="https://apigility.org/documentation/auth/authentication-http-digest" target="_blank">guide</a></span>\n      </div>\n    </div>\n  </div>\n  <!-- OAuth2 PDO -->\n  <div ng-show="vm.auth.type == \'OAuth2 PDO\'">\n    <div class="row">\n      <div class="col-sm-12">\n        <label class="control-label">DSN</label>\n        <input type="text" class="form-control" ng-model="vm.auth.pdo.oauth2_dsn" placeholder="sqlite::memory:">\n        <span class="help-block">The PDO database source name (DSN).</span>\n      </div>\n    </div>\n    <div class="row">\n      <div class="col-sm-12">\n        <label class="control-label">Username</label>\n        <input type="text" class="form-control" ng-model="vm.auth.pdo.oauth2_username" placeholder="(optional) username">\n        <span class="help-block">Username for OAuth2 database credentials (required if not using SQLite)</span>\n      </div>\n    </div>\n    <div class="row">\n      <div class="col-sm-12">\n        <label class="control-label">Password</label>\n        <input type="password" class="form-control" ng-model="vm.auth.pdo.oauth2_password" placeholder="(optional) password">\n        <span class="help-block">Password for the username listed (required if not using SQLite)</span>\n      </div>\n    </div>\n    <div class="row">\n      <div class="col-sm-12">\n        <label class="control-label">OAuth2 route</label>\n        <input type="text" class="form-control" ng-model="vm.auth.pdo.oauth2_route" placeholder="/oauth">\n        <span class="help-block">Base URI to use as the OAuth2 server endpoint</span>\n      </div>\n    </div>\n  </div>\n  <!-- OAuth2 Mongo -->\n  <div ng-show="vm.auth.type == \'OAuth2 Mongo\'">\n    <div class="row">\n      <div class="col-sm-12">\n        <label class="control-label">DSN</label>\n        <input type="text" class="form-control" ng-model="vm.auth.mongo.oauth2_dsn" placeholder="Insert the Mongo database source name (DSN)">\n        <span class="help-block">The MongoClient server connection string; if not provided, "mongodb://localhost:27017" will be used. "mongodb://" may be omitted from the string.</span>\n      </div>\n    </div>\n    <div class="row">\n      <div class="col-sm-12">\n        <label class="control-label">Locator name</label>\n        <input type="text" class="form-control" ng-model="vm.auth.mongo.oauth2_locator_name" placeholder="(optional) Insert the locator name">\n      </div>\n    </div>\n    <div class="row">\n      <div class="col-sm-12">\n        <label class="control-label">Database</label>\n        <input type="test" class="form-control" ng-model="vm.auth.mongo.oauth2_database" placeholder="The Mongo database name">\n      </div>\n    </div>\n    <div class="row">\n      <div class="col-sm-12">\n        <label class="control-label">OAuth2 route</label>\n        <input type="text" class="form-control" ng-model="vm.auth.mongo.oauth2_route" placeholder="/oauth">\n        <span class="help-block">Base URI to use as the OAuth2 server endpoint</span>\n      </div>\n    </div>\n  </div>\n</div>\n<div class="modal-footer">\n  <button type="button" class="btn btn-default" ng-click="vm.cancel()">Close</button>\n  <button type="button" class="btn btn-success btn-sm" ng-click="vm.ok()" ladda="vm.loading">Save</span></button>\n</div>\n')
    }]), angular.module("apigility-ui/modal/new-db.html", []).run(["$templateCache", function(a) {
        a.put("apigility-ui/modal/new-db.html", '<div class="modal-header">\n  <h4 class="modal-title">New Database Adapter</h4>\n</div>\n<div class="modal-body">\n  <div class="alert alert-danger" role="alert" ng-hide="!vm.alert">\n    <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> {{vm.alert}}\n  </div>\n  <label class="control-label">Adapter Name</label>\n  <input type="text" class="form-control" ng-model="vm.db.adapter_name" placeholder="Insert the adapter name" autofocus><br />\n  <div class="row">\n    <div class="col-sm-6">\n      <label class="control-label">Driver Type</label>\n      <select class="form-control" ng-model="vm.db.driver" ng-options="option as option for option in vm.driver_types"></select>\n    </div>\n    <div class="col-sm-6">\n      <label class="control-label">Database</label>\n      <input type="text" class="form-control" ng-model="vm.db.database" placeholder="Insert the database name"><br />\n    </div>\n  </div>\n  <label class="control-label">DSN</label>\n  <input type="text" class="form-control" ng-model="vm.db.dsn" placeholder="(Optional) DSN for database"><br />\n  <div class="row">\n    <div class="col-sm-6">\n      <label class="control-label">Username</label>\n      <input type="text" class="form-control" ng-model="vm.db.username" placeholder="(Optional) Username"><br />\n    </div>\n    <div class="col-sm-6">\n      <label class="control-label">Password</label>\n      <input type="password" class="form-control" ng-model="vm.db.password" placeholder="(Optional) Password"><br />\n    </div>\n  </div>\n  <label class="control-label">Hostname</label>\n  <input type="text" class="form-control" ng-model="vm.db.hostname" placeholder="(Optional) Hostname"><br />\n  <div class="row">\n    <div class="col-sm-6">\n      <label class="control-label">Port</label>\n      <input type="text" class="form-control" ng-model="vm.db.port" placeholder="(Optional) Port"><br />\n    </div>\n    <div class="col-sm-6">\n      <label class="control-label">Charset</label>\n      <input type="text" class="form-control" ng-model="vm.db.charset" placeholder="(Optional) Charset"><br />\n    </div>\n  </div>\n</div>\n<div class="modal-footer">\n  <button type="button" class="btn btn-default" ng-click="vm.cancel()">Close</button>\n  <button type="button" class="btn btn-success btn-sm" ng-click="vm.ok()" ladda="vm.loading">Save</span></button>\n</div>\n')
    }]), angular.module("apigility-ui/modal/new-doctrinestrategy.html", []).run(["$templateCache", function(a) {
        a.put("apigility-ui/modal/new-doctrinestrategy.html", '<div class="modal-header">\n  <h4 class="modal-title">New Hydrator Strategy</h4>\n</div>\n<div class="modal-body">\n  <div class="alert alert-danger" role="alert" ng-hide="!vm.alert">\n    <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> {{vm.alert}}\n  </div>\n  <label class="control-label">Field</label>\n  <select ng-model="vm.field" class="form-control" ng-options="k as v for (k,v) in vm.fields">\n    <option value=\'\' disabled>- Choose a field -</option>\n  </select><br>\n  <label class="control-label">Strategy</label>\n  <input type="text" class="form-control" ng-model="vm.strategy" placeholder="Type a declared strategy service name" ng-disabled="vm.loading" autofocus>\n</div>\n<div class="modal-footer">\n  <button type="button" class="btn btn-default" ng-click="vm.cancel()" ng-disabled="vm.loading">Close</button>\n  <button type="button" class="btn btn-primary" ng-click="vm.ok()" ladda="vm.loading">Create</span></button>\n</div>\n')
    }]), angular.module("apigility-ui/modal/new-field.html", []).run(["$templateCache", function(a) {
        a.put("apigility-ui/modal/new-field.html", '<div class="modal-header">\n  <h4 class="modal-title">New Field</h4>\n</div>\n<div class="modal-body">\n  <div class="alert alert-danger" role="alert" ng-hide="!vm.alert">\n    <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> {{vm.alert}}\n  </div>\n  <label class="control-label">Name</label>\n  <input type="text" class="form-control" ng-model="vm.field.name" placeholder="Insert the Field name" autofocus><br />\n  <label class="control-label">Description</label>\n  <textarea class="form-control" ng-model="vm.field.description" rows="3" placeholder="Insert the description"></textarea><br />\n  <label class="control-label">Field Type</label>\n  <input type="text" class="form-control" ng-model="vm.field.field_type" rows="3" placeholder="Insert the field type"><br />\n  <label class="col-sm-4 control-label">File upload?</label>\n  <input type="checkbox" ng-model="vm.field.type" ng-true-value="Zend\\InputFilter\\FileInput" class="col-sm-2 control-label">\n  <label class="col-sm-4 control-label">Required</label>\n  <input type="checkbox" ng-model="vm.field.required" value="Yes" class="col-sm-2 control-label"><br />\n  <label class="col-sm-4 control-label">Allow Empty</label>\n  <input type="checkbox" ng-model="vm.field.allow_empty" value="Yes" class="col-sm-2 control-label">\n  <label class="col-sm-4 control-label">Continue if Empty</label>\n  <input type="checkbox" ng-model="vm.field.continue_if_empty" value="Yes" class="col-sm-2 control-label"><br /><br />\n  <label class="control-label">Validation Failure Message</label>\n  <textarea class="form-control" ng-model="vm.field.error_message" rows="3" placeholder="Insert the failure message"></textarea>\n</div>\n<div class="modal-footer">\n  <button type="button" class="btn btn-default" ng-click="vm.cancel()">Close</button>\n  <button type="button" class="btn btn-success btn-sm" ng-click="vm.ok()" ladda="vm.loading">Save</span></button>\n</div>\n')
    }]), angular.module("apigility-ui/modal/new-selector.html", []).run(["$templateCache", function(a) {
        a.put("apigility-ui/modal/new-selector.html", '<div class="modal-header">\n  <h4 class="modal-title">Create new Selector</h4>\n</div>\n<div class="modal-body">\n  <div class="alert alert-danger" role="alert" ng-hide="!vm.alert">\n    <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> {{vm.alert}}\n  </div>\n  <input type="text" class="form-control" ng-model="vm.selectorname" placeholder="Insert the Selector name" ng-disabled="vm.loading" autofocus>\n</div>\n<div class="modal-footer">\n  <button type="button" class="btn btn-default" ng-click="vm.cancel()" ng-disabled="vm.loading">Close</button>\n  <button type="button" class="btn btn-primary" ng-click="vm.ok()" ladda="vm.loading">Create</span></button>\n</div>\n')
    }]), angular.module("apigility-ui/modal/new-service.html", []).run(["$templateCache", function(a) {
        a.put("apigility-ui/modal/new-service.html", '<div class="modal-header">\n  <h4 class="modal-title">Create a new service</h4>\n</div>\n<div class="modal-body">\n  <div class="alert alert-danger" role="alert" ng-hide="!vm.alert">\n    <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> {{vm.alert}}\n  </div>\n  <div role="tabpanel">\n    <label class="control-label">API</label>\n    <select class="form-control" ng-model="vm.apiname" ng-options="api.name for api in vm.apis" ng-disabled="vm.loading"></select>\n    <br />\n    <label class="control-label">Select the type of service to create</label>\n    <br />\n    <!-- Nav tabs -->\n    <tabset justified="true">\n      <tab heading="REST" active="vm.tabs.rest">\n        <label for="rest_service_name" class="control-label">Service name</label>\n        <input type="text" id="rest_service_name" class="form-control" ng-model="vm.restname" ng-disabled="vm.loading" placeholder="Insert the service name" autofocus>\n      </tab>\n      <tab heading="RPC" active="vm.tabs.rpc">\n        <label for="rpc_service_name" class="control-label">Service name</label>\n        <input type="text" id="rpc_service_name" class="form-control" ng-model="vm.rpcname" ng-disabled="vm.loading" placeholder="Insert the service name">\n        <br />\n        <label for="route_match" class="control-label">Route to match</label>\n        <input type="text" id="route_match" class="form-control" ng-model="vm.route" ng-disabled="vm.loading" placeholder="Insert the route to match">\n      </tab>\n      <tab heading="DB Connected" active="vm.tabs.db">\n        <div ng-if="vm.db.db_adapter.length === 0">\n          <h3>No DB Adapters Present</h3>\n          <p>You have not yet configured any database adapters, and thus cannot create a DB-Connected service. You can create adapters on the <a ui-sref="ag.database" ng-click="vm.cancel()">Database Adapters</a> setting page.\n        </div>\n        <div ng-if="vm.db.db_adapter.length > 0">\n          <label for="db_adapter_name" class="control-label">DB adapter name</label>\n          <select class="form-control" id="db_adapter_name" ng-model="vm.adapter" ng-options="db.adapter_name for db in vm.db.db_adapter" ng-change="vm.discoverDb()">\n            <option value="" disabled>- Choose an adapter -</option>\n          </select>\n        </div>\n        <div ui-tree class="angular-ui-tree db-tables-tree" data-max-depth="2" ng-if="(vm.tables && vm.tables.length > 0) || vm.discovering">\n          <label class="control-label">Tables (and views) <span class="glyphicon glyphicon-refresh glyphicon-spin" ng-if="vm.discovering"></span></label>\n          <ol ui-tree-nodes="options" ng-model="vm.tables" class="angular-ui-tree-nodes">\n            <li class="angular-ui-tree-node" ng-repeat="table in vm.tables" ui-tree-node collapsed="true">\n              <div class="tree-node">\n                <div class="pull-left tree-handle angular-ui-tree-handle" ui-tree-handle>\n                  <span class="glyphicon glyphicon-list"></span>\n                </div>\n                <div class="tree-node-content">\n                  <a class="btn btn-default btn-xs" ng-click="vm.toggle(this)" data-nodrag="">\n                    <span ng-class="{\'glyphicon-chevron-right\': collapsed, \'glyphicon-chevron-down\': !collapsed}" class="glyphicon glyphicon-chevron-down"></span>\n                  </a>\n                  <span>{{table.table_name}}</span>\n                  <input type="checkbox" class="pull-right" checklist-model="vm.dbServices" checklist-value="table">\n                  <div class="clearfix"></div>\n                  <div ng-class="{hidden: collapsed}">\n                    <table class="table table-bordered">\n                      <caption>Fields</caption>\n                      <thead>\n                      <tr>\n                        <th class="col-sm-3">Column</th>\n                        <th class="col-sm-4">Type (Length)</th>\n                        <th class="col-sm-2">Required</th>\n                        <th class="col-sm-3">Constraints</th>\n                      </tr>\n                      </thead>\n                      <tbody>\n                      <tr ng-repeat="column in table.columns">\n                        <td>{{column.name}}</td>\n                        <td>{{column.type}}<span ng-show="column[\'length\']"> ({{column[\'length\']}})</span></td>\n                        <td><i class="glyphicon glyphicon-ok" ng-if="!!column.required"></i></td>\n                        <td>{{column.constraints.join(\', \')}}</td>\n                      </tr>\n                      </tbody>\n                    </table>\n                  </div>\n                </div>\n              </div>\n            </li>\n          </ol>\n        </div>\n        <div ng-if="vm.tables && vm.tables.length == 0 && !vm.discovering && !vm.loading">\n          <h3>No tables found</h3>\n          <p>Autodiscovery could not find any existing tables, you can insert the table name here:</p>\n          <input type="text" class="form-control" ng-model="vm.rest.table_name" ng-disabled="vm.loading" placeholder="Insert the table name">\n        </div>\n      </tab>\n      <tab heading="Doctrine Connected" ng-if="vm.hasDoctrine" active="vm.tabs.doctrine">\n        <div ng-if="vm.doctrine.doctrine_adapter.length === 0">\n          <h3>Doctrine configuration broken</h3>\n          <p>You have not yet configured any Doctrine connection, and thus cannot create a Doctrine-Connected service.<br><br>Please refer to the <a href="#">documentation page</a> and define validation configuration for your Doctrine connection.\n        </div>\n        <div class="form-group" ng-if="vm.doctrine.doctrine_adapter.length > 0">\n          <label for="doctrine_entity_manager" class="control-label">Entity Manager</label>\n          <select class="form-control" id="doctrine_entity_manager" ng-model="vm.doctrineAdapter" ng-options="doctrine.adapter_name for doctrine in vm.doctrine.doctrine_adapter" ng-change="vm.discoverDoctrine()" ng-disabled="vm.discovering">\n            <option value="" disabled>- Choose an adapter -</option>\n          </select>\n        </div>\n        <div ng-if="vm.doctrine.doctrine_adapter.length > 0">\n          <div ui-tree class="angular-ui-tree" id="db-entities-tree" data-max-depth="2" ng-if="(vm.entities && vm.entities.length > 0 ) || vm.discovering">\n            <label class="control-label">Entities<span class="glyphicon glyphicon-refresh glyphicon-spin" ng-if="vm.discovering"></span></label>\n            <ol ui-tree-nodes="options" ng-model="vm.entities" class="angular-ui-tree-nodes">\n              <li class="angular-ui-tree-node" ng-repeat="entity in vm.entities" ui-tree-node>\n                <div class="tree-node">\n                  <div class="pull-left tree-handle angular-ui-tree-handle" ui-tree-handle>\n                    <span class="glyphicon glyphicon-list"></span>\n                  </div>\n                  <div class="tree-node-content">\n                    <span>{{entity.entity_class}}</span>\n                    <input type="checkbox" class="pull-right" checklist-model="vm.doctrineEntities" checklist-value="entity">\n                  </div>\n                </div>\n              </li>\n            </ol>\n          </div>\n          <div ng-if="vm.entities && vm.entities.length == 0 && !vm.discovering">\n            <h3>No entities found</h3>\n            <p>Autodiscovery could not find any existing entities, or those entities have already been exposed through Doctrine-connected services.</p>\n          </div>\n        </div>\n      </tab>\n    </tabset>\n  </div>\n</div>\n<div class="modal-footer">\n  <button type="button" class="btn btn-default" ng-click="vm.cancel()" ng-disabled="vm.loading">Close</button>\n  <button type="button" class="btn btn-primary btn-sm" ng-click="vm.ok()" ladda="vm.loading">Create service</span></button>\n</div>\n');
    }]), angular.module("apigility-ui/modal/new-version.html", []).run(["$templateCache", function(a) {
        a.put("apigility-ui/modal/new-version.html", '<div class="modal-header">\n  <h4 class="modal-title" id="myModalVersion">New API version</h4>\n</div>\n<div class="modal-body">\n  <div class="alert alert-danger" role="alert" ng-hide="!vm.alert">\n    <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> {{vm.alert}}\n  </div>\n  <p class="modal_msg">Do you want to create <strong>version {{vm.newVersion}}</strong> for <strong>{{vm.apiName}}</strong> API?</p>\n</div>\n<div class="modal-footer">\n  <button type="button" class="btn btn-default" ng-click="vm.cancel()">No</button>\n  <button type="button" class="btn btn-primary btn-sm"  ng-click="vm.ok()" ladda="vm.loading">Yes</button>\n</div>\n')
    }]), angular.module("apigility-ui/modal/new-viewmodel.html", []).run(["$templateCache", function(a) {
        a.put("apigility-ui/modal/new-viewmodel.html", '<div class="modal-header">\n  <h4 class="modal-title">New View Model</h4>\n</div>\n<div class="modal-body">\n  <div class="alert alert-danger" role="alert" ng-hide="!vm.alert">\n    <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> {{vm.alert}}\n  </div>\n  <label class="control-label">Name</label>\n  <input type="text" class="form-control" ng-model="vm.classname" placeholder="Insert the View Model class" autofocus><br />\n  <label class="control-label">Mediatypes</label>\n  <tags-input\n    ng-model="vm.mediatypes"\n    ng-readonly=""\n    placeholder="Add a media type"\n    add-on-space="true"\n    add-on-enter="true"\n    add-on-blur="true"\n    allowed-tags-pattern="^[a-zA-Z-]+/[a-zA-Z0-9*_+.-]+$"></tags-input>\n</div>\n<div class="modal-footer">\n  <button type="button" class="btn btn-default" ng-click="vm.cancel()">Close</button>\n  <button type="button" class="btn btn-success btn-sm" ng-click="vm.ok()" ladda="vm.loading">Save</span></button>\n</div>\n')
    }]), angular.module("apigility-ui/modal/view-doctrineparams.html", []).run(["$templateCache", function(a) {
        a.put("apigility-ui/modal/view-doctrineparams.html", '<div class="modal-header">\n  <h4 class="modal-title">View Doctrine Adapter Parameters</h4>\n</div>\n<div class="modal-body">\n  <form class="form-horizontal doctrine-params">\n    <div class="form-group">\n      <label class="col-sm-3 control-label">Driver Class:</label>\n      <div class="col-sm-9">\n        <p class="form-control-static">{{vm.adapter.driverClass}}</p>\n      </div>\n    </div>\n    <div class="form-group">\n      <label class="col-sm-3 control-label">Host:</label>\n      <div class="col-sm-9">\n        <p class="form-control-static">{{vm.adapter.params.host}}</p>\n      </div>\n    </div>\n    <div class="form-group">\n      <label class="col-sm-3 control-label">Port:</label>\n      <div class="col-sm-9">\n        <p class="form-control-static">{{vm.adapter.params.port}}</p>\n      </div>\n    </div>\n    <div class="form-group">\n      <label class="col-sm-3 control-label">Charset:</label>\n      <div class="col-sm-9">\n        <p class="form-control-static">{{vm.adapter.params.charset}}</p>\n      </div>\n    </div>\n    <div class="form-group">\n      <label class="col-sm-3 control-label">User:</label>\n      <div class="col-sm-9">\n        <p class="form-control-static">{{vm.adapter.params.user}}</p>\n      </div>\n    </div>\n    <div class="form-group">\n      <label class="col-sm-3 control-label">Database:</label>\n      <div class="col-sm-9">\n        <p class="form-control-static">{{vm.adapter.params.dbname}}</p>\n      </div>\n    </div>\n  </form>\n</div>\n<div class="modal-footer">\n  <button type="button" class="btn btn-default btn-sm" ng-click="vm.ok()">Close</button>\n</div>\n')
    }]), angular.module("apigility-ui/package/package.html", []).run(["$templateCache", function(a) {
        a.put("apigility-ui/package/package.html", '<div class="panel panel-default">\n  <div class="panel-heading">\n    <h3 class="panel-title">Package</h3>\n  </div>\n  <div class="panel-body">\n    <div class="alert alert-danger" role="alert" ng-hide="!vm.alert">\n      <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> {{vm.alert}}\n    </div>\n    <form class="form-horizontal" role="form" unsaved-warning-form ng-hide="vm.apis.length == 0">\n      <p>Package your API for deployment! This tool will build a deployment file in the format you specify (ZIP, TAR, TGZ or ZPK). For more information about deploying Apigility projects <a href="https://apigility.org/documentation/deployment/intro" target="_blank">read the documentation</a>.</p>\n      <br />\n      <div class="form-group">\n        <label class="col-sm-3 control-label">Package format</label>\n        <div class="col-sm-2">\n          <select class="form-control" ng-model="vm.package.format" ng-options="format for format in vm.formats" ng-disabled="vm.loading"></select>\n        </div>\n        <div class="col-sm-6">\n          <span class="help-block"><span class="glyphicon glyphicon-info-sign" aria-hidden="true"></span> ZPK packages are for deployment on <a href="http://www.zend.com/en/products/server" target="_blank">Zend Server</a></span>\n        </div>\n      </div>\n      <div class="form-group">\n        <label class="col-sm-3 control-label">APIs to include in the package</label>\n        <div class="col-sm-8">\n          <span ng-repeat="api in vm.apis">\n            <input type="checkbox" checklist-model="vm.package.modules" checklist-value="api.name" ng-change="vm.change()" ng-disabled="vm.loading"> {{api.name}}\n          </span>\n        </div>\n      </div>\n      <div class="form-group">\n        <label class="col-sm-3 control-label">Execute composer?</label>\n        <div class="col-sm-2">\n          <input type="checkbox" ng-model="vm.package.composer" ng-disabled="vm.loading"><br />\n        </div>\n      </div>\n      <div class="form-group">\n        <label class="col-sm-3 control-label">Application config to include</label>\n        <div class="col-sm-8">\n          <input type="text" class="form-control" ng-model="vm.package.config" placeholder="Insert the path of the config files to include" ng-disabled="vm.loading"><br />\n        </div>\n      </div>\n      <div class="panel panel-default" ng-if="vm.package.format === \'ZPK\'">\n        <div class="panel-heading">Zend Server ZPK options</div>\n        <div class="panel-body">\n          <div class="form-group">\n            <label class="col-sm-3 control-label">Path to a custom deployment.xml</label>\n            <div class="col-sm-8">\n              <input type="text" class="form-control" ng-model="vm.package.zpk.xml" placeholder="Insert the path of deployment.xml (optional)" ng-disabled="vm.loading"><br />\n            </div>\n          </div>\n          <div class="form-group">\n            <label class="col-sm-3 control-label">Directory containing ZPK package assets (deployment.xml, scripts)</label>\n            <div class="col-sm-8">\n              <input type="text" class="form-control" ng-model="vm.package.zpk.assets" placeholder="Insert the path of directory containing ZPK package assets (optional)" ng-disabled="vm.loading"><br />\n            </div>\n          </div>\n          <div class="form-group">\n            <label class="col-sm-3 control-label">Application version</label>\n            <div class="col-sm-8">\n              <input type="text" class="form-control" ng-model="vm.package.zpk.version" placeholder="Insert the application version to be used in ZPK package (optional)" ng-disabled="vm.loading"><br />\n            </div>\n          </div>\n        </div>\n      </div>\n      <div class="form-group" style="margin-top:30px">\n        <div class="col-sm-offset-3">\n          <button type="submit" class="btn btn-success" ladda="vm.loading" ng-click="vm.buildPackage()">Generate package</button> <span ng-show="vm.loading && vm.package.composer" style="color:gray">Please wait, the building process can take some time <span ng-show="vm.package.time">(last build took {{vm.package.time}} sec)</span></span>\n        </div>\n      </div>\n    </form>\n  </div>\n</div>\n')
    }]), angular.module("apigility-ui/rest/rest.html", []).run(["$templateCache", function(a) {
        a.put("apigility-ui/rest/rest.html", '<div class="panel panel-default service" name="{{vm.restName}}" data-api="{{vm.apiName}}" data-api-version="{{vm.version}}" data-service-type="REST">\n  <div class="panel-heading">\n    <h3 class="panel-title">\n      <span class="service-button pull-right"><button class="btn btn-danger" ng-click="vm.deleteRestModal()" ng-hide="vm.disabled"><span class="glyphicon glyphicon-trash"></span> Delete service</button></span>\n      <span class="glyphicon glyphicon-leaf"></span> REST service: {{vm.serviceName}} (v{{vm.version}})\n    </h3>\n  </div>\n  <div class="panel-body">\n      <tabset>\n        <tab heading="General Settings" active="vm.tabs.general_settings">\n          <form class="form-horizontal" role="form" unsaved-warning-form>\n            <div class="form-group">\n              <label for="rest_name" class="col-sm-2 control-label">Name</label>\n              <div class="col-sm-4">\n                <input type="text" class="form-control" id="rest_name" ng-model="vm.rest.service_name" readonly>\n              </div>\n              <label for="rest_page_size" class="col-sm-2 control-label">Page size</label>\n              <div class="col-sm-4">\n                <input type="text" class="form-control" id="rest_page_size" ng-model="vm.rest.page_size" ng-disabled="vm.disabled">\n              </div>\n            </div>\n            <div class="form-group">\n              <label class="col-sm-2 control-label">Route matches</label>\n              <div class="col-sm-4">\n                <input type="text" class="form-control" ng-model="vm.rest.route_match" ng-disabled="vm.disabled">\n              </div>\n              <label class="col-sm-2 control-label">HTTP Entity Methods</label>\n              <div class="col-sm-4">\n              <span ng-repeat="http in vm.httpMethods">\n                <label class="http-method">\n                  <input type="checkbox"\n                    checklist-model="vm.rest.entity_http_methods"\n                    checklist-value="http" ng-disabled="vm.disabled">\n                  {{http}}\n                </label>\n              </span>\n              </div>\n            </div>\n            <div class="form-group">\n              <label class="col-sm-2 control-label">Route identifier name</label>\n              <div class="col-sm-4">\n                <input type="text" class="form-control" ng-model="vm.rest.route_identifier_name" ng-disabled="vm.disabled">\n              </div>\n              <label class="col-sm-2 control-label">HTTP Collection Methods</label>\n              <div class="col-sm-4">\n              <span ng-repeat="http in vm.httpMethods">\n                <label class="http-method">\n                  <input type="checkbox"\n                    checklist-model="vm.rest.collection_http_methods"\n                    checklist-value="http"\n                    ng-disabled="vm.disabled">\n                  {{http}}\n                </label>\n              </span>\n              </div>\n            </div>\n            <div class="form-group">\n              <label for="rest_entity_id" class="col-sm-2 control-label">Entity identifier name</label>\n              <div class="col-sm-4">\n                <input type="text" class="form-control" id="rest_entity_id" ng-model="vm.rest.entity_identifier_name" ng-disabled="vm.disabled">\n              </div>\n              <label for="rest_page_size_parameter" class="col-sm-2 control-label">Page Size Parameter</label>\n              <div class="col-sm-4">\n                <input type="text" class="form-control" id="rest_page_size_parameter" ng-model="vm.rest.page_size_param" ng-disabled="vm.disabled">\n              </div>\n            </div>\n            <div class="form-group" ng-if="!vm.isDoctrine">\n              <label for="rest_hydrator" class="col-sm-2 control-label">Hydrator Service Name</label>\n              <div class="col-sm-4">\n                <ui-select\n                  ng-model="vm.rest.hydrator_name"\n                  ng-disabled="vm.disabled">\n                  <ui-select-match placeholder="Select Hydrator...">{{$select.selected}}</ui-select-match>\n                  <ui-select-choices\n                    repeat="hydrator in vm.hydrators | filter: $select.search">\n                    <div ng-bind-html="hydrator | highlight: $select.search"></div>\n                  </ui-select-choices>\n                </ui-select>\n              </div>\n            </div>\n            <div class="form-group">\n              <label for="rest_query_white_list" class="col-sm-2 control-label">Collection Query String Whitelist</label>\n              <div class="col-sm-4">\n                <tags-input\n                    ng-model="vm.tags.collection_query_whitelist"\n                    ng-hide="vm.disabled"\n                    placeholder="Insert query whitelist"\n                    add-on-space="true"\n                    add-on-enter="true"\n                    add-on-blur="true"\n                    allowed-tags-pattern="^[a-zA-Z0-9_+.-]+$"></tags-input>\n                <span ng-repeat="collection in vm.tabs.collection_query_whitelist" ng-show="vm.disabled">{{collection.text}}, </span>\n              </div>\n              <label for="rest_collection_name" class="col-sm-2 control-label">Collection Name</label>\n              <div class="col-sm-4">\n                <input type="text" class="form-control" ng-model="vm.rest.collection_name" ng-disabled="vm.disabled">\n              </div>\n            </div>\n            <div class="form-group">\n              <label for="rest_entity_class" class="col-sm-2 control-label">Entity Class</label>\n              <div class="col-sm-4">\n                <input type="text" class="form-control" ng-model="vm.rest.entity_class" ng-disabled="vm.disabled">\n              </div>\n              <label for="rest_collection_class" class="col-sm-2 control-label">Collection Class</label>\n              <div class="col-sm-4">\n                <input type="text" class="form-control" ng-model="vm.rest.collection_class" ng-disabled="vm.disabled">\n              </div>\n            </div>\n            <div class="form-group" style="margin-top:30px">\n              <div class="col-sm-offset-2 col-sm-4">\n                <button type="button" class="btn btn-default" ng-click="vm.resetGeneral()" unsaved-warning-clear ng-hide="vm.disabled">Reset</button>\n                <button type="submit" class="btn btn-success" ng-click="vm.saveGeneral()" ladda="vm.loading" ng-hide="vm.disabled">Save</button>\n              </div>\n            </div>\n          </form>\n        </tab>\n        <tab heading="Database Settings" active="vm.tabs.db" ng-if="vm.rest.table_name">\n          <form class="form-horizontal" role="form" unsaved-warning-form>\n            <div class="form-group">\n              <label for="db_adapter_name" class="col-sm-2 control-label">Adapter name</label>\n              <div class="col-sm-8">\n                <ui-select\n                  ng-model="vm.rest.adapter_name"\n                  ng-disabled="vm.disabled">\n                  <ui-select-match placeholder="Select db adapter name...">{{$select.selected}}</ui-select-match>\n                  <ui-select-choices\n                    repeat="adapter in vm.adapterNames | filter: $select.search">\n                    <div ng-bind-html="adapter | highlight: $select.search"></div>\n                  </ui-select-choices>\n                </ui-select>\n              </div>\n            </div>\n            <div class="form-group">\n              <label for="table_name" class="col-sm-2 control-label">Table name</label>\n              <div class="col-sm-8">\n                <input type="text" id="table_name" class="form-control" ng-model="vm.rest.table_name" ng-disabled="vm.disabled">\n              </div>\n            </div>\n            <div class="form-group">\n              <label for="tg_service" class="col-sm-2 control-label">TableGateway Service Name</label>\n              <div class="col-sm-8">\n                <input type="text" id="tg_service" class="form-control" ng-model="vm.rest.table_service" readonly>\n              </div>\n            </div>\n            <div class="form-group" style="margin-top:30px">\n              <div class="col-sm-offset-2 col-sm-4">\n                <button type="button" class="btn btn-default" ng-click="vm.resetGeneral()" unsaved-warning-clear ng-hide="vm.disabled">Reset</button>\n                <button type="submit" class="btn btn-success" ng-click="vm.saveGeneral()" ladda="vm.loading" ng-hide="vm.disabled">Save</button>\n              </div>\n            </div>\n          </form>\n        </tab>\n        <tab heading="Doctrine Settings" active="vm.tabs.doctrine" ng-if="vm.isDoctrine">\n          <form class="form-horizontal" role="form" unsaved-warning-form>\n            <div class="form-group">\n              <label for="doctrine_object_manager" class="col-sm-2 control-label">Object Manager</label>\n              <div class="col-sm-8">\n                <select class="form-control" id="doctrine_object_manager" ng-model="vm.rest.object_manager" ng-options="om.adapter_name as om.adapter_name for om in vm.doctrine track by vm.rest.object_manager"></select>\n              </div>\n            </div>\n            <div class="form-group">\n              <label for="doctrine_hydrator_service" class="col-sm-2 control-label">Hydrator Service</label>\n              <div class="col-sm-8">\n                <input type="text" id="doctrine_hydrator_service" class="form-control" ng-model="vm.rest.hydrator_name" readonly>\n              </div>\n            </div>\n            <div class="form-group">\n              <div class="col-sm-offset-2 col-sm-6">\n                <div class="checkbox">\n                  <label>\n                    <input type="checkbox" ng-model="vm.rest.by_value">Hydrate by value\n                  </label>\n                </div>\n              </div>\n            </div>\n            <div class="form-group">\n              <label class="col-sm-2 control-label">Hydrator strategies<br><button type="button" class="btn btn-xs btn-primary" ng-click="vm.newDoctrineStrategyModal()"><span class="glyphicon glyphicon-plus"></span></button></label>\n              <div class="col-sm-8">\n                <table class="table table-bordered">\n                  <thead>\n                    <tr>\n                      <th class="col-md-3">Field</th>\n                      <th class="col-md-8">Strategy</th>\n                      <th class="col-md-1">&nbsp;</th>\n                    </tr>\n                  </thead>\n                  <tbody>\n                    <tr ng-hide="vm.hasProperties(vm.rest.strategies)">\n                      <td colspan="3">No hydrator strategy configured<span ng-hide="vm.disabled">, <a ng-click="vm.newDoctrineStrategyModal()">create the first one</a></span></td>\n                    </tr>\n                    <tr ng-repeat="(k,v) in vm.rest.strategies">\n                      <td>{{k}}</td>\n                      <td>{{v}}</td>\n                      <td><button type="button" class="btn btn-xs btn-danger" ng-click="vm.removeStrategy(k)"><span class="glyphicon glyphicon-minus"></span></button></td>\n                    </tr>\n                  </tbody>\n                </table>\n              </div>\n            </div>\n            <div class="form-group" style="margin-top:30px">\n              <div class="col-sm-offset-3 col-sm-4">\n                <button type="button" class="btn btn-default" ng-click="vm.resetGeneral()" unsaved-warning-clear>Reset</button>\n                <button type="submit" class="btn btn-success" ng-click="vm.saveGeneral()" ladda="vm.loading">Save</button>\n              </div>\n            </div>\n          </form>\n        </tab>\n        <tab heading="Content Negotiation" active="vm.tabs.content_negotiation">\n          <form class="form-horizontal" role="form" unsaved-warning-form>\n            <div class="form-group">\n              <label for="rest_content_negotiation" class="col-sm-2 control-label">Content Negotiation Selector</label>\n              <div class="col-sm-8">\n                <ui-select\n                  ng-model="vm.rest.selector"\n                  ng-disabled="vm.disabled">\n                  <ui-select-match placeholder="Select content negotiation type...">{{$select.selected}}</ui-select-match>\n                  <ui-select-choices\n                    repeat="selector in vm.selectorNames | filter: $select.search">\n                    <div ng-bind-html="selector | highlight: $select.search"></div>\n                  </ui-select-choices>\n                </ui-select>\n              </div>\n            </div>\n            <div class="form-group">\n              <label class="col-sm-2 control-label">Accept whitelist</label>\n              <div class="col-sm-8">\n                <tags-input\n                    ng-hide="vm.disabled"\n                    ng-model="vm.tags.accept_whitelist"\n                    placeholder="Add a mediatype"\n                    add-on-space="true"\n                    add-on-enter="true"\n                    add-on-blur="true"\n                    allowed-tags-pattern="^[a-zA-Z-]+/[a-zA-Z0-9*_+.-]+$"></tags-input>\n                <span ng-repeat="accept in vm.tags.accept_whitelist" ng-show="vm.disabled">{{accept.text}}, </span>\n              </div>\n            </div>\n            <div class="form-group">\n              <label class="col-sm-2 control-label">Content-Type whitelist</label>\n              <div class="col-sm-8">\n                <tags-input\n                    ng-hide="vm.disabled"\n                    ng-model="vm.tags.content_type_whitelist"\n                    placeholder="Add a content type"\n                    add-on-space="true"\n                    add-on-enter="true"\n                    add-on-blur="true"\n                    allowed-tags-pattern="^[a-zA-Z-]+/[a-zA-Z0-9*_+.-]+$"></tags-input>\n                <span ng-repeat="content in vm.tags.content_type_whitelist" ng-show="vm.disabled">{{content.text}}, </span>\n              </div>\n            </div>\n            <div class="form-group" style="margin-top:30px">\n              <div class="col-sm-offset-2 col-sm-4">\n                <button type="button" class="btn btn-default" ng-click="vm.resetContentNegotiation()" unsaved-warning-clear ng-hide="vm.disabled">Reset</button>\n                <button type="submit" class="btn btn-success" ng-click="vm.saveContentNegotiation()" ladda="vm.loading" ng-hide="vm.disabled">Save</button>\n              </div>\n            </div>\n          </form>\n        </tab>\n        <tab heading="Fields" active="vm.tabs.fields">\n          <h3>Fields <button type="button" class="btn btn-primary btn-sm" ng-click="vm.newFieldModal()" ng-hide="vm.disabled">New field</button></h3>\n          <div class="form-group">\n            <table class="table table-bordered">\n              <thead>\n              <tr>\n                <th class="col-md-2">Name</th>\n                <th class="col-md-1">Required</th>\n                <th class="col-md-3">Validator</th>\n                <th class="col-md-3">Filter</th>\n                <th class="col-md-3">Action</th>\n              </tr>\n              </thead>\n              <tr ng-repeat="field in vm.rest.fields">\n                <td>{{field.name}}</td>\n                <td><span ng-if="field.required" class="glyphicon glyphicon-ok"></span></td>\n                <td>\n                  <button type="button" class="btn btn-primary btn-xs" ng-click="vm.addValidatorModal(field)" ng-hide="vm.disabled"><span class="glyphicon glyphicon-plus"></span></button>\n                  <span ng-repeat="validator in field.validators"><a ng-click="vm.editValidatorModal(field, validator)">{{validator.name}}</a>, </span>\n                  <span ng-if="field.validators.length == 0">No validators</span>\n                </td>\n                <td>\n                  <button type="button" class="btn btn-primary btn-xs" ng-click="vm.addFilterModal(field)" ng-hide="vm.disabled"><span class="glyphicon glyphicon-plus"></span></button>\n                  <span ng-repeat="filter in field.filters"><a ng-click="vm.editFilterModal(field, filter)">{{filter.name}}</a>, </span>\n                  <span ng-if="field.filters.length == 0">No filters</span>\n                </td>\n                <td>\n                  <button type="button" ng-click="vm.editFieldModal(field)" class="btn btn-success btn-xs" ng-hide="vm.disabled"><i class="glyphicon glyphicon-pencil"></i> edit</button> <button type="button" ng-click="vm.deleteFieldModal(field)" class="btn btn-danger btn-xs" ng-hide="vm.disabled"><i class="glyphicon glyphicon-trash"></i> delete</button>\n                </td>\n              </tr>\n              <tr ng-if="vm.rest.fields.length == 0">\n                <td colspan="5">\n                  No fields have been configured<span ng-hide="vm.disabled">, <a ng-click="vm.newFieldModal()">create the first one</a></span>\n                </td>\n              </tr>\n            </table>\n          </div>\n        </tab>\n        <tab heading="Authorization" active="vm.tabs.authorization">\n          <form class="form-horizontal" role="form" unsaved-warning-form>\n            <h3>HTTP methods authorization</h3>\n            <p ng-hide="vm.disabled">In this page you can specify which HTTP methods to put under authentication, for your entity and collection service.\n              You can choose only the HTTP methods available for the service, if you want to change it choose the <i>General Settings</i> option in the tab above.\n              The authentication type is defined per API in <a ui-sref="ag.apimodule({api: vm.apiName, ver: vm.version})">this page</a>.</p>\n            <br />\n            <div class="form-group">\n              <label class="col-sm-2 control-label">Entity authorization</label>\n              <div class="col-sm-8">\n              <span ng-repeat="http in vm.httpMethods">\n                <label class="http-method">\n                  <input type="checkbox"\n                    checklist-model="vm.auth.entity"\n                    checklist-value="http"\n                    ng-disabled="vm.rest.entity_http_methods.indexOf(http) < 0 || vm.disabled">\n                  {{http}}\n                </label>\n              </span>\n              </div>\n            </div>\n            <div class="form-group">\n              <label class="col-sm-2 control-label">Collection authorization</label>\n              <div class="col-sm-8">\n              <span ng-repeat="http in vm.httpMethods">\n                <label class="http-method">\n                  <input type="checkbox"\n                    checklist-model="vm.auth.collection"\n                    checklist-value="http"\n                    ng-disabled="vm.rest.collection_http_methods.indexOf(http) < 0 || vm.disabled">\n                  {{http}}\n                </label>\n              </span>\n              </div>\n            </div>\n            <div class="form-group" style="margin-top:30px">\n              <div class="col-sm-offset-2 col-sm-4">\n                <button type="button" class="btn btn-default" ng-click="vm.resetAuthorization()" unsaved-warning-clear ng-hide="vm.disabled">Reset</button>\n                <button type="submit" class="btn btn-success" ng-click="vm.saveAuthorization()" ladda="vm.loading" ng-hide="vm.disabled">Save</button>\n              </div>\n            </div>\n          </form>\n        </tab>\n        <tab heading="Documentation" active="vm.tabs.documentation">\n          <form class="form-horizontal" role="form" unsaved-warning-form>\n            <div class="form-group">\n              <label class="col-sm-2 control-label">REST service description</label>\n              <div class="col-sm-10">\n                <textarea class="form-control" ng-model="vm.rest.documentation.description" placeholder="Insert the description here" ng-disabled="vm.disabled"></textarea>\n              </div>\n            </div>\n            <div class="form-group">\n              <tabset justified="true" class="col-sm-12">\n                <tab heading="Collection" active="vm.tabs.doc.collection">\n                  <div class="form-group">\n                    <label class="col-sm-2 control-label">Description</label>\n                    <div class="col-sm-10">\n                      <textarea class="form-control" ng-model="vm.rest.documentation.collection.description" placeholder="Insert the Collection description here" ng-disabled="vm.disabled"></textarea>\n                    </div>\n                  </div>\n                  <div class="form-group">\n                    <tabset justified="true" class="col-sm-12">\n                      <tab ng-repeat="http in vm.rest.collection_http_methods" heading="{{http}}">\n                        <div class="form-group">\n                          <label class="col-sm-2 control-label">Description</label>\n                          <div class="col-sm-10">\n                            <textarea class="form-control" ng-model="vm.rest.documentation.collection[http].description" placeholder="Insert the description here" ng-disabled="vm.disabled"></textarea>\n                          </div>\n                        </div>\n                        <div class="form-group" ng-if="http !== \'GET\'">\n                          <label class="col-sm-2 control-label">Request Body</label>\n                          <div class="col-sm-10">\n                            <textarea class="form-control" ng-model="vm.rest.documentation.collection[http].request" placeholder="Insert the request specification" ng-disabled="vm.disabled"></textarea>\n                            <button class="btn btn-default btn-xs pull-right" ng-click="vm.rest.documentation.collection[http].request = vm.generateFromConfiguration(http, \'request\', \'collection\')" type="button">\n                              <i class="glyphicon glyphicon-refresh"></i> generate from configuration\n                            </button>\n                          </div>\n                        </div>\n                        <div class="form-group">\n                          <label class="col-sm-2 control-label">Response Body</label>\n                          <div class="col-sm-10">\n                            <textarea class="form-control" ng-model="vm.rest.documentation.collection[http].response" placeholder="Insert the response specification" ng-disabled="vm.disabled"></textarea>\n                            <button class="btn btn-default btn-xs pull-right" ng-click="vm.rest.documentation.collection[http].response = vm.generateFromConfiguration(http, \'response\', \'collection\')" type="button">\n                              <i class="glyphicon glyphicon-refresh"></i> generate from configuration\n                            </button>\n                          </div>\n                        </div>\n                      </tab>\n                    </tabset>\n                  </div>\n                </tab>\n                <tab heading="Entity" active="vm.tabs.doc.entity">\n                  <div class="form-group">\n                    <label class="col-sm-2 control-label">Description</label>\n                    <div class="col-sm-10">\n                      <textarea class="form-control" ng-model="vm.rest.documentation.entity.description" placeholder="Insert the Entity description here" ng-disabled="vm.disabled"></textarea>\n                    </div>\n                  </div>\n                  <div class="form-group">\n                    <tabset justified="true" class="col-sm-12">\n                      <tab ng-repeat="http in vm.rest.entity_http_methods" heading="{{http}}">\n                        <div class="form-group">\n                          <label class="col-sm-2 control-label">Description</label>\n                          <div class="col-sm-10">\n                            <textarea class="form-control" ng-model="vm.rest.documentation.entity[http].description" placeholder="Insert the description here" ng-disabled="vm.disabled"></textarea>\n                          </div>\n                        </div>\n                        <div class="form-group" ng-if="http !== \'GET\'">\n                          <label class="col-sm-2 control-label">Request Body</label>\n                          <div class="col-sm-10">\n                            <textarea class="form-control" ng-model="vm.rest.documentation.entity[http].request" placeholder="Insert the request specification" ng-disabled="vm.disabled"></textarea>\n                            <button class="btn btn-default btn-xs pull-right" ng-click="vm.rest.documentation.entity[http].request = vm.generateFromConfiguration(http, \'request\', \'entity\')" type="button">\n                              <i class="glyphicon glyphicon-refresh"></i> generate from configuration\n                            </button>\n                          </div>\n                        </div>\n                        <div class="form-group">\n                          <label class="col-sm-2 control-label">Response Body</label>\n                          <div class="col-sm-10">\n                            <textarea class="form-control" ng-model="vm.rest.documentation.entity[http].response" placeholder="Insert the response specification" ng-disabled="vm.disabled"></textarea>\n                            <button class="btn btn-default btn-xs pull-right" ng-click="vm.rest.documentation.entity[http].response = vm.generateFromConfiguration(http, \'response\', \'entity\')" type="button">\n                              <i class="glyphicon glyphicon-refresh"></i> generate from configuration\n                            </button>\n                          </div>\n                        </div>\n                      </tab>\n                    </tabset>\n                  </div>\n                </tab>\n              </tabset>\n            </div>\n            <div class="form-group" style="margin-top:30px">\n              <div class="col-sm-offset-2 col-sm-4">\n                <button type="button" class="btn btn-default" ng-click="vm.resetDocumentation()" unsaved-warning-clear ng-hide="vm.disabled">Reset</button>\n                <button type="submit" class="btn btn-success" ng-click="vm.saveDocumentation()" ladda="vm.loading" ng-hide="vm.disabled">Save</button>\n              </div>\n            </div>\n          </form>\n        </tab>\n        <tab heading="Source code" active="vm.tabs.sourcecode">\n          <form class="form-inline">\n            <div class="form-group">\n              <label class="control-label">Select the file to open</label>\n              <select ng-model="vm.source" class="form-control" ng-change="vm.getSourceCode(vm.source.classname)" ng-options="source.name for source in vm.rest.source_code"></select>\n            </div>\n          </form>\n          <br clear="left">\n          <div class="panel panel-default">\n            <div class="panel-heading code-button"><span class="glyphicon glyphicon-file" aria-hidden="true"></span> {{vm.file}}</div>\n            <div class="panel-body" ng-bind-html="vm.sourcecode"></div>\n          </div>\n        </tab>\n      </tabset>\n    </div>\n  </form>\n</div>\n');
    }]), angular.module("apigility-ui/rpc/rpc.html", []).run(["$templateCache", function(a) {
        a.put("apigility-ui/rpc/rpc.html", '<div class="panel panel-default service" name="{{vm.rpcName}}" data-api="{{vm.apiName}}" data-api-version="{{vm.version}}" data-service-type="RPC">\n  <div class="panel-heading">\n    <h3 class="panel-title">\n      <span class="service-button pull-right"><button class="btn btn-danger" ng-click="vm.deleteRpcModal()" ng-hide="vm.disabled"><span class="glyphicon glyphicon-trash"></span> Delete service</button></span>\n      <span class="glyphicon glyphicon-fire"></span> RPC service: {{vm.serviceName}} (v{{vm.version}})\n    </h3>\n  </div>\n  <div class="panel-body">\n    <tabset justified="true">\n      <tab heading="General Settings" active="vm.tabs.general_settings">\n        <form class="form-horizontal" role="form" unsaved-warning-form>\n          <div class="form-group">\n            <label class="col-sm-2 control-label">Name</label>\n            <div class="col-sm-10">\n              <input type="text" class="form-control" ng-model="vm.rpc.service_name" readonly>\n            </div>\n          </div>\n          <div class="form-group">\n            <label class="col-sm-2 control-label">Route to match</label>\n            <div class="col-sm-10">\n              <input type="text" class="form-control" ng-model="vm.rpc.route_match" ng-disabled="vm.disabled">\n            </div>\n          </div>\n          <div class="form-group">\n            <label class="col-sm-2 control-label">Allowed HTTP Methods</label>\n            <div class="col-sm-10">\n              <span ng-repeat="http in vm.httpMethods">\n                <label class="http-method">\n                  <input type="checkbox"\n                    checklist-model="vm.rpc.http_methods"\n                    checklist-value="http"\n                    ng-disabled="vm.disabled">\n                  {{http}}\n                </label>\n              </span>\n            </div>\n          </div>\n          <div class="form-group">\n            <label for="rest_content_negotiation" class="col-sm-2 control-label">Content Negotiation Selector</label>\n            <div class="col-sm-10">\n              <ui-select\n                ng-model="vm.rpc.selector"\n                ng-disabled="vm.disabled">\n                <ui-select-match placeholder="Select content negotiation type...">{{$select.selected}}</ui-select-match>\n                <ui-select-choices\n                  repeat="selector in vm.selectorNames | filter: $select.search">\n                  <div ng-bind-html="selector | highlight: $select.search"></div>\n                </ui-select-choices>\n              </ui-select>\n            </div>\n          </div>\n          <div class="form-group">\n            <label class="col-sm-2 control-label">Accept whitelist</label>\n            <div class="col-sm-10">\n              <tags-input\n              ng-hide="vm.disabled"\n              ng-model="vm.tags.accept_whitelist"\n              placeholder="Add a mediatype"\n              add-on-space="true"\n              add-on-enter="true"\n              add-on-blur="true"\n              allowed-tags-pattern="^[a-zA-Z-]+/[a-zA-Z0-9*_+.-]+$"></tags-input>\n              <span ng-repeat="accept in vm.tags.accept_whitelist" ng-show="vm.disabled">{{accept.text}}, </span>\n            </div>\n          </div>\n          <div class="form-group">\n            <label class="col-sm-2 control-label">Content-Type whitelist</label>\n            <div class="col-sm-10">\n              <tags-input\n              ng-hide="vm.disabled"\n              ng-model="vm.tags.content_type_whitelist"\n              placeholder="Add a content type"\n              add-on-space="true"\n              add-on-enter="true"\n              add-on-blur="true"\n              allowed-tags-pattern="^[a-zA-Z-]+/[a-zA-Z0-9*_+.-]+$"></tags-input>\n              <span ng-repeat="accept in vm.tags.content_type_whitelist" ng-show="vm.disabled">{{accept.text}}, </span>\n            </div>\n          </div>\n          <div class="form-group" style="margin-top:30px">\n            <div class="col-sm-offset-2 col-sm-4">\n              <button type="button" class="btn btn-default" ng-click="vm.resetGeneral()" unsaved-warning-clear ng-hide="vm.disabled">Reset</button>\n              <button type="submit" class="btn btn-success" ng-click="vm.saveGeneral()" ladda="vm.loading" ng-hide="vm.disabled">Save</button>\n            </div>\n          </div>\n        </form>\n      </tab>\n      <tab heading="Fields" active="vm.tabs.fields">\n        <h3>Fields <button type="button" class="btn btn-primary btn-sm" ng-click="vm.newFieldModal()" ng-hide="vm.disabled">New field</button></h3>\n        <div class="form-group">\n          <table class="table table-bordered">\n            <thead>\n              <tr>\n                <th class="col-md-2">Name</th>\n                <th class="col-md-1">Required</th>\n                <th class="col-md-3">Validator</th>\n                <th class="col-md-3">Filter</th>\n                <th class="col-md-3">Action</th>\n              </tr>\n            </thead>\n            <tr ng-repeat="field in vm.rpc.fields">\n              <td>{{field.name}}</td>\n              <td><span ng-if="field.required" class="glyphicon glyphicon-ok"></span></td>\n              <td>\n                <button type="button" class="btn btn-primary btn-xs" ng-click="vm.addValidatorModal(field)" ng-hide="vm.disabled"><span class="glyphicon glyphicon-plus"></span></button>\n                <span ng-repeat="validator in field.validators"><a ng-click="vm.editValidatorModal(field, validator)">{{validator.name}}</a>, </span>\n                <span ng-if="field.validators.length == 0">No validators</span>\n                </td>\n              <td>\n                <button type="button" class="btn btn-primary btn-xs" ng-click="vm.addFilterModal(field)" ng-hide="vm.disabled"><span class="glyphicon glyphicon-plus"></span></button>\n                <span ng-repeat="filter in field.filters"><a ng-click="vm.editFilterModal(field, filter)">{{filter.name}}</a>, </span>\n                <span ng-if="field.filters.length == 0">No filters</span>\n              </td>\n              <td>\n                <button type="button" ng-click="vm.editFieldModal(field)" class="btn btn-success btn-xs" ng-hide="vm.disabled"><i class="glyphicon glyphicon-pencil"></i> edit</button> <button type="button" ng-click="vm.deleteFieldModal(field)" class="btn btn-danger btn-xs" ng-hide="vm.disabled"><i class="glyphicon glyphicon-trash"></i> delete</button>\n              </td>\n            </tr>\n            <tr ng-if="vm.rest.fields.length == 0">\n              <td colspan="5">\n                No fields have been configured<span ng-hide="vm.disabled">, <a ng-click="vm.newFieldModal()">create the first one</a></span>\n              </td>\n            </tr>\n          </table>\n        </div>\n      </tab>\n      <tab heading="Authorization" active="vm.tabs.authorization">\n        <form class="form-horizontal" role="form" unsaved-warning-form>\n          <h3>HTTP methods authorization</h3>\n          <p ng-hide="vm.disabled">In this page you can specify which HTTP methods to put under authentication. You can choose only the HTTP methods available for the service, if you want to change it choose the <i>General Settings</i> option in the tab above.\n          The authentication type is defined per API in <a ui-sref="ag.apimodule({api: vm.apiName, ver: vm.version})">this page</a>.</p>\n          <br />\n          <div class="form-group">\n            <label class="col-sm-2 control-label">Authorization</label>\n            <div class="col-sm-8">\n              <span ng-repeat="http in vm.httpMethods">\n                <label class="http-method">\n                  <input type="checkbox"\n                    checklist-model="vm.auth"\n                    checklist-value="http"\n                    ng-disabled="vm.rpc.http_methods.indexOf(http) < 0 || vm.disabled">\n                  {{http}}\n                </label>\n              </span>\n            </div>\n          </div>\n          <div class="form-group" style="margin-top:30px">\n            <div class="col-sm-offset-2 col-sm-4">\n              <button type="button" class="btn btn-default" ng-click="vm.resetAuthorization()" unsaved-warning-clear ng-hide="vm.disabled">Reset</button>\n              <button type="submit" class="btn btn-success" ng-click="vm.saveAuthorization()" ladda="vm.loading" ng-hide="vm.disabled">Save</button>\n            </div>\n          </div>\n        </form>\n      </tab>\n      <tab heading="Documentation" active="vm.tabs.documentation">\n        <form class="form-horizontal" role="form" unsaved-warning-form>\n          <div class="form-group">\n            <label class="col-sm-2 control-label">RPC service description</label>\n            <div class="col-sm-10">\n              <textarea class="form-control" ng-model="vm.rpc.documentation.description" placeholder="Insert the description here" ng-disabled="vm.disabled"></textarea>\n            </div>\n          </div>\n          <div class="form-group">\n            <tabset justified="true" class="col-sm-12">\n              <tab ng-repeat="http in vm.rpc.http_methods" heading="{{http}}">\n                <div class="form-group">\n                  <label class="col-sm-2 control-label">Description</label>\n                  <div class="col-sm-10">\n                    <textarea class="form-control" ng-model="vm.rpc.documentation[http].description" placeholder="Insert the description here" ng-disabled="vm.disabled"></textarea>\n                  </div>\n                </div>\n                <div class="form-group" ng-if="http !== \'GET\'">\n                  <label class="col-sm-2 control-label">Request Body</label>\n                  <div class="col-sm-10">\n                    <textarea class="form-control" ng-model="vm.rpc.documentation[http].request" placeholder="Insert the request specification" ng-disabled="vm.disabled"></textarea>\n                    <button class="btn btn-default btn-xs pull-right" ng-click="vm.rpc.documentation[http].request = vm.generateFromConfiguration(http, \'request\')" type="button">\n                      <i class="glyphicon glyphicon-refresh"></i> generate from configuration\n                    </button>\n                  </div>\n                </div>\n                <div class="form-group">\n                  <label class="col-sm-2 control-label">Response Body</label>\n                  <div class="col-sm-10">\n                    <textarea class="form-control" ng-model="vm.rpc.documentation[http].response" placeholder="Insert the response specification" ng-disabled="vm.disabled"></textarea>\n                    <button class="btn btn-default btn-xs pull-right" ng-click="vm.rpc.documentation[http].response = vm.generateFromConfiguration(http, \'response\')" type="button">\n                      <i class="glyphicon glyphicon-refresh"></i> generate from configuration\n                    </button>\n                  </div>\n                </div>\n              </tab>\n            </tabset>\n          </div>\n          <div class="form-group" style="margin-top:30px">\n            <div class="col-sm-offset-2 col-sm-4">\n              <button type="button" class="btn btn-default" ng-click="vm.resetDocumentation()" unsaved-warning-clear ng-hide="vm.disabled">Reset</button>\n              <button type="submit" class="btn btn-success" ng-click="vm.saveDocumentation()" ladda="vm.loading" ng-hide="vm.disabled">Save</button>\n            </div>\n          </div>\n        </form>\n      </tab>\n      <tab heading="Source code" active="vm.tabs.sourcecode">\n        <form class="form-inline">\n          <div class="form-group">\n            <label class="control-label">Select the file to open</label>\n            <select ng-model="vm.source" class="form-control" ng-change="vm.getSourceCode(vm.source.classname)" ng-options="source.name for source in vm.rpc.source_code"></select>\n          </div>\n        </form>\n        <br clear="left">\n        <div class="panel panel-default">\n          <div class="panel-heading code-button"><span class="glyphicon glyphicon-file" aria-hidden="true"></span> {{vm.file}}</div>\n          <div class="panel-body" ng-bind-html="vm.sourcecode"></div>\n        </div>\n      </tab>\n    </tabset>\n  </div>\n</div>\n')
    }]), angular.module("apigility-ui/sidebar/sidebar.html", []).run(["$templateCache", function(a) {
        a.put("apigility-ui/sidebar/sidebar.html", '<div class="row search"><div class="col-sm-12">\n  <form class="form-horizontal" ng-submit="vm.searchApi(vm.search)">\n    <div class="input-group">\n      <input\n        class="form-control"\n        type="search"\n        placeholder="Search for a service"\n        ng-model="vm.search"\n        ng-disabled="vm.loading"\n        typeahead="service for service in vm.services | filter:$viewValue | limitTo:8">\n\n      <span class="glyphicon glyphicon-remove input-group-addon"\n        ng-hide="!vm.search" ng-click="vm.searchApi(\'\')"></span>\n\n      <span class="input-group-btn">\n        <button type="submit" class="pull-right btn btn-success"><span class="glyphicon glyphicon-search"></span> Search</button>\n      </span>\n    </div>\n  </form>\n</div></div>\n\n<div class="row">\n  <div class="col-sm-12 text-right">\n    <span class="pull-left sidebar-list" ng-hide="vm.loading"><strong>API LIST</strong></span>\n    <span class="pull-left" ng-show="vm.loading"><img src="apigility-ui/img/spinning.gif"> Loading...</span>\n    <button type="button" id="new_api" class="btn btn-primary btn-sm" ng-click="vm.newApiModal()" ng-disabled="vm.loading">New API</button>\n    <button type="button" id="new_service" class="btn btn-info btn-sm" ng-click="vm.newServiceModal()" ng-disabled="vm.loading || vm.apis.length == 0">New Service</button>\n  </div>\n</div>\n\n<div class="api-tree" ui-tree class="ng-scope angular-ui-tree" data-drag-enabled="false" data-max-depth="2" ng-hide="vm.apis.length == 0">\n  <ol ui-tree-nodes="options" ng-model="vm.apis" class="ng-scope ng-pristine ng-valid angular-ui-tree-nodes">\n    <li class="ng-scope angular-ui-tree-node" ng-repeat="item in vm.apis track by $index" ui-tree-node="">\n      <div class="ng-scope ng-binding angular-ui-tree-handle" ui-tree-handle ng-class="{ \'selected\' : \'api\'+item.name === vm.getSelected() }">\n        <a class="btn btn-default btn-xs" ng-click="vm.toggle(this)" data-nodrag="">\n          <span ng-class="{\'glyphicon-chevron-right\': collapsed, \'glyphicon-chevron-down\': !collapsed}" class="glyphicon glyphicon-chevron-down"></span>\n        </a>\n        <a ng-click="vm.apiname=item.name;vm.setSelected(\'api\'+item.name)" ui-sref="ag.apimodule({api: item.name, ver: item.selected_version})">{{item.name}}</a> - version <select ng-model="item.selected_version" ng-options="ver for ver in item.versions" ng-change="vm.changeVersion(item.name, item.selected_version);vm.setSelected(\'api\'+item.name)"></select>\n        <span class="badge pull-right">{{item.rest.length + item.rpc.length}}</span>\n      </div>\n      <ol class="ng-scope ng-pristine ng-valid angular-ui-tree-nodes" ng-class="{hidden: collapsed}">\n        <li class="ng-scope angular-ui-tree-node" ng-repeat="subItem in item.rest track by $index">\n          <div class="ng-scope ng-binding angular-ui-tree-handle" ui-tree-handle ng-class="{ \'selected\' : \'api\'+item.name+\'rest\'+subItem.service_name === vm.getSelected() }">\n            <span class="glyphicon glyphicon-leaf"></span> <a ui-sref="ag.rest({api: item.name, ver: item.selected_version, rest: subItem.controller_service_name})" ng-click="vm.setSelected(\'api\'+item.name+\'rest\'+subItem.service_name)">{{subItem.service_name}}</a>\n          </div>\n        </li>\n        <li class="ng-scope angular-ui-tree-node" ng-repeat="subItem in item.rpc track by $index">\n          <div class="ng-scope ng-binding angular-ui-tree-handle" ui-tree-handle ng-class="{ \'selected\' : \'api\'+item.name+\'rpc\'+subItem.service_name === vm.getSelected() }">\n            <span class="glyphicon glyphicon-fire"></span> <a ui-sref="ag.rpc({api: item.name, ver: item.selected_version, rpc: subItem.controller_service_name})" ng-click="vm.setSelected(\'api\'+item.name+\'rpc\'+subItem.service_name)">{{subItem.service_name}}</a>\n          </div>\n        </li>\n      </ol>\n    </li>\n  </ol>\n</div>\n\n<div class="alert alert-info" role="alert" ng-show="vm.apis.length == 0 && !vm.search && !vm.loading">\n  <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> No APIs configured, <a ng-click="vm.newApiModal()">would you like to create one?</a>\n</div>\n\n<div class="alert alert-danger" role="alert" ng-show="vm.apis.length == 0 && vm.search">\n  <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> No services found, try with a new search\n</div>\n')
    }]);