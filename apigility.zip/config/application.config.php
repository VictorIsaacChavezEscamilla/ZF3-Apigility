<?php return array (
  'modules' => 
  array (
    0 => 'Zend\\Db',
    1 => 'Zend\\Filter',
    2 => 'Zend\\Hydrator',
    3 => 'Zend\\InputFilter',
    4 => 'Zend\\Paginator',
    5 => 'Zend\\Router',
    6 => 'Zend\\Validator',
    7 => 'ZF\\Apigility',
    8 => 'ZF\\Apigility\\Documentation',
    9 => 'ZF\\ApiProblem',
    10 => 'ZF\\Configuration',
    11 => 'ZF\\OAuth2',
    12 => 'ZF\\MvcAuth',
    13 => 'ZF\\Hal',
    14 => 'ZF\\ContentNegotiation',
    15 => 'ZF\\ContentValidation',
    16 => 'ZF\\Rest',
    17 => 'ZF\\Rpc',
    18 => 'ZF\\Versioning',
    19 => 'Application',
    22 => 'Agenda',
  ),
  'module_listener_options' => 
  array (
    'module_paths' => 
    array (
      0 => './module',
      1 => './vendor',
    ),
    'config_glob_paths' => 
    array (
      0 => '/tmp/ZFDeploy_58b24e9fec858/config/autoload/{,*.}{global,local}.php',
    ),
    'config_cache_key' => 'application.config.cache',
    'config_cache_enabled' => true,
    'module_map_cache_key' => 'application.module.cache',
    'module_map_cache_enabled' => true,
    'cache_dir' => 'data/cache/',
  ),
);